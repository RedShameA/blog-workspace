package com.zhy.framework.security.oauth;

import com.alibaba.fastjson2.JSONObject;
import com.xkcoding.http.support.HttpHeader;
import me.zhyd.oauth.cache.AuthStateCache;
import me.zhyd.oauth.config.AuthConfig;
import me.zhyd.oauth.enums.scope.AuthGoogleScope;
import me.zhyd.oauth.exception.AuthException;
import me.zhyd.oauth.model.AuthCallback;
import me.zhyd.oauth.model.AuthToken;
import me.zhyd.oauth.model.AuthUser;
import me.zhyd.oauth.request.AuthDefaultRequest;
import me.zhyd.oauth.utils.AuthScopeUtils;
import me.zhyd.oauth.utils.Base64Utils;
import me.zhyd.oauth.utils.HttpUtils;
import me.zhyd.oauth.utils.UrlBuilder;

import java.util.HashMap;

/**
 * @author wangfeng
 * @since 2023-10-25 10:43
 */
public class CustomAuthRequest extends AuthDefaultRequest {


    public CustomAuthRequest(AuthConfig config) {
        super(config, CustomAuthSourceBean.CustomAuthSource.CUSTOM_AUTH);
    }

    public CustomAuthRequest(AuthConfig config, AuthStateCache authStateCache) {
        super(config, CustomAuthSourceBean.CustomAuthSource.CUSTOM_AUTH, authStateCache);
    }

    @Override
    protected String accessTokenUrl(String code) {
        return UrlBuilder.fromBaseUrl(this.source.accessToken()).queryParam("code", code).queryParam("grant_type", "authorization_code").queryParam("redirect_uri", this.config.getRedirectUri()).build();
    }

    @Override
    protected AuthToken getAccessToken(AuthCallback authCallback) {

        // 自定义获取AccessToken
        HttpUtils httpUtils = new HttpUtils(this.config.getHttpConfig());
        HashMap<String, String> headerMap = new HashMap<>();
        String encode = Base64Utils.encode(this.config.getClientId() + ":" + this.config.getClientSecret());
        headerMap.put("Authorization", "basic " + encode);
        String body = httpUtils.post(
                this.accessTokenUrl(authCallback.getCode()),
                "",
                new HttpHeader(headerMap)
        ).getBody();
        JSONObject object = JSONObject.parseObject(body);

        this.checkResponse(object);

        return AuthToken.builder()
                .accessToken(object.getString("access_token"))
                .refreshToken(object.getString("refresh_token"))
                .expireIn(object.getInteger("expires_in"))
                .tokenType(object.getString("token_type"))
                .scope(object.getString("scope"))
                .build();
    }

    @Override
    protected AuthUser getUserInfo(AuthToken authToken) {


        // 自定义获取UserInfo
        HttpUtils httpUtils = new HttpUtils(this.config.getHttpConfig());
        HashMap<String, String> headerMap = new HashMap<>();
        headerMap.put("Authorization", "Bearer " + authToken.getAccessToken());
        String body = httpUtils.post(
                source.userInfo(),
                "",
                new HttpHeader(headerMap)
        ).getBody();
        JSONObject object = JSONObject.parseObject(body);

        this.checkResponse(object);

        return AuthUser.builder()
                // .uuid(object.getString("id"))
                .username(object.getString("username"))
                // .nickname(object.getString("name"))
                // .avatar(object.getString("avatar_url"))
                // .blog(object.getString("web_url"))
                // .company(object.getString("organization"))
                // .location(object.getString("location"))
                // .email(object.getString("email"))
                // .remark(object.getString("bio"))
                // .gender(AuthUserGender.UNKNOWN)
                .token(authToken)
                .source(source.toString())
                .build();
    }

    private void checkResponse(JSONObject object) {
        // oauth/token 验证异常
        if (object.containsKey("error")) {
            throw new AuthException(object.getString("error_description"));
        }
        // user 验证异常
        if (object.containsKey("message")) {
            throw new AuthException(object.getString("message"));
        }
    }

    /**
     * 返回带{@code state}参数的授权url，授权回调时会带上这个{@code state}
     *
     * @param state state 验证授权流程的参数，可以防止csrf
     * @return 返回授权地址
     * @since 1.11.0
     */
    @Override
    public String authorize(String state) {
        return UrlBuilder.fromBaseUrl(super.authorize(state))
                .queryParam("scope", this.getScopes(" ", false, AuthScopeUtils.getDefaultScopes(AuthGoogleScope.values())))
                .build();
    }
}

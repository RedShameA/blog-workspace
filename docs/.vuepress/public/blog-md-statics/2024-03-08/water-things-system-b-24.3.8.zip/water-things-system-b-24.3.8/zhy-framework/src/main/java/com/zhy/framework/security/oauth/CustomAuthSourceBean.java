package com.zhy.framework.security.oauth;


import lombok.Data;
import me.zhyd.oauth.config.AuthSource;
import me.zhyd.oauth.request.AuthDefaultRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author wangfeng
 * @since 2023-10-25 10:41
 */
@Data
@Component
public class CustomAuthSourceBean {
    private static String oauthUrl;
    @Value("${oauth.redirect-url}")
    private String redirectUrl;
    @Value("${oauth.appkey}")
    private String appkey;
    @Value("${oauth.secret}")
    private String secret;

    @Value("${oauth.oauth-url}")
    public void setOauthUrl(String oauthUrlPara) {
        oauthUrl = oauthUrlPara;
    }

    public enum CustomAuthSource implements AuthSource {

        /**
         * OAuth服务器
         */
        CUSTOM_AUTH {
            /**
             * 授权的api
             *
             * @return url
             */
            @Override
            public String authorize() {
                return oauthUrl + "/oauth2/authorize";
            }

            /**
             * 获取accessToken的api
             *
             * @return url
             */
            @Override
            public String accessToken() {
                return oauthUrl + "/oauth2/token";
            }

            /**
             * 获取用户信息的api
             *
             * @return url
             */
            @Override
            public String userInfo() {
                return oauthUrl + "/userInfo";
            }

            /**
             * 平台对应的 AuthRequest 实现类，必须继承自 {@link AuthDefaultRequest}
             *
             * @return class
             */
            @Override
            public Class<? extends AuthDefaultRequest> getTargetClass() {
                return CustomAuthRequest.class;
            }
        }
    }
}



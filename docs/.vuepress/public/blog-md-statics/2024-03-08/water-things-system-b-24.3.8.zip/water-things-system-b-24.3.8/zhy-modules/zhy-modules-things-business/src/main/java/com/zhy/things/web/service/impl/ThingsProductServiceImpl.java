package com.zhy.things.web.service.impl;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.zhy.plugin.core.entity.domain.product.ThingsProduct;
import com.zhy.plugin.mapper.ThingsProductMapper;
import com.zhy.things.web.service.IThingsProductService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;

/**
 * @author wangfeng
 * @since 2023-11-09 14:34
 */
@Service
public class ThingsProductServiceImpl implements IThingsProductService {
    @Resource
    private ThingsProductMapper thingsProductMapper;

    @Override
    public JSONArray getAllPropertiesById(String id) {
        return Optional.ofNullable(selectThingsProductById(id))
                .map(ThingsProduct::getMetaData)
                .map(s->{
                    JSONObject metadata = JSONObject.parseObject(s);
                    JSONArray properties = metadata.getJSONArray("properties");
                    JSONArray array = new JSONArray();
                    for (Object property : properties) {
                        JSONObject object = new JSONObject();
                        object.put("propertyId", ((JSONObject) property).getString("id"));
                        object.put("propertyName", ((JSONObject) property).getString("name"));
                        object.put("propertyType", ((JSONObject) property).getString("type"));
                        array.add(object);
                    }
                    return array;
                }).orElse(new JSONArray());
    }

    /**
     * 查询product
     *
     * @param id product主键
     * @return product
     */
    @Override
    public ThingsProduct selectThingsProductById(String id)
    {
        return thingsProductMapper.selectThingsProductById(id);
    }

    /**
     * 查询product列表
     *
     * @param thingsProduct product
     * @return product
     */
    @Override
    public List<ThingsProduct> selectThingsProductList(ThingsProduct thingsProduct)
    {
        return thingsProductMapper.selectThingsProductList(thingsProduct);
    }

    /**
     * 新增product
     *
     * @param thingsProduct product
     * @return 结果
     */
    @Override
    public int insertThingsProduct(ThingsProduct thingsProduct)
    {
        return thingsProductMapper.insertThingsProduct(thingsProduct);
    }

    /**
     * 修改product
     *
     * @param thingsProduct product
     * @return 结果
     */
    @Override
    public int updateThingsProduct(ThingsProduct thingsProduct)
    {
        return thingsProductMapper.updateThingsProduct(thingsProduct);
    }

    /**
     * 批量删除product
     *
     * @param ids 需要删除的product主键
     * @return 结果
     */
    @Override
    public int deleteThingsProductByIds(String[] ids)
    {
        return thingsProductMapper.deleteThingsProductByIds(ids);
    }

    /**
     * 删除product信息
     *
     * @param id product主键
     * @return 结果
     */
    @Override
    public int deleteThingsProductById(String id)
    {
        return thingsProductMapper.deleteThingsProductById(id);
    }
}

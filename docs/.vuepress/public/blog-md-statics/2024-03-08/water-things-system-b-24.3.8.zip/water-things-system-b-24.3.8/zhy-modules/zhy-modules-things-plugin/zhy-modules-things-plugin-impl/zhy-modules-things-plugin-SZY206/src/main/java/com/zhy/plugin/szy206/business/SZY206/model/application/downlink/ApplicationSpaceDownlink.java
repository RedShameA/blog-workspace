package com.zhy.plugin.szy206.business.SZY206.model.application.downlink;

import com.zhy.plugin.szy206.business.SZY206.model.application.ApplicationSpace;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 下行
 * @author wangfeng
 * @since 2023-09-07 14:32
 */
@Data
@EqualsAndHashCode(callSuper = true)
public abstract class ApplicationSpaceDownlink extends ApplicationSpace {

    /**
     * 下行的解码方法 什么都不做
     */
    @Override
    public void decode() {}
}

package com.zhy.plugin.core.support;

import com.zhy.plugin.core.entity.domain.plugin.PluginDeviceOnlineStatus;
import com.zhy.plugin.core.entity.domain.plugin.PluginMessage;
import lombok.Getter;

import java.util.Locale;
import java.util.function.Consumer;

/**
 * 插件上下文
 *
 * @author wangfeng
 * @since 2023-11-06 11:37
 */
public class PluginContext {
    static Consumer<String> online;
    static Consumer<String> offline;
    static Consumer<PluginMessage> messageHandler;
    @Getter
    private static PluginContext instance;

    private PluginContext(Consumer<String> online, Consumer<String> offline, Consumer<PluginMessage> messageHandler) {
        PluginContext.online = online;
        PluginContext.offline = offline;
        PluginContext.messageHandler = messageHandler;
    }

    public static void initInstance(Consumer<String> online, Consumer<String> offline, Consumer<PluginMessage> messageHandler) {
        instance = new PluginContext(online, offline, messageHandler);
    }

    /**
     * 产生消息
     */
    public static void produceMessage(PluginMessage pluginMessage) {
        pluginMessage.setDeviceId(pluginMessage.getDeviceId().toUpperCase(Locale.ROOT));
        messageHandler.accept(pluginMessage);
    }

    /**
     * 设备上下线
     */
    public static void produceDeviceOnlineStatus(PluginDeviceOnlineStatus deviceOnlineStatus) {
        if (deviceOnlineStatus.isOnline()) {
            online.accept(deviceOnlineStatus.getDeviceId().toUpperCase(Locale.ROOT));
        } else {
            offline.accept(deviceOnlineStatus.getDeviceId().toUpperCase(Locale.ROOT));
        }
    }

}

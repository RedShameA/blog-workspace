package com.zhy.converter.handler.impl;

import com.zhy.things.common.constants.StationType;
import com.zhy.things.common.constants.ValueType;
import com.zhy.common.things.domain.StandardMessage;
import com.zhy.converter.domain.HydRiWqamdW;
import com.zhy.converter.domain.StRiverR;
import com.zhy.converter.handler.StationTypeHandler;
import com.zhy.converter.mapper.HydRiWqamdWMapper;
import com.zhy.converter.mapper.StRiverRMapper;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author wangfeng
 * @since 2023-11-28 16:08
 */
@Component
public class ZQStationTypeHandler implements StationTypeHandler {
    @Override
    public StationType getSupportedStationType() {
        return StationType.ZQ;
    }


    @Resource
    StRiverRMapper stRiverRMapper;
    @Resource
    HydRiWqamdWMapper hydRiWqamdWMapper;

    @Override
    public void handle(ValueType valueType, StandardMessage standardMessage) {
        StRiverR stRiverR = new StRiverR();
        stRiverR.setTm(standardMessage.getMessageTime());
        stRiverR.setStcd(standardMessage.getDeviceId());

        HydRiWqamdW hydRiWqamdW = new HydRiWqamdW();
        hydRiWqamdW.setSpt(standardMessage.getMessageTime());
        hydRiWqamdW.setStcd(standardMessage.getDeviceId());
        switch (valueType) {
            // 河道水情表
            case WATER_LEVEL:
                stRiverR.setZ(standardMessage.getMessageValue());
                stRiverRMapper.insertOrUpdate(stRiverR);
                break;
            case WATER_FLOW:
                stRiverR.setQ(standardMessage.getMessageValue());
                stRiverRMapper.insertOrUpdate(stRiverR);
                break;
            case WATER_SECTIONAL_SPEED_AVERAGE:
                stRiverR.setXsavv(standardMessage.getMessageValue());
                stRiverRMapper.insertOrUpdate(stRiverR);
                break;
            case WATER_SPEED_MAX:
                stRiverR.setXsmxv(standardMessage.getMessageValue());
                stRiverRMapper.insertOrUpdate(stRiverR);
                break;
            // 水质相关
            case WATER_QUALITY_WTMP:
                hydRiWqamdW.setWtmp(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_PH:
                hydRiWqamdW.setPh(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_COND:
                hydRiWqamdW.setCond(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_TURB:
                hydRiWqamdW.setTurb(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_DOC:
                hydRiWqamdW.setDoc(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_CODMN:
                hydRiWqamdW.setCodmn(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_CODCR:
                hydRiWqamdW.setCodcr(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_TN:
                hydRiWqamdW.setTn(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_NH4N:
                hydRiWqamdW.setNh3n(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_N02:
                hydRiWqamdW.setN02(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_N03:
                hydRiWqamdW.setN03(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_TP:
                hydRiWqamdW.setTp(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_TOC:
                hydRiWqamdW.setToc(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_VLPH:
                hydRiWqamdW.setVlph(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_CHLA:
                hydRiWqamdW.setChla(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_F:
                hydRiWqamdW.setF(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_ARS:
                hydRiWqamdW.setArs(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_HG:
                hydRiWqamdW.setHg(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_CR6:
                hydRiWqamdW.setCr6(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_CU:
                hydRiWqamdW.setCu(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_PB:
                hydRiWqamdW.setPb(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_CD:
                hydRiWqamdW.setCd(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_ZN:
                hydRiWqamdW.setZn(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            case WATER_QUALITY_SB:
                hydRiWqamdW.setSb(standardMessage.getMessageValue());
                hydRiWqamdWMapper.insertOrUpdate(hydRiWqamdW);
                break;
            default:
        }
    }
}

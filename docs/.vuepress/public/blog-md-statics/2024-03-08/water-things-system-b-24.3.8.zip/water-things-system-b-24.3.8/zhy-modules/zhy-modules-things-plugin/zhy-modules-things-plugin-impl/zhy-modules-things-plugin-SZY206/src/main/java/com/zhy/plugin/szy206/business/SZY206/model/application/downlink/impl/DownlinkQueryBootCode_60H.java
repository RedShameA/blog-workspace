package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：60H-查询终端站转发中继引导码长值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryBootCode_60H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._60.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 下行查询通用（无密码时间）
 * @author wangfeng
 * @since 2023-09-26 11:43
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryCommonSimple extends ApplicationSpaceDownlink {

    public DownlinkQueryCommonSimple(AFN afn) {
        applicationFunctionCode = afn.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{applicationFunctionCode};
    }
}

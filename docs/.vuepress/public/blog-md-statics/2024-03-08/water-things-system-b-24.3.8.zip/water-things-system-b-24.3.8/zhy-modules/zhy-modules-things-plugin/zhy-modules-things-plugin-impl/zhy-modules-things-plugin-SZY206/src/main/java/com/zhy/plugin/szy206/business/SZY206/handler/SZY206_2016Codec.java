package com.zhy.plugin.szy206.business.SZY206.handler;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.alibaba.fastjson2.JSONObject;
import com.zhy.plugin.szy206.business.SZY206.common.Crc8Utils;
import com.zhy.plugin.szy206.business.SZY206.model.MessageFrame;
import com.zhy.plugin.szy206.business.SZY206.model._ControlSpace;
import com.zhy.plugin.szy206.business.SZY206.model.application.ApplicationSpace;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplinkFactory;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageCodec;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * 对上行或下行的SZY206-2016报文进行编解码操作
 *
 * @author wangfeng
 * @since 2023-09-07 13:53
 */
@Slf4j
public class SZY206_2016Codec extends ByteToMessageCodec<MessageFrame> {
    /**
     * 编码 MessageFrame -> byte[]
     */
    @Override
    protected void encode(ChannelHandlerContext channelHandlerContext, MessageFrame frame, ByteBuf out) throws Exception {
        try {
            // 计算长度
            frame.compute();
            // 组装下行报文数据
            byte[] bytes = new byte[0];
            // 帧起始符
            bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getStartChar()});
            // 长度
            bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getContentLength()});
            // 帧起始符
            bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getStartCharAgain()});
            // 控制域
            bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getControlSpace().encode()});
            // 拆分帧计数
            if (frame.isDivided()) {
                bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getDivs()});
            }
            // 地址域
            bytes = ArrayUtil.addAll(bytes, frame.getAddressSpace());
            // 用户数据域
            bytes = ArrayUtil.addAll(bytes, frame.getApplicationSpace().encode());
            // crc
            byte[] crcBytes = Arrays.copyOfRange(bytes, 3, bytes.length);
            int crc8 = Crc8Utils.getCRC8(crcBytes);
            bytes = ArrayUtil.addAll(bytes, new byte[]{(byte) crc8});
            // 结束字符
            bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getEndChar()});
            // 编码完成
            out.writeBytes(bytes);
            log.info("下行编码: {}", HexUtil.encodeHexStr(bytes));
        } catch (Exception e) {
            log.error("下行编码出错: {}", frame, e);
        }

    }

    /**
     * 解码 byte[] -> MessageFrame
     */
    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext, ByteBuf byteBuf, List<Object> list) throws Exception {

        ByteBuf duplicate = byteBuf.duplicate();
        byte[] allBytes = new byte[duplicate.readableBytes()];
        duplicate.readBytes(allBytes);
        MessageFrame messageFrame = this.structMessage(byteBuf);
        messageFrame.setAllBytes(allBytes);
        messageFrame.setAllBytesStr(HexUtil.encodeHexStr(allBytes).toUpperCase(Locale.ROOT));
        list.add(messageFrame);
    }


    private MessageFrame structMessage(ByteBuf buffer) {
        MessageFrame messageFrame = new MessageFrame();

        // 帧起始符
        byte startChar = buffer.readByte();
        messageFrame.setStartChar(startChar);
        // 报文长度
        byte length = buffer.readByte();
        messageFrame.setContentLength(length);
        // 帧起始符
        byte startCharAgain = buffer.readByte();
        messageFrame.setStartCharAgain(startCharAgain);
        // 控制域
        byte controlSpace = buffer.readByte();
        _ControlSpace _controlSpace = new _ControlSpace();
        _controlSpace.decode(controlSpace);
        messageFrame.setControlSpace(_controlSpace);
        // 拆分帧计数
        if (messageFrame.isDivided()) {
            byte divs = buffer.readByte();
            messageFrame.setDivs(divs);
        }
        // 地址域
        byte[] addressSpace = new byte[5];
        buffer.readBytes(addressSpace);
        messageFrame.setAddressSpace(addressSpace);
        messageFrame.setAddress(HexUtil.encodeHexStr(addressSpace).toUpperCase());
        messageFrame.setAddress8(messageFrame.getAddress().substring(2));
        // 用户数据域(应用层)
        // messageFrame.setApplicationSpaceContent(dataSpace);
        try{
            byte[] dataSpace = new byte[length - 5 - 1 - (messageFrame.isDivided() ? 1 : 0)];
            buffer.readBytes(dataSpace);
            log.info("功能码: {}", HexUtil.encodeHexStr(new byte[]{dataSpace[0]}).toUpperCase() + "H");
            ApplicationSpace applicationSpace = ApplicationSpaceUplinkFactory.parseApplicationSpace(messageFrame, dataSpace);
            messageFrame.setApplicationSpace(applicationSpace);
        }catch (Exception e){
            log.error("error while parsing applicationSpace");
        }
        // 校验位
        byte crc = buffer.readByte();
        messageFrame.setCheckCode(crc);
        // 结束字符
        byte endChar = buffer.readByte();
        messageFrame.setEndChar(endChar);
        // messageFrame
        log.info(JSONObject.from(messageFrame).toJSONString());
        return messageFrame;
    }
}

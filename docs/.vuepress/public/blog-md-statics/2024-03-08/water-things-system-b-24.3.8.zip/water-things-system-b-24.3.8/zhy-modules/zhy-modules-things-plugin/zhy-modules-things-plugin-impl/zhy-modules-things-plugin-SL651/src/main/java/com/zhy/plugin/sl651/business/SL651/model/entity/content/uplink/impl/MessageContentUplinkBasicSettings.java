package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import com.zhy.plugin.sl651.business.SL651.utils.ElementParseUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;

/**
 * 遥测站基本配置报
 * @author wangfeng
 * @since 2023/8/27 17:17
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentUplinkBasicSettings extends MessageContentUplink {

    Map<String, byte[]> settings = new HashMap<>();

    @Override
    public void decode() {
        byte[] content = this.getBytes();
        ByteBuf buffer = Unpooled.wrappedBuffer(content);

        // 流水号
        byte[] serialNumber = new byte[2];
        buffer.readBytes(serialNumber);
        this.setSerialNumber(serialNumber);
        // 发报时间
        byte[] messageTime = new byte[6];
        buffer.readBytes(messageTime);
        this.setMessageTime(messageTime);

        // 标识符
        byte[] flag = new byte[2];
        while (buffer.isReadable()) {
            buffer.readBytes(flag);
            String flagStr = HexUtil.encodeHexStr(flag, false).substring(0, 2);
            switch (flagStr) {
                case "F1": // 观测站
                    byte[] station = new byte[5];
                    buffer.readBytes(station);
                    byte stationType = buffer.readByte();
                    this.setStation(station);
                    this.setStationType(stationType);
                    break;
                case "F0": // 观测时间
                    byte[] collectTime = new byte[5];
                    buffer.readBytes(collectTime);
                    this.setCollectTime(collectTime);
                    this.setCollectTimeParse(ElementParseUtil.parseCollectTime(collectTime));
                    break;
                default: // 其他配置串 剩余的所有内容
                    int length = (flag[1] & 0xff) >> 3;
                    if ("FF".equals(flagStr)){
                        // 自定义要素特殊处理
                        byte b = buffer.readByte();
                        length = (b & 0xff) >> 3;
                        flagStr =  HexUtil.encodeHexStr(flag, false);
                    }
                    byte[] elementData = new byte[length];
                    buffer.readBytes(elementData);
                    // byte[] elementAll = ArrayUtil.addAll(flag, elementData);
                    // Double result = ElementParseUtil.parseDouble(elementAll);
                    settings.put(flagStr, elementData);
                    break;
            }
        }
    }
}

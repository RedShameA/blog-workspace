package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：5AH-查询遥测终端水质参数种类、下限值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryWaterQualityDownParameter_5AH extends ApplicationSpaceDownlink {


    {
        applicationFunctionCode = AFN._59.getFNCByte();
    }
    @Override
    public byte[] encode() {
        return new byte[]{applicationFunctionCode};
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application.ApplicationSpace;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.StationWarnStatus;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;

import java.util.Calendar;
import java.util.Date;

/**
 * @author wangfeng
 * @since 2023-10-05 17:24
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkRemoteReportDanger_E1H extends ApplicationSpaceUplink {

    /**
     * 电源电压
     */
    Double powerVoltage;
    /**
     * 信号值
     */
    Integer csq;
    /**
     * 告警状态
     */
    StationWarnStatus stationWarnStatus;

    /**
     * 时间
     */
    Date date;

    public static void main(String[] args) {
        ApplicationSpace applicationSpace = new UplinkRemoteReportDanger_E1H()
                .decode(HexUtil.decodeHex("E112261720002000550917071023"));
        System.out.println(applicationSpace);
    }

    @SneakyThrows
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // 电压
        byte[] powerBytes = new byte[2];
        buffer.readBytes(powerBytes);
        this.powerVoltage = this.calcPower(powerBytes);
        // 信号值
        this.csq = this.calcCSQ(buffer.readByte());
        // 告警
        byte[] dangerBytes = new byte[4];
        buffer.readBytes(dangerBytes);
        stationWarnStatus = new StationWarnStatus().parse(dangerBytes);
        // 时间TP
        byte[] dateBytes = new byte[6];
        buffer.readBytes(dateBytes);
        date = calcDate(dateBytes);
    }

    private Double calcPower(byte[] bytes) {
        return (bytes[0] & 0b0000_1111) + // 个位
                (((bytes[0] & 0b1111_0000) >> 4) * 10) + // 十位
                ((bytes[1] & 0b0000_1111) * 0.01) + // 百分位
                (((bytes[1] & 0b1111_0000) >> 4) * 0.1); // 十分位
    }

    private Integer calcCSQ(byte b) {
        return (b & 0b0000_1111) + // 个位
                (((b & 0b1111_0000) >> 4) * 10); // 十位
    }

    private Date calcDate(byte[] bytes){
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.MILLISECOND, 0);
        instance.set(Calendar.SECOND, calcDate_(bytes[0]));
        instance.set(Calendar.MINUTE, calcDate_(bytes[1]));
        instance.set(Calendar.HOUR_OF_DAY, calcDate_(bytes[2]));
        instance.set(Calendar.DAY_OF_MONTH, calcDate_(bytes[3]));
        instance.set(Calendar.MONTH, calcDate_(bytes[4]) - 1);
        instance.set(Calendar.YEAR, calcDate_(bytes[5]) + 2000);
        return instance.getTime();
    }
    private int calcDate_(byte b) {
        return (b & 0b0000_1111) + (((b & 0b1111_0000)>>4) * 10);
    }
}

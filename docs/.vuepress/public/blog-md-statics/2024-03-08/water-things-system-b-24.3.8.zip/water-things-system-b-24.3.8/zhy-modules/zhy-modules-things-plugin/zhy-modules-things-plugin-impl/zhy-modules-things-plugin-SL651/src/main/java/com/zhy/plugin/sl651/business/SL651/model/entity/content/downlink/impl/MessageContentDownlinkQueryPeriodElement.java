package com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.MessageContentDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author wangfeng
 * @since 2023-07-28 16:55
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentDownlinkQueryPeriodElement extends MessageContentDownlink {

    private Date startTime;
    private Date endTime;
    private String periodCode;
    private String elementTag;

    private static SimpleDateFormat YYMMDDHH = new SimpleDateFormat("yyMMddHH");

    @Override
    public byte[] encode() {
        byte[] bytes = new byte[0];
        byte[] serialNumber = this.getSerialNumber();
        byte[] messageTime = this.getMessageTime();
        bytes = ArrayUtil.addAll(bytes, serialNumber);
        // 发报时间
        String yyyyMMddHHmmss = DateUtil.format(this.getMessageTimeParse(), "yyMMddHHmmss");
        this.setMessageTime(HexUtil.decodeHex(yyyyMMddHHmmss));
        bytes = ArrayUtil.addAll(bytes, messageTime);
        bytes = ArrayUtil.addAll(bytes, HexUtil.decodeHex(YYMMDDHH.format(startTime)));
        bytes = ArrayUtil.addAll(bytes, HexUtil.decodeHex(YYMMDDHH.format(endTime)));
        bytes = ArrayUtil.addAll(bytes, HexUtil.decodeHex("0418"+periodCode));
        bytes = ArrayUtil.addAll(bytes, HexUtil.decodeHex(elementTag)); // todo F460 中的60是什么意思
        return bytes;
    }
}

package com.zhy.plugin.sl651.business.SL651.utils;

import org.springframework.stereotype.Repository;

/**
 * @Author：houDeJian
 * @Record：统计单个对象的属性不为null的个数
 */
@Repository
public class CheckObjectElementsUtil {

    public int isNotNUll(String subString,int start,int end){
        int n=0;
        String substring1 = subString.toString().substring(start, end);
        String[] split = substring1.split(",");
        for (String s : split) {
            String[] split1 = s.split("=");
            if(!split1[1].equals("null")){
                n+=1;
            }
        }
        return n;
    }
}

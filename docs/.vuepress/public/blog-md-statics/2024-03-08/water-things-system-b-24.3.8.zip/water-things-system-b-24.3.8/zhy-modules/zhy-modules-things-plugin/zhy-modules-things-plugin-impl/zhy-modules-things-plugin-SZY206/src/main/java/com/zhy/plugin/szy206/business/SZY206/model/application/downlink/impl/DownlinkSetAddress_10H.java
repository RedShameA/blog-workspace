package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 10H 设置遥测终端、中继站 地址
 *
 * @author wangfeng
 * @since 2023-09-08 17:04
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetAddress_10H extends ApplicationSpaceDownlink {

    {
        applicationFunctionCode = AFN._10.getFNCByte();
    }

    String address;

    @Override
    public byte[] encode() {
        byte[] addressSpace;
        addressSpace = HexUtil.decodeHex(this.address);
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, addressSpace, this.aux.encode());
    }
}

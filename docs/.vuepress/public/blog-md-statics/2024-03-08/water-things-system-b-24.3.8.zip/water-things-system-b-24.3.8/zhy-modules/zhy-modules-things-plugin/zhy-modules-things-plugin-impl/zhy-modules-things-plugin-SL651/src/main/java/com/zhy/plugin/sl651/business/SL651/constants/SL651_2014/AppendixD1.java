package com.zhy.plugin.sl651.business.SL651.constants.SL651_2014;

/**
 * @Author wangfeng
 * @Description 水文协议 附录D.1
 * @Date 2023-05-03 16:01
 */
public enum AppendixD1 {

    _01("中心站地址", "01", "4 字节"), // 每个字节表示 1 个中心站地址，按顺序分别表示第一、二、三、四个中心站地址；HEX 码，地址范围 1～255；地址是 0 表示禁用。
    _02("遥测站地址", "02", "N(10)"), // BCD 码
    _03("密码", "03", "2 字节"), // HEX 码
    _04("中心站 1 主信道类型及地址", "04", "不定长"), // 信道类型在高位字节，地址在低位字节。信道类型用 1 字节 BCD 码：1-短信，2-IPV4，3-北斗，4-海事卫星，5-PSTN，6-超短波。中心站信道地址长度根据信道类型确定，其中 IP 型地址应包含地址及端口号，IP 地址用 6 字节 BCD 码表示，省略“.”；端口号用 3 字节 BCD 码表示，紧接在地址之后。
    _05("中心站 1 备用信道类型及地址", "05", "不定长"), // 同上。信道类型是“0”表示禁用该信道。
    _06("中心站 2 主信道类型及地址", "06", "不定长"), // 同上。信道类型是“0”表示禁用该信道。
    _07("中心站 2 备用信道类型及地址", "07", "不定长"), // 同上。信道类型是“0”表示禁用该信道。
    _08("中心站 3 主信道类型及地址", "08", "不定长"), // 同上。信道类型是“0”表示禁用该信道。
    _09("中心站 3 备用信道类型及地址", "09", "不定长"), // 同上。信道类型是“0”表示禁用该信道。
    _0A("中心站 4 主信道类型及地址", "0A", "不定长"), // 同上。信道类型是“0”表示禁用该信道。
    _0B("中心站 4 备用信道类型及地址", "0B", "不定长"), // 同上。信道类型是“0”表示禁用该信道。
    _0C("工作方式", "0C", "N(2)"), // BCD 码，1-自报工作状态；2-自报确认工作状态；3查询/应答工作状态；4-调试或维修状态
    _0D("遥测站采集要素设置", "0D", "见表D.2"), // HEX 码。要素对应数据位置“1”有效，置“0”无效，定义见表D.2。
    _0E("中继站（集合转发站）服务地址范围", "0E", "见表D.3"), // 编码见表 D.3，服务地址应尽量连续。标识符引导符后的数据定义字节 8Bit 均用于表示后续数据的字节数。
    _0F("遥测站通信设备识别号", "0F", "不定长"); // ASCII 码。第 1 字节表示卡类型：1-移动通信卡，2-北斗卫星通信卡；紧跟在卡类型后的数据为卡识别号。


    private String TEXT;
    private String HEX;
    private String ASC;
    // private String UNIT;
    private String DATA_DEFINITION; // 数据定义

    public String getTEXT() {
        return TEXT;
    }

    public String getHEX() {
        return HEX;
    }

    public String getDATA_DEFINITION() {
        return DATA_DEFINITION;
    }

    AppendixD1(String TEXT, String HEX, String DATA_DEFINITION) {
        this.TEXT = TEXT;
        this.HEX = HEX;
        this.DATA_DEFINITION = DATA_DEFINITION;
    }
}

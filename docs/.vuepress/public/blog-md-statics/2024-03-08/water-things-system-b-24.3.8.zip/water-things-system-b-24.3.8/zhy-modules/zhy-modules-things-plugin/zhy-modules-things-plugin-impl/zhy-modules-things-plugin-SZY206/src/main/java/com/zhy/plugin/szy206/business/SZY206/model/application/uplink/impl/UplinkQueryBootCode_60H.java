package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：60H-查询终端站转发中继引导码长值(响应码)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryBootCode_60H extends ApplicationSpaceUplink {

    /**
     * 返回的终端站转发中继引导码长值
     */
    int code;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        byte _byte1 = buffer.readByte();
        this.code = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
    }
}

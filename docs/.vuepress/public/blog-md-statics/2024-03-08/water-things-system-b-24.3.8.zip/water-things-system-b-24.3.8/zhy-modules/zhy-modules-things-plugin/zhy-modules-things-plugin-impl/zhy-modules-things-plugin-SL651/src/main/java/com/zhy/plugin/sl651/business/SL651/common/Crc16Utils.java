package com.zhy.plugin.sl651.business.SL651.common;

/**
 * @author yulei
 */
public final class Crc16Utils {
    /**
     * 根据指定的字节数组生成crc16校验码
     *
     * @param bytes 指定数组
     * @return 校验码, 低位在前，高位在后进行返回
     */
    public static int[] getCRC16(byte[] bytes) {
        int crc = 0x0000ffff;
        int polynomial = 0x0000a001;

        int i, j;
        for (i = 0; i < bytes.length; i++) {
            crc ^= ((int) bytes[i] & 0x000000ff);
            for (j = 0; j < 8; j++) {
                if ((crc & 0x00000001) != 0) {
                    crc >>= 1;
                    crc ^= polynomial;
                } else {
                    crc >>= 1;
                }
            }
        }
        //将校验码取出来分别放置，注意高位有一个算数右移的操作
        int highBit = (crc & 0xff00) >> 8;
        int lowBit = crc & 0xff;
        return new int[]{lowBit, highBit};
    }
}

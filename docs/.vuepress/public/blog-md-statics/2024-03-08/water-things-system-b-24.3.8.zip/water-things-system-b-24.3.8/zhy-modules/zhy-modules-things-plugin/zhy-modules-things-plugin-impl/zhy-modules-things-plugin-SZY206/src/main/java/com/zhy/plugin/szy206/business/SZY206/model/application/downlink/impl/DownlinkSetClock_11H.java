package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Calendar;
import java.util.Date;

/**
 * 11H 设置遥测终端、中继站 时钟
 *
 * @author wangfeng
 * @since 2023-09-14 14:08
 */


@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetClock_11H extends ApplicationSpaceDownlink {

    {
        applicationFunctionCode = AFN._11.getFNCByte();
    }

    /**
     * 要设置的时间
     */
    Date date;

    public static void main(String[] args) {
        DownlinkSetClock_11H i = new DownlinkSetClock_11H();
        i.setDate(new Date());
        i.encode();
    }

    @Override
    public byte[] encode() {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);

        int second = instance.get(Calendar.SECOND);
        int minute = instance.get(Calendar.MINUTE);
        int hour = instance.get(Calendar.HOUR_OF_DAY);
        int day = instance.get(Calendar.DAY_OF_MONTH);
        int month = instance.get(Calendar.MONTH)+1;
        int year = instance.get(Calendar.YEAR) - 2000;

        int dayOfWeek = instance.get(Calendar.DAY_OF_WEEK);
        // 这样获取出来 周天是1，周一是2 所以需要处理一下
        dayOfWeek = dayOfWeek == 1 ? 7 : dayOfWeek - 1;

        byte _SECOND = (byte) ((second / 10 << 4) | (second % 10));
        byte _MINUTE = (byte) ((minute / 10 << 4) | (minute % 10));
        byte _HOUR = (byte) ((hour / 10 << 4) | (hour % 10));
        byte _DAY = (byte) ((day / 10 << 4) | (day % 10));
        byte _WEEK_MONTH = (byte) ((dayOfWeek << 5) | (month / 10 << 4) | (month % 10));
        byte _YEAR = (byte) ((year / 10 << 4) | (year % 10));

        return ArrayUtil.addAll(new byte[]{applicationFunctionCode,_SECOND, _MINUTE, _HOUR, _DAY, _WEEK_MONTH, _YEAR},
                this.aux.encode());
    }
}

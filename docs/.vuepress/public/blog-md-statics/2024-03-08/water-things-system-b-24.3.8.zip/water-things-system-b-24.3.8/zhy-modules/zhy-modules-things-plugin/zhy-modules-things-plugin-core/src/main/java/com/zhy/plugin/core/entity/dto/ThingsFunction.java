package com.zhy.plugin.core.entity.dto;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.util.Objects;

@Data
public class ThingsFunction {
    private String functionId;
    private String functionName;
    public static ThingsFunction fromJson(JSONObject json){
        ThingsFunction entity = new ThingsFunction();
        entity.setFunctionId(json.getString("id"));
        entity.setFunctionName(json.getString("name"));
        return entity;
    }
    public JSONObject toJson(){
        JSONObject json = new JSONObject();
        json.put("id", this.getFunctionId());
        json.put("name", this.getFunctionName());
        return json;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ThingsFunction that = (ThingsFunction) o;
        return Objects.equals(functionId, that.functionId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(functionId);
    }
}

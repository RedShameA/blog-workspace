package com.zhy.plugin.szy206.business.SZY206.model.application;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 应用层
 * @author wangfeng
 * @since 2023-09-06 17:50
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class ApplicationSpace {

    /**
     * 应用层功能码 AFN
     */
    protected byte applicationFunctionCode;

    /**
     * 数据域(应用层)字节数组
     */
    protected byte[] content;

    /**
     * 附加信息域 AUX
     */
    protected _AUX aux;

    /**
     * 编码
     */
    abstract public byte[] encode();

    /**
     * 解码
     */
    abstract public void decode();

}

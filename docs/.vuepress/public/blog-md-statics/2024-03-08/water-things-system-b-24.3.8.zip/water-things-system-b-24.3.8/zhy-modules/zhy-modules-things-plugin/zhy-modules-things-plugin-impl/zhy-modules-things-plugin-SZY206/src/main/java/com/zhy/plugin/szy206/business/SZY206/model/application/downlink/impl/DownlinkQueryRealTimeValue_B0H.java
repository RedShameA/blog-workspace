package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：B0H-查询遥测终端实时值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryRealTimeValue_B0H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._B0.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

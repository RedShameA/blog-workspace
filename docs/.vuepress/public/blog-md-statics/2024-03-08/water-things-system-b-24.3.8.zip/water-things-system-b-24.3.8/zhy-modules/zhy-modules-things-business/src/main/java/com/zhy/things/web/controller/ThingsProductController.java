package com.zhy.things.web.controller;

import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson2.JSONObject;
import com.zhy.common.annotation.Log;
import com.zhy.common.core.controller.BaseController;
import com.zhy.common.core.domain.AjaxResult;
import com.zhy.common.core.page.TableDataInfo;
import com.zhy.common.enums.BusinessType;
import com.zhy.common.utils.poi.ExcelUtil;
import com.zhy.plugin.core.entity.domain.device.ThingsDevice;
import com.zhy.plugin.core.entity.domain.product.ThingsProduct;
import com.zhy.plugin.core.entity.dto.ThingsDeviceDto;
import com.zhy.plugin.core.entity.dto.ThingsProductDto;
import com.zhy.plugin.core.support.PluginSupport;
import com.zhy.plugin.store.DeviceMessageStore;
import com.zhy.plugin.store.PluginStatusStore;
import com.zhy.things.web.service.IThingsDeviceService;
import com.zhy.things.web.service.IThingsProductService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author wangfeng
 * @since 2023-11-09 14:35
 */
@RestController
@RequestMapping("/things/product")
public class ThingsProductController extends BaseController {

    @Resource
    private IThingsProductService thingsProductService;
    @Resource
    private IThingsDeviceService thingsDeviceService;

    /**
     * 查询产品相关联的插件的 所有propertyType和functionId
     */
    @PreAuthorize("@ss.hasPermi('things:product:list')")
    @GetMapping("/getPluginInfo")
    public AjaxResult getPluginInfo(ThingsProductDto thingsProductDto) {
        String productId = thingsProductDto.getProductId();
        ThingsProduct product = thingsProductService.selectThingsProductById(productId);
        PluginSupport pluginSupport = PluginStatusStore.getPluginSupport(product.getProtocol());
        List<JSONObject> supportedValueTypes = pluginSupport.getSupportedValueTypes().stream().map(JSONObject::from).collect(Collectors.toList());
        List<Map<String, String>> supportedFunctions = pluginSupport.getSupportedFunctions();
        String jsDeviceIdRegex = pluginSupport.getJsDeviceIdRegex();
        String jsDeviceIdRegexTip = pluginSupport.getJsDeviceIdRegexTip();
        JSONObject ret = new JSONObject();
        ret.put("protocolTypeOptions", supportedValueTypes);
        ret.put("functionOptions", supportedFunctions);
        ret.put("jsDeviceIdRegex", jsDeviceIdRegex);
        ret.put("jsDeviceIdRegexTip", jsDeviceIdRegexTip);
        return success(ret);
    }

    /**
     * 查询product列表
     */
    @PreAuthorize("@ss.hasPermi('things:product:list')")
    @GetMapping("/list")
    @SuppressWarnings({"unchecked"})
    public TableDataInfo list(ThingsProductDto thingsProductDto) {
        startPage();
        List<ThingsProduct> list = thingsProductService.selectThingsProductList(thingsProductDto.toThingsProduct());
        TableDataInfo dataTable = getDataTable(list);
        dataTable.setRows(
                ((List<ThingsProduct>) dataTable.getRows())
                        .stream()
                        .map(ThingsProductDto::fromThingsProduct)
                        .peek(dto -> {
                            dto.setProtocolStatus(PluginStatusStore.checkStatus(dto.getProtocol()));
                            dto.setProtocolName(PluginStatusStore.getName(dto.getProtocol()));
                        })
                        .collect(Collectors.toList())
        );
        return dataTable;
    }

    /**
     * 导出product列表
     */
    @PreAuthorize("@ss.hasPermi('things:product:export')")
    @Log(title = "product", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ThingsProduct thingsProduct) {
        List<ThingsProduct> list = thingsProductService.selectThingsProductList(thingsProduct);
        ExcelUtil<ThingsProduct> util = new ExcelUtil<ThingsProduct>(ThingsProduct.class);
        util.exportExcel(response, list, "product数据");
    }

    /**
     * 获取product详细信息
     */
    @PreAuthorize("@ss.hasPermi('things:product:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id) {
        return success(ThingsProductDto.fromThingsProduct(thingsProductService.selectThingsProductById(id)));
    }

    /**
     * 新增product
     */
    @PreAuthorize("@ss.hasPermi('things:product:add')")
    @Log(title = "product", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ThingsProductDto thingsProductDto) {
        thingsProductDto.setProductId(IdUtil.getSnowflakeNextIdStr());
        thingsProductDto.setCreateBy(getUsername());
        return toAjax(thingsProductService.insertThingsProduct(thingsProductDto.toThingsProduct()));
    }

    /**
     * 修改product
     */
    @PreAuthorize("@ss.hasPermi('things:product:edit')")
    @Log(title = "product", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ThingsProductDto thingsProductDto) {
        DeviceMessageStore.removeProductNameCacheMapKey(thingsProductDto.getProductId());
        ThingsProduct thingsProduct = thingsProductDto.toThingsProduct();
        thingsProduct.setUpdateBy(getUsername());
        return toAjax(thingsProductService.updateThingsProduct(thingsProduct));
    }

    /**
     * 删除product
     */
    @PreAuthorize("@ss.hasPermi('things:product:remove')")
    @Log(title = "product", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids) {
        for (String id : ids) {
            ThingsDeviceDto thingsDeviceDto = new ThingsDeviceDto();
            thingsDeviceDto.setProductId(id);
            List<ThingsDevice> list = thingsDeviceService.selectThingsDeviceList(thingsDeviceDto);
            if (null != list && !list.isEmpty()){
                return warn("选择的产品中存在关联的设备，禁止删除");
            }
        }
        for (String id : ids) {
            DeviceMessageStore.removeProductNameCacheMapKey(id);
        }
        return toAjax(thingsProductService.deleteThingsProductByIds(ids));
    }

}

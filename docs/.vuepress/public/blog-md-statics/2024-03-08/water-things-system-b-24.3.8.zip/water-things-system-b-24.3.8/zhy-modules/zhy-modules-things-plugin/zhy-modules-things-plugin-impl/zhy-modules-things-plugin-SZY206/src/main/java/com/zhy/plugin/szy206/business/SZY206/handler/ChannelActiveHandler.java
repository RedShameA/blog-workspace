package com.zhy.plugin.szy206.business.SZY206.handler;

import com.zhy.plugin.core.entity.domain.plugin.PluginDeviceOnlineStatus;
import com.zhy.plugin.core.support.PluginContext;
import com.zhy.plugin.szy206.business.SZY206.model.MessageFrame;
import com.zhy.plugin.szy206.business.SZY206.utils.ChannelUtil206;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

/**
 * 连接事件（只触发成功解析的报文）
 *
 * @author wangfeng
 * @since 2023-07-04 10:18
 */
public class ChannelActiveHandler extends SimpleChannelInboundHandler<MessageFrame> {

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, MessageFrame messageFrame) {
        String id = messageFrame.getAddress();
        // String password = messageFrame.getPasswordParse();
        // FamiliarStation651 familiarStation651 = FamiliarStation651.builder()
        //         .stationId(id)
        //         .password(password)
        //         .build();
        // StationUtil.addOnline(id, familiarStation651);
        PluginContext.produceDeviceOnlineStatus(new PluginDeviceOnlineStatus(id,true));
        boolean b = ChannelUtil206.addChannel(id, ctx.channel());
        if (b) {
            ctx.fireChannelRead(messageFrame);
        }
        // 遇到了特殊事件 不进行后续流程了
    }
}

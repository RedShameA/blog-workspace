package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Since 2023/9/27
 * @Author：houDeJian
 * @Record：82_人工置数(确认帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkConfirmManualSet_82H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._82.getFNCByte();
    }
    /**
     * 遥测站模式状态 <br>
     * 0-遥测站终端兼容工作状态 <br>
     * 1-遥测站自报状态 <br>
     * 2-遥测站处在应答/查询状态 <br>
     * 3-调试/维修 <br>
     */
    int workMode;


    @Override
    public byte[] encode() {
        byte _byte1 = (byte) (this.workMode & 0b0000_1111);
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode, _byte1});
    }
}

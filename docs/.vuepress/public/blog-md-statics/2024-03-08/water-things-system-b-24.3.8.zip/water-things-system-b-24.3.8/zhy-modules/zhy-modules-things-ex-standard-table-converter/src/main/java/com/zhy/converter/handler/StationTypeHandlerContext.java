package com.zhy.converter.handler;

import com.zhy.things.common.constants.StationType;
import com.zhy.things.common.constants.ValueType;
import com.zhy.common.things.domain.StandardMessage;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author wangfeng
 * @since 2023-11-24 11:14
 */
@Component
public class StationTypeHandlerContext implements ApplicationContextAware {
    private static final Map<StationType, StationTypeHandler> handlerMap = new ConcurrentHashMap<>();
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        Map<String, StationTypeHandler> beansOfType = applicationContext.getBeansOfType(StationTypeHandler.class);
        for (StationTypeHandler handler : beansOfType.values()) {
            handlerMap.put(handler.getSupportedStationType(), handler);
        }
    }

    public static void handle(StationType stationType, ValueType valueType, StandardMessage standardMessage){
        if (null==stationType) return;
        StationTypeHandler handler = handlerMap.get(stationType);
        if (null==handler) return;
        handler.handle(valueType, standardMessage);
    }
}

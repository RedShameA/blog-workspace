package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 中心站查询遥测站事件记录报
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentUplinkQueryRecord extends MessageContentUplink {

    /**
     * 历史数据初始化记录
     */
    public Integer historicalDataRecord;

    /**
     * 参数变更记录
     */
    public Integer parameterChangeRecord;

    /**
     * 状态量变位记录
     */
    public Integer statusRecord;

    /**
     * 传感器及仪表故障记录
     */
    public Integer sensorRecords;

    /**
     * 密码修改记录
     */
    public Integer passwordRecord;

    /**
     * 终端故障记录
     */
    public Integer terminalFaultRecord;

    /**
     * 交流失电记录
     */
    public Integer ACLossRecord;

    /**
     *蓄电池电压低告警记录
     */
    public Integer lowBatteryAlarmRecord;

    /**
     * 终端箱非法打开记录
     */
    public Integer illegalRecordOfBox;

    /**
     * 水泵故障记录
     */
    public Integer waterPumpFaultRecord;

    /**
     * 剩余水量超限告警记录
     */
    public Integer remainingWaterLimitAlarmRecord;

    /**
     * 水位超限告警记录
     */
    public Integer waterLevelLimitAlarm;

    /**
     *水压超限告警记录
     */
    public Integer waterPressureLimitAlarmRecord;

    /**
     * 水质参数超限告警记录
     */
    public Integer waterQualityLimitAlarmRecord;

    /**
     * 数据出错记录
     */
    public Integer dataErrorRecord;

    /**
     * 发报文记录
     */
    public Integer sendingMessageRecord;

    /**
     *收报文记录
     */
    public Integer messageReceivingRecord;

    /**
     * 发报文出错记录
     */
    public Integer messageSendingErrorRecord;

    /**
     * 备用事件 19-32
     */
    public Integer spare19;
    public Integer spare20;
    public Integer spare21;
    public Integer spare22;
    public Integer spare23;
    public Integer spare24;
    public Integer spare25;
    public Integer spare26;
    public Integer spare27;
    public Integer spare28;
    public Integer spare29;
    public Integer spare30;
    public Integer spare31;
    public Integer spare32;

    @Override
    public void decode() {
        // 正文内容
        byte[] content = this.getBytes();
        ByteBuf buffer = Unpooled.wrappedBuffer(content);

        // 流水号
        byte[] serialNumber = new byte[2];
        buffer.readBytes(serialNumber);
        this.setSerialNumber(serialNumber);
        // 发报时间
        byte[] messageTime = new byte[6];
        buffer.readBytes(messageTime);
        this.setMessageTime(messageTime);
        // 标识符
        byte[] flag = new byte[2];
            buffer.readBytes(flag);
            String flagStr = HexUtil.encodeHexStr(flag, false).substring(0, 2);
        if (flagStr.equals("F1")){
            byte[] station = new byte[5];
            buffer.readBytes(station);
        }
            byte[] flagEvent1 = new byte[2];
            buffer.readBytes(flagEvent1);
            // 十六进制转换十进制
            this.setHistoricalDataRecord(decimalConversion(flagEvent1));
            byte[] flagEvent2 = new byte[2];
            buffer.readBytes(flagEvent2);
            this.setParameterChangeRecord(decimalConversion(flagEvent2));
            byte[] flagEvent3 = new byte[2];
            buffer.readBytes(flagEvent3);
            this.setStatusRecord(decimalConversion(flagEvent3));
            byte[] flagEvent4 = new byte[2];
            buffer.readBytes(flagEvent4);
            this.setSensorRecords(decimalConversion(flagEvent4));
            byte[] flagEvent5 = new byte[2];
            buffer.readBytes(flagEvent5);
            this.setPasswordRecord(decimalConversion(flagEvent5));
            byte[] flagEvent6 = new byte[2];
            buffer.readBytes(flagEvent6);
            this.setTerminalFaultRecord(decimalConversion(flagEvent6));
            byte[] flagEvent7 = new byte[2];
            buffer.readBytes(flagEvent7);
            this.setACLossRecord(decimalConversion(flagEvent7));
            byte[] flagEvent8 = new byte[2];
            buffer.readBytes(flagEvent8);
            this.setLowBatteryAlarmRecord(decimalConversion(flagEvent8));
            byte[] flagEvent9 = new byte[2];
            buffer.readBytes(flagEvent9);
            this.setIllegalRecordOfBox(decimalConversion(flagEvent9));
            byte[] flagEvent10 = new byte[2];
            buffer.readBytes(flagEvent10);
            this.setWaterPumpFaultRecord(decimalConversion(flagEvent10));
            byte[] flagEvent11 = new byte[2];
            buffer.readBytes(flagEvent11);
            this.setRemainingWaterLimitAlarmRecord(decimalConversion(flagEvent11));
            byte[] flagEvent12 = new byte[2];
            buffer.readBytes(flagEvent12);
            this.setWaterLevelLimitAlarm(decimalConversion(flagEvent12));
            byte[] flagEvent13 = new byte[2];
            buffer.readBytes(flagEvent13);
            this.setWaterPressureLimitAlarmRecord(decimalConversion(flagEvent13));
            byte[] flagEvent14 = new byte[2];
            buffer.readBytes(flagEvent14);
            this.setWaterQualityLimitAlarmRecord(decimalConversion(flagEvent14));
            byte[] flagEvent15 = new byte[2];
            buffer.readBytes(flagEvent15);
            this.setDataErrorRecord(decimalConversion(flagEvent15));
            byte[] flagEvent16 = new byte[2];
            buffer.readBytes(flagEvent16);
            this.setSendingMessageRecord(decimalConversion(flagEvent16));
            byte[] flagEvent17 = new byte[2];
            buffer.readBytes(flagEvent17);
            this.setMessageReceivingRecord(decimalConversion(flagEvent17));
            byte[] flagEvent18 = new byte[2];
            buffer.readBytes(flagEvent18);
            this.setMessageSendingErrorRecord(decimalConversion(flagEvent18));
    }

    /**
     * byte数组转为十进制
     * @param bytes 十六进制数组
     * @return 返回值
     */
    public static Integer decimalConversion(byte[] bytes){
        String s = HexUtil.encodeHexStr(bytes);
        return Integer.valueOf(s,16);
    }
}

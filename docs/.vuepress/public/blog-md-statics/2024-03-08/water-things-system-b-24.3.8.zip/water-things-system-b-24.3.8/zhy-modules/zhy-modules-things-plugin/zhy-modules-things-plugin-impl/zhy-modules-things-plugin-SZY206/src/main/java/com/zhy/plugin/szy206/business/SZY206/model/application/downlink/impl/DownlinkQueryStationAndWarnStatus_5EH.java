package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：5E-查询遥测终端状态和报警状态
 */
public class DownlinkQueryStationAndWarnStatus_5EH extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._5E.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

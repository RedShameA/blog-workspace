package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;

/**
 * @Author：houDeJian
 * @Record：18H设置水压上下限
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetWaterPressure_18H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._18.getFNCByte();
    }

    /**
     * 对N个水压点设置水压上下限<br/>
     * Pair: 左为上限，右为下限
     */
    ArrayList<Pair<Double, Double>> waterLevelAndLimit;

    @Override
    public byte[] encode() {
        byte[] array = new byte[waterLevelAndLimit.size() * 8];
        int n = 0;
        for (Pair<Double, Double> doubleDoubleDoubleTriple : waterLevelAndLimit) {
            Double first = doubleDoubleDoubleTriple.getLeft();
            Double second = doubleDoubleDoubleTriple.getRight();
            // 使用 String.format() 方法格式化
            String formattedFirst1 = String.format("%09.2f", first);
            String formattedSecond1 = String.format("%09.2f", second);
            //去除小数点
            String formattedFirst = formattedFirst1.replace(".", "");
            String formattedSecond = formattedSecond1.replace(".", "");

            int byte1 = Integer.parseInt(formattedFirst.substring(6, 8));
            int byte2 = Integer.parseInt(formattedFirst.substring(4, 6));
            int byte3 = Integer.parseInt(formattedFirst.substring(2, 4));
            int byte4 = Integer.parseInt(formattedFirst.substring(0, 2));

            byte _byte1 = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
            array[n * 8 + 0] = _byte1;
            byte _byte2 = (byte) ((byte2 / 10 << 4) | (byte2 % 10));
            array[n * 8 + 1] = _byte2;
            byte _byte3 = (byte) ((byte3 / 10 << 4) | (byte3 % 10));
            array[n * 8 + 2] = _byte3;
            byte _byte4 = (byte) ((byte4 / 10 << 4) | (byte4 % 10));
            array[n * 8 + 3] = _byte4;

            int byte5 = Integer.parseInt(formattedSecond.substring(6, 8));
            int byte6 = Integer.parseInt(formattedSecond.substring(4, 6));
            int byte7 = Integer.parseInt(formattedSecond.substring(2, 4));
            int byte8 = Integer.parseInt(formattedSecond.substring(0, 2));

            byte _byte5 = (byte) ((byte5 / 10 << 4) | (byte5 % 10));
            array[n * 8 + 4] = _byte5;
            byte _byte6 = (byte) ((byte6 / 10 << 4) | (byte6 % 10));
            array[n * 8 + 5] = _byte6;
            byte _byte7 = (byte) ((byte7 / 10 << 4) | (byte7 % 10));
            array[n * 8 + 6] = _byte7;
            byte _byte8 = (byte) ((byte8 / 10 << 4) | (byte8 % 10));
            array[n * 8 + 7] = _byte8;
            n += 1;
        }

        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode}, array, this.aux.encode());


    }
}

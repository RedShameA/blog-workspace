package com.zhy.plugin.sl651.business;

import com.zhy.plugin.sl651.business.SL651.handler.*;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author yulei
 */
@Component
public class NettySL651Server {

    private static final Logger LOGGER = LoggerFactory.getLogger(NettySL651Server.class);

    /**
     * 服务端NIO线程组
     * bossGroup只处理连接请求，workerGroup处理与客户端的连接（业务处理）
     * 下面两个group含有的线程数默认等于cpu核心数*2，一般来说bossGroup需要的核心数少于workerGroup即可
     */
    private EventLoopGroup bossGroup = null;
    private EventLoopGroup workGroup = null;

    public ChannelFuture start() {
        String host = "0.0.0.0";
        int port = 2217;
        bossGroup = new NioEventLoopGroup(2);
        workGroup = new NioEventLoopGroup(8);
        ChannelFuture channelFuture = null;
        try {
            ServerBootstrap bootstrap = new ServerBootstrap();
            bootstrap.group(bossGroup, workGroup)
                    .channel(NioServerSocketChannel.class)
                    // 设置保持活动连接状态
                    .childOption(ChannelOption.SO_KEEPALIVE, true)
                    // 给workerGroup的EventLoop设置管道
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel socketChannel) throws Exception {
                            // todo 拆包处理: 首先将数据进行拆包，确保下游处理的消息是完整的一条，才可以进行后续处理
                            // socketChannel.pipeline().addLast("decoder", new SL651_2014Decoder());
                            // socketChannel.pipeline().addLast("testing", new MyChannelInboundHandler());
                            // 字节校验处理，确保收到的完整消息没有损坏才能进行后续处理
                            socketChannel.pipeline().addLast("crc16", new Crc16Handler());
                            // logger
                            //socketChannel.pipeline().addLast(new LoggingHandler(LogLevel.INFO));
                            // crc校验成功后进行消息的编解码
                            socketChannel.pipeline().addLast("codec", new SL651_2014Codec());
                            // 保存连接
                            socketChannel.pipeline().addLast("clients-active", new ChannelActiveHandler());
                            socketChannel.pipeline().addLast("clients-inactive", new ChannelInactiveHandler());
                            // 捕获解码完成的消息，并做处理
                            socketChannel.pipeline().addLast("message handler", new DealingHandler());
                        }
                    });
            // 绑定端口并同步等待
            channelFuture = bootstrap.bind(host, port).sync();
            LOGGER.info("========= netty server start on {} =========", port);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return channelFuture;
    }

    public void close() {
        workGroup.shutdownGracefully();
        bossGroup.shutdownGracefully();
        LOGGER.info("========= shutdown netty server success! =========");
    }

    //private static class MyChannelInboundHandler extends ChannelInboundHandlerAdapter {
    //    @Override
    //    public void channelRegistered(ChannelHandlerContext channelHandlerContext) throws Exception {
    //        Channel channel = channelHandlerContext.channel();
    //        String id = "0020000116";
    //        ChannelUtil.addChannel(id, channel);
    //        channelHandlerContext.fireChannelRegistered();
    //    }
    //}
}

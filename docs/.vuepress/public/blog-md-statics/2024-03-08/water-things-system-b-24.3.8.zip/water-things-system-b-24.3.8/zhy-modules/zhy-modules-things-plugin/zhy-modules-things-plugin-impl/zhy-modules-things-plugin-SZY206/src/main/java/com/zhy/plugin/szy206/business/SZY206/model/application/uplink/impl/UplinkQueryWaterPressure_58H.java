package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;

/**
 * @Author：houDeJian
 * @Record：58查询遥测站终端水压上、下限值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryWaterPressure_58H extends ApplicationSpaceUplink {
    /**
     * left:水压上限
     * right：水压下限
     */
    ArrayList<Pair<Double,Double>> waterLevelAndLimit=new ArrayList<>();
    //存放告警值
    byte waterWarnSpace[];
    /**
     * 警告值
     */
    String  waterWarn;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        int i = buffer.readableBytes();
        int n=i/8;
        for (int y = 0; y < n; y++) {
            double downLevel;
            double upLevel;

            //水压上限
            byte _byte1 = buffer.readByte();
            byte _byte2 = buffer.readByte();
            byte _byte3 = buffer.readByte();
            byte _byte4 = buffer.readByte();
            int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
            int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
            int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
            int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
            upLevel=byte4*10000+byte3*100+byte2+byte1*0.01;

            //水压下限
            byte _byte5 = buffer.readByte();
            byte _byte6 = buffer.readByte();
            byte _byte7 = buffer.readByte();
            byte _byte8 = buffer.readByte();
            int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
            int byte6 = ((_byte6 >> 4 & 0x0F) * 10) + (_byte6 & 0x0F);
            int byte7 = ((_byte7 >> 4 & 0x0F) * 10) + (_byte7 & 0x0F);
            int byte8 = ((_byte8 >> 4 & 0x0F) * 10) + (_byte8 & 0x0F);
            downLevel=byte8*10000+byte7*100+byte6+byte5*0.01;
            Pair<Double, Double> doublePair = Pair.of(upLevel, downLevel);
            waterLevelAndLimit.add(doublePair);

        }
        this.waterWarnSpace = new byte[2];
        buffer.readBytes(this.waterWarnSpace);
        this.waterWarn = HexUtil.encodeHexStr(this.waterWarnSpace);
    }
}

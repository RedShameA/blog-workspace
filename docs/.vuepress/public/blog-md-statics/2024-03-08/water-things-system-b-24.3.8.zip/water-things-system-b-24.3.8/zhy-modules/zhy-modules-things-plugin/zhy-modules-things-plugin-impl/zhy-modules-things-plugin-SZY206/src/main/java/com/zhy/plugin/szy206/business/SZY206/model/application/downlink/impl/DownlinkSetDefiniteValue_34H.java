package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：34H-定值量设定
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetDefiniteValue_34H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._34.getFNCByte();
    }

    /**
     * 定量值
     */
    Long definiteValue;
    @Override
    public byte[] encode() {
        //首先补0，保持数字为10位
        String formattedLong = String.format("%010d", definiteValue);
        byte[] byteData=new byte[5];
        for (int i = 0; i < 5; i++) {
            int byte_num = Integer.parseInt(formattedLong.substring(10-i*2-2, 10-i*2));
            byteData[i]=(byte) ((byte_num / 10 << 4) | (byte_num % 10));
        }

        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, byteData,this.aux.encode());
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

/**
 * @Author：houDeJian
 * @Record：91_清空遥测终端历史数据单元(响应帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkSetClearHistoryData_91H extends ApplicationSpaceUplink {

    HashMap<String,Object> Data=new HashMap<>();

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        byte _byte = buffer.readByte();

        int D0= (_byte & 0b0000_0001);
        int D1= (_byte>>6 & 0b0100_0010);

        if(D0 > 1){
            Data.put("D0", "清空执行完毕");
        }else{
            Data.put("D0", "清空未执行");
        }
        if(D1 > 1){
            Data.put("D1", "清空执行完毕");
        }else{
            Data.put("D1", "清空未执行");
        }

    }

}

package com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.MessageContentDownlink;

/**
 * 下行报文 ACK报文，通知遥测站接收成功 <br>
 * 适用功能码：
 * @author wangfeng
 * @since 2023-06-28 11:09
 */
public class MessageContentDownlinkACK extends MessageContentDownlink {
    /**
     * 编码方法 <br>
     * ack的下行报文正文只有 [流水号] 和 [发报时间]
     */
    @Override
    public byte[] encode() {
        byte[] serialNumber = this.getSerialNumber();
        // 发报时间
        String yyyyMMddHHmmss = DateUtil.format(this.getMessageTimeParse(), "yyMMddHHmmss");
        this.setMessageTime(HexUtil.decodeHex(yyyyMMddHHmmss));
        byte[] messageTime = this.getMessageTime();
        return ArrayUtil.addAll(serialNumber, messageTime);
    }
}

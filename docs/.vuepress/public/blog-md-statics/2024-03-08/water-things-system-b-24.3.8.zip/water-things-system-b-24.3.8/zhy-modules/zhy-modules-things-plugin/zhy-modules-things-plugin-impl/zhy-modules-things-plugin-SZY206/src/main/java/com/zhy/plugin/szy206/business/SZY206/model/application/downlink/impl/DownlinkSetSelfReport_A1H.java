package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.SelfReport;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.lang.reflect.Field;

/**
 * @Author：houDeJian
 * @Record：A1H设置遥测站的数据自报种类及时间间隔
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetSelfReport_A1H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._A1.getFNCByte();
    }

    /**
     * 自报种类及时间间隔配置参数
     */
    SelfReport selfReport;

    @Override
    public byte[] encode() {
        byte[] selfReportType = byteData(selfReport);
        byte[] timeIntervalData = timeInterval(selfReport);
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, selfReportType, timeIntervalData, this.aux.encode());
    }

    public byte[] byteData(Object object) {
        byte[] array = new byte[2];
        try {
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);
                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val != null) {
                    String name = f.getName();
                    String s = name.split("D")[1];
                    //放在那个数组中
                    int n = Integer.parseInt(s) / 8;
                    //字节数组中的位置
                    int n1 = Integer.parseInt(s) % 8;
                    array[n] = (byte) (array[n] | (1 << 8 - n1 - 1));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return array;
    }

    public byte[] timeInterval(Object object) {
        byte[] timeIntervalValue = new byte[28];
        try {
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);
                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val != null) {
                    String name = f.getName();
                    int n = Integer.parseInt(name.split("D")[1]);
                    String replace = String.format("%0" + 4 + "d", val);
                    //去小数点
                    int byte1 = Integer.parseInt(replace.substring(replace.length() - 2, replace.length()));
                    int byte2 = Integer.parseInt(replace.substring(replace.length() - 4, replace.length() - 2));
                    byte _byte1 = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
                    byte _byte2 = (byte) ((byte2 / 10 << 4) | (byte2 % 10));
                    timeIntervalValue[n * 2] = _byte1;
                    timeIntervalValue[n * 2 + 1] = _byte2;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return timeIntervalValue;
    }


}

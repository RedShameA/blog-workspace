package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：32-定值控制投入
 */
public class DownlinkSetOpenValueControl_32H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._32.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode}, this.aux.encode());
    }
}

package com.zhy.plugin.sl651.business.SL651.handler;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * 自定义解码器，对SL651 2014水文协议进行解码
 *
 * @author yulei
 */
public class SL651_2014Decoder extends ByteToMessageDecoder {
    private static final Logger LOGGER = LoggerFactory.getLogger(SL651_2014Decoder.class);

    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext, ByteBuf in, List<Object> out) throws Exception {

        //将字节读到字节数组中
        byte[] bytes = new byte[in.readableBytes()];
        in.readBytes(bytes);

        int decodeIndex = 0;
        // 循环读取字节数据，直到读取完整个 ByteBuf 对象
        while (true) {
            //获取数据帧的起始索引
            int index = getIndex(bytes);

            //如果不包含开始字符，结束这次解包行为，因为输入的字节没有一个完整的包
            if (index == -1) {
                in.resetReaderIndex();
                break;
            }

            //往后读13个字节，第13个字节代表正文长度（每次都要重新计算正文的长度，因此可能每次正文都是不一样的）
            int contentLength = Byte.toUnsignedInt(bytes[12]);
            //计算数据帧的总长度，13表示从帧起始符到报文上下行标识符及长度共占用13个字节，1表示报文起始符占1字节，contentLength为正文字节数
            //第二个1为报文结束符，2为校验码长度，所以这个数据帧的总长度如下
            int total = 13 + 1 + contentLength + 1 + 2;
            if (total > bytes.length - index) {
                in.readerIndex(111);
                break;
            }

            ByteBuf byteBuf = Unpooled.copiedBuffer(bytes, index, total);
            out.add(byteBuf);
            if (index + total >= bytes.length) {
                break;
            }

            bytes = Arrays.copyOfRange(bytes, index + total, bytes.length);
            decodeIndex += total;
        }
    }

    /**
     * 获取到 0x7E, 0x7E 开头的字节数组的开始索引
     *
     * @param data 字节数组
     * @return 索引
     */
    private int getIndex(byte[] data) {
        byte[] searchBytes = new byte[]{0x7E, 0x7E};
        for (int i = 0; i < data.length; i++) {
            if (data[i] == searchBytes[0] && data[i + 1] == searchBytes[1]) {
                return i;
            }
        }
        return -1;
    }
}

package com.zhy.things.data.service;

import com.zhy.common.things.domain.ThingsDataHis;

import java.util.List;

/**
 * @author wangfeng
 * @since 2023-11-29 14:42
 */
public interface ThingsDataHisService {
    int insertThingsDataHis(ThingsDataHis record);
    void initTable();


    /**
     * 查询历史数据列表
     */
     List<ThingsDataHis> selectThingsDataHisList(ThingsDataHis record);


}

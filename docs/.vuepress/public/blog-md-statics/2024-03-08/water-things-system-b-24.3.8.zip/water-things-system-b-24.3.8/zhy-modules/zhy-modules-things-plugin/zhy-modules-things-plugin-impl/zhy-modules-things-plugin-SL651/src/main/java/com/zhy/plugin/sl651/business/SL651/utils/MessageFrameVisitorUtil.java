package com.zhy.plugin.sl651.business.SL651.utils;

import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.visitor.reply.MessageFrameReplyVisitor;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author wangfeng
 * @since 2023-07-05 09:22
 */
@Slf4j
@Component("MessageFrameVisitorUtilSL651")
public class MessageFrameVisitorUtil implements ApplicationContextAware {
    private static final Map<String, List<MessageFrameUseVisitor>> USE_VISITOR_MAP = new ConcurrentHashMap<>();

    private static final Map<String, MessageFrameReplyVisitor> REPLY_VISITOR_MAP = new ConcurrentHashMap<>();

    /**
     * 获取所有的visitor
     */
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

        Map<String, MessageFrameUseVisitor> use = applicationContext.getBeansOfType(MessageFrameUseVisitor.class);
        use.forEach((str, bean) -> {
            String functionCode = bean.getFunctionCode();
            List<MessageFrameUseVisitor> visitors = USE_VISITOR_MAP.getOrDefault(functionCode, new ArrayList<>(1));
            visitors.add(bean);
            USE_VISITOR_MAP.put(functionCode, visitors);
        });

        Map<String, MessageFrameReplyVisitor> reply = applicationContext.getBeansOfType(MessageFrameReplyVisitor.class);
        reply.forEach((str, bean) -> {
            String functionCode = bean.getFunctionCode();
            if (REPLY_VISITOR_MAP.get(functionCode) != null) {
                System.exit(1);
                log.error("error, reply visitor duplicated : [{}]", functionCode);
            }
            REPLY_VISITOR_MAP.put(functionCode, bean);
        });
    }

    /**
     * 调用visitor
     */
    public static void doVisit(String functionCode, ChannelHandlerContext ctx, MessageFrame frame) {
        List<MessageFrameUseVisitor> useVisitors = USE_VISITOR_MAP.getOrDefault(functionCode, new ArrayList<>(1));
        useVisitors.forEach(visitor -> {
            try {
                visitor.visit(ctx, frame);
            } catch (Exception ignored) {
            }
        });
        MessageFrameReplyVisitor replyVisitor = REPLY_VISITOR_MAP.get(functionCode);
        if (null != replyVisitor) {
            try {
                replyVisitor.doReply(ctx, frame);
            } catch (Exception ignored) {
            }
        }
    }
}

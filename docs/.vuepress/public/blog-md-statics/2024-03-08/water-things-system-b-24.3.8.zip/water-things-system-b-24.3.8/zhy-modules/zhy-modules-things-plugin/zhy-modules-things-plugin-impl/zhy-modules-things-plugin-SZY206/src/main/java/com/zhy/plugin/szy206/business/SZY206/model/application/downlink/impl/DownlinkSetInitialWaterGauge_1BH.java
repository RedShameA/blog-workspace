package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;

/**
 * @Author：houDeJian
 * @Record：1BH设置遥测站水量的表底初始值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetInitialWaterGauge_1BH extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode= AFN._1B.getFNCByte();
    }


    //水表初始值列表
    ArrayList<Long> initialWaterGaugeValue;
    @Override
    public byte[] encode() {
        byte[] array = new byte[initialWaterGaugeValue.size()*5];
        int n=0;
        for (Long aLong : initialWaterGaugeValue) {
            String formattedLong= String.format("%010d", aLong);
            int byte1 = Integer.parseInt(formattedLong.substring(8, 10));
            int byte2 = Integer.parseInt(formattedLong.substring(6, 8));
            int byte3 = Integer.parseInt(formattedLong.substring(4, 6));
            int byte4 = Integer.parseInt(formattedLong.substring(2, 4));
            int byte5 = Integer.parseInt(formattedLong.substring(0, 2));

            byte _byte1 = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
            array[n*5+0]=_byte1;
            byte _byte2 = (byte) ((byte2 / 10 << 4) | (byte2 % 10));
            array[n*5+1]=_byte2;
            byte _byte3 = (byte) ((byte3 / 10 << 4) | (byte3 % 10));
            array[n*5+2]=_byte3;
            byte _byte4 = (byte) ((byte4 / 10 << 4) | (byte4 % 10));
            array[n*5+3]=_byte4;
            byte _byte5 = (byte) ((byte5 / 10 << 4) | (byte5 % 10));
            array[n*5+4]=_byte5;
            n+=1;
        }

        return ArrayUtil.addAll(new byte[]{applicationFunctionCode},array, this.aux.encode());
    }
}

package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkInitializeData;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 初始化固态存储数据
 */
@Slf4j
@Component
public class InitializeDataFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkInitializeData> {
    @Override
    public String getFunctionCode() {
        return AppendixB._47.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("初始化固态存储数据visitor");
        MessageContentUplinkInitializeData content = getContent(frame);
        System.out.println(HexUtil.encodeHexStr(content.getMessageTime()));
    }
}

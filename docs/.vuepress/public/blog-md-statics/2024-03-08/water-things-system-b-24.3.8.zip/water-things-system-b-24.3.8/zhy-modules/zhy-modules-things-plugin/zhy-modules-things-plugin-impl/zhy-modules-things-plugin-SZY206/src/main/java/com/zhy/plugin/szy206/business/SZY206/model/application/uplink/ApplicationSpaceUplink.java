package com.zhy.plugin.szy206.business.SZY206.model.application.uplink;

import com.zhy.plugin.szy206.business.SZY206.model.application.ApplicationSpace;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 上行
 * @author wangfeng
 * @since 2023-09-07 14:32
 */
@Data
@EqualsAndHashCode(callSuper = true)
public abstract class ApplicationSpaceUplink extends ApplicationSpace {

    /**
     * 上行的编码方法 什么都不做
     */
    @Override
    public byte[] encode() {
        return null;
    }

    public ApplicationSpace decode(byte[] bytes) {
        this.content = bytes;
        this.decode();
        return this;
    }
}

package com.zhy.converter.mapper;

import java.util.Date;

import com.zhy.converter.domain.StRiverR;
import org.apache.ibatis.annotations.Param;

/**
* 
* 
* @author wangfeng
* @since 2023-11-28 15:59
*/
public interface StRiverRMapper {
    int deleteByPrimaryKey(@Param("tm") Date tm, @Param("stcd") String stcd);

    int insert(StRiverR record);

    int insertOrUpdate(StRiverR record);

    int insertSelective(StRiverR record);

    StRiverR selectByPrimaryKey(@Param("tm") Date tm, @Param("stcd") String stcd);

    int updateByPrimaryKeySelective(StRiverR record);

    int updateByPrimaryKey(StRiverR record);
}
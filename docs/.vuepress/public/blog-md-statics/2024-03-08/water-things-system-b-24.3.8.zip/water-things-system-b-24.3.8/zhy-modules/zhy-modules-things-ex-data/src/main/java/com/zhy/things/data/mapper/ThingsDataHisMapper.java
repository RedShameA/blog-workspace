package com.zhy.things.data.mapper;


import com.zhy.common.things.domain.ThingsDataHis;

import java.util.List;

/**
* @author wangfeng
* @since 2023-11-28 19:42
*/
public interface ThingsDataHisMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ThingsDataHis record);

    int insertSelective(ThingsDataHis record);

    ThingsDataHis selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ThingsDataHis record);

    int updateByPrimaryKey(ThingsDataHis record);
    List<ThingsDataHis> selectThingsDataHisList (ThingsDataHis record);

    void createTable();

}
package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：33-定值控制退出(响应帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkSetExitValueControl_33H extends ApplicationSpaceUplink {
    String message;

    /**
     * 是否成功
     */
    boolean success;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        byte _byte = buffer.readByte();
        success = (_byte & 0x5A) == 90;
    }
}

package com.zhy.plugin.szy206.business.SZY206.handler;

import com.zhy.plugin.core.entity.domain.plugin.PluginDeviceOnlineStatus;
import com.zhy.plugin.core.support.PluginContext;
import com.zhy.plugin.szy206.business.SZY206.utils.ChannelUtil206;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

/**
 * 连接断开事件
 * @author wangfeng
 * @since 2023-06-26 15:54
 */
public class ChannelInactiveHandler extends ChannelInboundHandlerAdapter {
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        String id = ChannelUtil206.getIdByChannel(ctx.channel());
        PluginContext.produceDeviceOnlineStatus(new PluginDeviceOnlineStatus(id,false));
        ChannelUtil206.removeChannel(ctx.channel());
        // StationUtil.removeOnline(id);
        super.channelInactive(ctx);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        String id = ChannelUtil206.getIdByChannel(ctx.channel());
        PluginContext.produceDeviceOnlineStatus(new PluginDeviceOnlineStatus(id,false));
        ChannelUtil206.removeChannel(ctx.channel());
        // StationUtil.removeOnline(id);
        super.exceptionCaught(ctx, cause);
    }
}

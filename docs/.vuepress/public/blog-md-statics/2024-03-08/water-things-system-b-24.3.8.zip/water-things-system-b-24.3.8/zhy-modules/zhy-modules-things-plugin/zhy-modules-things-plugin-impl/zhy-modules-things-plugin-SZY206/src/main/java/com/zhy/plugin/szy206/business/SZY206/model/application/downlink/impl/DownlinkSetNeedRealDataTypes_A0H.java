package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.RealTimeDataTypes;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.lang.reflect.Field;

/**
 * @Author：houDeJian
 * @Record：A0H设置遥测站需要查询的实时数据种类
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetNeedRealDataTypes_A0H extends ApplicationSpaceDownlink {
    /**
     * 实体类中其中元素：1-查询
     *               0-不查询
     */
    RealTimeDataTypes realTimeDataTypes=new RealTimeDataTypes();

    @Override
    public byte[] encode() {
        byte[] needSelfReporteTypes = byteData(realTimeDataTypes);
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode},needSelfReporteTypes, this.aux.encode());

    }

    
    public byte[] byteData(Object object) {
        byte[] array = new byte[2];
        try {
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);
                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val != null ||((Number)val).intValue()!=0) {
                    String name = f.getName();
                    String s = name.split("D")[1];
                    //放在那个数组中
                    int n = Integer.parseInt(s) / 8;
                    //字节数组中的位置
                    int n1 = Integer.parseInt(s) % 8;
                    array[n] = (byte) (array[n] | (1 << 8-n1 - 1));
                    System.out.println("数组："+array.toString());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return array;
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：56H 查询遥测站终端剩余水量和报警值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQuerySurplusWater_56H extends ApplicationSpaceUplink {

    /**
     * 剩余水量警报值
     */
    int waterWarn;

    /**
     * 剩余水量
     */
    int surplusWater;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // 警戒值
        byte _byte1 = buffer.readByte();
        byte _byte2 = buffer.readByte();
        byte _byte3 = buffer.readByte();
        // 剩余水量
        byte _byte5 = buffer.readByte();
        byte _byte6 = buffer.readByte();
        byte _byte7 = buffer.readByte();
        byte _byte8 = buffer.readByte();
        byte _byte9 = buffer.readByte();

        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
        this.waterWarn = byte3 * 10000 + byte2 * 100 + byte1;

        int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
        int byte6 = ((_byte6 >> 4 & 0x0F) * 10) + (_byte6 & 0b0000_1111);
        int byte7 = ((_byte7 >> 4 & 0x0F) * 10) + (_byte7 & 0b0000_1111);
        int byte8 = ((_byte8 >> 4 & 0x0F) * 10) + (_byte8 & 0b0000_1111);
        int byte9 = ((_byte9 >> 4 & 0x07) * 10) + (_byte9 & 0b0000_1111);
        // 判断正负号-根据byte9的第一位
        int sign = (_byte9 >> 7 & 0x01) == 0 ? 1 : -1;
        this.surplusWater = sign * byte9 * 100000000 + byte8 * 1000000 + byte7 * 10000 + byte6 * 100 + byte5;
    }
}

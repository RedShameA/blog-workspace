package com.zhy.plugin.szy206.business.SZY206.controller;

import com.zhy.plugin.szy206.business.SZY206.model.MessageFrame;
import com.zhy.plugin.szy206.business.SZY206.utils.DownlinkUtil;
import com.zhy.plugin.szy206.business.SZY206.utils.WaitForResultUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangfeng
 * @since 2023-10-11 9:48
 */
@RestController
@RequestMapping("/206")
public class BizController {

    @GetMapping("/50H")
    public MessageFrame _50HQueryAddress(String stationId) throws IllegalAccessException {
        MessageFrame frame = DownlinkUtil.get50HQueryAddressFrame(stationId);
        return WaitForResultUtil.sendAndWait(frame, 10);
    }

    // todo 这个160设备不支持，一发报文就卡死
    @GetMapping("/91H")
    public MessageFrame _91HSetClearHistoryData(String stationId, boolean rain, boolean waterLevel) throws IllegalAccessException {
        MessageFrame frame = DownlinkUtil.get91HResetTelemetryStationFrame(stationId, rain, waterLevel);
        return WaitForResultUtil.sendAndWait(frame, 10);
    }
}

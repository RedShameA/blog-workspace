package com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.MessageContentDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 查询遥测站配置表
 * @author wangfeng
 * @since 2023/8/27 17:35
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentDownlinkQuerySettings extends MessageContentDownlink {
    String[] settingTags;
    @Override
    public byte[] encode() {
        byte[] bytes = new byte[0];
        byte[] serialNumber = this.getSerialNumber();
        // 发报时间
        String yyyyMMddHHmmss = DateUtil.format(this.getMessageTimeParse(), "yyMMddHHmmss");
        this.setMessageTime(HexUtil.decodeHex(yyyyMMddHHmmss));
        byte[] messageTime = this.getMessageTime();
        bytes = ArrayUtil.addAll(bytes, serialNumber);
        bytes = ArrayUtil.addAll(bytes, messageTime);
        for (String settingTag : settingTags) {
            bytes = ArrayUtil.addAll(bytes, HexUtil.decodeHex(settingTag));
        }
        return bytes;
    }
}

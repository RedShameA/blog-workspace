package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：54H 查询遥测站需查询的实时数据种类
 */
public class DownlinkQueryRealDataType_54H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._54.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{applicationFunctionCode};
    }
}

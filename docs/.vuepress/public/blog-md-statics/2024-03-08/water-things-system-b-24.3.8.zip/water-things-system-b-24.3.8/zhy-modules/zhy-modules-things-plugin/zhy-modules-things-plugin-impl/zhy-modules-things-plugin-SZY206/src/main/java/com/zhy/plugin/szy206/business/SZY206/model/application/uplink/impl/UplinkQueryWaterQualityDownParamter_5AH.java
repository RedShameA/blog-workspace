package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.WaterQualityParameter_Enum;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.WaterQualityParameter;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;

/**
 * @Author：houDeJian
 * @Record：59H-查询遥测终端水质参数种类、下限值（响应帧）
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryWaterQualityDownParamter_5AH extends ApplicationSpaceUplink {
    /**
     * 水质参数实体类
     */
    WaterQualityParameter waterQualityParameter = new WaterQualityParameter();

    @SneakyThrows
    @Override
    public void decode() {

        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        byte[] parameter = new byte[5];
        buffer.readBytes(parameter);
        //怎么判断一个字节的八位中那些不为0
        for (int y = 0; y < 5; y++) {
            for (int i = 0; i <= 7; i++) {
                byte mask = (byte) (1 << i);
                if ((parameter[y] & mask) != 0) {
                    //拼接水质元素名字
                    String parameterName = "D" + (8 * y + i);
                    if (8 * y + i == 24) {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        byte _byte5 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
                        Double value = (double) (byte5 * 100000000 + byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                        waterQualityParameter.setParameterValue(parameterName, value);
                    } else if (8 * y + i == 4) {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        Double value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                        waterQualityParameter.setParameterValue(parameterName, value);
                    } else {
                        if (8 * y + i < 37) {
                            byte _byte1 = buffer.readByte();
                            byte _byte2 = buffer.readByte();
                            byte _byte3 = buffer.readByte();
                            byte _byte4 = buffer.readByte();
                            int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                            int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                            int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                            int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                            Integer decimalPlaces = WaterQualityParameter_Enum.getRight(parameterName);
                            double result = Math.pow(0.1, decimalPlaces);
                            Double value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1) * result;
                            waterQualityParameter.setParameterValue(parameterName, value);
                        }
                    }
                    System.out.println("D" + (8 * y + i) + " 不为0");

                }

            }
        }
    }
}

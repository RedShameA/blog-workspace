package com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.MessageContentDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 修改遥测站配置表
 * @author wangfeng
 * @since 2023-08-01 11:23
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentDownlinkSetSettings extends MessageContentDownlink {

    String settingTag;
    byte[] settingData;


    @Override
    public byte[] encode() {
        byte[] bytes = new byte[0];
        byte[] serialNumber = this.getSerialNumber();
        // 发报时间
        String yyyyMMddHHmmss = DateUtil.format(this.getMessageTimeParse(), "yyMMddHHmmss");
        this.setMessageTime(HexUtil.decodeHex(yyyyMMddHHmmss));
        byte[] messageTime = this.getMessageTime();
        bytes = ArrayUtil.addAll(bytes, serialNumber);
        bytes = ArrayUtil.addAll(bytes, messageTime);
        bytes = ArrayUtil.addAll(bytes, HexUtil.decodeHex(settingTag));
        bytes = ArrayUtil.addAll(bytes, settingData);
        return bytes;
    }
}

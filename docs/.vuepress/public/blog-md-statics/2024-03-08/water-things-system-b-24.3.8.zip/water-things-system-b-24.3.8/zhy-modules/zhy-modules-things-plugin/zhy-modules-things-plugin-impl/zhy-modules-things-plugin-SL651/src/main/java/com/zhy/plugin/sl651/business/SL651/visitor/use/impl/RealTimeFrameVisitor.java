package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixC;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkRealTime;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;

/**
 * 处理实时报
 */
@Slf4j
@Component
public class RealTimeFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkRealTime> {
    @Override
    public String getFunctionCode() {
        return AppendixB._37.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("实时报visitor");
        MessageContentUplinkRealTime messageContentUplinkRealTime = getContent(frame);
        Map<String, Double> doubleMap = messageContentUplinkRealTime.getDoubleMap();
        Date collectTimeParse = messageContentUplinkRealTime.getCollectTimeParse();
        Double aDouble = doubleMap.get(AppendixC._38.getHEX());
        Double aDouble1 = doubleMap.get(AppendixC._20.getHEX());
        Double aDouble2 = doubleMap.get(AppendixC._26.getHEX());
        Double aDouble3 = doubleMap.get(AppendixC._39.getHEX());
        System.out.println(collectTimeParse);
        System.out.println(aDouble);
        System.out.println(aDouble1);
        System.out.println(aDouble2);
        System.out.println(aDouble3);
        // reply

    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application._AUX;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 10H 设置遥测终端、中继站 地址
 *
 * @author wangfeng
 * @since 2023-09-08 17:04
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkSetAddress_10H extends ApplicationSpaceUplink {


    byte[] addressSpace;
    /**
     * 地址
     */
    String address;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // address
        this.addressSpace = new byte[5];
        buffer.readBytes(this.addressSpace);
        this.address = HexUtil.encodeHexStr(this.addressSpace);
        // aux
        _AUX aux = new _AUX();
        buffer.readBytes(aux.getContent());
        aux.decode();
        this.aux = aux;
    }
}

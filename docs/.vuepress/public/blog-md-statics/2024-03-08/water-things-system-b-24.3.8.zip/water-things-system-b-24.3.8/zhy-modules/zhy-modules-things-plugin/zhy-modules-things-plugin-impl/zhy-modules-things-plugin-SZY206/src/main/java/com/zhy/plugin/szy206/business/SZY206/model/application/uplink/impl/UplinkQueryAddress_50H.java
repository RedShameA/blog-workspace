package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Since 2023/9/27
 * @Author：houDeJian
 * @Record：50H 查询遥测终端、中继站 地址(响应帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryAddress_50H extends ApplicationSpaceUplink {

    /**
     * 返回的遥测终端、中继站 地址
     */
    String address;

    @Override
    public void decode() {
        ByteBuf byteBuf = Unpooled.wrappedBuffer(this.content);
        this.applicationFunctionCode = byteBuf.readByte();
        byte[] addressSpace = new byte[5];
        byteBuf.readBytes(addressSpace);
        this.address = HexUtil.encodeHexStr(addressSpace);
    }
}

package com.zhy.plugin.szy206.business.SZY206.handler;

import com.zhy.plugin.szy206.business.SZY206.model.MessageFrame;
import com.zhy.plugin.szy206.business.SZY206.utils.MessageFrameVisitorUtil;
import com.zhy.plugin.szy206.business.SZY206.utils.WaitForResultUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import lombok.extern.slf4j.Slf4j;

/**
 * 在netty链路中处理解码成功的对象
 * @author wangfeng
 * @since 2023-07-04 17:32
 */
@Slf4j
public class DealingHandler extends SimpleChannelInboundHandler<MessageFrame> {
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, MessageFrame messageFrame) {
        // log.info("获取到了一个解码成功的对象");
        byte applicationFunctionCode = messageFrame.getApplicationSpace().getApplicationFunctionCode();
        MessageFrameVisitorUtil.doVisit(applicationFunctionCode, ctx, messageFrame);
        WaitForResultUtil.fireResult(messageFrame);
        WaitForResultUtil.fireFirstInResult(messageFrame);
    }
}

package com.zhy.things.web.controller;

import com.alibaba.fastjson2.JSONObject;
import com.zhy.common.annotation.Log;
import com.zhy.common.core.controller.BaseController;
import com.zhy.common.core.domain.AjaxResult;
import com.zhy.common.core.page.TableDataInfo;
import com.zhy.common.enums.BusinessType;
import com.zhy.things.common.constants.StationType;
import com.zhy.things.common.constants.ValueType;
import com.zhy.common.utils.poi.ExcelUtil;
import com.zhy.plugin.core.entity.domain.device.ThingsDevice;
import com.zhy.plugin.core.entity.domain.product.ThingsProduct;
import com.zhy.plugin.core.entity.dto.ThingsDeviceDto;
import com.zhy.plugin.core.support.PluginSupport;
import com.zhy.plugin.store.DeviceStatusStore;
import com.zhy.plugin.store.PluginStatusStore;
import com.zhy.plugin.util.TimeOutUtil;
import com.zhy.things.web.service.IThingsDeviceService;
import com.zhy.things.web.service.IThingsProductService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

import static com.zhy.plugin.constants.DeviceConstant.HEARTBEAT_TIMEOUT_SECONDS;

/**
 * @author wangfeng
 * @since 2023-11-09 19:53
 */
@RestController
@RequestMapping("/things/device")
public class ThingsDeviceController extends BaseController {
    @Resource
    private IThingsDeviceService thingsDeviceService;
    @Resource
    private IThingsProductService thingsProductService;

    @Log(title = "用户管理", businessType = BusinessType.IMPORT)
    @PreAuthorize("@ss.hasPermi('things:device:import')")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file) throws Exception
    {
        ExcelUtil<ThingsDevice> util = new ExcelUtil<>(ThingsDevice.class);
        List<ThingsDevice> deviceList = util.importExcel(file.getInputStream());
        // 继承产品物模型
        deviceList.forEach(thingsDevice -> {
            ThingsProduct thingsProduct = thingsProductService.selectThingsProductById(thingsDevice.getProductId());
            if (null==thingsProduct) return;
            String metaData = thingsProduct.getMetaData();
            thingsDevice.setMetadata(metaData);
        });
        String operName = getUsername();
        String message = thingsDeviceService.importDevice(deviceList, operName);
        return success(message);
    }
    @PreAuthorize("@ss.hasPermi('things:device:import')")
    @PostMapping("/importTemplate")
    public void importTemplate(HttpServletResponse response)
    {
        ExcelUtil<ThingsDevice> util = new ExcelUtil<>(ThingsDevice.class);
        util.importTemplateExcel(response, "设备数据");
    }
    @PreAuthorize("@ss.hasPermi('things:device:use')")
    @PostMapping("/use")
    public AjaxResult use(@RequestBody Map<String, Object> params) {
        String deviceId = (String) params.get("deviceId");
        String function = (String) params.get("function");
        String param = (String) params.get("param");
        // 先根据deviceId获取productId
        ThingsDevice thingsDevice = thingsDeviceService.selectThingsDeviceById(deviceId);
        // 判断设备是否在线
        // Date validateHeartBeatTime = new Date(new Date().getTime() - HEARTBEAT_TIMEOUT_SECONDS * 1000);
        // boolean online = false;
        // if (null != thingsDevice.getHeartbeatTime()) {
        //     online = (validateHeartBeatTime.before(thingsDevice.getHeartbeatTime()));
        // }
        // if (!online) {
        //     return warn("设备不在线");
        // }
        // 再根据productId获取pluginSupport
        ThingsProduct thingsProduct = thingsProductService.selectThingsProductById(thingsDevice.getProductId());
        PluginSupport pluginSupport = PluginStatusStore.getPluginSupport(thingsProduct.getProtocol());
        if (null == pluginSupport) {
            return warn("操作失败");
        }
        // 获取功能方法
        BiFunction<String, String, String> functionInstance = pluginSupport.getFunction(function);
        if (null == functionInstance) {
            return warn("功能不支持:" + function);
        }
        try {
            String s = TimeOutUtil.RunTimeOutString(() -> functionInstance.apply(thingsDevice.getDeviceId(), param), 8 * 1000).orElse("等待报文回复超时");
            return success(s);
        }catch (Exception e){
            return warn(e.getMessage());
        }

    }

    /**
     * 查询device列表
     */
    @PreAuthorize("@ss.hasPermi('things:device:list')")
    @GetMapping("/listStationTypes")
    public AjaxResult listStationTypes() {
        List<JSONObject> collect = Arrays.stream(StationType.values()).map(JSONObject::from).collect(Collectors.toList());
        return success(collect);
    }

    /**
     * 查询device列表
     */
    @PreAuthorize("@ss.hasPermi('things:device:list')")
    @GetMapping("/list")
    @SuppressWarnings({"unchecked"})
    public TableDataInfo list(ThingsDeviceDto thingsDeviceDto) {
        startPage();
        Date validateHeartBeatTime = new Date(new Date().getTime() - HEARTBEAT_TIMEOUT_SECONDS * 1000);
        if (null != thingsDeviceDto.getOnline()) {
            if (!thingsDeviceDto.getOnline()) {
                // 查不在线
                thingsDeviceDto.setHeartbeatTime(new Date(new Date().getTime() + HEARTBEAT_TIMEOUT_SECONDS * 1000));
            } else {
                // 查在线(心跳时间大于指定多少秒前)
                thingsDeviceDto.setHeartbeatTime(validateHeartBeatTime);
            }
        }
        // 查询无心跳时间
        List<ThingsDevice> list = thingsDeviceService.selectThingsDeviceList(thingsDeviceDto);
        TableDataInfo dataTable = getDataTable(list);
        dataTable.setRows(
                ((List<ThingsDevice>) dataTable.getRows())
                        .stream()
                        .map(ThingsDeviceDto::fromThingsDevice)
                        .peek(e -> {
                            if (null == e.getHeartbeatTime()) {
                                e.setOnline(false);
                            } else {
                                e.setOnline(validateHeartBeatTime.before(e.getHeartbeatTime()));
                            }
                        })
                        .collect(Collectors.toList())
        );
        return dataTable;
    }

    /**
     * 导出device列表
     */
    @PreAuthorize("@ss.hasPermi('things:device:export')")
    @Log(title = "device", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ThingsDeviceDto thingsDeviceDto) {
        List<ThingsDevice> list = thingsDeviceService.selectThingsDeviceList(thingsDeviceDto);
        ExcelUtil<ThingsDevice> util = new ExcelUtil<>(ThingsDevice.class);
        util.exportExcel(response, list, "device数据");
    }

    /**
     * 获取device详细信息
     */
    @PreAuthorize("@ss.hasPermi('things:device:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id) {
        ThingsDevice device = thingsDeviceService.selectThingsDeviceById(id);
        ThingsProduct product = thingsProductService.selectThingsProductById(device.getProductId());
        return success(ThingsDeviceDto.fromThingsDeviceAndProduct(device, product));
    }

    /**
     * 获取device可配置的属性
     */
    @PreAuthorize("@ss.hasPermi('things:device:query')")
    @GetMapping(value = "/getSupportedValueTypes/{id}")
    public AjaxResult getSupportedValueTypes(@PathVariable("id") String id) {
        List<ValueType> valueTypes = Optional.ofNullable(thingsDeviceService.selectThingsDeviceById(id))
                .map(thingsDevice -> thingsProductService.selectThingsProductById(thingsDevice.getProductId()))
                .map(ThingsProduct::getProtocol)
                .map(PluginStatusStore::getPluginSupportedValueTypes)
                .orElse(new ArrayList<>());
        return success(valueTypes);
    }

    /**
     * 新增device
     */
    @PreAuthorize("@ss.hasPermi('things:device:add')")
    @Log(title = "device", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ThingsDeviceDto thingsDeviceDto) {
        ThingsDevice selected = thingsDeviceService.selectThingsDeviceById(thingsDeviceDto.getDeviceId());
        if (null != selected) {
            return warn("设备编号与已存在设备重复，请检查");
        }
        // 继承产品物模型
        // ThingsProduct thingsProduct = thingsProductService.selectThingsProductById(thingsDevice.getProductId());
        // String metaData = thingsProduct.getMetaData();
        // thingsDevice.setMetadata(metaData);
        thingsDeviceDto.setCreateBy(getUsername());
        ThingsDevice thingsDevice = thingsDeviceDto.toThingsDevice();
        int i = thingsDeviceService.insertThingsDevice(thingsDevice);
        DeviceStatusStore.addDevice(thingsDevice);
        return toAjax(i);
    }

    /**
     * 修改device
     */
    @PreAuthorize("@ss.hasPermi('things:device:edit')")
    @Log(title = "device", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ThingsDeviceDto thingsDeviceDto) {
        ThingsDevice thingsDevice = thingsDeviceDto.toThingsDevice();
        thingsDevice.setUpdateBy(getUsername());
        DeviceStatusStore.removeDevice(thingsDevice.getDeviceId());
        DeviceStatusStore.addDevice(thingsDevice);
        return toAjax(thingsDeviceService.updateThingsDevice(thingsDevice));
    }

    /**
     * 删除device
     */
    @PreAuthorize("@ss.hasPermi('things:device:remove')")
    @Log(title = "device", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids) {
        int i = thingsDeviceService.deleteThingsDeviceByIds(ids);
        Arrays.stream(ids).forEach(DeviceStatusStore::removeDevice);
        return toAjax(i);
    }
}

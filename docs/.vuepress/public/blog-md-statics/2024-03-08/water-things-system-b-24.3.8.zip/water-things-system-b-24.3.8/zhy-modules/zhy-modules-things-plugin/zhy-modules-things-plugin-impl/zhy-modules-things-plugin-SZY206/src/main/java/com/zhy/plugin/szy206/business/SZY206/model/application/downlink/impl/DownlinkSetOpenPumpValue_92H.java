package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

/**
 * @Author：houDeJian
 * @Record：92H-遥控启动水泵或阀门/闸门
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetOpenPumpValue_92H extends ApplicationSpaceDownlink {
    /**
     * code:编号
     * type:类别-0:水泵
     * 1：阀门/闸门
     */
    HashMap<String, Integer> Data;

    {
        this.applicationFunctionCode = AFN._92.getFNCByte();
    }

    @Override
    public byte[] encode() {
        //水泵/水闸编号
        Integer code = Data.get("code");
        //水泵/水闸类别
        int byte1 = Data.get("type") == 0 ? 0 : 16;
        byte _byte1 = (byte) (((code / 10) << 4) | byte1);
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode, _byte1}, this.aux.encode());
    }
}

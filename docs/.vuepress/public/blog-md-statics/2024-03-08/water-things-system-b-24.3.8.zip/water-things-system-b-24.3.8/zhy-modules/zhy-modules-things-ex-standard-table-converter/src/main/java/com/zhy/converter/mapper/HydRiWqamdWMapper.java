package com.zhy.converter.mapper;

import java.util.Date;

import com.zhy.converter.domain.HydRiWqamdW;
import org.apache.ibatis.annotations.Param;

/**
* 
* 
* @author wangfeng
* @since 2023-11-28 16:29
*/
public interface HydRiWqamdWMapper {
    int deleteByPrimaryKey(@Param("spt") Date spt, @Param("stcd") String stcd);

    int insert(HydRiWqamdW record);

    int insertOrUpdate(HydRiWqamdW record);

    int insertSelective(HydRiWqamdW record);

    HydRiWqamdW selectByPrimaryKey(@Param("spt") Date spt, @Param("stcd") String stcd);

    int updateByPrimaryKeySelective(HydRiWqamdW record);

    int updateByPrimaryKey(HydRiWqamdW record);
}
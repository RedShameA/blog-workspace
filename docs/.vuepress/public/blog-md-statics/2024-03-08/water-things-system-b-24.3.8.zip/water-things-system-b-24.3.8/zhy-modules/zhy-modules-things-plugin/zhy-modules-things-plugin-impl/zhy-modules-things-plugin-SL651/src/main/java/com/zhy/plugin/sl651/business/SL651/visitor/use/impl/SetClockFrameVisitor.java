package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkSetClock;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SetClockFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkSetClock> {
    @Override
    public String getFunctionCode() {
        return AppendixB._4A.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("设置遥测站时钟报");
        MessageContentUplinkSetClock content = getContent(frame);
        System.out.println(HexUtil.encodeHex(content.getMessageTime()));
    }
}

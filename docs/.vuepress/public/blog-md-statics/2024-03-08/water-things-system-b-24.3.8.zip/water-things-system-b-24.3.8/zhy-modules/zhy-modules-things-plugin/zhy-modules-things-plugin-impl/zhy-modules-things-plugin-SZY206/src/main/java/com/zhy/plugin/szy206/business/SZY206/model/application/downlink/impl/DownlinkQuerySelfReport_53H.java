package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：53H-查询遥测终端的数据自报种类及时间
 */
public class DownlinkQuerySelfReport_53H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._53.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

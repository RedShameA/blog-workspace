package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 15H 设置遥测站终端的本次充值量
 *
 * @author houDeJian
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetCharge_15H extends ApplicationSpaceDownlink {

    {
        applicationFunctionCode = AFN._15.getFNCByte();
    }

    /**
     * 本次充值量: 0～99999999
     */
    private int change;

    @Override
    public byte[] encode() {
        if (change > 0 && change < 99999999) {
            byte[] arr = new byte[4];
            String changeString = String.format("%08d", change);
            int byte1 = Integer.parseInt(changeString.substring(6, 8));
            int byte2 = Integer.parseInt(changeString.substring(4, 6));
            int byte3 = Integer.parseInt(changeString.substring(2, 4));
            int byte4 = Integer.parseInt(changeString.substring(0, 2));
            arr[0] = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
            arr[1] = (byte) ((byte2 / 10 << 4) | (byte2 % 10));
            arr[2] = (byte) ((byte3 / 10 << 4) | (byte3 % 10));
            arr[3] = (byte) ((byte4 / 10 << 4) | (byte4 % 10));
            return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, arr, this.aux.encode());
        } else {
            throw new RuntimeException("输入的数据不在取值范围内！");
        }


    }

}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.SwitchStatus;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：1Eh-设置中继站工作机自动切换、自报的状态
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetSwitchStatus_1EH extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._1E.getFNCByte();
    }
    SwitchStatus switchStatus;
    @Override
    public byte[] encode() {

        byte _byte1 = (byte) ((switchStatus.getD0())
                | (switchStatus.getD0()<<1)
                | (switchStatus.getD1()<<2)
                | (switchStatus.getD1()<<3)
                | (switchStatus.getD2()<<4)
                | (switchStatus.getD3()<<5)
                | (switchStatus.getD4()<<6));
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode,_byte1}, this.aux.encode());

    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：52查询遥测终端的工作模式
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryWorkMode_52H extends ApplicationSpaceDownlink {
    //设置功能码
    {
        applicationFunctionCode = AFN._52.getFNCByte();
    }

    //编码
    @Override
    public byte[] encode() {
        return new byte[]{applicationFunctionCode};
    }
}

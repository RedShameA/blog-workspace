package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：96H_修改遥测终端密码
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetPassword_96H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._96.getFNCByte();
    }

    /**
     * 密码
     */
    int password;

    @Override
    public byte[] encode() {
        byte[] array = new byte[2];
        String formattedLong = String.format("%04d", password);
        int byte1 = Integer.parseInt(formattedLong.substring(2, 4));
        int byte2 = Integer.parseInt(formattedLong.substring(0, 2));
        byte _byte1 = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
        array[0] = _byte1;
        byte _byte2 = (byte) ((byte2 / 10 << 4) | (byte2 % 10));
        array[1] = _byte2;

        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode}, array, this.aux.encode());

    }
}

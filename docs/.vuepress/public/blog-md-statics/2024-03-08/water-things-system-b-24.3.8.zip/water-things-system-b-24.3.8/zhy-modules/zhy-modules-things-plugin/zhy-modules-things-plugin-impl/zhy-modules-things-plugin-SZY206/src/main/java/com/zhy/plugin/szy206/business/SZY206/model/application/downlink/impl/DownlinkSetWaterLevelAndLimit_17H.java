package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.tuple.Triple;

import java.util.ArrayList;

/**
 * @Author：houDeJian
 * @Record：17H-设置水位基本水位、水位上限和下限
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetWaterLevelAndLimit_17H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._17.getFNCByte();
    }

    /**
     * 设置参数<br/>
     * left:水位基值,middle:上限水位,right:下限水位
     */
    ArrayList<Triple<Double, Double, Double>> waterLevelAndLimit;

    @Override
    public byte[] encode() {
        byte[] array = new byte[waterLevelAndLimit.size()*7];
        int n=0;
        for (Triple<Double, Double, Double> doubleDoubleDoubleTriple : waterLevelAndLimit) {
            Double left = doubleDoubleDoubleTriple.getLeft();
            Double middle = doubleDoubleDoubleTriple.getMiddle();
            Double right = doubleDoubleDoubleTriple.getRight();
            // 格式化双精度浮点数
            String formattedLeft1 = String.format("%07.2f",left);
            String formattedLeft = formattedLeft1.replace(".", "");
            int sign = left > 0 ? 0 : 1;
            int byte1 = Integer.parseInt(formattedLeft.substring(4, 6));
            int byte2 = Integer.parseInt(formattedLeft.substring(2, 4));
            int byte3 = Integer.parseInt(formattedLeft.substring(0, 2));
            byte _byte1 = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
            byte _byte2 = (byte) ((byte2 / 10 << 4) | (byte2 % 10));
            byte _byte3 = (byte) ((sign << 7) | (byte3 / 10 << 4) | (byte3 % 10));
            array[n*7+0]=_byte1;
            array[n*7+1]=_byte2;
            array[n*7+2]=_byte3;
            //水位下限
            String formattedMiddle1 = String.format("%05.2f", middle);
            String formattedMiddle = formattedMiddle1.replace(".", "");
            int byte4 = Integer.parseInt(formattedMiddle.substring(2, 4));
            int byte5 = Integer.parseInt(formattedMiddle.substring(0, 2));
            byte _byte4 = (byte) ((byte4 / 10 << 4) | (byte4 % 10));
            byte _byte5 = (byte) ((byte5 / 10 << 4) | (byte5 % 10));
            array[n*7+3]=_byte4;
            array[n*7+4]=_byte5;
            //水位上限制
            String formattedRight1 = String.format("%05.2f", right);
            String formattedRight = formattedRight1.replace(".", "");
            int byte6 = Integer.parseInt(formattedRight.substring(formattedRight.length() - 2, formattedRight.length()));
            int byte7 = Integer.parseInt(formattedRight.substring(formattedRight.length() - 4, formattedRight.length() - 2));
            byte _byte6 = (byte) ((byte6 / 10 << 4) | (byte6 % 10));
            byte _byte7 = (byte) ((byte7 / 10 << 4) | (byte7 % 10));
            array[n*7+5]=_byte6;
            array[n*7+6]=_byte7;
            n+=1;
        }
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode},array, this.aux.encode());
    }
}

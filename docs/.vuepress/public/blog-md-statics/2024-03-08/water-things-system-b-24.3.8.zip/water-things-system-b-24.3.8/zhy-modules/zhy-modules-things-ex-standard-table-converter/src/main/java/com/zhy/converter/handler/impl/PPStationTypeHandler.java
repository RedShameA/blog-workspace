package com.zhy.converter.handler.impl;

import com.zhy.things.common.constants.StationType;
import com.zhy.things.common.constants.ValueType;
import com.zhy.common.things.domain.StandardMessage;
import com.zhy.converter.domain.StPptnR;
import com.zhy.converter.handler.StationTypeHandler;
import com.zhy.converter.mapper.StPptnRMapper;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author wangfeng
 * @since 2023-11-24 11:08
 */
@Component
public class PPStationTypeHandler implements StationTypeHandler {
    @Override
    public StationType getSupportedStationType() {
        return StationType.PP;
    }

    @Resource
    StPptnRMapper stPptnRMapper;

    @Override
    public void handle(ValueType valueType, StandardMessage standardMessage) {
        StPptnR stPptnR = new StPptnR();
        stPptnR.setTm(standardMessage.getMessageTime());
        stPptnR.setStcd(standardMessage.getDeviceId());
        switch (valueType){
            // 降水量表
            case RAIN_IN_1H:
                stPptnR.setDrp(standardMessage.getMessageValue());
                stPptnR.setIntv(1D);
                stPptnRMapper.insertOrUpdate(stPptnR);
                break;
            default:
        }
    }
}

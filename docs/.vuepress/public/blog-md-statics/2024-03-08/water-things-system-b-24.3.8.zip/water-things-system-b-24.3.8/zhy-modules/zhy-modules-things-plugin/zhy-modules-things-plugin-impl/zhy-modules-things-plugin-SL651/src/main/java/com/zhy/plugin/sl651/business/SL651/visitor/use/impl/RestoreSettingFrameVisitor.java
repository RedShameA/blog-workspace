package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkRestoreSetting;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 *恢复遥测站出厂报
 */

@Slf4j
@Component
public class RestoreSettingFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkRestoreSetting> {
    @Override
    public String getFunctionCode() {
        return AppendixB._48.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("恢复遥测站出厂设置visitor");
        MessageContentUplinkRestoreSetting content = getContent(frame);
        System.out.println("getStation" + Arrays.toString(HexUtil.encodeHex(content.getStation())));
    }
}

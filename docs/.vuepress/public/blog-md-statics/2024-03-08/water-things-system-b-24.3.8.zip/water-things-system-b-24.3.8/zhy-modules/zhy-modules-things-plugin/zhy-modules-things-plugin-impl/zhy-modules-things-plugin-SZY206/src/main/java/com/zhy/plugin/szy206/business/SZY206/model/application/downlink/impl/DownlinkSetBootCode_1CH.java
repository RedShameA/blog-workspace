package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：1CH-设置终端站转发中继引导码长值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetBootCode_1CH extends ApplicationSpaceDownlink {
    {
        applicationFunctionCode = AFN._1C.getFNCByte();
    }

    int code;

    @Override
    public byte[] encode() {
        if (code < 255 || code > 0) {
            byte _byte1 = (byte) ((code / 10 << 4) | (code % 10));
            byte[] bytes = {applicationFunctionCode, _byte1};
            return ArrayUtil.addAll(bytes, this.aux.encode());
        } else {
            throw new RuntimeException("参数不在要求范围内");
        }
    }
}

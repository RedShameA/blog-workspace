package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Calendar;
import java.util.Date;

/**
 * @author: 周志浩
 * @Record: B2H查询指定日期区间内自报失败的终端内存自报数据
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryTerminalMemorySelfReportedData_B2H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._B2.getFNCByte();
    }

    /**
     * 起止时间
     * Pair配对：
     * left:开始时间，right:结束时间
     */
    Pair<Date, Date> queryDate;



    @Override
    public byte[] encode() {
        // 开始时间
        Calendar instance = Calendar.getInstance();
        instance.setTime(this.queryDate.getLeft());
        int minute = instance.get(Calendar.MINUTE);
        int hour = instance.get(Calendar.HOUR_OF_DAY);
        int day = instance.get(Calendar.DAY_OF_MONTH);
        int month = instance.get(Calendar.MONTH) + 1;

        byte _strMINUTE = (byte) ((minute / 10 << 4) | (minute % 10));
        byte _strHOUR = (byte) ((hour / 10 << 4) | (hour % 10));
        byte _strDAY = (byte) ((day / 10 << 4) | (day % 10));
        byte _strMONTH = (byte) ((month / 10 << 4) | (month % 10));
        // 结束时间
        Calendar instance1 = Calendar.getInstance();
        instance1.setTime(this.queryDate.getRight());
        int minute1 = instance.get(Calendar.MINUTE);
        int hour1 = instance.get(Calendar.HOUR_OF_DAY);
        int day1 = instance.get(Calendar.DAY_OF_MONTH);
        int month1 = instance.get(Calendar.MONTH) + 1;

        byte _endMINUTE = (byte) ((minute1 / 10 << 4) | (minute1 % 10));
        byte _endHOUR = (byte) ((hour1 / 10 << 4) | (hour1 % 10));
        byte _endDAY = (byte) ((day1 / 10 << 4) | (day1 % 10));
        byte _endMONTH = (byte) ((month1 / 10 << 4) | (month1 % 10));

        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode, _strMINUTE, _strHOUR, _strDAY, _strMONTH, _endMINUTE, _endHOUR, _endDAY, _endMONTH});
    }
}

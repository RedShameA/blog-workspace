package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

/**
 * @Author：houDeJian
 * @Record：94-遥控终端或中继站通信机切换
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkSetCommunicationSwitch_94H extends ApplicationSpaceUplink {

    HashMap<String,String> result = new HashMap<>();

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        byte _byte = buffer.readByte();
        //编码
        int name= (_byte>>4  & 0b0000_1111);
        if (name==9){
            result.put("machine","A");
        }
        if(name==6){
            result.put("machine","B");
        }
        //1-表示成功 0-失败
        String ifSuccess=(_byte  & 0b0000_1010)!=0?"执行完毕":"执行失败";
        result.put("ifSuccess",ifSuccess);


    }
}

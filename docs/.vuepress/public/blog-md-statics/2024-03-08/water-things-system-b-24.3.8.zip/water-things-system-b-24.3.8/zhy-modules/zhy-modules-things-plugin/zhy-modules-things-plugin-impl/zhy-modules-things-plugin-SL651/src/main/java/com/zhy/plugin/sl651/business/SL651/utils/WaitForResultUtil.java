package com.zhy.plugin.sl651.business.SL651.utils;

import cn.hutool.core.util.HexUtil;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * @author wangfeng
 * @since 2023-09-05 16:08
 */
public class WaitForResultUtil {

    private static final Cache<String, Pair<CountDownLatch, ResultHandler>> CACHE = CacheBuilder
            .newBuilder()
            .expireAfterWrite(1, TimeUnit.MINUTES)
            .build();


    public static MessageFrame sendAndWaitFirstInResult(String stationId, ByteBuf downlinkFrame, int second) throws IllegalAccessException {
        if (second < 1 || second > 60) {
            throw new IllegalArgumentException("waiting second should between 1 and 60");
        }
        Channel channel = ChannelUtil.getChannel(stationId);
        if (null != channel) {
            channel.writeAndFlush(downlinkFrame);
            AtomicReference<MessageFrame> messageFrame = new AtomicReference<>();
            ResultHandler handler = messageFrame::set;
            CountDownLatch latch = new CountDownLatch(1);
            Pair<CountDownLatch, ResultHandler> pair = Pair.of(latch, handler);
            CACHE.put(stationId, pair);
            try {
                boolean await = latch.await(second, TimeUnit.SECONDS);
                if (!await) {
                    throw new IllegalAccessException("fail in waiting respond");
                }
                return messageFrame.get();
            } catch (Exception e) {
                throw new IllegalAccessException("exception while waiting and getting");
            }
        }
        throw new IllegalAccessException("station not online");
    }
    public static MessageFrame sendAndWaitFirstIn(String stationId, ByteBuf downlinkFrame, int second) throws IllegalAccessException {
        if (second < 1 || second > 60) {
            throw new IllegalArgumentException("waiting second should between 1 and 60");
        }
        Channel channel = ChannelUtil.getChannel(stationId);
        if (null != channel) {
            channel.writeAndFlush(downlinkFrame);
            AtomicReference<MessageFrame> messageFrame = new AtomicReference<>();
            ResultHandler handler = messageFrame::set;
            CountDownLatch latch = new CountDownLatch(1);
            Pair<CountDownLatch, ResultHandler> pair = Pair.of(latch, handler);
            CACHE.put("first-in", pair);
            try {
                boolean await = latch.await(second, TimeUnit.SECONDS);
                if (!await) {
                    throw new IllegalAccessException("fail in waiting respond");
                }
                return messageFrame.get();
            } catch (Exception e) {
                throw new IllegalAccessException("exception while waiting and getting");
            }
        }
        throw new IllegalAccessException("station not online");
    }

    public static MessageFrame sendAndWait(String stationId, MessageFrame downlinkFrame, int second) throws IllegalAccessException {
        if (second < 1 || second > 60) {
            throw new IllegalArgumentException("waiting second should between 1 and 60");
        }

        String functionCode = HexUtil.encodeHexStr(new byte[]{downlinkFrame.getFunctionCode()}).toUpperCase();
        Channel channel = ChannelUtil.getChannel(stationId);

        if (null != channel) {
            channel.writeAndFlush(downlinkFrame);
            AtomicReference<MessageFrame> messageFrame = new AtomicReference<>();
            ResultHandler handler = messageFrame::set;
            CountDownLatch latch = new CountDownLatch(1);
            Pair<CountDownLatch, ResultHandler> pair = Pair.of(latch, handler);
            CACHE.put(stationId + "-" + functionCode, pair);
            try {
                boolean await = latch.await(second, TimeUnit.SECONDS);
                if (!await) {
                    throw new IllegalAccessException("fail in waiting respond");
                }
                return messageFrame.get();
            } catch (Exception e) {
                throw new IllegalAccessException("exception while waiting and getting");
            }
        }
        throw new IllegalAccessException("station not online");
    }

    public static void fireResult(MessageFrame result) {
        String functionCode = HexUtil.encodeHexStr(new byte[]{result.getFunctionCode()}).toUpperCase();
        String stationId = result.getTelemetricStationParse();
        Pair<CountDownLatch, ResultHandler> pair = CACHE.getIfPresent(stationId + "-" + functionCode);
        if (null != pair) {
            CountDownLatch latch = pair.getKey();
            if (latch.getCount() > 0) {
                ResultHandler handler = pair.getValue();
                handler.handle(result);
                latch.countDown();
            }
        }
    }
    public static void fireFirstInResult(MessageFrame result) {
        String stationId = result.getTelemetricStationParse();
        Pair<CountDownLatch, ResultHandler> pairFirstIn = CACHE.getIfPresent(stationId);
        if (null != pairFirstIn) {
            CountDownLatch latch = pairFirstIn.getKey();
            if (latch.getCount() > 0) {
                ResultHandler handler = pairFirstIn.getValue();
                handler.handle(result);
                latch.countDown();
            }
        }
    }

    public static void fireFirstIn(byte[] bytes) {
        Pair<CountDownLatch, ResultHandler> pairFirstIn = CACHE.getIfPresent("first-in");
        MessageFrame messageFrame = new MessageFrame();
        messageFrame.setAllBytes(bytes);
        messageFrame.setAllBytesStr(HexUtil.encodeHexStr(bytes).toUpperCase(Locale.ROOT));
        if (null != pairFirstIn) {
            CountDownLatch latch = pairFirstIn.getKey();
            if (latch.getCount() > 0) {
                ResultHandler handler = pairFirstIn.getValue();
                handler.handle(messageFrame);
                latch.countDown();
            }
        }
    }

    @FunctionalInterface
    public interface ResultHandler {
        void handle(MessageFrame messageFrame);
    }


}

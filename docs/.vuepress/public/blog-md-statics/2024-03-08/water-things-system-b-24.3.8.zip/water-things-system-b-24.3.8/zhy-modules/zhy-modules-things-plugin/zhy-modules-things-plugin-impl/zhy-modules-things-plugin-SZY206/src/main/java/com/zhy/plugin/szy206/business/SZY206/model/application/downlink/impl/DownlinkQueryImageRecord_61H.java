package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Since 2023/10/8
 * @Author：houDeJian
 * @Record：61H查询遥测站图像记录
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryImageRecord_61H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._61.getFNCByte();
    }

    /**
     * 图片的编号
     */
    private byte cmd;

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode, this.cmd};
    }
}

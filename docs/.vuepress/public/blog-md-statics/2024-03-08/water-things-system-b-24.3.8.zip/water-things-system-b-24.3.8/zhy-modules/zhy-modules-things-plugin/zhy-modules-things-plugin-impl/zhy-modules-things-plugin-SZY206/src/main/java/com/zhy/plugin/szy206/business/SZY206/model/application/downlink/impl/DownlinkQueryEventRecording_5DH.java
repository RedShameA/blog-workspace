package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Since 2023/10/7
 * @Author：houDeJian
 * @Record：5D-查询遥测终端的事件记录
 */
public class DownlinkQueryEventRecording_5DH extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._5D.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

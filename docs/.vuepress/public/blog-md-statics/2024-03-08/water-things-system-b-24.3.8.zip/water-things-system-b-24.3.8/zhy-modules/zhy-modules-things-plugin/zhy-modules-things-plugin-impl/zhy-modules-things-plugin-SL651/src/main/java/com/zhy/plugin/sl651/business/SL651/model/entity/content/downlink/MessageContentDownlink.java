package com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink;

import com.zhy.plugin.sl651.business.SL651.model.entity.content.MessageContent;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 下行报文正文 <br>
 * 多了1个字段：遥测站地址 <br>
 * <br>
 * 下行链路子类需实现此类，再添加自己的字段。 <br>
 * 同时也需要重写encode{@link MessageContentDownlink#encode}方法
 * @author wangfeng
 * @since 2023/06/28
 */
@Data
@EqualsAndHashCode(callSuper = true)
public abstract class MessageContentDownlink extends MessageContent implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 编码方法 <br>
     * 子类需重写此方法，将content编码成字节数据
     */
    @Override
    abstract public byte[] encode();

    /**
     * 解码方法 <br>
     * 对于下行报文来说，解码方法无作用
     */
    @Override
    @Deprecated
    public void decode() {
        // do nothing
    }
}

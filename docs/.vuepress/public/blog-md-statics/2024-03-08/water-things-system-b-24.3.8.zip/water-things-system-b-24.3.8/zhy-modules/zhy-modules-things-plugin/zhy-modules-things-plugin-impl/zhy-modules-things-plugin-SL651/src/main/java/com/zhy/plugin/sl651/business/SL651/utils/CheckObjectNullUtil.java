package com.zhy.plugin.sl651.business.SL651.utils;

import org.springframework.stereotype.Repository;

import java.lang.reflect.Field;

/**
 * @Author：houDeJian
 * @Record：
 */

@Repository
public class CheckObjectNullUtil {
    public int isNotNUll(Object object){
        int n=0;
        try{
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);
                System.out.println();
                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if(val != null) {
                    n+=1;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
//        System.out.println("该对象有："+n+"参数不为空");
        return n;
    }
}

package com.zhy.converter.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 降水量表
 * @TableName st_pptn_r
 */
@Data
public class StPptnR implements Serializable {
    /**
     * 降水量值的截止时间
     */
    private Date tm;

    /**
     * 由全国统一编制的，用于标识涉及报送降水、蒸发、河道、水库、闸坝、泵站、潮沙、沙情、冰情、墒情、地下水、水文预报等信息的各类测站的站码。测站编码具有唯一性，由数字和大写字母组成的8位字符串，按《全国水文测站编码》执行。
     */
    private String stcd;

    /**
     * 表示指定时段内的降水量，计量单位为mm
     */
    private Double drp;

    /**
     * 描述测站所报时段降水量的统计时段长度，计量单位为h
     */
    private Double intv;

    /**
     * 描述指定时段的实际降雨时间。数据存储的格式是HH.NN,其中HH为小时数，取值为00~23;NN为分钟数，取值为01~59。当降水历时为整小时数时，可只列小时数
     */
    private Double pdr;

    /**
     * 表示前一天8时至截至当天8时共计24h的累计降水量，计量单位为mm
     */
    private Double dyp;

    /**
     * 时间字段截至时刻的天气状况，用代码表示。天气状况代码应按表31确定取值
     */
    private String wth;

    private static final long serialVersionUID = 1L;
}
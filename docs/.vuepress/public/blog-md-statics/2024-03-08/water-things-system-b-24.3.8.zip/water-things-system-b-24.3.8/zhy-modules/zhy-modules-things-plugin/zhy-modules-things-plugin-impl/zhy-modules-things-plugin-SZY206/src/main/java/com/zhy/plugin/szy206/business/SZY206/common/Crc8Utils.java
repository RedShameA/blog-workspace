package com.zhy.plugin.szy206.business.SZY206.common;

import cn.hutool.core.util.HexUtil;

/**
 * @author yulei
 */
public final class Crc8Utils {

    public static void main(String[] args) {
        System.out.println(getCRC8(HexUtil.decodeHex("B0370300000002F0")));
    }
    /**
     * 根据指定的字节数组生成crc16校验码
     *
     * @param bytes 指定数组
     * @return 校验码, 低位在前，高位在后进行返回
     */
    public static int getCRC8(byte[] bytes) {
        int crc = 0;
        int polynomial = 0xE5;

        int i, j;
        for (i = 0; i < bytes.length; i++) {
            crc ^= ((int) bytes[i] & 0xff);
            for (j = 0; j < 8; j++) {
                if ((crc & 0x80) != 0) {
                    crc <<= 1;
                    crc ^= polynomial;
                } else {
                    crc <<= 1;
                }
            }
        }
        return crc & 0xff;
    }
}

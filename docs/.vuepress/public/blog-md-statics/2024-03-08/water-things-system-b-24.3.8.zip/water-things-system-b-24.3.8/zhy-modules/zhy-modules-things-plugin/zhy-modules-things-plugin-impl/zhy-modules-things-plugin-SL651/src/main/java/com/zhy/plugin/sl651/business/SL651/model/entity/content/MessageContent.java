package com.zhy.plugin.sl651.business.SL651.model.entity.content;

import lombok.Data;

import java.util.Date;

/**
 * 最基本框架 上下行都有这俩参数: 流水号、发报时间
 * @author wangfeng
 * @since 2023-06-27 11:26
 */
@Data
public abstract class MessageContent {

    private static final long serialVersionUID = 1L;


    /**
     * 流水号
     */
    private byte[] serialNumber;
    /**
     * 发报时间
     */
    private byte[] messageTime;
    /**
     * 发报时间
     */
    private Date messageTimeParse;

    /**
     * 编码方法
     */
    abstract public byte[] encode();

    /**
     * 解码方法
     */
    abstract public void decode();
}

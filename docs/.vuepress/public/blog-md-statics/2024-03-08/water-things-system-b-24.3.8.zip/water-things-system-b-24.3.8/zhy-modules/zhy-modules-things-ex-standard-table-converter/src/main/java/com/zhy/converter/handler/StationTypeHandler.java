package com.zhy.converter.handler;

import com.zhy.things.common.constants.StationType;
import com.zhy.things.common.constants.ValueType;
import com.zhy.common.things.domain.StandardMessage;

/**
 * @author wangfeng
 * @since 2023-11-24 11:09
 */
public interface StationTypeHandler {
    StationType getSupportedStationType();
    void handle(ValueType valueType, StandardMessage standardMessage);
}

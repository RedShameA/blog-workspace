package com.zhy.things.web.service.impl;

import com.zhy.common.core.domain.TreeSelect;
import com.zhy.common.things.domain.ThingsDeviceOrg;
import com.zhy.common.utils.StringUtils;
import com.zhy.things.web.mapper.ThingsDeviceOrgMapper;
import com.zhy.things.web.service.IThingsDeviceOrgService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author wangfeng
 * @since 2023-12-08 16:29
 */
@Service
public class ThingsDeviceOrgServiceImpl implements IThingsDeviceOrgService {

    @Resource
    ThingsDeviceOrgMapper thingsDeviceOrgMapper;

    @Override
    public List<TreeSelect> getTree() {
        List<ThingsDeviceOrg> thingsDeviceOrgs = thingsDeviceOrgMapper.selectThingsDeviceOrgList(new ThingsDeviceOrg());
        return buildDeptTree(thingsDeviceOrgs).stream().map(TreeSelect::new).collect(Collectors.toList());
    }

    @Override
    public int addOrg(ThingsDeviceOrg org) {
        if (org.getParentId() == 0) {
            org.setAncestors(",0");
        } else {
            ThingsDeviceOrg parent = thingsDeviceOrgMapper.selectThingsDeviceOrgByDeviceOrgId(org.getParentId());
            org.setAncestors(parent.getAncestors() + "," + org.getParentId());
        }
        return thingsDeviceOrgMapper.insertThingsDeviceOrg(org);
    }

    @Override
    public int delOrg(Long id) {
        return thingsDeviceOrgMapper.deleteThingsDeviceOrgByDeviceOrgId(id);
    }

    @Override
    public boolean hasChild(Long id) {
        ThingsDeviceOrg thingsDeviceOrg = new ThingsDeviceOrg();
        thingsDeviceOrg.setParentId(id);
        List<ThingsDeviceOrg> list = thingsDeviceOrgMapper.selectThingsDeviceOrgList(thingsDeviceOrg);
        return !list.isEmpty();
    }


    /**
     * 构建树
     *
     * @param orgs 所有组织
     * @return 树
     */
    public List<ThingsDeviceOrg> buildDeptTree(List<ThingsDeviceOrg> orgs) {
        List<ThingsDeviceOrg> returnList = new ArrayList<>();
        List<Long> tempList = orgs.stream().map(ThingsDeviceOrg::getDeviceOrgId).collect(Collectors.toList());
        for (ThingsDeviceOrg org : orgs) {
            // 如果是顶级节点, 遍历该父节点的所有子节点
            if (!tempList.contains(org.getParentId())) {
                recursionFn(orgs, org);
                returnList.add(org);
            }
        }
        if (returnList.isEmpty()) {
            returnList = orgs;
        }
        return returnList;
    }

    /**
     * 递归列表
     */
    private void recursionFn(List<ThingsDeviceOrg> list, ThingsDeviceOrg t) {
        // 得到子节点列表
        List<ThingsDeviceOrg> childList = getChildList(list, t);
        t.setChildren(childList);
        for (ThingsDeviceOrg tChild : childList) {
            if (hasChild(list, tChild)) {
                recursionFn(list, tChild);
            }
        }
    }

    /**
     * 得到子节点列表
     */
    private List<ThingsDeviceOrg> getChildList(List<ThingsDeviceOrg> list, ThingsDeviceOrg t) {
        List<ThingsDeviceOrg> tlist = new ArrayList<>();
        for (ThingsDeviceOrg n : list) {
            if (StringUtils.isNotNull(n.getParentId()) && n.getParentId().longValue() == t.getDeviceOrgId().longValue()) {
                tlist.add(n);
            }
        }
        return tlist;
    }

    /**
     * 判断是否有子节点
     */
    private boolean hasChild(List<ThingsDeviceOrg> list, ThingsDeviceOrg t) {
        return !getChildList(list, t).isEmpty();
    }



    /**
     * 查询物联设备组织树
     *
     * @param deviceOrgId 物联设备组织树主键
     * @return 物联设备组织树
     */
    @Override
    public ThingsDeviceOrg selectThingsDeviceOrgByDeviceOrgId(Long deviceOrgId)
    {
        return thingsDeviceOrgMapper.selectThingsDeviceOrgByDeviceOrgId(deviceOrgId);
    }

    /**
     * 查询物联设备组织树列表
     *
     * @param thingsDeviceOrg 物联设备组织树
     * @return 物联设备组织树
     */
    @Override
    public List<ThingsDeviceOrg> selectThingsDeviceOrgList(ThingsDeviceOrg thingsDeviceOrg)
    {
        return thingsDeviceOrgMapper.selectThingsDeviceOrgList(thingsDeviceOrg);
    }

    /**
     * 新增物联设备组织树
     *
     * @param thingsDeviceOrg 物联设备组织树
     * @return 结果
     */
    @Override
    public int insertThingsDeviceOrg(ThingsDeviceOrg thingsDeviceOrg)
    {
        thingsDeviceOrg.setCreateTime(new Date());
        ThingsDeviceOrg info = thingsDeviceOrgMapper.selectThingsDeviceOrgByDeviceOrgId(thingsDeviceOrg.getParentId());
        thingsDeviceOrg.setAncestors(info.getAncestors() + "," + thingsDeviceOrg.getParentId());
        return thingsDeviceOrgMapper.insertThingsDeviceOrg(thingsDeviceOrg);
    }

    /**
     * 修改物联设备组织树
     *
     * @param thingsDeviceOrg 物联设备组织树
     * @return 结果
     */
    @Override
    public int updateThingsDeviceOrg(ThingsDeviceOrg thingsDeviceOrg)
    {
        thingsDeviceOrg.setUpdateTime(new Date());
        return thingsDeviceOrgMapper.updateThingsDeviceOrg(thingsDeviceOrg);
    }

    /**
     * 批量删除物联设备组织树
     *
     * @param deviceOrgIds 需要删除的物联设备组织树主键
     * @return 结果
     */
    @Override
    public int deleteThingsDeviceOrgByDeviceOrgIds(Long[] deviceOrgIds)
    {
        return thingsDeviceOrgMapper.deleteThingsDeviceOrgByDeviceOrgIds(deviceOrgIds);
    }

    /**
     * 删除物联设备组织树信息
     *
     * @param deviceOrgId 物联设备组织树主键
     * @return 结果
     */
    @Override
    public int deleteThingsDeviceOrgByDeviceOrgId(Long deviceOrgId)
    {
        return thingsDeviceOrgMapper.deleteThingsDeviceOrgByDeviceOrgId(deviceOrgId);
    }
}

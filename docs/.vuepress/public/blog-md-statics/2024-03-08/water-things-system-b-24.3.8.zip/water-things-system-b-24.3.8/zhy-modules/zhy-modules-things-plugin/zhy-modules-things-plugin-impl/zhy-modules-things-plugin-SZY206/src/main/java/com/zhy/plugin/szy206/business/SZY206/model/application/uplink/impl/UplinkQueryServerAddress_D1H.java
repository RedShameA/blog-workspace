package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * D1H 获取服务端地址 （山东）
 *
 * @author wangfeng
 * @since 2023-10-05 16:23
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryServerAddress_D1H extends ApplicationSpaceUplink {
    /**
     * 服务端地址ip
     */
    String ip;
    /**
     * 服务端地址端口
     */
    Integer port;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码
        this.applicationFunctionCode = buffer.readByte();
        // 服务端地址信息
        this.ip = "";
        byte[] bytes = new byte[2];
        buffer.readBytes(bytes);
        this.ip += this.calc(bytes) + ".";
        buffer.readBytes(bytes);
        this.ip += this.calc(bytes) + ".";
        buffer.readBytes(bytes);
        this.ip += this.calc(bytes) + ".";
        buffer.readBytes(bytes);
        this.ip += this.calc(bytes);
        buffer.readBytes(bytes);
        this.port = Integer.valueOf(HexUtil.encodeHexStr(bytes), 16);
    }

    private int calc(byte[] bytes) {
        return (bytes[1] & 0b0000_1111) // 个位
                + (((bytes[1] & 0b1111_0000) >> 4) * 10) // 十位
                + ((bytes[0] & 0b0000_1111) * 100); // 百位
    }
}

package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkManualPacket;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 处理人工置数报(主动上行)
 * @author wangfeng
 * @since 2023-07-31 17:18
 */
@Slf4j
@Component
public class ManualPacketVisitor implements MessageFrameUseVisitor<MessageContentUplinkManualPacket> {

    @Override
    public String getFunctionCode() {
        return AppendixB._35.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("人工置数报(主动上行)visitor");
        log.info(getContent(frame).getManualPacket());
    }
}

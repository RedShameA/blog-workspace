package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.WaterQualityParameter_Enum;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.StationWarnStatus;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.WaterQualityParameter;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Calendar;
import java.util.Date;

/**
 * @author wangfeng
 * @since 2023-09-27 10:00
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkRealTimeValue_C1H extends ApplicationSpaceUplink {

    int controlAfn;

    /**
     * 告警状态
     */
    StationWarnStatus stationWarnStatus;

    /**
     * 此报文tp比较特殊 为6个字节
     */
    Date tp;

    /**
     * 流量(水量) 左流量 右水量
     */
    Pair<Double, Double> flowAndWaters;


    @SneakyThrows
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // 去除告警、tp后的剩余字节
        int readable = buffer.readableBytes() - 10;
        if (readable != 10) {
            throw new IllegalStateException("报文错误，数据不为10个字节");
        }

        flowAndWaters = getFlowAndWaters(readable, buffer)[0];

        // danger
        byte[] dangerBytes = new byte[4];
        buffer.readBytes(dangerBytes);
        stationWarnStatus = new StationWarnStatus().parse(dangerBytes);
        // Tp
        byte[] tpBytes = new byte[6];
        buffer.readBytes(tpBytes);
        int sec = (tpBytes[0] & 0b0000_1111) + (((tpBytes[0] & 0b1111_0000) >> 4) * 10);
        int min = (tpBytes[1] & 0b0000_1111) + (((tpBytes[1] & 0b1111_0000) >> 4) * 10);
        int hour = (tpBytes[2] & 0b0000_1111) + (((tpBytes[2] & 0b1111_0000) >> 4) * 10);
        int day = (tpBytes[3] & 0b0000_1111) + (((tpBytes[3] & 0b1111_0000) >> 4) * 10);
        int month = (tpBytes[4] & 0b0000_1111) + (((tpBytes[4] & 0b1111_0000) >> 4) * 10);
        int year = (tpBytes[5] & 0b0000_1111) + (((tpBytes[5] & 0b1111_0000) >> 4) * 10);

        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.SECOND, sec);
        instance.set(Calendar.MINUTE, min);
        instance.set(Calendar.HOUR_OF_DAY, hour);
        instance.set(Calendar.DAY_OF_MONTH, day);
        instance.set(Calendar.MONTH, month - 1);
        instance.set(Calendar.YEAR, year + 2000);
        instance.set(Calendar.MILLISECOND, 0);

        this.tp = instance.getTime();
    }

    private Double getVoltage(ByteBuf buffer) {
        byte[] voltageBytes = new byte[2];
        buffer.readBytes(voltageBytes);
        return ((voltageBytes[0] & 0b0000_1111) * 0.01d) // 小数后2位
                + (((voltageBytes[0] & 0b1111_0000) >> 4) * 0.01d) // 小数后1位
                + ((voltageBytes[1] & 0b0000_1111)) // 个位
                + (((voltageBytes[1] & 0b1111_0000) >> 4) * 10); // 十位
    }

    private Double[] getWaterPressures(int readable, ByteBuf buffer) {
        // 水压设备数
        int n = readable / 4;
        Double[] waterPressures = new Double[n];
        byte[] waterPressureBytes = new byte[4];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(waterPressureBytes);
            double waterPressure = (waterPressureBytes[0] & 0b0000_1111) * 0.01 // 小数点后2位
                    + ((waterPressureBytes[0] & 0b1111_0000) >> 4) * 0.1 // 小数点后1位
                    + (waterPressureBytes[1] & 0b0000_1111) // 个位
                    + ((waterPressureBytes[1] & 0b1111_0000) >> 4) * 10 // 十位
                    + (waterPressureBytes[2] & 0b0000_1111) * 100 // 百位
                    + ((waterPressureBytes[2] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (waterPressureBytes[3] & 0b0000_1111) * 10000 // 万位
                    + ((waterPressureBytes[3] & 0b1111_0000) >> 4) * 10_0000; // 十万位
            waterPressures[i] = waterPressure;
        }
        return waterPressures;
    }

    private Double getEvaporation(ByteBuf buffer) {
        byte[] evaporationBytes = new byte[3];
        buffer.readBytes(evaporationBytes);
        return (evaporationBytes[0] & 0b0000_1111) * 0.1 // 小数点后1位
                + ((evaporationBytes[0] & 0b1111_0000) >> 4) // 个位
                + (evaporationBytes[1] & 0b0000_1111) * 10 // 十位
                + ((evaporationBytes[1] & 0b1111_0000) >> 4) * 100 // 百位
                + (evaporationBytes[2] & 0b0000_1111) * 1000; // 千位
    }

    private Double getSoilWater(ByteBuf buffer) {
        byte[] soilWaterBytes = new byte[2];
        buffer.readBytes(soilWaterBytes);
        return (soilWaterBytes[0] & 0b0000_1111) * 0.1 // 小数点后1位
                + ((soilWaterBytes[0] & 0b1111_0000) >> 4) // 个位
                + (soilWaterBytes[1] & 0b0000_1111) * 10 // 十位
                + ((soilWaterBytes[1] & 0b1111_0000) >> 4) * 100; // 百位
    }

    private WaterQualityParameter getWaterQuality(ByteBuf buffer) throws NoSuchFieldException, IllegalAccessException {
        byte[] parameter = new byte[5];
        WaterQualityParameter waterQualityParameter = new WaterQualityParameter();
        buffer.readBytes(parameter);
        // 怎么判断一个字节的八位中那些不为0
        for (int y = 0; y < 5; y++) {
            for (int i = 0; i <= 7; i++) {
                byte mask = (byte) (1 << i);
                if ((parameter[y] & mask) != 0) {
                    // 拼接水质元素名字
                    String parameterName = "D" + (8 * y + i);
                    byte[] array = 8 * y + i == 24 ? new byte[5] : new byte[4];
                    buffer.readBytes(array);
                    Double value;
                    if (8 * y + i == 24) {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        byte _byte5 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
                        value = (double) (byte5 * 100000000 + byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                    } else if (8 * y + i == 4) {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                    } else {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        Integer decimalPlaces = WaterQualityParameter_Enum.getRight(parameterName);
                        double result = Math.pow(0.1, decimalPlaces);
                        value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1) * result;
                    }
                    System.out.println("D" + 8 * y + i + " 不为0");
                    waterQualityParameter.setParameterValue(parameterName, value);
                }
            }
        }
        return waterQualityParameter;
    }

    private Double getWaterTemperature(ByteBuf buffer) {
        byte[] waterTemperatureBytes = new byte[2];
        buffer.readBytes(waterTemperatureBytes);
        return (waterTemperatureBytes[0] & 0b0000_1111) * 0.1 // 小数点后1位
                + ((waterTemperatureBytes[0] & 0b1111_0000) >> 4) // 个位
                + (waterTemperatureBytes[1] & 0b0000_1111) * 10; // 十位
    }

    private Pair<Double, Double> getWindSpeedAndDirection(ByteBuf buffer) {
        byte[] windBytes = new byte[3];
        buffer.readBytes(windBytes);
        double windSpeed = (windBytes[0] & 0b0000_1111) * 0.01 // 小数点后2位
                + ((windBytes[0] & 0b1111_0000) >> 4) * 0.1 // 小数点后1位
                + (windBytes[1] & 0b0000_1111) // 个位
                + ((windBytes[1] & 0b1111_0000) >> 4) * 10 // 十位
                + (windBytes[2] & 0b0000_1111) * 100; // 百位
        double windDirection = (windBytes[2] & 0b1111_0000);
        return Pair.of(windSpeed, windDirection);
    }

    private Double getPressure(ByteBuf buffer) {
        byte[] pressureBytes = new byte[3];
        buffer.readBytes(pressureBytes);
        return (Double) (double) ((pressureBytes[0] & 0b0000_1111) // 个位
                + ((pressureBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                + (pressureBytes[1] & 0b0000_1111) * 100 // 百位
                + ((pressureBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                + (pressureBytes[2] & 0b0000_1111) * 1_0000);
    }

    private Double[] getPowers(int readable, ByteBuf buffer) {
        // 功率仪表数量
        int n = readable / 3;
        Double[] powers = new Double[n];
        byte[] powerBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(powerBytes);
            double power = (powerBytes[0] & 0b0000_1111) // 个位
                    + ((powerBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                    + (powerBytes[1] & 0b0000_1111) * 100 // 百位
                    + ((powerBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (powerBytes[2] & 0b0000_1111) * 1_0000 // 万位
                    + ((powerBytes[2] & 0b1111_0000) >> 4) * 10_0000; // 十万位
            powers[i] = power;
        }
        return powers;
    }

    private Double[] getGateLevels(int readable, ByteBuf buffer) {
        // 闸位仪表数量
        int n = readable / 3;
        Double[] gateLevels = new Double[n];
        byte[] gateLevelBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(gateLevelBytes);
            double gateLevel = (gateLevelBytes[0] & 0b0000_1111) * 0.01 // 厘米位
                    + ((gateLevelBytes[0] & 0b1111_0000) >> 4) * 0.1 // 分米位
                    + (gateLevelBytes[1] & 0b0000_1111) // 米位
                    + ((gateLevelBytes[1] & 0b1111_0000) >> 4) * 10 // 十米位
                    + (gateLevelBytes[2] & 0b0000_1111) * 100; // 百米位
            gateLevels[i] = gateLevel;
        }
        return gateLevels;
    }

    private Double[] getFlowSpeeds(int readable, ByteBuf buffer) {
        // 流速仪表数量
        int n = readable / 3;
        Double[] flowSpeeds = new Double[n];
        byte[] flowSpeedBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(flowSpeedBytes);
            double flowSpeed = (flowSpeedBytes[0] & 0b0000_1111) * 0.001 // 小数点后3位
                    + ((flowSpeedBytes[0] & 0b1111_0000) >> 4) * 0.01 // 小数点后2位
                    + (flowSpeedBytes[1] & 0b0000_1111) * 0.1 // 小数点后1位
                    + ((flowSpeedBytes[1] & 0b1111_0000) >> 4) // 个位
                    + (flowSpeedBytes[2] & 0b0000_1111) * 10; // 十位
            flowSpeed *= ((flowSpeedBytes[2] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            flowSpeeds[i] = flowSpeed;
        }
        return flowSpeeds;
    }

    private Pair<Double, Double>[] getFlowAndWaters(int readable, ByteBuf buffer) {
        // 流量(水量)仪表数量
        int n = readable / (5 * 2);
        Pair[] flowAndWaters = new Pair[n];
        byte[] flowAndWaterBytes = new byte[5];
        for (int i = 0; i < n; i++) {
            double flow, water;
            // 流量
            buffer.readBytes(flowAndWaterBytes);
            flow = (flowAndWaterBytes[0] & 0b0000_1111) * 0.001d // 小数点后3
                    + ((flowAndWaterBytes[0] & 0b1111_0000) >> 4) * 0.01d // 小数点后2
                    + (flowAndWaterBytes[1] & 0b0000_1111) * 0.1d // 小数点后1
                    + ((flowAndWaterBytes[1] & 0b1111_0000) >> 4) // 个位
                    + (flowAndWaterBytes[2] & 0b0000_1111) * 10 // 十位
                    + ((flowAndWaterBytes[2] & 0b1111_0000) >> 4) * 100 // 百位
                    + (flowAndWaterBytes[3] & 0b0000_1111) * 1000 // 千位
                    + ((flowAndWaterBytes[3] & 0b1111_0000) >> 4) * 1_0000 // 万位
                    + (flowAndWaterBytes[4] & 0b0000_1111) * 10_0000; // 十万位
            flow *= ((flowAndWaterBytes[4] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            // 水量
            buffer.readBytes(flowAndWaterBytes);
            water = (flowAndWaterBytes[0] & 0b0000_1111) // 个位
                    + ((flowAndWaterBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                    + (flowAndWaterBytes[1] & 0b0000_1111) * 100 // 百位
                    + ((flowAndWaterBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (flowAndWaterBytes[2] & 0b0000_1111) * 1_0000 // 万位
                    + ((flowAndWaterBytes[2] & 0b1111_0000) >> 4) * 10_0000 // 十万位
                    + (flowAndWaterBytes[3] & 0b0000_1111) * 10_0000 // 百万位
                    + ((flowAndWaterBytes[3] & 0b1111_0000) >> 4) * 1000_0000 // 千万位
                    + (flowAndWaterBytes[4] & 0b0000_1111) * 10000_0000 // 万万位
                    + ((flowAndWaterBytes[4] & 0b1111_0000) >> 4) * 10_000_0000; // 十万万位
            flowAndWaters[i] = Pair.of(flow, water);
        }
        return flowAndWaters;
    }

    private Double[] getWaterLevels(int readable, ByteBuf buffer) {
        // 水位仪表个数
        int n = readable / 4;
        Double[] waterLevels = new Double[n];
        byte[] waterLevelBytes = new byte[4];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(waterLevelBytes);
            double waterLevel;
            waterLevel = (waterLevelBytes[0] & 0b0000_1111) * 0.001d // 毫米位
                    + ((waterLevelBytes[0] & 0b1111_0000) >> 4) * 0.01d // 厘米位
                    + (waterLevelBytes[1] & 0b0000_1111) * 0.1d // 分米位
                    + ((waterLevelBytes[1] & 0b1111_0000) >> 4) // 米位
                    + (waterLevelBytes[2] & 0b0000_1111) * 10 // 十米位
                    + ((waterLevelBytes[2] & 0b1111_0000) >> 4) * 100 // 百米位
                    + (waterLevelBytes[3] & 0b0000_1111) * 1000; // 千米位
            waterLevel *= ((waterLevelBytes[3] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            waterLevels[i] = waterLevel;
        }
        return waterLevels;
    }

    private double getRain(ByteBuf buffer) {
        byte[] rainBytes = new byte[3];
        buffer.readBytes(rainBytes);
        return ((rainBytes[0] & 0b0000_1111) * 0.1d) // 小数位
                + ((rainBytes[0] & 0b1111_0000) >> 4) // 个位
                + ((rainBytes[1] & 0b0000_1111) * 10) // 十位
                + (((rainBytes[1] & 0b1111_0000) >> 4) * 100) // 百位
                + ((rainBytes[2] & 0b0000_1111) * 1000) // 千位
                + (((rainBytes[2] & 0b1111_0000) >> 4) * 10000); // 万位
    }
}

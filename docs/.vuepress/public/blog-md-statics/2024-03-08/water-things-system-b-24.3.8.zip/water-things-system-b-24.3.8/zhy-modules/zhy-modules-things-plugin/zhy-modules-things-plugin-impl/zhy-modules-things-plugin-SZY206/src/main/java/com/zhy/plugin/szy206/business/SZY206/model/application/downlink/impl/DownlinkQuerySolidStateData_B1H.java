package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

/**
 * @Since 2023/10/8
 * @Author：houDeJian
 * @Record：B1-查询遥测终端固态存储数据
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQuerySolidStateData_B1H extends ApplicationSpaceDownlink {
    // todo 这个功能没看明白
    {
        this.applicationFunctionCode = AFN._B1.getFNCByte();
    }

    // todo 还没测试
    /**
     * left-起始时间
     * right-结束时间
     */
    HashMap<String, Date> queryData;

    /**
     * 0—雨量；
     * 1 —水位；
     * 2—流量（水量）；
     * 3—流速；
     * 4—闸位；
     * 5—功率；
     * 6—气压；
     * 7—风速（风向）；
     * 8—水温；
     * 9—水质；
     * 10—土壤含水率；
     * 11—水压；
     */
    int mum;


    @Override
    public byte[] encode() {

        // 开始时间
        Calendar instance = Calendar.getInstance();
        instance.setTime(queryData.get("startTime"));
        int hour = instance.get(Calendar.HOUR_OF_DAY);
        int day = instance.get(Calendar.DAY_OF_MONTH);
        int month = instance.get(Calendar.MONTH) + 1;
        int year = instance.get(Calendar.YEAR) - 2000;

        byte _strHOUR = (byte) ((hour / 10 << 4) | (hour % 10));
        byte _strDAY = (byte) ((day / 10 << 4) | (day % 10));
        byte _strMONTH = (byte) ((month / 10 << 4) | (month % 10));
        byte _strYEAR = (byte) ((year / 10 << 4) | (year % 10));
        // 结束时间
        Calendar instance1 = Calendar.getInstance();
        instance1.setTime(queryData.get("endTime"));
        int hour1 = instance.get(Calendar.HOUR_OF_DAY);
        int day1 = instance.get(Calendar.DAY_OF_MONTH);
        int month1 = instance.get(Calendar.MONTH) + 1;
        int year1 = instance.get(Calendar.YEAR) - 2000;

        byte _endHOUR = (byte) ((hour1 / 10 << 4) | (hour1 % 10));
        byte _endDAY = (byte) ((day1 / 10 << 4) | (day1 % 10));
        byte _endMONTH = (byte) ((month1 / 10 << 4) | (month1 % 10));
        byte _endYEAR = (byte) ((year1 / 10 << 4) | (year1 % 10));

        // 编号
        byte code = (byte) (((mum & 0b1111_1111) << 4) | 0b0000_0001);

        return ArrayUtil.addAll(new byte[]{applicationFunctionCode, code, _strHOUR, _strDAY, _strMONTH, _strYEAR, _endHOUR, _endDAY, _endMONTH, _endYEAR});
    }
}

package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 链路维持报
 * @author wangfeng
 * @since 2023-07-31 16:11
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentUplinkHeartBeat extends MessageContentUplink {
    @Override
    public void decode() {
        byte[] content = this.getBytes();
        ByteBuf buffer = Unpooled.wrappedBuffer(content);

        // 流水号
        byte[] serialNumber = new byte[2];
        buffer.readBytes(serialNumber);
        this.setSerialNumber(serialNumber);
        // 发报时间
        byte[] messageTime = new byte[6];
        buffer.readBytes(messageTime);
        this.setMessageTime(messageTime);
    }
}

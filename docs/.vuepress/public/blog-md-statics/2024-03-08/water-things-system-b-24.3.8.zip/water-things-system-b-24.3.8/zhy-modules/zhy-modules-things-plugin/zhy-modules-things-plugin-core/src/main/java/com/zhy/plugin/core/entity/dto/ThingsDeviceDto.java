package com.zhy.plugin.core.entity.dto;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.zhy.common.core.domain.BaseEntity;
import com.zhy.common.core.domain.entity.SysDept;
import com.zhy.plugin.core.entity.domain.device.ThingsDevice;
import com.zhy.plugin.core.entity.domain.product.ThingsProduct;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author wangfeng
 * @since 2023-11-30 15:15
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ThingsDeviceDto extends BaseEntity {
    String productId;
    String productName;
    String deviceId;
    String deviceName;
    String deviceDesc;
    String deviceOrgName;
    Long deviceOrgId;
    SysDept dept;
    /* 激活时间，第一次上线的时间 */
    Date registryTime;
    /* 搜索用 */
    Boolean isRegistry;
    Boolean registryTimeNull;
    Date registryTimeStart;
    Date registryTimeEnd;
    Boolean registryTimeRangeInvert;
    /* 最新一次心跳时间 */
    Date heartbeatTime;
    /* 搜索用 */
    Boolean isHeartbeat;
    Boolean heartbeatTimeNull;
    Date heartbeatTimeStart;
    Date heartbeatTimeEnd;
    Boolean heartbeatTimeRangeInvert;
    /* 用于传输 */
    Boolean online;
    /* 测站类型 */
    String stationType;
    /* 产品的 固定不可修改删除 */
    List<ThingsProperty> productProperties = new ArrayList<>();
    List<ThingsFunction> productFunctions = new ArrayList<>();
    /* 设备的 可修改删除 */
    List<ThingsProperty> properties = new ArrayList<>();
    List<ThingsFunction> functions = new ArrayList<>();

    public static ThingsDeviceDto fromThingsDeviceAndProduct(ThingsDevice device, ThingsProduct product){
        ThingsDeviceDto entity = fromThingsDevice(device);
        // 解析metadata
        JSONObject metadata = JSONObject.parseObject(product.getMetaData());
        JSONArray properties = metadata.getJSONArray("properties");
        JSONArray functions = metadata.getJSONArray("functions");
        for (Object json : properties) {
            ThingsProperty thingsProperty = ThingsProperty.fromJson((JSONObject) json);
            entity.productProperties.add(thingsProperty);
            // 从设备的里删除
            entity.properties.remove(thingsProperty);
        }
        for (Object json : functions) {
            ThingsFunction thingsFunction = ThingsFunction.fromJson((JSONObject) json);
            entity.productFunctions.add(thingsFunction);
            // 从设备的里删除
            entity.functions.remove(thingsFunction);
        }
        return entity;
    }

    public static ThingsDeviceDto fromThingsDevice(ThingsDevice device){
        ThingsDeviceDto entity = new ThingsDeviceDto();
        entity.setDeviceId(device.getDeviceId());
        entity.setProductName(device.getProductName());
        entity.setProductId(device.getProductId());
        entity.setDeviceName(device.getDeviceName());
        entity.setDeviceDesc(device.getDeviceDesc());
        entity.setDeviceOrgName(device.getDeviceOrgName());
        entity.setDeviceOrgId(device.getDeviceOrgId());
        entity.setRegistryTime(device.getRegistryTime());
        entity.setHeartbeatTime(device.getHeartbeatTime());
        entity.setOnline(false);
        entity.setStationType(device.getStationType());
        // 解析metadata
        JSONObject metadata = JSONObject.parseObject(device.getMetadata());
        JSONArray properties = metadata.getJSONArray("properties");
        JSONArray functions = metadata.getJSONArray("functions");
        for (Object json : properties) {
            entity.properties.add(ThingsProperty.fromJson((JSONObject) json));
        }
        for (Object json : functions) {
            entity.functions.add(ThingsFunction.fromJson((JSONObject) json));
        }
        return entity;
    }

    public ThingsDevice toThingsDevice(){
        ThingsDevice entity = new ThingsDevice();
        entity.setDeviceId(this.deviceId);
        entity.setProductId(this.productId);
        entity.setProductName(this.productName);
        entity.setDeviceName(this.deviceName);
        entity.setDeviceDesc(this.deviceDesc);
        entity.setDeviceOrgName(this.deviceOrgName);
        entity.setDeviceOrgId(this.deviceOrgId);
        entity.setRegistryTime(this.registryTime);
        entity.setHeartbeatTime(this.heartbeatTime);
        entity.setStationType(this.stationType);
        // 组装metadata
        JSONObject metadata = new JSONObject();
        JSONArray properties = new JSONArray();
        JSONArray functions = new JSONArray();
        metadata.put("properties", properties);
        metadata.put("functions", functions);
        // 设备的
        for (ThingsProperty property : this.properties) {
            properties.add(property.toJson());
        }
        for (ThingsFunction function : this.functions) {
            functions.add(function.toJson());
        }
        // 产品的
        for (ThingsProperty property : this.productProperties) {
            properties.add(property.toJson());
        }
        for (ThingsFunction function : this.productFunctions) {
            functions.add(function.toJson());
        }
        entity.setMetadata(metadata.toJSONString());
        // 返回
        return entity;
    }
}

package com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.MessageContentDownlink;

/**
 * 通用的下行查询报文正文，只有流水号和发报时间，大部分下行查询报文都只需这俩 <br>
 * 适用功能码：
 * @author wangfeng
 * @since 2023-07-27 11:28
 */
public class MessageContentDownlinkQueryCommon extends MessageContentDownlink {
    /**
     * 编码方法 <br>
     * 正文只有 [流水号] 和 [发报时间]
     */
    @Override
    public byte[] encode() {
        byte[] serialNumber = this.getSerialNumber();
        // 发报时间
        String yyyyMMddHHmmss = DateUtil.format(this.getMessageTimeParse(), "yyMMddHHmmss");
        this.setMessageTime(HexUtil.decodeHex(yyyyMMddHHmmss));
        byte[] messageTime = this.getMessageTime();
        return ArrayUtil.addAll(serialNumber, messageTime);
    }
}

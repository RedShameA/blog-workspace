package com.zhy.plugin.sl651.business.SL651.utils;

import cn.hutool.core.util.HexUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

/**
 * @author wangfeng
 * @since 2023-07-26 09:12
 */
public class ElementParseUtil {

    static SimpleDateFormat YYMMDDHHmm = new SimpleDateFormat("yyMMddHHmm");
    static SimpleDateFormat YYMMDDHHmmss = new SimpleDateFormat("yyMMddHHmmss");
    private static final Logger LOGGER = LoggerFactory.getLogger(ElementParseUtil.class);

    public static Double parseDouble(byte[] elementAllBytes){
        // int length = (elementAllBytes[1] & 0xff) >> 3;
        int point = (elementAllBytes[1] & 0xff) & 0x07;
        byte[] dataBytes = Arrays.copyOfRange(elementAllBytes, 2, elementAllBytes.length);
        long l = Long.parseLong(HexUtil.encodeHexStr(dataBytes), 16);
        return (double) l / Math.pow(10, point);
    }

    public static Date parseCollectTime(byte[] collectTimeBytes){
        String s = HexUtil.encodeHexStr(collectTimeBytes);
        Date ret = null;
        try{
            ret = YYMMDDHHmm.parse(s);
        }catch (Exception ignored){
        }
        return ret;
    }

    public static Date parseMessageTime(byte[] collectionTimeBytes){
        String s = HexUtil.encodeHexStr(collectionTimeBytes);
        Date ret = null;
        try {
            ret = YYMMDDHHmmss.parse(s);
        } catch (ParseException e) {
            LOGGER.error(e.getMessage(),e);
        }
        return ret;
    }
    public static void main(String[] args) {
        System.out.println(parseDouble(HexUtil.decodeHex("391A000012")));
    }
}

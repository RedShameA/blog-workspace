package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.RealTimeDataTypes;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：54H 查询遥测站需查询的实时数据种类(响应帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryRealDataType_54H extends ApplicationSpaceUplink {

    /**
     * 遥测站需查询的实时数据种类
     */
    RealTimeDataTypes realTimeDataTypes = new RealTimeDataTypes();

    @Override
    public void decode() {
        ByteBuf byteBuf = Unpooled.wrappedBuffer(this.content);
        this.applicationFunctionCode = byteBuf.readByte();
        byte[] parameter = new byte[2];
        byteBuf.readBytes(parameter);
        for (int i = 0; i < 2; i++) {
            if (i == 0) {
                for (int y = 0; y < 8; y++) {
                    byte mask = (byte) (1 << y);
                    if ((parameter[i] & mask) != 0) {
                        // 拼接水质元素名字
                        String parameterName = "D" + (y);
                        /**
                         * 1-表示查询；0-不查询
                         */
                        switch (y) {
                            case 0:
                                this.realTimeDataTypes.setD0(1);
                                break;
                            case 1:
                                this.realTimeDataTypes.setD1(1);
                                break;
                            case 2:
                                this.realTimeDataTypes.setD2(1);
                                break;
                            case 3:
                                this.realTimeDataTypes.setD3(1);
                                break;
                            case 4:
                                this.realTimeDataTypes.setD4(1);
                                break;
                            case 5:
                                this.realTimeDataTypes.setD5(1);
                                break;
                            case 6:
                                this.realTimeDataTypes.setD6(1);
                                break;
                            case 7:
                                this.realTimeDataTypes.setD7(1);
                                break;
                        }
                    }
                }
            }
            if (i == 1) {
                for (int y = 0; y < 7; y++) {
                    byte mask = (byte) (1 << y);
                    if ((parameter[i] & mask) != 0) {
                        // 拼接水质元素名字
                        String parameterName = "D" + (8 * i + y);
                        /**
                         * 1-表示查询；0-不查询
                         */
                        switch (y) {
                            case 0:
                                this.realTimeDataTypes.setD8(1);
                                break;
                            case 1:
                                this.realTimeDataTypes.setD9(1);
                                break;
                            case 2:
                                this.realTimeDataTypes.setD10(1);
                                break;
                            case 3:
                                this.realTimeDataTypes.setD11(1);
                                break;
                            case 4:
                                this.realTimeDataTypes.setD12(1);
                                break;
                            case 5:
                                this.realTimeDataTypes.setD13(1);
                                break;
                            case 6:
                                this.realTimeDataTypes.setD14(1);
                                break;
                        }
                    }
                }
            }

        }

    }
}

package com.zhy.plugin.sl651.business.SL651.constants.SL651_2014;

import cn.hutool.core.util.HexUtil;

/**
 * SL651协议通用常量
 * @author wangfeng
 * @since 2023-09-05 9:47
 */
public class Common651 {
    public static byte[] HEX_0000 = HexUtil.decodeHex("0000");

    public static byte DOWNLINK_FLAG = (byte) 8;

    public static byte CENTER_STATION = (byte) 16;

}

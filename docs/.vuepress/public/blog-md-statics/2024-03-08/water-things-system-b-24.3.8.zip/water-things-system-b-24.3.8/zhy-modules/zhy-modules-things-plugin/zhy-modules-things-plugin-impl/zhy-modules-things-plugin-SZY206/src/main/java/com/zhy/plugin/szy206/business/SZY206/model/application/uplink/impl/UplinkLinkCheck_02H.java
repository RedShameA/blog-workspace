package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 02H 链路检测（上行-解码）--将收到的
 *
 * @author wangfeng
 * @since 2023-09-07 14:24
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkLinkCheck_02H extends ApplicationSpaceUplink {

    /**
     * 链路监测指令 <br>
     * F0登录
     * F1退出登录
     * F2在线保持
     */
    private byte cmd;

    @Override
    public void decode() {
        this.applicationFunctionCode = this.content[0];
        this.cmd = this.content[1];
    }
}

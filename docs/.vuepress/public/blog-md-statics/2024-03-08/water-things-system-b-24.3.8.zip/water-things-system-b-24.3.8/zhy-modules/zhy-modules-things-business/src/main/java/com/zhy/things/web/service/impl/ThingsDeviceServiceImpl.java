package com.zhy.things.web.service.impl;

import com.zhy.common.exception.ServiceException;
import com.zhy.common.utils.StringUtils;
import com.zhy.plugin.core.entity.domain.device.ThingsDevice;
import com.zhy.plugin.core.entity.dto.ThingsDeviceDto;
import com.zhy.plugin.mapper.ThingsDeviceMapper;
import com.zhy.things.web.service.IThingsDeviceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * @author wangfeng
 * @since 2023-11-09 19:52
 */
@Slf4j
@Service
public class ThingsDeviceServiceImpl implements IThingsDeviceService {
    @Resource
    private ThingsDeviceMapper thingsDeviceMapper;

    /**
     * 查询device
     *
     * @param id device主键
     * @return device
     */
    @Override
    public ThingsDevice selectThingsDeviceById(String id) {
        return thingsDeviceMapper.selectThingsDeviceById(id);
    }

    /**
     * 查询device列表
     *
     * @param thingsDeviceDto device
     * @return device
     */
    @Override
    public List<ThingsDevice> selectThingsDeviceList(ThingsDeviceDto thingsDeviceDto) {
        return thingsDeviceMapper.selectThingsDeviceList(thingsDeviceDto);
    }

    /**
     * 新增device
     *
     * @param thingsDevice device
     * @return 结果
     */
    @Override
    public int insertThingsDevice(ThingsDevice thingsDevice) {
        return thingsDeviceMapper.insertThingsDevice(thingsDevice);
    }

    /**
     * 修改device
     *
     * @param thingsDevice device
     * @return 结果
     */
    @Override
    public int updateThingsDevice(ThingsDevice thingsDevice) {
        return thingsDeviceMapper.updateThingsDevice(thingsDevice);
    }

    /**
     * 批量删除device
     *
     * @param ids 需要删除的device主键
     * @return 结果
     */
    @Override
    public int deleteThingsDeviceByIds(String[] ids) {
        return thingsDeviceMapper.deleteThingsDeviceByIds(ids);
    }

    /**
     * 删除device信息
     *
     * @param id device主键
     * @return 结果
     */
    @Override
    public int deleteThingsDeviceById(String id) {
        return thingsDeviceMapper.deleteThingsDeviceById(id);
    }

    @Override
    @Transactional
    public String importDevice(List<ThingsDevice> deviceList, String operName) {
        if (StringUtils.isNull(deviceList) || deviceList.isEmpty()) {
            throw new ServiceException("导入设备数据不能为空！");
        }
        int successNum = 0;
        int failureNum = 0;
        StringBuilder successMsg = new StringBuilder();
        StringBuilder failureMsg = new StringBuilder();
        for (ThingsDevice device : deviceList) {
            try {
                // 验证是否存在这个设备
                ThingsDevice d = thingsDeviceMapper.selectThingsDeviceById(device.getDeviceId());
                if (StringUtils.isNull(d)) {
                    device.setCreateBy(operName);
                    device.setCreateTime(new Date());
                    // 处理不该导入的东西
                    device.setHeartbeatTime(null);
                    device.setRegistryTime(null);
                    thingsDeviceMapper.insertThingsDevice(device);
                    successNum++;
                    successMsg.append("<br/>" + successNum + "、设备 " + device.getDeviceId() + " 导入成功");
                } else {
                    failureNum++;
                    failureMsg.append("<br/>" + failureNum + "、设备 " + device.getDeviceId() + " 已存在");
                }
            } catch (Exception e) {
                failureNum++;
                String msg = "<br/>" + failureNum + "、设备 " + device.getDeviceId() + " 导入失败：";
                failureMsg.append(msg + e.getMessage());
                log.error(msg, e);
            }
        }
        if (failureNum > 0) {
            failureMsg.insert(0, "很抱歉，导入失败！共 " + failureNum + " 条数据格式不正确，错误如下：");
            throw new ServiceException(failureMsg.toString());
        } else {
            successMsg.insert(0, "恭喜您，数据已全部导入成功！共 " + successNum + " 条，数据如下：");
        }
        return successMsg.toString();
    }
}

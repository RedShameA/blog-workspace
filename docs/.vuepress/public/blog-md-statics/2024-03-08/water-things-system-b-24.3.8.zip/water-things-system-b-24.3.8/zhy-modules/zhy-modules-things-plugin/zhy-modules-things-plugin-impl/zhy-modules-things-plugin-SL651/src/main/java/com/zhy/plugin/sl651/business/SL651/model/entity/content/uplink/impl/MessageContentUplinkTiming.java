package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import com.zhy.plugin.sl651.business.SL651.utils.ElementParseUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;

/**
 * 定时报
 * @author wangfeng
 * @since 2023-07-25 09:50
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentUplinkTiming extends MessageContentUplink {

    /**
     * 要素串键值对
     */
    public Map<String, Double> doubleElements = new HashMap<>();
    public Map<String, byte[]> byteElements = new HashMap<>();

    @Override
    public void decode() {
        byte[] content = this.getBytes();
        ByteBuf buffer = Unpooled.wrappedBuffer(content);

        // 流水号
        byte[] serialNumber = new byte[2];
        buffer.readBytes(serialNumber);
        this.setSerialNumber(serialNumber);
        // 发报时间
        byte[] messageTime = new byte[6];
        buffer.readBytes(messageTime);
        this.setMessageTime(messageTime);
        while (buffer.isReadable()) {
            // 标识符
            byte[] flag = new byte[2];
            buffer.readBytes(flag);
            String flagStr = HexUtil.encodeHexStr(flag, false).substring(0, 2);
            switch (flagStr) {
                case "F1": // 观测站
                    byte[] station = new byte[5];
                    buffer.readBytes(station);
                    byte stationType = buffer.readByte();
                    this.setStation(station);
                    this.setStationType(stationType);
                    break;
                case "F0": // 观测时间
                    byte[] collectTime = new byte[5];
                    buffer.readBytes(collectTime);
                    this.setCollectTime(collectTime);
                    this.setCollectTimeParse(ElementParseUtil.parseCollectTime(collectTime));
                    break;
                default: // 其他要素串
                    int length = (flag[1] & 0xff) >> 3;
                    if ("FF".equals(flagStr)){
                        // 自定义要素特殊处理
                        byte b = buffer.readByte();
                        length = (b & 0xff) >> 3;
                        flagStr =  HexUtil.encodeHexStr(flag, false);
                    }
                    byte[] elementData = new byte[length];
                    buffer.readBytes(elementData);
                    byte[] elementAll = ArrayUtil.addAll(flag, elementData);
                    Double aDouble = ElementParseUtil.parseDouble(elementAll);
                    doubleElements.put(flagStr, aDouble);
                    byteElements.put(flagStr, elementAll);
            }
        }
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.ThresholdAndStorageInterval;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.WaterQualityParameter;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.tuple.Pair;

import java.lang.reflect.Field;

/**
 * @Since 2023/9/26
 * @Author：houDeJian
 * @Record：20H——设置遥测终端检测参数启报阈值及固态存储时间段间隔
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetThresholdAndStorageInterval_20H extends ApplicationSpaceDownlink {
    // todo 这个比较复杂 先不写了
    {
        this.applicationFunctionCode = AFN._20.getFNCByte();
    }
    /**
     * 参数设置：启报阈值及固态存储时间段间隔
     */
    ThresholdAndStorageInterval thresholdAndStorageInterval;

    @Override
    public byte[] encode() {
        //参数类别和参数编号
        int parameterType = thresholdAndStorageInterval.getParameterType();
        int parameterCode = thresholdAndStorageInterval.getParameterCode();
        byte _byte1 = (byte) ((byte) (parameterType & 0b1111_0000) | (parameterCode & 0b0000_1111));
        //时段间隔
        Integer timeInterval = thresholdAndStorageInterval.getOtherStorageInterval();
        byte _byte2 = (byte) (timeInterval & 0b1111_1111);
        byte[] threshold = threshold(thresholdAndStorageInterval);
        //启报阈值
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode, _byte1, _byte2}, threshold, this.aux.encode());
    }

    /**
     * 判断哪个属性不为空
     *
     */
    public int isNotNUll(Object object) {
        int n = 0;
        try {
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);
                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val != null) {
                    String name = f.getName();
                    if (name != "parameterType" ||
                            name != "parameterCode" ||
                            name != "otherStorageInterval") {
                        switch (name) {
                            case "rain": // 雨量
                            case "multiValue": // 综合
                                n = 1;
                                break;
                            case "waterLevels"://水位
                            case "waterPressures": // 水压
                                n = java.lang.reflect.Array.getLength(val) * 4;
                                break;
                            case "flowAndWaters": // 流量(水量)
                                n = java.lang.reflect.Array.getLength(val) * 10;
                                break;
                            case "flowSpeeds": // 流速
                            case "gateLevels": // 闸位
                            case "powers": // 功率
                            case "evaporation": // 蒸发量
                                n = java.lang.reflect.Array.getLength(val) * 3;
                                break;
                            case "pressure": // 气压
                            case "wind": // 风速风向
                                n = 3;
                                break;
                            case "waterTemperature": // 水温
                            case "voltage": // 电压
                                n = 2;
                                break;
                            case "waterQualityParameter": // 水质

                                break;
                            case "soilWater": // 土壤含水率
                                n = java.lang.reflect.Array.getLength(val) * 2;
                                break;
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return n;
    }


    public byte[] threshold(Object object) {
        int isNotNull = isNotNUll(thresholdAndStorageInterval);
        byte[] threshold = new byte[isNotNull];
        try {
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);

                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val != null) {
                    String name = f.getName();
                    if (name != "parameterType" ||
                            name != "parameterCode" ||
                            name != "otherStorageInterval") {
                        switch (name) {
                            case "rain": // 雨量
                                Double rain = thresholdAndStorageInterval.getRain();
                                String formatString =
                                        String.format("%0" + 2 + "." + 1 + "f", rain);
                                String replace = formatString.replace(".", "");
                                int byte1 = Integer.parseInt(replace.substring(0, 2));
                                threshold[0] = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
                                break;
                            case "waterLevels"://水位
                                for (int i = 0; i < thresholdAndStorageInterval.getWaterLevels().length; i++) {
                                    Double waterLevel = thresholdAndStorageInterval.getWaterLevels()[i];
                                    int sign = waterLevel > 0 ? 0 : 16;
                                    double abs = Math.abs(waterLevel);
                                    String formatWaterLevel =
                                            String.format("%0" + 7 + "." + 3 + "f", abs);
                                    String replaceWaterLevel = formatWaterLevel.replace(".", "");
                                    int byte1Water = Integer.parseInt(replaceWaterLevel.substring(5, 7));
                                    int byte2Water = Integer.parseInt(replaceWaterLevel.substring(3, 5));
                                    int byte3Water = Integer.parseInt(replaceWaterLevel.substring(1, 3));
                                    int byte4Water = Integer.parseInt(replaceWaterLevel.substring(0, 1));
                                    threshold[4 * i + 0] = (byte) ((byte1Water / 10 << 4) | (byte1Water % 10));
                                    threshold[4 * i + 1] = (byte) ((byte2Water / 10 << 4) | (byte2Water % 10));
                                    threshold[4 * i + 2] = (byte) ((byte3Water / 10 << 4) | (byte3Water % 10));
                                    threshold[4 * i + 3] = (byte) ((sign << 4 & 0b1111_0000) | (byte4Water & 0b0000_1111));
                                }
                                break;
                            case "flowAndWaters": // 流量(水量)
                                for (int i = 0; i < thresholdAndStorageInterval.getFlowAndWaters().length; i++) {
                                    Double left = thresholdAndStorageInterval.getFlowAndWaters()[i].getLeft();
                                    int sign = left > 0 ? 0 : 16;
                                    double abs = Math.abs(left);
                                    String formatWaterLevel =
                                            String.format("%0" + 9 + "." + 3 + "f", abs);
                                    //去掉小数点
                                    String replaceFlow = formatWaterLevel.replace(".", "");
                                    int byte1Flow = Integer.parseInt(replaceFlow.substring(7, 9));
                                    int byte2Flow = Integer.parseInt(replaceFlow.substring(5, 7));
                                    int byte3Flow = Integer.parseInt(replaceFlow.substring(3, 5));
                                    int byte4Flow = Integer.parseInt(replaceFlow.substring(1, 3));
                                    int byte5Flow = Integer.parseInt(replaceFlow.substring(0, 1));
                                    threshold[10 * i + 0] = (byte) ((byte1Flow / 10 << 4) | (byte1Flow % 10));
                                    threshold[10 * i + 1] = (byte) ((byte2Flow / 10 << 4) | (byte2Flow % 10));
                                    threshold[10 * i + 2] = (byte) ((byte3Flow / 10 << 4) | (byte3Flow % 10));
                                    threshold[10 * i + 3] = (byte) ((byte4Flow / 10 << 4) | (byte4Flow % 10));
                                    threshold[10 * i + 4] = (byte) ((sign << 4 & 0b1111_0000) | (byte5Flow & 0b0000_1111));
                                    Double right = thresholdAndStorageInterval.getFlowAndWaters()[i].getRight();
                                    String formatWaters =
                                            String.format("%0" + 10 + "d", right);
                                    int byte1Waters = Integer.parseInt(formatWaters.substring(8, 10));
                                    int byte2Waters = Integer.parseInt(formatWaters.substring(6, 8));
                                    int byte3Waters = Integer.parseInt(formatWaters.substring(4, 6));
                                    int byte4Waters = Integer.parseInt(formatWaters.substring(2, 4));
                                    int byte5Waters = Integer.parseInt(formatWaters.substring(0, 2));
                                    threshold[10 * i + 5] = (byte) ((byte1Waters / 10 << 4) | (byte1Waters % 10));
                                    threshold[10 * i + 6] = (byte) ((byte2Waters / 10 << 4) | (byte2Waters % 10));
                                    threshold[10 * i + 7] = (byte) ((byte3Waters / 10 << 4) | (byte3Waters % 10));
                                    threshold[10 * i + 8] = (byte) ((byte4Waters / 10 << 4) | (byte4Waters % 10));
                                    threshold[10 * i + 9] = (byte) ((byte5Waters / 10 << 4) | (byte5Waters % 10));
                                }
                                break;
                            case "flowSpeeds": // 流速
                                for (int i = 0; i < thresholdAndStorageInterval.getFlowSpeeds().length; i++) {
                                    Double flowSpeeds = thresholdAndStorageInterval.getFlowSpeeds()[i];
                                    int sign = flowSpeeds > 0 ? 0 : 16;
                                    double abs = Math.abs(flowSpeeds);
                                    String formatWaterLevel =
                                            String.format("%0" + 5 + "." + 3 + "f", abs);
                                    String replaceParameter = formatWaterLevel.replace(".", "");
                                    int byte2Parameter = Integer.parseInt(replaceParameter.substring(3, 5));
                                    int byte3Parameter = Integer.parseInt(replaceParameter.substring(1, 3));
                                    int byte4Parameter = Integer.parseInt(replaceParameter.substring(0, 1));
                                    threshold[3 * i + 0] = (byte) ((byte2Parameter / 10 << 4) | (byte2Parameter % 10));
                                    threshold[3 * i + 1] = (byte) ((byte3Parameter / 10 << 4) | (byte3Parameter % 10));
                                    threshold[3 * i + 2] = (byte) ((sign << 4 & 0b1111_0000) | (byte4Parameter & 0b0000_1111));
                                }
                                break;
                            case "gateLevels": // 闸位
                                for (int i = 0; i < thresholdAndStorageInterval.getGateLevels().length; i++) {
                                    Double gateLevel = thresholdAndStorageInterval.getGateLevels()[i];
                                    String formatData =
                                            String.format("%0" + 5 + "." + 2 + "f", gateLevel);
                                    int byte1Parameter = Integer.parseInt(formatData.substring(3, 5));
                                    int byte2Parameter = Integer.parseInt(formatData.substring(1, 3));
                                    int byte3Parameter = Integer.parseInt(formatData.substring(0, 1));
                                    threshold[3 * i + 0] = (byte) ((byte1Parameter / 10 << 4) | (byte1Parameter % 10));
                                    threshold[3 * i + 1] = (byte) ((byte2Parameter / 10 << 4) | (byte2Parameter % 10));
                                    threshold[3 * i + 2] = (byte) ((byte3Parameter & 0b0000_1111));
                                }
                                break;
                            case "powers": // 功率
                                for (int i = 0; i < thresholdAndStorageInterval.getPowers().length; i++) {
                                    Double power = thresholdAndStorageInterval.getPowers()[i];
                                    String formatData =
                                            String.format("%0" + 6 + "d", power);
                                    int byte1Parameter = Integer.parseInt(formatData.substring(4, 6));
                                    int byte2Parameter = Integer.parseInt(formatData.substring(2, 4));
                                    int byte3Parameter = Integer.parseInt(formatData.substring(0, 2));
                                    threshold[3 * i + 0] = (byte) ((byte1Parameter / 10 << 4) | (byte1Parameter % 10));
                                    threshold[3 * i + 1] = (byte) ((byte2Parameter / 10 << 4) | (byte2Parameter % 10));
                                    threshold[3 * i + 2] = (byte) ((byte3Parameter / 10 << 4) | (byte3Parameter % 10));
                                }
                                break;
                            case "pressure": // 气压
                                Double pressure = thresholdAndStorageInterval.getPressure();
                                String formatData =
                                        String.format("%0" + 5 + "d", pressure);
                                int byte1Parameter = Integer.parseInt(formatData.substring(3, 5));
                                int byte2Parameter = Integer.parseInt(formatData.substring(1, 3));
                                int byte3Parameter = Integer.parseInt(formatData.substring(0, 1));
                                threshold[0] = (byte) ((byte1Parameter / 10 << 4) | (byte1Parameter % 10));
                                threshold[1] = (byte) ((byte2Parameter / 10 << 4) | (byte2Parameter % 10));
                                threshold[2] = (byte) ((byte3Parameter & 0b1111_1111));
                                break;
                            case "wind": // 风速风向
                                Pair<Double, Double> wind = thresholdAndStorageInterval.getWind();
                                Double right = wind.getRight();
                                String formatData1 =
                                        String.format("%0" + 5 + "." + 2 + "f", right);
                                String replaceParameter = formatData1.replace(".", "");
                                int byte1Wind = Integer.parseInt(replaceParameter.substring(3, 5));
                                int byte2Wind = Integer.parseInt(replaceParameter.substring(1, 3));
                                int byte3Wind = Integer.parseInt(replaceParameter.substring(0, 1));
                                threshold[0] = (byte) ((byte1Wind / 10 << 4) | (byte1Wind % 10));
                                threshold[1] = (byte) ((byte2Wind / 10 << 4) | (byte2Wind % 10));
                                Double left = wind.getLeft();
                                String formatData2 =
                                        String.format("%0" + 1 + "d", right);
                                int byte4Wind = Integer.parseInt(formatData2.substring(0, 1));
                                threshold[2] = (byte) ((byte3Wind << 4) | (byte3Wind & 0b1111_1111));
                                break;
                            case "waterTemperature": // 水温
                                Double waterTemperature = thresholdAndStorageInterval.getWaterTemperature();
                                String formatTemperature =
                                        String.format("%0" + 3 + "." + 1 + "f", waterTemperature);
                                String replaceTemperature = formatTemperature.replace(".", "");
                                int byte1Temperature = Integer.parseInt(replaceTemperature.substring(1, 3));
                                int byte2Temperature = Integer.parseInt(replaceTemperature.substring(0, 1));
                                threshold[0] = (byte) ((byte1Temperature / 10 << 4) | (byte1Temperature % 10));
                                threshold[1] = (byte) (byte2Temperature);
                                break;
                            case "waterQualityParameter": // 水质
                                WaterQualityParameter waterQualityParameter = thresholdAndStorageInterval.getWaterQualityParameter();

                                break;
                            case "soilWater": // 土壤含水率
                                for (int i = 0; i < thresholdAndStorageInterval.getSoilWater().length; i++) {
                                    Double aDouble = thresholdAndStorageInterval.getSoilWater()[i];
                                    String formatSoilWater =
                                            String.format("%0" + 4 + "." + 1 + "f", aDouble);
                                    String replaceSoilWater = formatSoilWater.replace(".", "");
                                    int byte1SoilWater = Integer.parseInt(replaceSoilWater.substring(1, 3));
                                    int byte2SoilWater = Integer.parseInt(replaceSoilWater.substring(0, 1));
                                    threshold[i + 0] = (byte) ((byte1SoilWater / 10 << 4) | (byte1SoilWater % 10));
                                    threshold[i + 1] = (byte) ((byte2SoilWater / 10 << 4) | (byte2SoilWater % 10));
                                }
                                break;
                            case "evaporation": // 蒸发量
                                for (int i = 0; i < thresholdAndStorageInterval.getEvaporation().length; i++) {
                                    Double aDouble = thresholdAndStorageInterval.getEvaporation()[i];
                                    String formatEvaporation =
                                            String.format("%0" + 5 + "." + 1 + "f", aDouble);
                                    String replaceEvaporation = formatEvaporation.replace(".", "");
                                    int byte1evaporation = Integer.parseInt(replaceEvaporation.substring(3, 5));
                                    int byte2evaporation = Integer.parseInt(replaceEvaporation.substring(1, 3));
                                    int byte3evaporation = Integer.parseInt(replaceEvaporation.substring(0, 1));
                                    threshold[i + 0] = (byte) ((byte1evaporation / 10 << 4) | (byte1evaporation % 10));
                                    threshold[i + 1] = (byte) ((byte2evaporation / 10 << 4) | (byte2evaporation % 10));
                                    threshold[i + 2] = (byte) (byte3evaporation);
                                }
                                break;
                            case "waterPressures": // 水压
                                for (int i = 0; i < thresholdAndStorageInterval.getWaterPressures().length; i++) {
                                    Double waterPressure = thresholdAndStorageInterval.getWaterPressures()[i];
                                    String formatPressure =
                                            String.format("%0" + 8 + "." + 2 + "f", waterPressure);
                                    String replacePressure = formatPressure.replace(".", "");
                                    int byte1Pressure = Integer.parseInt(replacePressure.substring(6, 8));
                                    int byte2Pressure = Integer.parseInt(replacePressure.substring(4, 6));
                                    int byte3Pressure = Integer.parseInt(replacePressure.substring(2, 4));
                                    int byte4Pressure = Integer.parseInt(replacePressure.substring(0, 2));
                                    threshold[i + 0] = (byte) ((byte1Pressure / 10 << 4) | (byte1Pressure % 10));
                                    threshold[i + 1] = (byte) ((byte2Pressure / 10 << 4) | (byte2Pressure % 10));
                                    threshold[i + 2] = (byte) ((byte3Pressure / 10 << 4) | (byte3Pressure % 10));
                                    threshold[i + 3] = (byte) ((byte4Pressure / 10 << 4) | (byte4Pressure % 10));
                                }
                                break;
                            case "voltage": // 电压
                                Double voltage = thresholdAndStorageInterval.getVoltage();
                                String formatVoltage =
                                        String.format("%0" + 4 + "." + 2 + "f", voltage);
                                String replaceVoltage = formatVoltage.replace(".", "");
                                int byte1eVoltage = Integer.parseInt(replaceVoltage.substring(2, 4));
                                int byte2eVoltage = Integer.parseInt(replaceVoltage.substring(0, 2));
                                threshold[0] = (byte) ((byte1eVoltage / 10 << 4) | (byte1eVoltage % 10));
                                threshold[1] = (byte) ((byte2eVoltage / 10 << 4) | (byte2eVoltage % 10));
                                break;
                            case "multiValue": // 综合
                                thresholdAndStorageInterval.getMultiValue();
                                threshold[0] = (byte) (Math.round(thresholdAndStorageInterval.getMultiValue()[0])
                                        | Math.round(thresholdAndStorageInterval.getMultiValue()[1]) << 1
                                        | Math.round(thresholdAndStorageInterval.getMultiValue()[2]) << 2
                                        | Math.round(thresholdAndStorageInterval.getMultiValue()[3]) << 3
                                        | Math.round(thresholdAndStorageInterval.getMultiValue()[4]) << 4
                                        | Math.round(thresholdAndStorageInterval.getMultiValue()[5]) << 5
                                        | Math.round(thresholdAndStorageInterval.getMultiValue()[6]) << 6
                                        | Math.round(thresholdAndStorageInterval.getMultiValue()[7]) << 7);
                                break;
                        }
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return threshold;
    }

}

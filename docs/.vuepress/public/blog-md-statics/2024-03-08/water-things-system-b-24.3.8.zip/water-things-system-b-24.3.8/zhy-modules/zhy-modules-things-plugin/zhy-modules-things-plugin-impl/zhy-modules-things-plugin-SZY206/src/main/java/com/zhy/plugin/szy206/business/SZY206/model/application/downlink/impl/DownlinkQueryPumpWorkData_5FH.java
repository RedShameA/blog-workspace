package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：5H-查询水泵电机实时工作数据
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryPumpWorkData_5FH extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._5F.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

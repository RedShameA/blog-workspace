package com.zhy.plugin.core.support;


import com.zhy.things.common.constants.ValueType;
import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;

/**
 * 插件接口
 *
 * @author wangfeng
 * @date 2023-11-06 10:37
 */
public interface PluginSupport {

    // 存放不同插件的方法
    //   插件id     方法id                    方法相关
    Map<String, Map<String, FunctionPackage>> functions = new ConcurrentHashMap<>();

    default BiFunction<String, String, String> getFunction(String functionId) {
        return functions.get(getProtocol()).get(functionId).getFunction();
    }

    default void addFunction(String functionId, String functionName, BiFunction<String, String, String> function) {
        FunctionPackage functionPackage = new FunctionPackage();
        functionPackage.setFunctionId(functionId);
        functionPackage.setFunctionName(functionName);
        functionPackage.setFunction(function);
        functions.computeIfAbsent(getProtocol(), key -> new ConcurrentHashMap<>())
                .put(functionId, functionPackage);
    }

    default List<Map<String, String>> getSupportedFunctions() {
        ArrayList<Map<String, String>> ret = new ArrayList<>();
        functions.get(getProtocol()).forEach((functionId, functionPackage)->{
            HashMap<String, String> map = new HashMap<>();
            map.put("functionId", functionId);
            map.put("functionName", functionPackage.getFunctionName());
            ret.add(map);
        });
        return ret;
    }

    List<ValueType> getSupportedValueTypes();

    /**
     * 插件支持的协议，建议英文，且唯一
     */
    String getProtocol();

    /**
     * 插件名
     */
    String getName();

    /**
     * 插件版本号
     */
    String getVersion();

    /**
     * 插件描述
     */
    String getDescription();

    /**
     * 设备id的正则匹配(注意是给js用的，要注意转义)
     */
    String getJsDeviceIdRegex();
    /**
     * 设备id的正则匹配提示，不正确的时候的提示
     */
    String getJsDeviceIdRegexTip();

    /**
     * 插件开始工作方法
     */
    boolean startTransaction(PluginContext pluginContext) throws Exception;

    /**
     * 插件结束工作方法
     */
    boolean stopTransaction();

    /**
     * 插件加载方法
     */
    void init(PluginContext pluginContext);


    @Data
    class FunctionPackage {
        private String functionId;
        private String functionName;
        private BiFunction<String, String, String> function;
    }
}

package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentUplinkSoftwareVersion extends MessageContentUplink {

    /**
     * 存放系解析内容
     */

    public String version ;

    @Override
    public void decode() {
        byte[] content = this.getBytes();
        ByteBuf byteBuf = Unpooled.wrappedBuffer(content);
        // 流水号
        byte[] serialNumber = new byte[2];
        byteBuf.readBytes(serialNumber);
        this.setSerialNumber(serialNumber);
        // 发报时间
        byte[] messageTime = new byte[6];
        byteBuf.readBytes(messageTime);
        this.setMessageTime(messageTime);

        // 1字节hex
        byte[] bytes = new byte[2];
        byteBuf.readBytes(bytes);

        byte[] station = new byte[5];
        byteBuf.readBytes(station);
        this.setStation(station);

        byte b = byteBuf.readByte();
        byte[] bytes1 = new byte[b];
        byteBuf.readBytes(bytes1);
        String s = HexUtil.encodeHexStr(bytes1);
        String s1 = hex2Str(s);
        version = s1;
    }

    public static String hex2Str(String hex) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hex.length() - 1; i += 2) {
            String h = hex.substring(i, (i + 2));
            int decimal = Integer.parseInt(h, 16);
            sb.append((char) decimal);
        }
        return sb.toString();
    }
}

package com.zhy.converter;

import com.zhy.common.enums.DataSourceType;
import com.zhy.things.common.constants.StationType;
import com.zhy.things.common.constants.ValueType;
import com.zhy.common.things.domain.StandardMessage;
import com.zhy.converter.handler.StationTypeHandlerContext;
import com.zhy.framework.datasource.DynamicDataSourceContextHolder;

/**
 * @author wangfeng
 * @since 2023-11-24 10:01
 */
public class StandardTableConverter {
    public static void handle(StationType stationType, ValueType valueType, StandardMessage standardMessage) {
        // 手动切换数据源
        DynamicDataSourceContextHolder.setDataSourceType(DataSourceType.SLAVE.name());
        // 入库
        StationTypeHandlerContext.handle(stationType, valueType, standardMessage);
        // 最后清除数据源
        DynamicDataSourceContextHolder.clearDataSourceType();
    }
}
package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：34H 34H-定值量设定（响应帧）
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkSetDefiniteValue_34H extends ApplicationSpaceUplink {
    Long definitionValue=0L ;
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        for (int i = 0; i < 5; i++) {
            byte _byte = buffer.readByte();
            int byte1 = ((_byte >> 4 & 0x0F) * 10) + (_byte & 0x0F);
            int pow= (int)Math.pow(10, 2*i);
            definitionValue+= (long) byte1 * pow;
        }

    }
}

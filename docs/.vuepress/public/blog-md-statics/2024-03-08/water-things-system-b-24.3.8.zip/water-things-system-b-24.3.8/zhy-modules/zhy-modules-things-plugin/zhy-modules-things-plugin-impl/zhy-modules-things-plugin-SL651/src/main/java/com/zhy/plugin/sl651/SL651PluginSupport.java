package com.zhy.plugin.sl651;

import cn.hutool.core.util.HexUtil;
import com.alibaba.fastjson2.JSON;
import com.zhy.things.common.constants.ValueType;
import com.zhy.plugin.core.support.PluginContext;
import com.zhy.plugin.core.support.PluginSupport;
import com.zhy.plugin.sl651.business.NettySL651Server;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.utils.WaitForResultUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 651协议插件
 *
 * @author wangfeng
 * @since 2023-11-06 11:18
 */
@Slf4j
@Component
public class SL651PluginSupport implements PluginSupport {

    @Override
    public List<ValueType> getSupportedValueTypes() {
        HashSet<ValueType> valueTypes = new HashSet<>();
        valueTypes.add(ValueType.RAIN_IN_1H);
        valueTypes.add(ValueType.WATER_SECTIONAL_AREA);
        valueTypes.add(ValueType.AIR_TEMPERATURE);
        valueTypes.add(ValueType.WATER_TEMPERATURE);
        valueTypes.add(ValueType.AIR_PRESSURE);
        valueTypes.add(ValueType.HUMIDITY);
        valueTypes.add(ValueType.RAIN_IN_1D);
        valueTypes.add(ValueType.RAIN_IN_NOW);
        valueTypes.add(ValueType.RAIN_IN_ALL);
        valueTypes.add(ValueType.WATER_FLOW);
        valueTypes.add(ValueType.WIND_DIRECTION);
        valueTypes.add(ValueType.WIND_LEVEL);
        valueTypes.add(ValueType.WIND_SPEED);
        valueTypes.add(ValueType.WATER_SECTIONAL_SPEED_AVERAGE);
        valueTypes.add(ValueType.WATER_SPEED_NOW);
        valueTypes.add(ValueType.SUPPLY_VOLTAGE);
        valueTypes.add(ValueType.WATER_LEVEL);
        valueTypes.add(ValueType.WATER_QUALITY_PH);
        valueTypes.add(ValueType.WATER_QUALITY_DOC);
        valueTypes.add(ValueType.WATER_QUALITY_COND);
        valueTypes.add(ValueType.WATER_QUALITY_TURB);
        valueTypes.add(ValueType.WATER_QUALITY_NH4N);
        valueTypes.add(ValueType.WATER_QUALITY_TP);
        valueTypes.add(ValueType.WATER_PRESSURE_1);
        valueTypes.add(ValueType.WATER_PRESSURE_2);
        valueTypes.add(ValueType.WATER_PRESSURE_3);
        valueTypes.add(ValueType.WATER_PRESSURE_4);
        valueTypes.add(ValueType.WATER_PRESSURE_5);
        valueTypes.add(ValueType.WATER_PRESSURE_6);
        valueTypes.add(ValueType.WATER_PRESSURE_7);
        valueTypes.add(ValueType.WATER_PRESSURE_8);
        return valueTypes.stream().sorted().collect(Collectors.toList());
    }

    @Override
    public String getProtocol() {
        return "SL651";
    }

    @Override
    public String getName() {
        return "水利651协议";
    }

    @Override
    public String getVersion() {
        return "0.0.2";
    }

    @Override
    public String getDescription() {
        return "水利651协议";
    }

    @Override
    public String getJsDeviceIdRegex() {
        return "^[A-Z\\d]{10}$";
    }

    @Override
    public String getJsDeviceIdRegexTip() {
        return "十位，由数字或大写字母ABCDEF组成 ";
    }

    @Override
    public boolean startTransaction(PluginContext pluginContext) {
        log.info("===== SL651协议插件启动中 =====");
        NettySL651Server server = new NettySL651Server();
        ChannelFuture start = server.start();
        return true;
    }

    @Override
    public boolean stopTransaction() {
        log.info("===== SL651协议插件关闭中 =====");
        return false;
    }

    @Override
    public void init(PluginContext pluginContext) {
        log.info("===== SL651协议插件加载中 =====");
        // 注册function
        addFunction("pass-through", "透传", (manualId, param) -> {
            try {
                if (StringUtils.isBlank(param)) {
                    return "入参不能为空";
                }
                ByteBuf byteBuf = Unpooled.copiedBuffer(HexUtil.decodeHex(param));
                MessageFrame messageFrame = WaitForResultUtil.sendAndWaitFirstInResult(manualId, byteBuf, 20);
                return JSON.toJSONString(messageFrame);
            } catch (Exception e) {
                log.error("651透传功能报错", e);
                return "功能报错：" + e.getMessage();
            }
        });
        addFunction("pass-through-raw", "透传-raw", (manualId, param) -> {
            try {
                if (StringUtils.isBlank(param)) {
                    return "入参不能为空";
                }
                ByteBuf byteBuf = Unpooled.copiedBuffer(HexUtil.decodeHex(param));
                MessageFrame messageFrame = WaitForResultUtil.sendAndWaitFirstIn(manualId, byteBuf, 20);
                return JSON.toJSONString(messageFrame);
            } catch (Exception e) {
                log.error("651透传功能raw报错", e);
                return "功能报错：" + e.getMessage();
            }
        });
    }


}

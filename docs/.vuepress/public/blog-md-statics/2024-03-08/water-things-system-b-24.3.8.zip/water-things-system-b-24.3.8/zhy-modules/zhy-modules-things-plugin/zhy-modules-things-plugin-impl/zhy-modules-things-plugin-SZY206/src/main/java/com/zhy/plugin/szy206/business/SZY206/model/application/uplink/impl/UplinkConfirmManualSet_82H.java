package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.WaterQualityParameter_Enum;
import com.zhy.plugin.szy206.business.SZY206.model.application._AUX;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.StationWarnStatus;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.WaterQualityParameter;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;
import org.apache.commons.lang3.tuple.Pair;

/**
 * @Since 2023/9/27
 * @Author：houDeJian
 * @Record：82_人工置数
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkConfirmManualSet_82H extends ApplicationSpaceUplink {

    int controlAfn;

    /**
     * 告警状态
     */
    StationWarnStatus stationWarnStatus;

    /**
     * 雨量结果
     */
    Double rain;

    /**
     * 水位结果
     */
    Double[] waterLevels;

    /**
     * 流量(水量) 左流量 右水量
     */
    Pair<Double, Double>[] flowAndWaters;

    /**
     * 流速
     */
    Double[] flowSpeeds;

    /**
     * 闸位
     */
    Double[] gateLevels;

    /**
     * 功率
     */
    Double[] powers;

    /**
     * 气压
     */
    Double pressure;

    /**
     * 风速
     */
    Double windSpeed;
    /**
     * 风向 0-8
     */
    Double windDirection;
    /**
     * 水温
     */
    Double waterTemperature;
    /**
     * 水质参数
     */
    WaterQualityParameter waterQualityParameter;

    /**
     * 土壤含水率
     */
    Double[] soilWater;

    /**
     * 蒸发量
     */
    Double[] evaporation;

    /**
     * 水压
     */
    Double[] waterPressures;

    /**
     * 电压
     */
    Double voltage;

    /**
     * 综合参数查询，数组共9个成员都为double，单独的水质在multiValueWaterQuality里 <br>
     * 0：雨量 1：水位 2：流量 3：水量 4：闸位 <br>
     * 5：风速 6：风向 7：功率 8：土壤含水率
     */
    Double[] multiValue;

    /**
     * 水质
     */
    WaterQualityParameter multiValueWaterQuality;


    @SneakyThrows
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // 去除告警、tp后的剩余字节
        int readable = buffer.readableBytes() - 9;
        // 数据数量（有几组数据，不同数据类型计算方法不同）
        int n;
        switch (controlAfn) {
            case 1: // 雨量
                this.rain = this.getRain(buffer);
                break;
            case 2:
                this.waterLevels = this.getWaterLevels(readable, buffer);
                break;
            case 3: // 流量(水量)
                this.flowAndWaters = this.getFlowAndWaters(readable, buffer);
                break;
            case 4: // 流速
                this.flowSpeeds = this.getFlowSpeeds(readable, buffer);
                break;
            case 5: // 闸位
                this.gateLevels = this.getGateLevels(readable, buffer);
                break;
            case 6: // 功率
                this.powers = this.getPowers(readable, buffer);
                break;
            case 7: // 气压
                this.pressure = this.getPressure(buffer);
                break;
            case 8: // 风速风向
                Pair<Double, Double> pair = this.getWindSpeedAndDirection(buffer);
                this.windSpeed = pair.getLeft();
                this.windDirection = pair.getRight();
                break;
            case 9: // 水温
                this.waterTemperature = this.getWaterTemperature(buffer);
                break;
            case 10: // 水质
                this.waterQualityParameter = this.getWaterQuality(buffer);
                break;
            case 11: // 土壤含水率
                this.soilWater = this.getSoilWater(readable, buffer);
                break;
            case 12: // 蒸发量
                this.evaporation = this.getEvaporation(readable, buffer);
                break;
            case 13: // 水压
                this.waterPressures = this.getWaterPressures(readable, buffer);
                break;
            case 15: // 电压
                this.voltage = this.getVoltage(buffer);
                break;
            case 14: // 综合
                byte kind = buffer.readByte();
                // 雨量
                if (1 == ((kind & 0b1000_0000) >> 7)) {
                    this.multiValue[0] = this.getRain(buffer);
                }
                // 水位
                if (1 == ((kind & 0b0100_0000) >> 6)) {
                    this.multiValue[1] = this.getWaterLevels(4, buffer)[0];
                }
                // 流量（水量）
                if (1 == ((kind & 0b0010_0000) >> 5)) {
                    Pair<Double, Double> flowAndWater = this.getFlowAndWaters(10, buffer)[0];
                    this.multiValue[2] = flowAndWater.getLeft();
                    this.multiValue[3] = flowAndWater.getRight();
                }
                // 闸位
                if (1 == ((kind & 0b0001_0000) >> 4)) {
                    this.multiValue[4] = this.getGateLevels(3, buffer)[0];
                }
                // 风速（风向）
                if (1 == ((kind & 0b0000_1000) >> 3)) {
                    Pair<Double, Double> windSpeedAndDirection = this.getWindSpeedAndDirection(buffer);
                    this.multiValue[5] = windSpeedAndDirection.getLeft();
                    this.multiValue[6] = windSpeedAndDirection.getRight();
                }
                // 功率
                if (1 == ((kind & 0b0000_0100) >> 2)) {
                    this.multiValue[7] = this.getPowers(3, buffer)[0];
                }
                // 土壤含水率
                if (1 == ((kind & 0b0000_0010) >> 1)) {
                    this.multiValue[8] = this.getSoilWater(2, buffer)[0];
                }
                // 水质
                if (1 == ((kind & 0b0000_0001))) {
                    this.multiValueWaterQuality = this.getWaterQuality(buffer);
                }
                break;
        }
        // danger
        byte[] dangerBytes = new byte[4];
        buffer.readBytes(dangerBytes);
        this.stationWarnStatus = new StationWarnStatus().parse(dangerBytes);
        // Tp
        byte[] tpBytes = new byte[5];
        buffer.readBytes(tpBytes);
        _AUX aux = new _AUX();
        aux.setContent(ArrayUtil.addAll(new byte[]{0, 0}, tpBytes));
        aux.decode();
        this.aux = aux;


    }


    private Double getVoltage(ByteBuf buffer) {
        byte[] voltageBytes = new byte[2];
        buffer.readBytes(voltageBytes);
        return ((voltageBytes[0] & 0b0000_1111) * 0.01d) // 小数后2位
                + (((voltageBytes[0] & 0b1111_0000) >> 4) * 0.01d) // 小数后1位
                + ((voltageBytes[1] & 0b0000_1111)) // 个位
                + (((voltageBytes[1] & 0b1111_0000) >> 4) * 10); // 十位
    }

    private Double[] getWaterPressures(int readable, ByteBuf buffer) {
        // 水压设备数
        int n = readable / 4;
        Double[] waterPressures = new Double[n];
        byte[] waterPressureBytes = new byte[4];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(waterPressureBytes);
            double waterPressure = (waterPressureBytes[0] & 0b0000_1111) * 0.01 // 小数点后2位
                    + ((waterPressureBytes[0] & 0b1111_0000) >> 4) * 0.1 // 小数点后1位
                    + (waterPressureBytes[1] & 0b0000_1111) // 个位
                    + ((waterPressureBytes[1] & 0b1111_0000) >> 4) * 10 // 十位
                    + (waterPressureBytes[2] & 0b0000_1111) * 100 // 百位
                    + ((waterPressureBytes[2] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (waterPressureBytes[3] & 0b0000_1111) * 10000 // 万位
                    + ((waterPressureBytes[3] & 0b1111_0000) >> 4) * 10_0000; // 十万位
            waterPressures[i] = waterPressure;
        }
        return waterPressures;
    }

    private Double[] getEvaporation(int readable, ByteBuf buffer) {
        int n = readable / 3;
        Double[] evaporations = new Double[n];
        byte[] evaporationBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(evaporationBytes);
            double evaporation = (evaporationBytes[0] & 0b0000_1111) * 0.1 // 小数点后1位
                    + ((evaporationBytes[0] & 0b1111_0000) >> 4) // 个位
                    + (evaporationBytes[1] & 0b0000_1111) * 10 // 十位
                    + ((evaporationBytes[1] & 0b1111_0000) >> 4) * 100 // 百位
                    + (evaporationBytes[2] & 0b0000_1111) * 1000; // 千位
            evaporations[i] = evaporation;
        }

        return evaporations;
    }

    private Double[] getSoilWater(int readable, ByteBuf buffer) {
        int n = readable / 2;
        Double[] soilWater = new Double[n];
        byte[] soilWaterBytes = new byte[4];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(soilWaterBytes);
            double soilWaterOne = (soilWaterBytes[0] & 0b0000_1111) * 0.1 // 小数点后1位
                    + ((soilWaterBytes[0] & 0b1111_0000) >> 4) // 个位
                    + (soilWaterBytes[1] & 0b0000_1111) * 10 // 十位
                    + ((soilWaterBytes[1] & 0b1111_0000) >> 4) * 100; // 百位
            soilWater[i] = soilWaterOne;
        }
        return soilWater;
    }

    private WaterQualityParameter getWaterQuality(ByteBuf buffer) throws NoSuchFieldException, IllegalAccessException {
        byte[] parameter = new byte[5];
        WaterQualityParameter waterQualityParameter = new WaterQualityParameter();
        buffer.readBytes(parameter);
        // 怎么判断一个字节的八位中那些不为0
        for (int y = 0; y < 5; y++) {
            for (int i = 0; i <= 7; i++) {
                byte mask = (byte) (1 << i);
                if ((parameter[y] & mask) != 0) {
                    // 拼接水质元素名字
                    String parameterName = "D" + (8 * y + i);
                    byte[] array = 8 * y + i == 24 ? new byte[5] : new byte[4];
                    buffer.readBytes(array);
                    Double value;
                    if (8 * y + i == 24) {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        byte _byte5 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
                        value = (double) (byte5 * 100000000 + byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                    } else if (8 * y + i == 4) {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                    } else {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        Integer decimalPlaces = WaterQualityParameter_Enum.getRight(parameterName);
                        double result = Math.pow(0.1, decimalPlaces);
                        value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1) * result;
                    }
                    System.out.println("D" + 8 * y + i + " 不为0");
                    waterQualityParameter.setParameterValue(parameterName, value);
                }
            }
        }
        return waterQualityParameter;
    }

    private Double getWaterTemperature(ByteBuf buffer) {
        byte[] waterTemperatureBytes = new byte[2];
        buffer.readBytes(waterTemperatureBytes);
        return (waterTemperatureBytes[0] & 0b0000_1111) * 0.1 // 小数点后1位
                + ((waterTemperatureBytes[0] & 0b1111_0000) >> 4) // 个位
                + (waterTemperatureBytes[1] & 0b0000_1111) * 10; // 十位
    }

    private Pair<Double, Double> getWindSpeedAndDirection(ByteBuf buffer) {
        byte[] windBytes = new byte[3];
        buffer.readBytes(windBytes);
        double windSpeed = (windBytes[0] & 0b0000_1111) * 0.01 // 小数点后2位
                + ((windBytes[0] & 0b1111_0000) >> 4) * 0.1 // 小数点后1位
                + (windBytes[1] & 0b0000_1111) // 个位
                + ((windBytes[1] & 0b1111_0000) >> 4) * 10 // 十位
                + (windBytes[2] & 0b0000_1111) * 100; // 百位
        double windDirection = (windBytes[2] & 0b1111_0000);
        return Pair.of(windSpeed, windDirection);
    }

    private Double getPressure(ByteBuf buffer) {
        byte[] pressureBytes = new byte[3];
        buffer.readBytes(pressureBytes);
        return (Double) (double) ((pressureBytes[0] & 0b0000_1111) // 个位
                + ((pressureBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                + (pressureBytes[1] & 0b0000_1111) * 100 // 百位
                + ((pressureBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                + (pressureBytes[2] & 0b0000_1111) * 1_0000);
    }

    private Double[] getPowers(int readable, ByteBuf buffer) {
        // 功率仪表数量
        int n = readable / 3;
        Double[] powers = new Double[n];
        byte[] powerBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(powerBytes);
            double power = (powerBytes[0] & 0b0000_1111) // 个位
                    + ((powerBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                    + (powerBytes[1] & 0b0000_1111) * 100 // 百位
                    + ((powerBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (powerBytes[2] & 0b0000_1111) * 1_0000 // 万位
                    + ((powerBytes[2] & 0b1111_0000) >> 4) * 10_0000; // 十万位
            powers[i] = power;
        }
        return powers;
    }

    private Double[] getGateLevels(int readable, ByteBuf buffer) {
        // 闸位仪表数量
        int n = readable / 3;
        Double[] gateLevels = new Double[n];
        byte[] gateLevelBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(gateLevelBytes);
            double gateLevel = (gateLevelBytes[0] & 0b0000_1111) * 0.01 // 厘米位
                    + ((gateLevelBytes[0] & 0b1111_0000) >> 4) * 0.1 // 分米位
                    + (gateLevelBytes[1] & 0b0000_1111) // 米位
                    + ((gateLevelBytes[1] & 0b1111_0000) >> 4) * 10 // 十米位
                    + (gateLevelBytes[2] & 0b0000_1111) * 100; // 百米位
            gateLevels[i] = gateLevel;
        }
        return gateLevels;
    }

    private Double[] getFlowSpeeds(int readable, ByteBuf buffer) {
        // 流速仪表数量
        int n = readable / 3;
        Double[] flowSpeeds = new Double[n];
        byte[] flowSpeedBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(flowSpeedBytes);
            double flowSpeed = (flowSpeedBytes[0] & 0b0000_1111) * 0.001 // 小数点后3位
                    + ((flowSpeedBytes[0] & 0b1111_0000) >> 4) * 0.01 // 小数点后2位
                    + (flowSpeedBytes[1] & 0b0000_1111) * 0.1 // 小数点后1位
                    + ((flowSpeedBytes[1] & 0b1111_0000) >> 4) // 个位
                    + (flowSpeedBytes[2] & 0b0000_1111) * 10; // 十位
            flowSpeed *= ((flowSpeedBytes[2] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            flowSpeeds[i] = flowSpeed;
        }
        return flowSpeeds;
    }

    private Pair<Double, Double>[] getFlowAndWaters(int readable, ByteBuf buffer) {
        // 流量(水量)仪表数量
        int n = readable / (5 * 2);
        Pair[] flowAndWaters = new Pair[n];
        byte[] flowAndWaterBytes = new byte[5];
        for (int i = 0; i < n; i++) {
            double flow, water;
            // 流量
            buffer.readBytes(flowAndWaterBytes);
            flow = (flowAndWaterBytes[0] & 0b0000_1111) * 0.001d // 小数点后3
                    + ((flowAndWaterBytes[0] & 0b1111_0000) >> 4) * 0.01d // 小数点后2
                    + (flowAndWaterBytes[1] & 0b0000_1111) * 0.1d // 小数点后1
                    + ((flowAndWaterBytes[1] & 0b1111_0000) >> 4) // 个位
                    + (flowAndWaterBytes[2] & 0b0000_1111) * 10 // 十位
                    + ((flowAndWaterBytes[2] & 0b1111_0000) >> 4) * 100 // 百位
                    + (flowAndWaterBytes[3] & 0b0000_1111) * 1000 // 千位
                    + ((flowAndWaterBytes[3] & 0b1111_0000) >> 4) * 1_0000 // 万位
                    + (flowAndWaterBytes[4] & 0b0000_1111) * 10_0000; // 十万位
            flow *= ((flowAndWaterBytes[4] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            // 水量
            buffer.readBytes(flowAndWaterBytes);
            water = (flowAndWaterBytes[0] & 0b0000_1111) // 个位
                    + ((flowAndWaterBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                    + (flowAndWaterBytes[1] & 0b0000_1111) * 100 // 百位
                    + ((flowAndWaterBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (flowAndWaterBytes[2] & 0b0000_1111) * 1_0000 // 万位
                    + ((flowAndWaterBytes[2] & 0b1111_0000) >> 4) * 10_0000 // 十万位
                    + (flowAndWaterBytes[3] & 0b0000_1111) * 10_0000 // 百万位
                    + ((flowAndWaterBytes[3] & 0b1111_0000) >> 4) * 1000_0000 // 千万位
                    + (flowAndWaterBytes[4] & 0b0000_1111) * 10000_0000 // 万万位
                    + ((flowAndWaterBytes[4] & 0b1111_0000) >> 4) * 10_000_0000; // 十万万位
            flowAndWaters[i] = Pair.of(flow, water);
        }
        return flowAndWaters;
    }

    private Double[] getWaterLevels(int readable, ByteBuf buffer) {
        // 水位仪表个数
        int n = readable / 4;
        Double[] waterLevels = new Double[n];
        byte[] waterLevelBytes = new byte[4];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(waterLevelBytes);
            double waterLevel;
            waterLevel = (waterLevelBytes[0] & 0b0000_1111) * 0.001d // 毫米位
                    + ((waterLevelBytes[0] & 0b1111_0000) >> 4) * 0.01d // 厘米位
                    + (waterLevelBytes[1] & 0b0000_1111) * 0.1d // 分米位
                    + ((waterLevelBytes[1] & 0b1111_0000) >> 4) // 米位
                    + (waterLevelBytes[2] & 0b0000_1111) * 10 // 十米位
                    + ((waterLevelBytes[2] & 0b1111_0000) >> 4) * 100 // 百米位
                    + (waterLevelBytes[3] & 0b0000_1111) * 1000; // 千米位
            waterLevel *= ((waterLevelBytes[3] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            waterLevels[i] = waterLevel;
        }
        return waterLevels;
    }

    private double getRain(ByteBuf buffer) {
        byte[] rainBytes = new byte[3];
        buffer.readBytes(rainBytes);
        return ((rainBytes[0] & 0b0000_1111) * 0.1d) // 小数位
                + ((rainBytes[0] & 0b1111_0000) >> 4) // 个位
                + ((rainBytes[1] & 0b0000_1111) * 10) // 十位
                + (((rainBytes[1] & 0b1111_0000) >> 4) * 100) // 百位
                + ((rainBytes[2] & 0b0000_1111) * 1000) // 千位
                + (((rainBytes[2] & 0b1111_0000) >> 4) * 10000); // 万位
    }
}

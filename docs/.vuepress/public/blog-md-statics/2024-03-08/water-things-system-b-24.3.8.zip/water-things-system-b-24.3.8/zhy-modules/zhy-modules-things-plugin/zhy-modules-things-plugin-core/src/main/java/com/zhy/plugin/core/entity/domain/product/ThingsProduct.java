package com.zhy.plugin.core.entity.domain.product;

import com.zhy.common.core.domain.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author wangfeng
 * @since 2023-11-06 14:26
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ThingsProduct extends BaseEntity {
    String productId;
    String productName;
    String productDesc;
    String protocol;
    String metaData;
}

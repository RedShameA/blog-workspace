package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 02H 链路检测
 *
 * @author wangfeng
 * @since 2023-09-07 14:24
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkLinkCheck_02H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._02.getFNCByte();
    }

    /**
     * 链路监测指令 <br>
     * F0登录
     * F1退出登录
     * F2在线保持
     */
    private byte cmd;

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode, this.cmd};
    }

}

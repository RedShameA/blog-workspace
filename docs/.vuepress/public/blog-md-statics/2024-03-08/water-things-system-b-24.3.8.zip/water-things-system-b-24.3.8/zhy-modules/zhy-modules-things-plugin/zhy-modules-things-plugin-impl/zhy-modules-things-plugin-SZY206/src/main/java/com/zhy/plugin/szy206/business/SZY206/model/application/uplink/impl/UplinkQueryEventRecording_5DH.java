package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.ERCRecord;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;

/**
 * @Since 2023/10/7
 * @Author：houDeJian
 * @Record：
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryEventRecording_5DH extends ApplicationSpaceUplink {

    /**
     * 返回的事件记录
     */
    ERCRecord ERC = new ERCRecord();

    @SneakyThrows
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        for (int i = 1; i < 19; i++) {
            byte[] arr = new byte[2];
            buffer.readBytes(arr);
            String name = "ERC" + i;
            this.ERC.setParameterValue(name, arr);
        }
    }
}

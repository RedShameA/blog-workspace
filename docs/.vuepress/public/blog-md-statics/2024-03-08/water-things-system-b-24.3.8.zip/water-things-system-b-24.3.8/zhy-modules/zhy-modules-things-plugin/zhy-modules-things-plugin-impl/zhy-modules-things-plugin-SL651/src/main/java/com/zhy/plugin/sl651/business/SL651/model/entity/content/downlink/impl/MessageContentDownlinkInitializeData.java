package com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.MessageContentDownlink;
import lombok.Data;

/**
 * 初始化固态储存数据下行报
 */
@Data
public class MessageContentDownlinkInitializeData extends MessageContentDownlink {

    /**
     * 初始化固态数据标识符
     */
    private byte[] Identifier;
    @Override
    public byte[] encode() {
        byte[] bytes = new byte[0];
        // 发报时间
        String yyyyMMddHHmmss = DateUtil.format(this.getMessageTimeParse(), "yyMMddHHmmss");
        this.setMessageTime(HexUtil.decodeHex(yyyyMMddHHmmss));
        byte[] messageTime = this.getMessageTime();
        byte[] serialNumber = this.getSerialNumber();
        bytes = ArrayUtil.addAll(bytes,serialNumber);
        bytes = ArrayUtil.addAll(bytes,messageTime);
        bytes = ArrayUtil.addAll(bytes,Identifier);
        return bytes;
    }
}

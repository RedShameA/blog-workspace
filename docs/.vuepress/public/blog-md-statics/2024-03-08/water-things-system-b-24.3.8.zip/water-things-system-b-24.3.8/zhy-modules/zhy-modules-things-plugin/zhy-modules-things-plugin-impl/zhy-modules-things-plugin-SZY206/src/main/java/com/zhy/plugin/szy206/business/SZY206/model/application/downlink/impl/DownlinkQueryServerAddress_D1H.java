package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * D1H 获取服务端地址 （山东）
 *
 * @author wangfeng
 * @since 2023-10-05 16:20
 */
public class DownlinkQueryServerAddress_D1H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._D1.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

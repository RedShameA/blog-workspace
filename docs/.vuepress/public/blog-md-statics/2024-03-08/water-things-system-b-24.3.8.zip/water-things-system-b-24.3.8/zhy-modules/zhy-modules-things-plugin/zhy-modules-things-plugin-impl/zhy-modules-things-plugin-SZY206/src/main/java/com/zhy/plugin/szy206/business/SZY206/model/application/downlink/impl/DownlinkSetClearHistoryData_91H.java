package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

/**
 * @Author：houDeJian
 * @Record：91_清空遥测终端历史数据单元
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetClearHistoryData_91H extends ApplicationSpaceDownlink {

    {
        applicationFunctionCode = AFN._91.getFNCByte();
    }

    HashMap<String, Integer> clearCommand;

    @Override
    public byte[] encode() {
        byte command = (byte) (clearCommand.get("D0") | (clearCommand.get("D1") << 1));
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode, command}, this.aux.encode());
    }
}

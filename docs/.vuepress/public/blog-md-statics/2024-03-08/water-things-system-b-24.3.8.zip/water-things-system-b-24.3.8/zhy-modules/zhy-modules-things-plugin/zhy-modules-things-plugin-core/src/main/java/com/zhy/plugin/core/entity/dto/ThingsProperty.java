package com.zhy.plugin.core.entity.dto;

import com.alibaba.fastjson2.JSONObject;
import lombok.Data;

import java.util.Objects;

@Data
public class ThingsProperty {
    private String propertyId;
    private String propertyName;
    private String propertyType;
    private String propertyProtocolType;
    public static ThingsProperty fromJson(JSONObject json){
        ThingsProperty entity = new ThingsProperty();
        entity.setPropertyId(json.getString("id"));
        entity.setPropertyName(json.getString("name"));
        entity.setPropertyType(json.getString("type"));
        entity.setPropertyProtocolType(json.getString("protocolType"));
        return entity;
    }
    public JSONObject toJson(){
        JSONObject json = new JSONObject();
        json.put("id", this.getPropertyId());
        json.put("name", this.getPropertyName());
        json.put("type", this.getPropertyType());
        json.put("protocolType", this.getPropertyProtocolType());
        return json;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ThingsProperty that = (ThingsProperty) o;
        return Objects.equals(propertyProtocolType, that.propertyProtocolType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(propertyProtocolType);
    }
}

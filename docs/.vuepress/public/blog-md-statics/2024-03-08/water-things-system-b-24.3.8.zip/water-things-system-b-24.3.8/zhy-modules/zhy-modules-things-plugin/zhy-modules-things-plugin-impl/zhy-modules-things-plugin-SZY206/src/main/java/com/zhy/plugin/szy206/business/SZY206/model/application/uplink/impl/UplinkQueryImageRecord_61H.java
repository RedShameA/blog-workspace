package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Since 2023/10/8
 * @Author：houDeJian
 * @Record：
 */

// todo 需要处理拆包
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryImageRecord_61H extends ApplicationSpaceUplink {
    /**
     * 图片长度 Kb
     */
    int length = 0;
    byte[] imageData;

    @Override
    public void decode() {
        // 功能码
        ByteBuf byteBuf = Unpooled.wrappedBuffer(this.content);
        this.applicationFunctionCode = byteBuf.readByte();
        // 图片长度
        byte[] arr = new byte[2];
        byteBuf.readBytes(arr);
        int byte1 = ((arr[0] >> 4 & 0x0F) * 10) + (arr[0] & 0x0F);
        int byte2 = ((arr[1] >> 4 & 0x0F) * 10) + (arr[1] & 0x0F);
        this.length = byte1 + byte2 * 100;

        // 图片
        byte[] image = new byte[this.length];
        byteBuf.readBytes(image);
        this.imageData = image;
    }
}

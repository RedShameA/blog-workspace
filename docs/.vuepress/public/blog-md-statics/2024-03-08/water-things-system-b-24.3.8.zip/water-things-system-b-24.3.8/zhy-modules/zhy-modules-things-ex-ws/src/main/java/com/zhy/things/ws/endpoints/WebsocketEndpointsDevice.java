package com.zhy.things.ws.endpoints;

import com.zhy.things.ws.util.WebsocketSessionUtil;
import org.springframework.stereotype.Component;

import javax.websocket.OnClose;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

/**
 * @author wangfeng
 * @since 2023-12-28 16:41
 */
@Component
@ServerEndpoint("/websocket/device/message")
public class WebsocketEndpointsDevice {
    // 每个客户端都会有相应的session,服务端可以发送相关消息
    private Session session;


    @OnOpen
    public void onOpen(Session session) {
        this.session = session;
        WebsocketSessionUtil.addSession(session);
        System.out.println("websocket有新的连接:" + session.getId());
    }

    @OnClose
    public void onClose() {
        WebsocketSessionUtil.removeSession(session);
        System.out.println("websocket连接断开:" + this.session.getId());
    }


}

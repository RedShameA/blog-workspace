package com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.MessageContentDownlink;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * 指定要素实时数据
 *
 * @author wangfeng
 * @since 2023-07-27 17:27
 */
public class MessageContentDownlinkQueryRealTimeSpecify extends MessageContentDownlink {

    private final HashSet<String> elementTagSet = new HashSet<>();

    public void addElementTag(String elementTag){
        this.elementTagSet.add(elementTag);
    }

    public void addElementTag(String[] elementTag){
        this.elementTagSet.addAll(Arrays.asList(elementTag));
    }

    public void addElementTag(List<String> elementTag){
        this.elementTagSet.addAll(elementTag);
    }
    @Override
    public byte[] encode() {
        byte[] bytes = new byte[0];
        byte[] serialNumber = this.getSerialNumber();
        byte[] messageTime = this.getMessageTime();
        // 发报时间
        String yyyyMMddHHmmss = DateUtil.format(this.getMessageTimeParse(), "yyMMddHHmmss");
        this.setMessageTime(HexUtil.decodeHex(yyyyMMddHHmmss));
        bytes = ArrayUtil.addAll(bytes, serialNumber);
        bytes = ArrayUtil.addAll(bytes, messageTime);
        for (String tag : this.elementTagSet) {
            bytes = ArrayUtil.addAll(bytes, HexUtil.decodeHex(tag));
        }
        return bytes;
    }
}

package com.zhy.plugin.sl651.business.SL651.visitor.reply.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl.MessageContentDownlinkACK;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkTest;
import com.zhy.plugin.sl651.business.SL651.visitor.reply.MessageFrameReplyVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 回复测试报
 * @author wangfeng
 * @since 2023-07-05 09:16
 */
@Slf4j
@Component
public class TestFrameReplyVisitor implements MessageFrameReplyVisitor<MessageContentUplinkTest> {

    @Override
    public String getFunctionCode() {
        return AppendixB._30.getHEX();
    }



    @Override
    public void doReply(ChannelHandlerContext ctx, MessageFrame frame) {
        // 开始解析
        // MessageContentUplinkTest messageContent = new MessageContentUplinkTest();
        // messageContent.setBytes(frame.getContent());
        // messageContent.decode();
        // List<Pair<String, byte[]>> elements = messageContent.getElements();
        // // 解析完对正文做处理，存库或者回复
        // System.out.println(elements);
        // byte[] filter = ElementTagUtil.filter(frame.getContent(), "");
        log.info("回复测试报");
        // 是测试报 做回复 报文正文套用上行报文
        MessageContentDownlinkACK ack = new MessageContentDownlinkACK();
        ack.setSerialNumber(frame.getMessageContent().getSerialNumber());
        ack.setMessageTimeParse(new Date());
        frame.setMessageContent(ack);
        // 配置为下行报文
        frame.setUpLinkFlag((byte) 8);
        // 重新计算长度
        frame.compute();
        // log.info("先不返回ack");
        // 返回报文
        String endType;
        if ((byte) 3 == frame.getContentEndChar()) {
            log.info("后续无报文");
            endType = "结束";
            frame.setContentEndChar((byte) 4);
            log.info("返回" + endType + "ack");
        } else if ((byte) 23 == frame.getContentEndChar()) {
            log.info("后续有报文");
            endType = "继续";
            frame.setContentEndChar((byte) 6);
            log.info("返回" + endType + "ack");

        } else {
            log.info("不知道的报文结束字符");
            return;
        }
        ctx.channel().writeAndFlush(frame);
    }
}

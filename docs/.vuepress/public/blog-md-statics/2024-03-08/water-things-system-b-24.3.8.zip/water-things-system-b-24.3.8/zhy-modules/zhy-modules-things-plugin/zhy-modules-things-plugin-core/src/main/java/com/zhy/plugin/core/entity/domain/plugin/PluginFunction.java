package com.zhy.plugin.core.entity.domain.plugin;

/**
 * @author wangfeng
 * @since 2023-11-06 15:00
 */
public class PluginFunction {
}

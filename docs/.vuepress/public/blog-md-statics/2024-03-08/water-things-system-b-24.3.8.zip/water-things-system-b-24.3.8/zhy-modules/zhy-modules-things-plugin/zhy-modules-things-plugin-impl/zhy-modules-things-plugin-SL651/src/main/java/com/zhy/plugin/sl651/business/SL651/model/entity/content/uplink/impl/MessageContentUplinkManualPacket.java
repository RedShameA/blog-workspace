package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.nio.charset.Charset;

/**
 * 人工置数报(主动上行)
 * @author wangfeng
 * @since 2023-07-31 17:12
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentUplinkManualPacket extends MessageContentUplink {

    private String manualPacket;
    @Override
    public void decode() {
        byte[] content = this.getBytes();
        ByteBuf buffer = Unpooled.wrappedBuffer(content);

        // 流水号
        byte[] serialNumber = new byte[2];
        buffer.readBytes(serialNumber);
        this.setSerialNumber(serialNumber);
        // 发报时间
        byte[] messageTime = new byte[6];
        buffer.readBytes(messageTime);
        this.setMessageTime(messageTime);

        while (buffer.isReadable()) {
            // 标识符
            byte[] flag = new byte[2];
            buffer.readBytes(flag);
            String flagStr = HexUtil.encodeHexStr(flag, false).substring(0, 2);
            if (flagStr.equals("F2")) { // 人工置数
                int length = buffer.readableBytes();
                byte[] elementData = new byte[length];
                buffer.readBytes(elementData);
                this.manualPacket = Convert.hexToStr(HexUtil.encodeHexStr(elementData), Charset.defaultCharset());
            }
        }
    }


    public static void main(String[] args) {
        System.out.println(Convert.hexToStr("51312E32333420", Charset.defaultCharset()));

    }
}

package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkQueryRecord;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 处理查询遥测站事件记录报
 */
@Slf4j
@Component
public class QueryRecordFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkQueryRecord> {
    @Override
    public String getFunctionCode() {
        return AppendixB._50.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("查询遥测站事件记录visitor");
        MessageContentUplinkQueryRecord queryRecord = getContent(frame);
        Integer acLossRecord = queryRecord.getACLossRecord();
        Integer dataErrorRecord = queryRecord.getDataErrorRecord();
        Integer messageReceivingRecord = queryRecord.getMessageReceivingRecord();
        Integer sendingMessageRecord = queryRecord.getSendingMessageRecord();

        System.out.println("交流失电记录" + acLossRecord);
        System.out.println("数据出错记录" + dataErrorRecord);
        System.out.println("受保温记录" + messageReceivingRecord);
        System.out.println(sendingMessageRecord);
    }
}

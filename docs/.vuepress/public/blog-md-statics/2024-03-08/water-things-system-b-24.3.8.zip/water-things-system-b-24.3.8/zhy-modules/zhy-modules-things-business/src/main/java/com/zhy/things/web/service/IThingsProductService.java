package com.zhy.things.web.service;

import com.alibaba.fastjson2.JSONArray;
import com.zhy.plugin.core.entity.domain.product.ThingsProduct;

import java.util.List;

/**
 * @author wangfeng
 * @since 2023-11-09 14:33
 */

public interface IThingsProductService {

    /**
     * 获取所有属性id
     */
    public JSONArray getAllPropertiesById(String id);
    /**
     * 查询product
     *
     * @param id product主键
     * @return product
     */
    public ThingsProduct selectThingsProductById(String id);

    /**
     * 查询product列表
     *
     * @param thingsProduct product
     * @return product集合
     */
    public List<ThingsProduct> selectThingsProductList(ThingsProduct thingsProduct);

    /**
     * 新增product
     *
     * @param thingsProduct product
     * @return 结果
     */
    public int insertThingsProduct(ThingsProduct thingsProduct);

    /**
     * 修改product
     *
     * @param thingsProduct product
     * @return 结果
     */
    public int updateThingsProduct(ThingsProduct thingsProduct);

    /**
     * 批量删除product
     *
     * @param ids 需要删除的product主键集合
     * @return 结果
     */
    public int deleteThingsProductByIds(String[] ids);

    /**
     * 删除product信息
     *
     * @param id product主键
     * @return 结果
     */
    public int deleteThingsProductById(String id);
}

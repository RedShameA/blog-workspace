package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 50H 查询遥测终端、中继站 地址
 *
 * @author houdejian
 * @since 2023-09-27 17:04
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryAddress_50H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._50.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

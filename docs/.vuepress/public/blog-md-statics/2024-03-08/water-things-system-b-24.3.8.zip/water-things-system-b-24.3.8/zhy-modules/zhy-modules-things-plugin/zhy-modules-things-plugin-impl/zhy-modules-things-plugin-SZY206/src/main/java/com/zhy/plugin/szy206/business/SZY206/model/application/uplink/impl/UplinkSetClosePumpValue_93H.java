package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

/**
 * @Author：houDeJian
 * @Record：
 *          93H-遥控关闭水泵或阀门/闸门
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkSetClosePumpValue_93H extends ApplicationSpaceUplink {

    HashMap<String,Object> Data=new HashMap<>();
    @Override
    public void decode() {
        ByteBuf byteBuf = Unpooled.wrappedBuffer(content);
        this.applicationFunctionCode=byteBuf.readByte();
        byte _byte= byteBuf.readByte();
        //编码
        int  code= (_byte  & 0b1111_0000) ;
        Data.put("code",code);
        //1-表示成功 0-失败

        String ifSuccess=(_byte  & 0b0000_1010)!=0?"成功":"失败";
        Data.put("ifSuccess",ifSuccess);

    }
}

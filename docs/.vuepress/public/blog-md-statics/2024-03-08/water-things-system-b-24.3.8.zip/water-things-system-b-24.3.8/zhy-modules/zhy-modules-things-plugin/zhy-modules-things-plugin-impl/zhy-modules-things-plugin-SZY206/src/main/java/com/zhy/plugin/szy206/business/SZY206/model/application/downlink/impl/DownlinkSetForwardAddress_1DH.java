package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;

/**
 * @Author：houDeJian
 * @Record：1DH: 设置中继站转发终端地址
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetForwardAddress_1DH extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode= AFN._1D.getFNCByte();
    }
    ArrayList<String> forwardAddress;
    @Override
    public byte[] encode() {
        int size = forwardAddress.size();
        ByteBuf buffer = Unpooled.buffer(5*size);
        for (int i = 0; i < size; i++) {
            if(forwardAddress.get(i).length()==10){
                String s = forwardAddress.get(i);
                //怎么判断地址转为为5位字节？
                buffer.writeBytes(HexUtil.decodeHex(forwardAddress.get(i)));
            }else{
                throw new RuntimeException("设置的地址不符合要求！！！");
            }
        }
        byte[] arr=new byte[5*size];
        buffer.readBytes(arr);
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, arr, this.aux.encode());
    }
}

package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink;

import com.zhy.plugin.sl651.business.SL651.model.entity.content.MessageContent;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

/**
 * 上行报文正文 <br>
 * 多了几个字段：遥测站地址、遥测站分类码、观测时间 <br>
 * 但这几个字段也可能没有，比如上行链路维持报，就没有下列3个参数，只有父类的两个字段；人工置数也没有 <br>
 * <br>
 * 上行链路子类需实现此类，再添加自己的字段，如：存放具体的要素/参数 对的list字段、放置水泵开关机数据的字段
 *
 * @author wangfeng
 * @since 2023/06/028
 */
@Data
@EqualsAndHashCode(callSuper = true)
public abstract class MessageContentUplink extends MessageContent implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 正文的原始字节数据
     */
    private byte[] bytes;

    /**
     * 遥测站地址
     */
    private byte[] station;

    /**
     * 遥测站分类码
     */
    private Byte stationType;

    /**
     * 观测时间
     */
    private byte[] collectTime;
    private Date collectTimeParse;

    /**
     * 编码方法实现 <br>
     * 上行报文直接返回记录的原报文字节数组
     */
    @Override
    public byte[] encode() {
        return bytes;
    }

    /**
     * 解码方法 <br>
     * 上行报文应自己去实现
     */
    @Override
    abstract public void decode();

}

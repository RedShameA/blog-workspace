package com.zhy.plugin.sl651.business.SL651.handler;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.common.Crc16Utils;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.MessageContent;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplinkFactory;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageCodec;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Locale;

/**
 * 对上行或下行的SL651-2014报文进行编解码操作
 *
 * @author wangfeng
 * @since 2023-06-27 11:00
 */
@Slf4j
public class SL651_2014Codec extends ByteToMessageCodec<MessageFrame> {

    /**
     * 只有下行的时候才会encode，所以这里的包一般都是下行报文
     */
    @Override
    protected void encode(ChannelHandlerContext channelHandlerContext, MessageFrame frame, ByteBuf out) throws Exception {
        log.info("发送报文 进入下行编码");
        frame.compute();
        // 组装下行报文数据
        byte[] bytes = new byte[0];
        // 帧起始符
        bytes = ArrayUtil.addAll(bytes, frame.getStartChar());
        // 遥测站地址
        bytes = ArrayUtil.addAll(bytes, frame.getTelemetricStation());
        // 中心站地址
        bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getCenterStation()});
        // 密码
        bytes = ArrayUtil.addAll(bytes, frame.getPassword());
        // 功能码
        bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getFunctionCode()});
        // 下行标志及长度
        int i = (((int) frame.getUpLinkFlag()) << 4) + ((int) frame.getContentLength()[0]);
        ByteBuffer allocate = ByteBuffer.allocate(4);
        allocate.putInt(i);
        byte[] array = allocate.array();
        bytes = ArrayUtil.addAll(bytes, new byte[]{array[3], frame.getContentLength()[1]});
        // 报文起始符
        bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getContentStartChar()});
        // 报文正文
        bytes = ArrayUtil.addAll(bytes, frame.getMessageContent().encode());
        // 报文结束符
        bytes = ArrayUtil.addAll(bytes, new byte[]{frame.getContentEndChar()});
        // crc
        int[] crc16 = Crc16Utils.getCRC16(bytes);
        bytes = ArrayUtil.addAll(bytes, new byte[]{(byte)crc16[1], (byte)crc16[0]});
        //System.out.println(HexUtil.encodeHex(bytes));
        // 编码完成
        out.writeBytes(bytes);
    }

    /**
     * 同理，这里的包一般就是上行报文
     */
    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext, ByteBuf byteBuf, List<Object> list) throws Exception {
        log.info("收到报文 进入上行解码");
        // 解析报文主体
        ByteBuf duplicate = byteBuf.duplicate();
        byte[] allBytes = new byte[duplicate.readableBytes()];
        duplicate.readBytes(allBytes);
        MessageFrame messageFrame = structMessage(byteBuf);
        messageFrame.setAllBytes(allBytes);
        messageFrame.setAllBytesStr(HexUtil.encodeHexStr(allBytes).toUpperCase(Locale.ROOT));
        // 解析报文正文主体（只解析流水号、发报时间、遥测站地址； 不解析正文内的要素/参数串）
        // MessageContent messageContent = structContent(messageFrame.getContent());
        MessageContent messageContent = MessageContentUplinkFactory.parseContent(messageFrame.getFunctionCode(), messageFrame.getContent());
        messageFrame.setMessageContent(messageContent);
        list.add(messageFrame);
    }


    /**
     * 结构化报文帧.
     *
     * @param buffer 报文帧字节
     * @return 报文帧结构化
     */
    private MessageFrame structMessage(ByteBuf buffer) {
        MessageFrame messageFrame = new MessageFrame();

        // 帧起始符
        byte[] startChar = new byte[2];
        buffer.readBytes(startChar);
        messageFrame.setStartChar(startChar);

        // 中心站地址
        byte centerStation = buffer.readByte();
        messageFrame.setCenterStation(centerStation);

        // 遥测站地址
        byte[] telemetricStation = new byte[5];
        buffer.readBytes(telemetricStation);
        messageFrame.setTelemetricStation(telemetricStation);
        String stcd = HexUtil.encodeHexStr(telemetricStation).toUpperCase(Locale.ROOT);
        messageFrame.setTelemetricStationParse(stcd);
        messageFrame.setTelemetricStationParse8(stcd.substring(2));

        // 密码
        byte[] password = new byte[2];
        buffer.readBytes(password);
        messageFrame.setPassword(password);
        messageFrame.setPasswordParse(HexUtil.encodeHexStr(password));

        // 功能码
        byte functionCode = buffer.readByte();
        messageFrame.setFunctionCode(functionCode);

        // 报文上下行标识及长度
        byte[] contentHeader = new byte[2];
        buffer.readBytes(contentHeader);
        byte upLinkFlag = (byte) (contentHeader[0] >> 4);
        messageFrame.setUpLinkFlag(upLinkFlag);
        contentHeader[0] = (byte) (contentHeader[0] & 0x0f);
        messageFrame.setContentLength(contentHeader);

        // 报文起始符
        byte contentStartChar = buffer.readByte();
        messageFrame.setContentStartChar(contentStartChar);

        // 报文正文
        short contentLength = (short) (((contentHeader[0] & 0x00ff) << 8) | (contentHeader[1] & 0x00ff));
        byte[] content = new byte[contentLength];
        buffer.readBytes(content);
        messageFrame.setContent(content);

        // 报文结束符
        byte contentEndChar = buffer.readByte();
        messageFrame.setContentEndChar(contentEndChar);

        // 校验码
        byte[] checkCode = new byte[2];
        buffer.readBytes(checkCode);
        messageFrame.setCheckCode(checkCode);

        return messageFrame;
    }

    /**
     * 结构化报文帧正文.
     *
     * @param content 报文帧正文字节
     * @return 报文帧正文结构化
     */
    private MessageContent structContent(byte[] content) {
        // System.out.println("=========报文正文=====================");
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // MessageContentUplink messageContent = new MessageContentUplink();

        // 流水号
        byte[] serialNumber = new byte[2];
        buffer.readBytes(serialNumber);
        // messageContent.setSerialNumber(serialNumber);

        // 发报时间
        byte[] messageTime = new byte[6];
        buffer.readBytes(messageTime);
        // messageContent.setMessageTime(messageTime);
        // 正文要素串
        // 标识符
        byte[] flag = new byte[2];
        // 遥测站地址
        byte[] station = new byte[5];
        // 遥测站分类码
        byte stationType = 0;
        // 观测时间
        byte[] collectTime = new byte[5];
        // 循环读要素
        boolean breakFlag = false;
        while (buffer.isReadable()) {
            buffer.readBytes(flag);
            String flagStr = HexUtil.encodeHexStr(flag, false).substring(0, 2);
            switch (flagStr) {
                case "F1":
                    buffer.readBytes(station);
                    stationType = buffer.readByte();
                    // System.out.println("遥测站地址:" + Arrays.toString(station));
                    // System.out.println("遥测站分类码:" + stationType);
                    System.out.println("解析到了遥测站信息");
                    // breakFlag = true;
                    break;
                case "F0":
                    buffer.readBytes(collectTime);
                    // System.out.println("观测时间:" + Arrays.toString(collectTime));
                    breakFlag = true;
                    break;
                default:

            }
            if (breakFlag) {
                break;
            }
        }
        // 将一些信息写入正文对象
        // messageContent.setStation(station);
        // messageContent.setStationType(stationType);
        // messageContent.setCollectTime(collectTime);
        // messageContent.setElementParas(elementParas);
        // return messageContent;
        return null;
    }

    /**
     * 把一个字节数组拼成一个字节,并计算小数点位数
     */
    private static double joinBytes(ByteBuf buffer, byte[] flag) {
        int length = (flag[1] & 0xff) >> 3;
        int decimal = flag[1] & 0x7;
        byte[] data = new byte[length];
        buffer.readBytes(data);
        boolean flag2 = false;// 是否是负数
        double result0 = 0;
        for (int i = 0; i < data.length; i++) {
            if (i == 0 && data[i] == 0xff) {
                flag2 = true;
                continue;
            }
            double high = ((data[i] & 0xff) >> 4) * Math.pow(10, (length * 2 - i * 2) - 1);
            double low = (data[i] & 0xf) * Math.pow(10, (length * 2 - i * 2) - 2);
            result0 = result0 + high + low;
        }
        BigDecimal result01 = new BigDecimal(String.valueOf(result0));
        double result = result01.movePointLeft(decimal).doubleValue();
        if (flag2) {
            result = 0 - result;
        }
        return result;
    }
}

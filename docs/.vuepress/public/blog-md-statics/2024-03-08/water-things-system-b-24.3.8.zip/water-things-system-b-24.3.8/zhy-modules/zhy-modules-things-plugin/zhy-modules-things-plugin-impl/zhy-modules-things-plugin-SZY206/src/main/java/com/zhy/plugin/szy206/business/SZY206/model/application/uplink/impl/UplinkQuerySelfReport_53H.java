package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.SelfReport;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;

/**
 * @Author：houDeJian
 * @Record：53H-查询遥测终端的数据自报种类及时间(响应报文)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQuerySelfReport_53H extends ApplicationSpaceUplink {

    /**
     * 返回的数据自报种类及时间
     */
    SelfReport selfReport = new SelfReport();

    @SneakyThrows
    @Override
    public void decode() {
        ByteBuf byteBuffer = Unpooled.wrappedBuffer(this.content);
        this.applicationFunctionCode = byteBuffer.readByte();
        byte[] parameter = new byte[2];
        byteBuffer.readBytes(parameter);

        for (int y = 0; y < 2; y++) {
            if (y == 0) {
                for (int i = 0; i < 8; i++) {
                    byte mask = (byte) (1 << i);
                    // if ((parameter[y] & mask) != 0) {
                    // 拼接水质元素名字
                    String parameterName = "D" + (i);
                    byte _byte1 = byteBuffer.readByte();
                    byte _byte2 = byteBuffer.readByte();
                    int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                    int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                    int value = byte2 * 100 + byte1;
                    switch (i) {
                        case 0:
                            this.selfReport.setD0(value);
                            break;
                        case 1:
                            this.selfReport.setD1(value);
                            break;
                        case 2:
                            this.selfReport.setD2(value);
                            break;
                        case 3:
                            this.selfReport.setD3(value);
                            break;
                        case 4:
                            this.selfReport.setD4(value);
                            break;
                        case 5:
                            this.selfReport.setD5(value);
                            break;
                        case 6:
                            this.selfReport.setD6(value);
                            break;
                        case 7:
                            this.selfReport.setD7(value);
                            break;
                    }
                }
            }
            if (y == 1) {
                for (int i = 0; i < 6; i++) {
                    byte mask = (byte) (1 << i);
                    String parameterName = "D" + (8 * y + i);
                    byte _byte1 = byteBuffer.readByte();
                    byte _byte2 = byteBuffer.readByte();
                    int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                    int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                    int value = byte2 * 100 + byte1;
                    switch (i) {
                        case 0:
                            this.selfReport.setD8(value);
                            break;
                        case 1:
                            this.selfReport.setD9(value);
                            break;
                        case 2:
                            this.selfReport.setD10(value);
                            break;
                        case 3:
                            this.selfReport.setD11(value);
                            break;
                        case 4:
                            this.selfReport.setD12(value);
                            break;
                        case 5:
                            this.selfReport.setD13(value);
                            break;
                    }
                }
            }
        }

    }

}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;

/**
 * @Author：houDeJian
 * @Record：5FH-查询水泵电机实时工作数据
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryPumpWorkData_5FH extends ApplicationSpaceUplink {

    /**
     * key current1、current2、current3 分别代表 电流A、电流B、电流C
     * key voltage1、voltage2、voltage3 分别代表 电压A、电压B、电压C
     */
    HashMap<String, byte[]> pumpData = new HashMap<>();

    @Override
    public void decode() {
        ByteBuf byteBuf = Unpooled.wrappedBuffer(this.content);
        this.applicationFunctionCode = byteBuf.readByte();
        for (int i = 1; i < 4; i++) {
            byte[] arr = new byte[2];
            byteBuf.readBytes(arr);
            String name = "voltage" + i;
            this.pumpData.put(name, arr);
        }
        for (int i = 1; i < 4; i++) {
            byte[] arr = new byte[2];
            byteBuf.readBytes(arr);
            String name = "current" + i;
            this.pumpData.put(name, arr);
        }
    }
}

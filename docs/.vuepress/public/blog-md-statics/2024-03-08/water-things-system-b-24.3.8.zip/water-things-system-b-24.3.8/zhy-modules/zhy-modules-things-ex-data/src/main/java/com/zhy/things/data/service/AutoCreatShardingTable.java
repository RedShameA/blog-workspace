package com.zhy.things.data.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

/**
 * @author wangfeng
 * @since 2023-11-29 19:08
 */
@Slf4j
@Component
public class AutoCreatShardingTable {
    @Resource
    ThingsDataHisService thingsDataHisService;

    @PostConstruct
    void run(){
        log.info("creating sharding table things_data_his...");
        thingsDataHisService.initTable();
    }
}

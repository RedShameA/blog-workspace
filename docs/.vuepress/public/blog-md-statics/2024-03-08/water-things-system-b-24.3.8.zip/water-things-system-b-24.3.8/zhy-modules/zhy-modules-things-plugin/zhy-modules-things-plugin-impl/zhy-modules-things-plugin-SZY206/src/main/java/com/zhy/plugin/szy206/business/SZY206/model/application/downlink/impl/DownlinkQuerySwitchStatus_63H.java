package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：63H 查询中继站工作机状态和切换记录
 */
public class DownlinkQuerySwitchStatus_63H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._63.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

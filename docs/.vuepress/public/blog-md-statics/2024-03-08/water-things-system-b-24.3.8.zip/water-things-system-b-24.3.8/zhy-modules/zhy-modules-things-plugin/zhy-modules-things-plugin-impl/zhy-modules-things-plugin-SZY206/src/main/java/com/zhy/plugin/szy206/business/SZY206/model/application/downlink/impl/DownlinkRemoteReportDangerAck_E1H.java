package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @author wangfeng
 * @since 2023-10-07 16:29
 */
public class DownlinkRemoteReportDangerAck_E1H extends ApplicationSpaceDownlink {
    //设置功能码
    {
        applicationFunctionCode = AFN._E1.getFNCByte();
    }
    @Override
    public byte[] encode() {
        return new byte[]{applicationFunctionCode};
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：33H_定值控制退出
 */

public class DownlinkSetExitValueControl_33H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._33.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, this.aux.encode());
    }
}

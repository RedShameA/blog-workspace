package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：52H查询遥测终端的工作模式的响应帧解析
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryWorkMode_52H extends ApplicationSpaceUplink {


    /**
     * 0：兼容  1：自报  2：查询/应答
     */
    private byte workMode;

    @Override
    public void decode() {
        this.applicationFunctionCode = this.content[0];
        this.workMode = this.content[1];
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：90H_复位遥测终端参数和状态（响应帧）
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkResetTelemetryStation_90H extends ApplicationSpaceUplink {
    /**
     * 执行状态
     */
    String message;
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        byte _byte = buffer.readByte();
        message=(int)(_byte & 0x5A)==90?"已执行完毕":"未执行完毕";

    }
}

package com.zhy.plugin.core.entity.domain.plugin;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wangfeng
 * @since 2023-11-06 13:51
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PluginDeviceOnlineStatus {
    /**
     * 设备id
     */
    String deviceId;

    /**
     * true在线，false不在线
     */
    boolean online;
}

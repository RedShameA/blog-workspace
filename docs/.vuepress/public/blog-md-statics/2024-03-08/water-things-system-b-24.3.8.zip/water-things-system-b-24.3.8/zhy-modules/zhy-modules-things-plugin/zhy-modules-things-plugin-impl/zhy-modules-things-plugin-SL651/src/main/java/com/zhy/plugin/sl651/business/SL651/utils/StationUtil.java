package com.zhy.plugin.sl651.business.SL651.utils;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.db.entity.FamiliarStation651;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author wangfeng
 * @since 2023-09-05 9:24
 */
@Slf4j
public class StationUtil {

    public static ConcurrentHashMap<String, FamiliarStation651> ONLINE_STATION = new ConcurrentHashMap<>();


    public static void addOnline(String id, FamiliarStation651 station) {
        ONLINE_STATION.put(id, station);
        // 记录到数据库

    }

    public static void removeOnline(String id) {
        if (null!=id){
            ONLINE_STATION.remove(id);
        }
    }

    public static FamiliarStation651 getOnlineStation(String id) {
        return ONLINE_STATION.get(id);
    }

    /**
     * 在在线遥测站列表中根据id获取密码 <br>
     * 如果在线列表没有就抛出IllegalStateException("station is not in the online list")
     * @param id 遥测站id
     * @return 密码
     */
    public static String getPasswordInOnline(String id) {
        FamiliarStation651 familiarStation651 = ONLINE_STATION.get(id);
        if (null == familiarStation651){
            throw new IllegalStateException("station is not in the online list");
        }else{
            return familiarStation651.getPassword();
        }
    }
    /**
     * 在在线遥测站列表中根据id获取十六进制密码 <br>
     * 如果在线列表没有就抛出IllegalStateException("station is not in the online list")
     * @param id 遥测站id
     * @return 十六进制密码
     */
    public static byte[] getPasswordHexInOnline(String id) {
        FamiliarStation651 familiarStation651 = ONLINE_STATION.get(id);
        if (null == familiarStation651){
            throw new IllegalStateException("station is not in the online list");
        }else{
            return HexUtil.decodeHex(familiarStation651.getPassword());
        }
    }
}

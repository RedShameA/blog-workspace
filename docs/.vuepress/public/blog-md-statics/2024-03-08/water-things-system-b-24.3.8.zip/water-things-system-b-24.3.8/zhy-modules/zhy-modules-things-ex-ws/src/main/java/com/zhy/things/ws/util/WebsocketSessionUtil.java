package com.zhy.things.ws.util;

import javax.websocket.Session;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * @author wangfeng
 * @since 2023-12-28 17:27
 */
public class WebsocketSessionUtil {
    private static final CopyOnWriteArraySet<Session> sessions = new CopyOnWriteArraySet<>();

    public static void addSession(Session session) {
        sessions.add(session);
    }


    public static void removeSession(Session session) {
        sessions.remove(session);
    }

    public static void send(String message) {
        for (Session session : sessions) {
            try {
                // 加锁避免同时对某个session发送数据，导致发送失败
                synchronized (session) {
                    session.getBasicRemote().sendText(message);
                }
            } catch (Exception ignored) {
            }
        }
    }
}

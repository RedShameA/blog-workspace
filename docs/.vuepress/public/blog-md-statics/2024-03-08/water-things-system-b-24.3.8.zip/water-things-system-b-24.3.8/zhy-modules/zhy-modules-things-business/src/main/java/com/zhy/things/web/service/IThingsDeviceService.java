package com.zhy.things.web.service;

import com.zhy.plugin.core.entity.domain.device.ThingsDevice;
import com.zhy.plugin.core.entity.dto.ThingsDeviceDto;

import java.util.List;

/**
 * @author wangfeng
 * @since 2023-11-09 19:52
 */
public interface IThingsDeviceService {
    /**
     * 查询device
     *
     * @param id device主键
     * @return device
     */
    public ThingsDevice selectThingsDeviceById(String id);

    /**
     * 查询device列表
     *
     * @param thingsDeviceDto device
     * @return device集合
     */
    public List<ThingsDevice> selectThingsDeviceList(ThingsDeviceDto thingsDeviceDto);

    /**
     * 新增device
     *
     * @param thingsDevice device
     * @return 结果
     */
    public int insertThingsDevice(ThingsDevice thingsDevice);

    /**
     * 修改device
     *
     * @param thingsDevice device
     * @return 结果
     */
    public int updateThingsDevice(ThingsDevice thingsDevice);

    /**
     * 批量删除device
     *
     * @param ids 需要删除的device主键集合
     * @return 结果
     */
    public int deleteThingsDeviceByIds(String[] ids);

    /**
     * 删除device信息
     *
     * @param id device主键
     * @return 结果
     */
    public int deleteThingsDeviceById(String id);

    /**
     * 导入设备数据
     *
     * @param deviceList 设备数据列表
     * @param operName 操作用户
     * @return 结果
     */
    public String importDevice(List<ThingsDevice> deviceList, String operName);
}

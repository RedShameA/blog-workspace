package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.MessageContent;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.*;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

/**
 * @author wangfeng
 * @since 2023-06-28 11:47
 */
public class MessageContentUplinkFactory {

    /**
     * 根据功能码，解析正文 到 对应的正文对象
     * @param functionCode 功能码
     * @param content 正文字节
     */
    public static MessageContent parseContent(byte functionCode, byte[] content){

        // MessageContentUplinkCommon common = new MessageContentUplinkCommon();
        // common.setBytes(content);
        // ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // // 流水号
        // byte[] serialNumber = new byte[2];
        // buffer.readBytes(serialNumber);
        // common.setSerialNumber(serialNumber);
        // // 发报时间
        // byte[] messageTime = new byte[6];
        // buffer.readBytes(messageTime);
        // common.setMessageTime(messageTime);
        // return common;
        String str = HexUtil.encodeHexStr(new byte[]{functionCode}).toUpperCase();
        switch (str){
            case "2F": // 链路维持报
                MessageContentUplinkHeartBeat uplinkHeartBeat = new MessageContentUplinkHeartBeat();
                uplinkHeartBeat.setBytes(content);
                uplinkHeartBeat.decode();
                return uplinkHeartBeat;
            case "30": // 测试报
                MessageContentUplinkTest uplinkTest = new MessageContentUplinkTest();
                uplinkTest.setBytes(content);
                uplinkTest.decode();
                return uplinkTest;
            case "31": //均匀时段水文信息报
                MessageContentUplinkAverage uplinkAverage = new MessageContentUplinkAverage();
                uplinkAverage.setBytes(content);
                uplinkAverage.decode();
                return uplinkAverage;
            case "32": //定时报
                MessageContentUplinkTiming uplinkTiming = new MessageContentUplinkTiming();
                uplinkTiming.setBytes(content);
                uplinkTiming.decode();
                return uplinkTiming;
            case "33" ://加报报
                MessageContentUplinkPlus uplinkPlus = new MessageContentUplinkPlus();
                uplinkPlus.setBytes(content);
                uplinkPlus.decode();
                return uplinkPlus;
            case "34": //小时报
                MessageContentUplinkHourly uplinkHourly = new MessageContentUplinkHourly();
                uplinkHourly.setBytes(content);
                uplinkHourly.decode();
                return uplinkHourly;
            case "35":
                // 人工置数报(主动上行)
                MessageContentUplinkManualPacket uplinkManualPacket = new MessageContentUplinkManualPacket();
                uplinkManualPacket.setBytes(content);
                uplinkManualPacket.decode();
                return uplinkManualPacket;
            case "37":
                // 中心站查询遥测站实时数据上行报
                MessageContentUplinkRealTime uplinkRealTime = new MessageContentUplinkRealTime();
                uplinkRealTime.setBytes(content);
                uplinkRealTime.decode();
                return uplinkRealTime;
            case "38":
                // 中心站查询时段数据
                MessageContentUplinkPeriodElement uplinkPeriodElement = new MessageContentUplinkPeriodElement();
                uplinkPeriodElement.setBytes(content);
                uplinkPeriodElement.decode();
                return uplinkPeriodElement;
            case "39":
                // 人工置数报(查询上行)
                MessageContentUplinkManualPacketQuery uplinkManualPacketQuery = new MessageContentUplinkManualPacketQuery();
                uplinkManualPacketQuery.setBytes(content);
                uplinkManualPacketQuery.decode();
                return uplinkManualPacketQuery;
            case "3A":
                // 中心站查询遥测站指定要素实时数据上行报
                MessageContentUplinkRealTimeSpecify uplinkRealTimeSpecify = new MessageContentUplinkRealTimeSpecify();
                uplinkRealTimeSpecify.setBytes(content);
                uplinkRealTimeSpecify.decode();
                return uplinkRealTimeSpecify;
            case "40":
                // 中心站修改遥测站基本配置表
            case "41":
                // 中心站查询/遥测站自报 基本配置表
                MessageContentUplinkBasicSettings uplinkBasicSettings = new MessageContentUplinkBasicSettings();
                uplinkBasicSettings.setBytes(content);
                uplinkBasicSettings.decode();
                return uplinkBasicSettings;
            case "42":
                // 中心站修改遥测站运行参数配置表
            case "43":
                // 中心站查询/遥测站自报 运行参数配置表
                MessageContentUplinkOperatingSettings uplinkOperatingSettings = new MessageContentUplinkOperatingSettings();
                uplinkOperatingSettings.setBytes(content);
                uplinkOperatingSettings.decode();
                return uplinkOperatingSettings;
            case "45":
                //查询遥测终端软件版本
                MessageContentUplinkSoftwareVersion uplinkSoftwareVersion = new MessageContentUplinkSoftwareVersion();
                uplinkSoftwareVersion.setBytes(content);
                uplinkSoftwareVersion.decode();
                return uplinkSoftwareVersion;
            case "46":
                // 查询遥测站状态和报警信息
                MessageContentUplinkStatus uplinkStatus = new MessageContentUplinkStatus();
                uplinkStatus.setBytes(content);
                uplinkStatus.decode();
                return uplinkStatus;
            case "47":
                // 初始化固态存储数据
                MessageContentUplinkInitializeData uplinkInitializeData = new MessageContentUplinkInitializeData();
                uplinkInitializeData.setBytes(content);
                uplinkInitializeData.decode();
                return uplinkInitializeData;
            case "48":
                // 恢复遥测站出厂设置报文
                 MessageContentUplinkRestoreSetting uplinkRestoreSetting = new MessageContentUplinkRestoreSetting();
                 uplinkRestoreSetting.setBytes(content);
                 uplinkRestoreSetting.decode();
                 return uplinkRestoreSetting;
            case "49":
                // 修改密码
                MessageContentUplinkChangePassword uplinkChangePassword = new MessageContentUplinkChangePassword();
                uplinkChangePassword.setBytes(content);
                uplinkChangePassword.decode();
                return uplinkChangePassword;
            case "4A":
                // 中心站设置遥测站时间记录
                MessageContentUplinkSetClock setClock = new MessageContentUplinkSetClock();
                setClock.setBytes(content);
                setClock.decode();
                return setClock;
            case "50":
                // 中心站查询遥测站事件记录
                MessageContentUplinkQueryRecord uplinkQueryRecord = new MessageContentUplinkQueryRecord();
                uplinkQueryRecord.setBytes(content);
                uplinkQueryRecord.decode();
                return uplinkQueryRecord;
            case "51":
                // 中心站查询遥测站时钟
                MessageContentUplinkQueryClock uplinkQueryClock = new MessageContentUplinkQueryClock();
                uplinkQueryClock.setBytes(content);
                uplinkQueryClock.decode();
                return uplinkQueryClock;
            default:
                MessageContentUplinkCommon common = new MessageContentUplinkCommon();
                common.setBytes(content);
                ByteBuf buffer = Unpooled.wrappedBuffer(content);
                // 流水号
                byte[] serialNumber = new byte[2];
                buffer.readBytes(serialNumber);
                common.setSerialNumber(serialNumber);
                // 发报时间
                byte[] messageTime = new byte[6];
                buffer.readBytes(messageTime);
                common.setMessageTime(messageTime);
                return common;
        }
    }
}

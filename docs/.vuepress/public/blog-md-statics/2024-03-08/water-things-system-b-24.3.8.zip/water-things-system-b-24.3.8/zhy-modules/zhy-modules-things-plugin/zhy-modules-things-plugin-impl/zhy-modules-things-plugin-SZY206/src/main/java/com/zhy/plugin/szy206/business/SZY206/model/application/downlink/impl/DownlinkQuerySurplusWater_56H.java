package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：56H 查询遥测站终端剩余水量和报警值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQuerySurplusWater_56H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._56.getFNCByte();
    }


    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

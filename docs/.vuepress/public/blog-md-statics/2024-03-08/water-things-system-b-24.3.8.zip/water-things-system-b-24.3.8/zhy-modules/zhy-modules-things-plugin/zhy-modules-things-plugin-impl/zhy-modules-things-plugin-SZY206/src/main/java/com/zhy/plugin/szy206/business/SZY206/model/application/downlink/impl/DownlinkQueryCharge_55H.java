package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：55H-查询遥测站最近充值量和现有剩余水量
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryCharge_55H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._55.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

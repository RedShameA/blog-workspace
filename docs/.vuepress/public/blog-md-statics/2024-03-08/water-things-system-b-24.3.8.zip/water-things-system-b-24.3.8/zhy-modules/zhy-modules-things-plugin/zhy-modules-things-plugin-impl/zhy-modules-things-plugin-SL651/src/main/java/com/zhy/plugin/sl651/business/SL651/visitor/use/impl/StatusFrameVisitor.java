package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkStatus;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 处理遥测站状态报
 */
@Slf4j
@Component
public class StatusFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkStatus> {

    @Override
    public String getFunctionCode() {
        return AppendixB._46.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("遥测站状态报visitor");
        MessageContentUplinkStatus uplinkStatus = getContent(frame);
        Boolean memoryStatus = uplinkStatus.getMemoryStatus();
        Boolean icIsValid = uplinkStatus.getICIsValid();
        Boolean flowMeterStatus = uplinkStatus.getFlowMeterStatus();
        Boolean waterPumpWorkingStatus = uplinkStatus.getWaterPumpWorkingStatus();
        Boolean residualWaterVolumeAlarm = uplinkStatus.getResidualWaterVolumeAlarm();
        Boolean waterPumpWorkingStatus1 = uplinkStatus.getWaterPumpWorkingStatus();

        System.out.println("存储器状态" + (memoryStatus ? "正常":"异常"));
        System.out.println("IC 卡功能有效" + (icIsValid ? "正常":"异常"));
        System.out.println("水泵工作状态" + (waterPumpWorkingStatus1 ? "正常":"异常"));
    }
}

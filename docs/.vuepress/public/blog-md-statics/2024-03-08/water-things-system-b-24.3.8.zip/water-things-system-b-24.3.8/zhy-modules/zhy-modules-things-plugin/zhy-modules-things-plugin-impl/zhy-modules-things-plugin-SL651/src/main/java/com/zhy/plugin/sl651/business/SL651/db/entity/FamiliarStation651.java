package com.zhy.plugin.sl651.business.SL651.db.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 已连接过的遥测站的实体类
 * @author wangfeng
 * @since 2023-08-09 9:04
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FamiliarStation651 {

    private String stationId;

    private String password;

}

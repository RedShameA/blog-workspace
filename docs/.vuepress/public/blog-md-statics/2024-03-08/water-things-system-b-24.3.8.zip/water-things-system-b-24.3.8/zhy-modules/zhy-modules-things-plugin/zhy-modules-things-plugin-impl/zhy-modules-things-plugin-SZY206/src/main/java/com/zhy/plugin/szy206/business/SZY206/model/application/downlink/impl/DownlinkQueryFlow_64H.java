package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：64H-查询遥终端的流量参数上限值
 */
public class DownlinkQueryFlow_64H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._64.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

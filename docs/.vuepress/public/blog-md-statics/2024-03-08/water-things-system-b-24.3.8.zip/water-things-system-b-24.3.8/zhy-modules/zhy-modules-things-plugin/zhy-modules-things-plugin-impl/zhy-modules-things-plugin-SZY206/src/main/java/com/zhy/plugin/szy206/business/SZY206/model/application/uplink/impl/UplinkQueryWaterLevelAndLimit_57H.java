package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.tuple.Triple;

import java.util.ArrayList;

/**
 * @Author：houDeJian
 * @Record：57查询遥测站终端的水位基值、水位上下限
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryWaterLevelAndLimit_57H extends ApplicationSpaceUplink {

    /**
     * 存放水位
     * left:水位基值
     * middle：水位上限
     * right:水位下限
     */
    ArrayList<Triple<Double, Double, Double>> waterLevelAndLimit=new ArrayList<>();

    byte waterWarnSpace[];
    /**
     * 存放告警值
     */
    String  waterWarn;
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        int i = buffer.readableBytes();
        int n=i/7;
        for (int y = 0; y < n; y++) {
            double basicLevel;
            double downLevel;
            double upLevel;

            // 水位基值
            byte _byte1 = buffer.readByte();
            byte _byte2 = buffer.readByte();
            byte _byte3 = buffer.readByte();
            int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
            int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
            int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
            int sign=(_byte3 >> 7 & 0x01)==0?1:-1;
            basicLevel=sign*byte3*100+byte2+byte1*0.01;

            // 水位下限
            byte _byte4 = buffer.readByte();
            byte _byte5 = buffer.readByte();
            int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
            int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
            downLevel=byte5+byte4*0.01;

            byte _byte6 = buffer.readByte();
            byte _byte7 = buffer.readByte();
            int byte6 = ((_byte6 >> 4 & 0x0F) * 10) + (_byte6 & 0x0F);
            int byte7 = ((_byte7 >> 4 & 0x0F) * 10) + (_byte7 & 0x0F);
            upLevel=byte7+byte6*0.01;
            Triple<Double, Double, Double> triple = Triple.of(basicLevel,downLevel,upLevel);
            waterLevelAndLimit.add(triple);
        }

        this.waterWarnSpace = new byte[2];
        buffer.readBytes(this.waterWarnSpace);
        this.waterWarn = HexUtil.encodeHexStr(this.waterWarnSpace);

    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;

/**
 * @Author：houDeJian
 * @Record：
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryForwardAddress_62H extends ApplicationSpaceUplink {

    /**
     * 返回的中继站转发地址
     */
    ArrayList<String> forwardAddress;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        int n = buffer.readableBytes() / 5;
        for (int i = 0; i < n; i++) {
            byte[] addressSpace = new byte[5];
            buffer.readBytes(addressSpace);
            String address = HexUtil.encodeHexStr(addressSpace);
            this.forwardAddress.add(address);
        }
    }
}

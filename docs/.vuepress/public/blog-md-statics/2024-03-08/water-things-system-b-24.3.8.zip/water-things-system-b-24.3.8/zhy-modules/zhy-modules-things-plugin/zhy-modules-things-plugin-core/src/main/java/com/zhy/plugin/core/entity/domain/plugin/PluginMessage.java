package com.zhy.plugin.core.entity.domain.plugin;

import com.zhy.things.common.constants.ValueType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 插件消息
 *
 * @author wangfeng
 * @since 2023-11-06 11:49
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PluginMessage {

    /**
     * 设备id
     */
    String deviceId;
    /**
     * 消息时间
     */
    Date messageTime;
    /**
     * 消息属性类型
     */
    ValueType messageValueType;
    /**
     * 消息值
     */
    Double messageValue;

    public static PluginMessage of(String deviceId, Date messageTime, ValueType messageValueType, Double messageValue) {
        return new PluginMessage(deviceId, messageTime, messageValueType, messageValue);
    }


}

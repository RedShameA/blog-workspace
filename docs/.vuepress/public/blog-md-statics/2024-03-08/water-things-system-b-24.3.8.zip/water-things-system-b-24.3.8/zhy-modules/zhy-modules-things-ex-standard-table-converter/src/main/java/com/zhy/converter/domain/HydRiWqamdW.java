package com.zhy.converter.domain;

import lombok.Data;

import java.util.Date;

/**
 * 水质自动监测数据表
 */
@Data
public class HydRiWqamdW {
    /**
     * 采样时间
     */
    private Date spt;

    /**
     * 测站编码
     */
    private String stcd;

    /**
     * 砷-水中无机和有机化合物中砷的总量
     */
    private Double ars;

    /**
     * 镉-水中镉的含量
     */
    private Double cd;

    /**
     * 叶绿素a-水中藻类的光合作用色素叶绿素的含量
     */
    private Double chla;

    /**
     * 化学需氧量-以重铬酸钾为氧化剂所能氧化的物质含量
     */
    private Double codcr;

    /**
     * 高锰酸盐指数-以高锰酸钾为氧化剂所能氧化的物质含量
     */
    private Double codmn;

    /**
     * 砷-水中无机和有机化合物中砷的总量
     */
    private Double cr6;

    /**
     * 铜-水中铜的含量
     */
    private Double cu;

    /**
     * 溶解氧-水中氢离子活度（H+）的负对数。小数不过二位
     */
    private Double doc;

    /**
     * 氟化物-水中游离的氛离子总量，以F-计
     */
    private Double f;

    /**
     * 砷-水中无机和有机化合物中砷的总量
     */
    private Double hg;

    /**
     * 亚硝酸盐氮-水中亚硝酸盐含量，以N计
     */
    private Double n02;

    /**
     * 硝酸盐氮-水中硝酸盐含量，以N计
     */
    private Double n03;

    /**
     * 氨氮-水中的游离氨和按盐含量，以N计
     */
    private Double nh3n;

    /**
     * 铅-水中铅的含量
     */
    private Double pb;

    /**
     * 锑-水中锑的含量
     */
    private Double sb;

    /**
     * 总氮-水中能被过硫酸钾氧化的无机氮和有机氮化合物总量
     */
    private Double tn;

    /**
     * 总有机碳-水中溶解性和悬浮性有机物中存在的碳的总量
     */
    private Double toc;

    /**
     * 总磷-水中经过强氧化后转变成正磷酸盐的各种无机磷和有机磷总量，以P计
     */
    private Double tp;

    /**
     * 浑浊度-指水体着色的程度，它影响着水体的透光性和水生生物的生长。单位为度，记至整数
     */
    private Double turb;

    /**
     * 挥发酚-随水蒸汽熘出的，并和4-氨基安替比林反应生成有色化合物的挥发酚类化合物含量，结果以苯酚计
     */
    private Double vlph;

    /**
     * 水温
     */
    private Double wtmp;

    /**
     * 锌-水中锌的含量
     */
    private Double zn;

    /**
     * 电导率-在特定条件下，规定尺寸单位立方体的水溶液相对面之间的测得的电阻倒数。单位为微西门/cm，计至整数
     */
    private Double cond;

    /**
     * PH-水中氢离子活度（H+）的负对数。小数不过二位
     */
    private Double ph;
}
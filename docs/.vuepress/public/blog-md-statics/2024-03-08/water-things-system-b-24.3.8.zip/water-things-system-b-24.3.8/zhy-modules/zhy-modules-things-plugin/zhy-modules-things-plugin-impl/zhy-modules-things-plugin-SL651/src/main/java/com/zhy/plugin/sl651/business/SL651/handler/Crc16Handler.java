package com.zhy.plugin.sl651.business.SL651.handler;

import com.zhy.plugin.sl651.business.SL651.utils.WaitForResultUtil;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.internal.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;

/**
 * 校验收到的字节数组是否合法
 *
 * @author yulei
 */
public class Crc16Handler extends ChannelInboundHandlerAdapter {
    private static final Logger LOGGER = LoggerFactory.getLogger(Crc16Handler.class);

    /**
     * 客户端数据到来时触发
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        //将字节读到字节数组中
        ByteBuf buf = (ByteBuf) msg;
        byte[] b = new byte[buf.readableBytes()];
        buf.readBytes(b);
        WaitForResultUtil.fireFirstIn(b);
        //将收到的数据转成字符串作为日志输出
        LOGGER.info("msg size:{}, content: {}", b.length, StringUtil.toHexString(b).toUpperCase());
        //校验数据是否合法,最后两个字节的数据是校验码，我们在自己做校验的时候需求截掉
        int[] crc16 = this.getCRC16(Arrays.copyOfRange(b, 0, b.length - 2));
        //倒数第二个字节和倒数第一个字节为校验字符，上面一句话在计算出校验字符以后，与他自身携带的校验字符做对比，如果相等，输出交给下游处理
        if (crc16[0] == Byte.toUnsignedInt(b[b.length - 1]) && crc16[1] == Byte.toUnsignedInt(b[b.length - 2])) {
            LOGGER.info("crc success!");
            ctx.fireChannelRead(buf.resetReaderIndex());
        }else{
            LOGGER.info("crc failed");
        }
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        // 将发送缓冲区的消息全部写到SocketChannel中
        ctx.flush();
    }

    /**
     * 发生异常时触发
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        cause.printStackTrace();
        // 释放与ChannelHandlerContext相关联的资源
        ctx.close();
    }

    public static String toHexString(byte[] b) {
        StringBuilder buffer = new StringBuilder();
        for (byte value : b) {
            buffer.append(toHexString(value));
        }
        return buffer.toString();
    }

    public static String toHexString(byte b) {
        String s = Integer.toHexString(b & 0xFF);
        if (s.length() == 1) {
            return "0" + s.toUpperCase();
        } else {
            return s.toUpperCase();
        }
    }

    public int[] getCRC16(byte[] bytes) {
        int crc = 0x0000ffff;
        int polynomial = 0x0000a001;

        int i, j;
        for (i = 0; i < bytes.length; i++) {
            crc ^= ((int) bytes[i] & 0x000000ff);
            for (j = 0; j < 8; j++) {
                if ((crc & 0x00000001) != 0) {
                    crc >>= 1;
                    crc ^= polynomial;
                } else {
                    crc >>= 1;
                }
            }
        }
        //将校验码取出来分别放置，注意高位有一个算数右移的操作
        int highBit = (crc & 0xff00) >> 8;
        int lowBit = crc & 0xff;
        return new int[]{lowBit, highBit};
    }
}

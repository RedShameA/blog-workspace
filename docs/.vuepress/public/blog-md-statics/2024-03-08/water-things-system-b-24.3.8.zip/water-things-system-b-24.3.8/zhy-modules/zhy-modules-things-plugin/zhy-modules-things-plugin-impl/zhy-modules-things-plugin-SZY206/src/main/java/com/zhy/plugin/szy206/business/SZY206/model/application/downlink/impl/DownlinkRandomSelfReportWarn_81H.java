package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Since 2023/9/27
 * @Author：houDeJian
 * @Record：81_随机自报报警数据
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkRandomSelfReportWarn_81H extends ApplicationSpaceDownlink {
    {
        applicationFunctionCode = AFN._81.getFNCByte();
    }

    /**
     * 遥测站工作模式 <br>
     * 0-遥测站终端兼容工作状态 <br>
     * 1-遥测站自报状态 <br>
     * 2-遥测站处在应答/查询状态 <br>
     * 3-调试/维修 <br>
     */
    int workMode;

    @Override
    public byte[] encode() {
        byte _byte1 = (byte) (workMode & 0b0000_1111);
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode, _byte1});
    }
}

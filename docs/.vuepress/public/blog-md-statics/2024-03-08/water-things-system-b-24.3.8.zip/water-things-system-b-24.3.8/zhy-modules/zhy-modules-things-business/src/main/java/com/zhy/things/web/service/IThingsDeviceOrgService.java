package com.zhy.things.web.service;

import com.zhy.common.core.domain.TreeSelect;
import com.zhy.common.things.domain.ThingsDeviceOrg;

import java.util.List;

/**
 * @author wangfeng
 * @since 2023-12-08 16:29
 */
public interface IThingsDeviceOrgService {

    public List<TreeSelect> getTree();

    public int addOrg(ThingsDeviceOrg org);

    public int delOrg(Long id);

    public boolean hasChild(Long id);



    /**
     * 查询物联设备组织树
     *
     * @param deviceOrgId 物联设备组织树主键
     * @return 物联设备组织树
     */
    public ThingsDeviceOrg selectThingsDeviceOrgByDeviceOrgId(Long deviceOrgId);

    /**
     * 查询物联设备组织树列表
     *
     * @param thingsDeviceOrg 物联设备组织树
     * @return 物联设备组织树集合
     */
    public List<ThingsDeviceOrg> selectThingsDeviceOrgList(ThingsDeviceOrg thingsDeviceOrg);

    /**
     * 新增物联设备组织树
     *
     * @param thingsDeviceOrg 物联设备组织树
     * @return 结果
     */
    public int insertThingsDeviceOrg(ThingsDeviceOrg thingsDeviceOrg);

    /**
     * 修改物联设备组织树
     *
     * @param thingsDeviceOrg 物联设备组织树
     * @return 结果
     */
    public int updateThingsDeviceOrg(ThingsDeviceOrg thingsDeviceOrg);

    /**
     * 批量删除物联设备组织树
     *
     * @param deviceOrgIds 需要删除的物联设备组织树主键集合
     * @return 结果
     */
    public int deleteThingsDeviceOrgByDeviceOrgIds(Long[] deviceOrgIds);

    /**
     * 删除物联设备组织树信息
     *
     * @param deviceOrgId 物联设备组织树主键
     * @return 结果
     */
    public int deleteThingsDeviceOrgByDeviceOrgId(Long deviceOrgId);

}

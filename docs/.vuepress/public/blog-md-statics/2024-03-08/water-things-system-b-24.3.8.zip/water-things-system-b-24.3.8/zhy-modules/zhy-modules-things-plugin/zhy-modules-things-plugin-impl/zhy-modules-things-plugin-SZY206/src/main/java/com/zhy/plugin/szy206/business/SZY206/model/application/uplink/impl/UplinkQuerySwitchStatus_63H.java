package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.SwitchStatus;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

/**
 * @Author：houDeJian
 * @Record：63-查询中继站工作机状态和切换记录（响应帧）
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQuerySwitchStatus_63H extends ApplicationSpaceUplink {
    // todo 有问题没解决
    //切换状态
    SwitchStatus switchStatus=new SwitchStatus();
    //机器状态
     HashMap<String,Integer> machineFault=new HashMap<>();
//    SwitchStatus machineFault=new SwitchStatus();
    //切换记录
    ArrayList<Date> switchDate=new ArrayList<>();


    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();

        byte _byte = buffer.readByte();

        byte mask1 = (byte) (1 << 0);
        byte mask2 = (byte) (1 << 1);
        int value0=(_byte & mask1) +(_byte & mask2)==3?1:0;
        switchStatus.setD0(value0);
        byte mask3 = (byte) (1 << 2);
        byte mask4 = (byte) (1 << 3);
        int value1=(_byte & mask3)+(_byte & mask4)==3?1:0;
        switchStatus.setD1(value1);

        for (int i = 4; i <7; i++) {
            byte mask = (byte) (1 << i);
            String name = "D" + (i-2);
            int value=(_byte & mask) > 0 ?1:0;
            switch (i-2){
                case 2:
                    switchStatus.setD2(value);
                    break;
                case 3:
                    switchStatus.setD3(value);
                    break;
                case 4:
                    switchStatus.setD4(value);
                    break;
            }
        }
        byte _byte1 = buffer.readByte();
        for (int i = 0; i < 6; i++) {
            byte mask5 = (byte) (1 << i);
            int value5=(_byte & mask5) > 0 ?1:0;
            String meter5="M"+i;
            machineFault.put(meter5,value5);
        }
        int num = buffer.readableBytes()/5;
        if(num>0){
            for (int i = 0; i < num; i++) {
                byte _MINUTE = buffer.readByte();
                byte _HOUR = buffer.readByte();
                byte _DAY = buffer.readByte();
                byte _WEEK_MONTH = buffer.readByte();
                byte _YEAR = buffer.readByte();

                int minute = ((_MINUTE >> 4) * 10) + (_MINUTE & 0b0000_1111);
                int hour = ((_HOUR >> 4) * 10) + (_HOUR & 0b0000_1111);
                int day = ((_DAY >> 4) * 10) + (_DAY & 0b0000_1111);
                int month = ((_WEEK_MONTH >> 4 & 0b0000_0001) * 10) + (0b00001111 & _WEEK_MONTH) - 1;
                int year = ((_YEAR >> 4) * 10) + (_YEAR & 0b0000_1111) + 2000;
                Calendar instance = Calendar.getInstance();
                instance.set(Calendar.MILLISECOND, 0);
                instance.set(Calendar.MINUTE, minute);
                instance.set(Calendar.HOUR_OF_DAY, hour);
                instance.set(Calendar.DAY_OF_MONTH, day);
                instance.set(Calendar.MONTH, month);
                instance.set(Calendar.YEAR, year);
                Date time = instance.getTime();
                switchDate.add(time);
            }
        }
    }
}

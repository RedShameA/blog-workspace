package com.zhy.plugin.szy206.business.SZY206.constants;

import lombok.Getter;

/**
 * 控制域功能码
 * @author wangfeng
 * @since 2023-09-14 13:47
 */
public enum CONTROL_FNC {

    DOWNLINK_0(0, "发送∕确认", "命令"),
    DOWNLINK_1(1, "查询∕响应帧", "雨量参数"),
    DOWNLINK_2(2, "查询∕响应帧", "水位参数"),
    DOWNLINK_3(3, "查询∕响应帧", "流量(水量)参数"),
    DOWNLINK_4(4, "查询∕响应帧", "流速参数"),
    DOWNLINK_5(5, "查询∕响应帧", "闸位参数"),
    DOWNLINK_6(6, "查询∕响应帧", "功率参数"),
    DOWNLINK_7(7, "查询∕响应帧", "气压参数"),
    DOWNLINK_8(8, "查询∕响应帧", "风速参数"),
    DOWNLINK_9(9, "查询∕响应帧", "水温参数"),
    DOWNLINK_10(10, "查询∕响应帧", "水质参数"),
    DOWNLINK_11(11, "查询∕响应帧", "土壤含水率参数"),
    DOWNLINK_12(12, "查询∕响应帧", "蒸发量参数"),
    DOWNLINK_13(13, "查询∕响应帧", "报警或状态参数"),
    DOWNLINK_14(14, "查询∕响应帧", "综合参数"),
    DOWNLINK_15(15, "查询∕响应帧", "水压参数"),
    UPLINK_0(0, "确认", "认可"),
    UPLINK_1(1, "自报帧", "雨量参数"),
    UPLINK_2(2, "自报帧", "水位参数"),
    UPLINK_3(3, "自报帧", "流量（水量）参数"),
    UPLINK_4(4, "自报帧", "流速参数"),
    UPLINK_5(5, "自报帧", "闸位参数"),
    UPLINK_6(6, "自报帧", "功率参数"),
    UPLINK_7(7, "自报帧", "气压参数"),
    UPLINK_8(8, "自报帧", "风速参数"),
    UPLINK_9(9, "自报帧", "水温参数"),
    UPLINK_10(10, "自报帧", "水质参数"),
    UPLINK_11(11, "自报帧", "土壤含水率参数"),
    UPLINK_12(12, "自报帧", "蒸发量参数"),
    UPLINK_13(13, "自报帧", "报警或状态参数"),
    UPLINK_14(14, "自报帧", "统计雨量"),
    UPLINK_15(15, "自报帧", "水压参数");



    


    /**
     * 功能码
     */
    @Getter
    private int FNC;

    /**
     * 帧类型
     */
    private String frameType;

    /**
     * 定义
     */
    private String definition;

    CONTROL_FNC(int FNC, String frameType, String definition) {
        this.FNC = FNC;
        this.frameType = frameType;
        this.definition = definition;
    }
}

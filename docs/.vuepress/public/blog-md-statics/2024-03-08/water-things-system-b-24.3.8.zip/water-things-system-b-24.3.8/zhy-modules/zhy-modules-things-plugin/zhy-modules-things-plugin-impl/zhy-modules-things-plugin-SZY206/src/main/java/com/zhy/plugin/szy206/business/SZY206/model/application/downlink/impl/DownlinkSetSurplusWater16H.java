package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：16H 设置遥测站的剩余水量报警值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetSurplusWater16H extends ApplicationSpaceDownlink {


    {
        this.applicationFunctionCode = AFN._16.getFNCByte();
    }

    /**
     * 设置剩余水量报警值<br/>
     * 取值范围 0 ~ 999999
     */
    int surplusWaterWarn;

    @Override
    public byte[] encode() {
        if (surplusWaterWarn > 0 && surplusWaterWarn < 999999) {
            byte[] arr = new byte[3];

            String changeString = String.format("%06d", surplusWaterWarn);
            int byte1 = Integer.parseInt(changeString.substring(4, 6));
            int byte2 = Integer.parseInt(changeString.substring(2, 4));
            int byte3 = Integer.parseInt(changeString.substring(0, 2));
            arr[0] = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
            arr[1] = (byte) ((byte2 / 10 << 4) | (byte2 % 10));
            arr[2] = (byte) ((byte3 / 10 << 4) | (byte3 % 10));
            return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode}, arr, this.aux.encode());

        } else {
            throw new RuntimeException("输入的数据不在取值范围内！");
        }

    }


}

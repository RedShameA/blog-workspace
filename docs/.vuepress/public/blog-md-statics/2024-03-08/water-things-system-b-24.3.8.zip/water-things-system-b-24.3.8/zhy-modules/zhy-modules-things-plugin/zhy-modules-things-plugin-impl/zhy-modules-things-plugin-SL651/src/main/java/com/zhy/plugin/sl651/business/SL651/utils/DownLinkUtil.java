package com.zhy.plugin.sl651.business.SL651.utils;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.*;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.downlink.impl.*;
import lombok.extern.slf4j.Slf4j;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * 下行报文工具类
 *
 * @author wangfeng
 * @since 2023-07-27 11:07
 */
@Slf4j
public class DownLinkUtil {
    private static final SimpleDateFormat YYMMDDHHmmSS = new SimpleDateFormat("yyMMddHHmmss");

    /**
     * 获取下行帧: 查询遥测站实时数据报文
     *
     * @param id 遥测站id
     */
    public static MessageFrame getRealTimePacket(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._37.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryCommon queryCommon = new MessageContentDownlinkQueryCommon();
        queryCommon.setSerialNumber(Common651.HEX_0000);
        queryCommon.setMessageTimeParse(new Date());
        frame.setMessageContent(queryCommon);
        // 报文结束符
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        // 获取下行帧:
        return frame;
    }

    /**
     * 获取下行帧: 查询遥测站指定要素实时数据报文
     *
     * @param id          遥测站id
     * @param elementTags 指定的要素数组
     */
    public static MessageFrame getRealTimeSpecifyPacket(String id, String... elementTags) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._3A.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryRealTimeSpecify specify = new MessageContentDownlinkQueryRealTimeSpecify();
        specify.setSerialNumber(Common651.HEX_0000);
        specify.setMessageTimeParse(new Date());
        for (String elementTag : elementTags) {
            specify.addElementTag(elementTag);
        }
        frame.setMessageContent(specify);
        // 报文结束符
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        // 获取下行帧:
        log.info("获取下行帧: 中心站查询指定要素实时数据");
        return frame;
    }

    /**
     * 获取下行帧: 查询终端软件版本报文
     *
     * @param id 遥测站id
     */
    public static MessageFrame getSoftwareVersionPacket(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._45.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryCommon queryCommon = new MessageContentDownlinkQueryCommon();
        queryCommon.setSerialNumber(Common651.HEX_0000);
        queryCommon.setMessageTimeParse(new Date());
        frame.setMessageContent(queryCommon);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站查询终端软件版本");
        return frame;
    }

    /**
     * 查询获取下行帧: 遥测站状态信息报文
     *
     * @param id 遥测站id
     */
    public static MessageFrame getStatusPacket(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._46.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryCommon queryCommon = new MessageContentDownlinkQueryCommon();
        queryCommon.setSerialNumber(HexUtil.decodeHex("0"));
        queryCommon.setMessageTimeParse(new Date());
        frame.setMessageContent(queryCommon);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站查询获取下行帧: 遥测站状态信息");
        return frame;
    }

    /**
     * 获取下行帧: 查询遥测站时段数据报文 <br>
     * 这个查询SL160只支持查一小时每5分钟水位或雨量，也就是时段步长码固定000000、要素标识符固定F4或F5
     *
     * @param id         遥测站id
     * @param startTime  起始时间
     * @param endTime    结束时间
     * @param periodCode 时段步长码
     * @param elementTag 要素标识符
     */
    public static MessageFrame getPeriodElementPacket(String id, Date startTime, Date endTime, String periodCode, String elementTag) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._38.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryPeriodElement periodElement = new MessageContentDownlinkQueryPeriodElement();
        periodElement.setSerialNumber(Common651.HEX_0000);
        periodElement.setMessageTimeParse(new Date());
        periodElement.setStartTime(startTime);
        periodElement.setEndTime(endTime);
        periodElement.setPeriodCode(periodCode);
        periodElement.setElementTag(elementTag);
        // Date date = new Date();
        // periodElement.setStartTime(new Date(date.getTime() - 60*60));
        // periodElement.setEndTime(date);
        // periodElement.setPeriodCode("000005");
        // periodElement.setElementTag(AppendixC._26.getHEX());
        frame.setMessageContent(periodElement);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站查询遥测站时段数据");
        return frame;
    }

    /**
     * 获取下行帧: 查询遥测站遥测站时钟
     *
     * @param id 遥测站id
     */
    public static MessageFrame getQueryClockPacket(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._51.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryCommon queryCommon = new MessageContentDownlinkQueryCommon();
        queryCommon.setSerialNumber(Common651.HEX_0000);
        queryCommon.setMessageTimeParse(new Date());
        frame.setMessageContent(queryCommon);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站查询遥测站时钟");
        return frame;
    }

    /**
     * 获取下行帧: 中心站查询遥测站事件记录
     *
     * @param id 遥测站id
     */
    public static MessageFrame getQueryRecordPacket(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._50.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryCommon queryCommon = new MessageContentDownlinkQueryCommon();
        queryCommon.setSerialNumber(Common651.HEX_0000);
        queryCommon.setMessageTimeParse(new Date());
        frame.setMessageContent(queryCommon);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站查询遥测站事件记录");
        return frame;
    }

    /**
     * 查询人工置数报
     *
     * @param id 遥测站id
     */
    public static MessageFrame getQueryManualPacket(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._39.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryCommon queryCommon = new MessageContentDownlinkQueryCommon();
        queryCommon.setSerialNumber(Common651.HEX_0000);
        queryCommon.setMessageTimeParse(new Date());
        frame.setMessageContent(queryCommon);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站查询人工置数");
        return frame;
    }

    /**
     * 设置遥测站时钟报
     *
     * @param id 遥测站id
     */
    public static MessageFrame getSetClockPacket(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._4A.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryCommon queryCommon = new MessageContentDownlinkQueryCommon();
        queryCommon.setSerialNumber(Common651.HEX_0000);
        queryCommon.setMessageTimeParse(new Date());
        frame.setMessageContent(queryCommon);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站设置遥测站时间记录");
        return frame;
    }

    /**
     * 修改遥测站基本配置表
     *
     * @param id 遥测站id
     */
    public static MessageFrame getSetBasicSettings(String id, AppendixD1 settingTag, byte[] settingData) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._40.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkSetSettings setSettings = new MessageContentDownlinkSetSettings();
        setSettings.setSerialNumber(Common651.HEX_0000);
        setSettings.setMessageTimeParse(new Date());
        setSettings.setSettingTag(settingTag.getHEX());
        setSettings.setSettingData(settingData);
        frame.setMessageContent(setSettings);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站修改遥测站基本配置表");
        return frame;
    }

    /**
     * 查询遥测站基本配置表
     *
     * @param id 遥测站id
     */
    public static MessageFrame getQueryBasicSettings(String id, AppendixD1... settingTags) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._41.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQuerySettings querySettings = new MessageContentDownlinkQuerySettings();
        querySettings.setSerialNumber(Common651.HEX_0000);
        querySettings.setMessageTimeParse(new Date());
        ArrayList<String> settingTagStrList = new ArrayList<>();
        for (AppendixD1 settingTag : settingTags) {
            settingTagStrList.add(settingTag.getHEX());
        }
        querySettings.setSettingTags(settingTagStrList.toArray(new String[0]));
        frame.setMessageContent(querySettings);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站查询遥测站基本配置表");
        return frame;
    }

    /**
     * 修改遥测站运行参数配置配置表
     *
     * @param id 遥测站id
     */
    public static MessageFrame getSetOperatingSettings(String id, AppendixD4 settingTag, byte[] settingData) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._42.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkSetSettings setSettings = new MessageContentDownlinkSetSettings();
        setSettings.setSerialNumber(Common651.HEX_0000);
        setSettings.setMessageTimeParse(new Date());
        setSettings.setSettingTag(settingTag.getHEX());
        setSettings.setSettingData(settingData);
        frame.setMessageContent(setSettings);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站修改遥测站运行参数配置表");
        return frame;
    }

    /**
     * 查询遥测站运行参数配置表
     *
     * @param id 遥测站id
     */
    public static MessageFrame getQueryOperatingSettings(String id, AppendixD4... settingTags) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._43.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQuerySettings querySettings = new MessageContentDownlinkQuerySettings();
        querySettings.setSerialNumber(Common651.HEX_0000);
        querySettings.setMessageTimeParse(new Date());
        ArrayList<String> settingTagStrList = new ArrayList<>();
        for (AppendixD4 settingTag : settingTags) {
            settingTagStrList.add(settingTag.getHEX());
        }
        querySettings.setSettingTags(settingTagStrList.toArray(new String[0]));
        frame.setMessageContent(querySettings);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站查询遥测站运行参数配置表");
        return frame;
    }

    /**
     * 中心站修改传输密码
     *
     * @param id          测站id
     * @param newPassword 新密码
     * @param oldPassword 旧尼玛
     */
    public static MessageFrame getChangePassword(String id, String newPassword, String oldPassword) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码 传入旧密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._49.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 正文
        MessageContentDownlinkQueryChangePassword queryCommon = new MessageContentDownlinkQueryChangePassword();
        // 下行流水号
        queryCommon.setSerialNumber(Common651.HEX_0000);
        // 下行发报时间
        queryCommon.setMessageTimeParse(new Date());
        // 下行旧密码 标识符+旧密码数据
        queryCommon.setOldPassword(HexUtil.decodeHex(oldPassword));
        // 新密码
        queryCommon.setNewPassword(HexUtil.decodeHex(newPassword));
        frame.setMessageContent(queryCommon);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 中心站修改传输密码记录");
        return frame;
    }

    /**
     * 恢复遥测站出厂设置
     *
     * @param id 遥测站id
     */
    public static MessageFrame getRestoreSetting(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._48.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkQueryRestoreSetting queryRestoreSetting = new MessageContentDownlinkQueryRestoreSetting();
        queryRestoreSetting.setSerialNumber(Common651.HEX_0000);
        queryRestoreSetting.setMessageTimeParse(new Date());
        // 恢复遥测站出场设置标识符
        queryRestoreSetting.setIdentifier(HexUtil.decodeHex("9800"));
        frame.setMessageContent(queryRestoreSetting);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 恢复遥测站出厂设置记录");
        return frame;
    }

    /**
     * 初始化固态存储数据报
     *
     * @param id 遥测站id
     */
    public static MessageFrame getInitializeData(String id) {
        MessageFrame frame = new MessageFrame();
        // 帧起始符
        frame.setStartChar(HexUtil.decodeHex(ControlCharacter._S0H_7E7E.getHEX()));
        // 遥测站地址
        frame.setTelemetricStation(HexUtil.decodeHex(id));
        // 中心站地址
        frame.setCenterStation(Common651.CENTER_STATION);
        // 密码
        frame.setPassword(StationUtil.getPasswordHexInOnline(id));
        // 功能码
        frame.setFunctionCode(HexUtil.decodeHex(AppendixB._47.getHEX())[0]);
        // 下行标志
        frame.setUpLinkFlag(Common651.DOWNLINK_FLAG);
        // 报文起始符
        frame.setContentStartChar(HexUtil.decodeHex(ControlCharacter._STX_02.getHEX())[0]);
        // 报文正文
        MessageContentDownlinkInitializeData initializeData = new MessageContentDownlinkInitializeData();
        initializeData.setSerialNumber(Common651.HEX_0000);
        initializeData.setMessageTimeParse(new Date());
        // 初始化固态数据标识符
        initializeData.setIdentifier(HexUtil.decodeHex("9700"));
        frame.setMessageContent(initializeData);
        frame.setContentEndChar(HexUtil.decodeHex(ControlCharacter._ENQ_05.getHEX())[0]);
        log.info("获取下行帧: 初始化固态存储数据下行报记录");
        return frame;
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：62H查询中继站转发地址
 */
public class DownlinkQueryForwardAddress_62H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._62.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：55H-查询遥测站最近充值量和现有剩余水量(响应帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryCharge_55H extends ApplicationSpaceUplink {

    /**
     * 最近充值量
     */
    int charge;
    /**
     * 现有剩余水量
     */
    int surplusWater;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // 充值量
        byte _byte1 = buffer.readByte();
        byte _byte2 = buffer.readByte();
        byte _byte3 = buffer.readByte();
        byte _byte4 = buffer.readByte();
        // 剩余水量
        byte _byte5 = buffer.readByte();
        byte _byte6 = buffer.readByte();
        byte _byte7 = buffer.readByte();
        byte _byte8 = buffer.readByte();
        byte _byte9 = buffer.readByte();

        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);

        this.charge = byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1;

        int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
        int byte6 = ((_byte6 >> 4 & 0x0F) * 10) + (_byte6 & 0b0000_1111);
        int byte7 = ((_byte7 >> 4 & 0x0F) * 10) + (_byte7 & 0b0000_1111);
        int byte8 = ((_byte8 >> 4 & 0x0F) * 10) + (_byte8 & 0b0000_1111);
        int byte9 = ((_byte9 >> 4 & 0x07) * 10) + (_byte9 & 0b0000_1111);
        this.surplusWater = byte9 * 100000000 + byte8 * 1000000 + byte7 * 10000 + byte6 * 100 + byte5;
    }
}

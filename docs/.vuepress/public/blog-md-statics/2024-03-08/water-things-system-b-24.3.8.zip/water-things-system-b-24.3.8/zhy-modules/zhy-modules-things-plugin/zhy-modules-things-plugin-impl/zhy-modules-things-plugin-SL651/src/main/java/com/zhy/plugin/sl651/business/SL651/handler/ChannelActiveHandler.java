package com.zhy.plugin.sl651.business.SL651.handler;

import com.zhy.plugin.core.entity.domain.plugin.PluginDeviceOnlineStatus;
import com.zhy.plugin.core.support.PluginContext;
import com.zhy.plugin.sl651.business.SL651.db.entity.FamiliarStation651;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.utils.ChannelUtil;
import com.zhy.plugin.sl651.business.SL651.utils.StationUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

/**
 * 连接事件（只触发成功解析的报文）
 *
 * @author wangfeng
 * @since 2023-07-04 10:18
 */
public class ChannelActiveHandler extends SimpleChannelInboundHandler<MessageFrame> {

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, MessageFrame messageFrame) {
        String id = messageFrame.getTelemetricStationParse();
        String password = messageFrame.getPasswordParse();
        FamiliarStation651 familiarStation651 = FamiliarStation651.builder()
                .stationId(id)
                .password(password)
                .build();
        StationUtil.addOnline(id, familiarStation651);
        PluginContext.produceDeviceOnlineStatus(new PluginDeviceOnlineStatus(id,true));
        boolean b = ChannelUtil.addChannel(id, ctx.channel());
        if (b) {
            ctx.fireChannelRead(messageFrame);
        }
        // 遇到了特殊事件 不进行后续流程了
    }
}

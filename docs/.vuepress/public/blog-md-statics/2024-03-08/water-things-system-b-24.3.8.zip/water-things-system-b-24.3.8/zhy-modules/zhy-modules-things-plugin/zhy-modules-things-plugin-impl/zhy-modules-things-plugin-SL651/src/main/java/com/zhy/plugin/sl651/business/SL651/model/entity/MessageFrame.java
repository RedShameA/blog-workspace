package com.zhy.plugin.sl651.business.SL651.model.entity;

import com.zhy.plugin.sl651.business.SL651.model.entity.content.MessageContent;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * 报文帧.
 *
 * @author <a href="mailto:xiaoQQya@126.com">xiaoQQya</a>
 * @since 2023/05/03
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MessageFrame implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 所有的原始字节
     */
    private byte[] allBytes;
    private String allBytesStr;

    /**
     * 帧起始符
     */
    private byte[] startChar;

    /**
     * 中心站地址
     */
    private Byte centerStation;

    /**
     * 遥测站地址
     */
    private byte[] telemetricStation;
    private String telemetricStationParse;
    private String telemetricStationParse8;

    /**
     * 密码
     */
    private byte[] password;
    private String passwordParse;

    /**
     * 功能码
     */
    private Byte functionCode;

    /**
     * 报文上下行标识, 0000 上行, 1000 下行
     */
    private Byte upLinkFlag;

    /**
     * 报文长度
     */
    private byte[] contentLength;

    /**
     * 报文起始符
     */
    private Byte contentStartChar;

    /**
     * 报文正文
     */
    private byte[] content;

    /**
     * 结构化报文正文
     */
    private MessageContent messageContent;

    /**
     * 报文结束符
     */
    private Byte contentEndChar;

    /**
     * 校验码
     */
    private byte[] checkCode;


    /**
     * 重新生成 [长度]
     */
    public void compute(){
        this.content = this.messageContent.encode();
        int length = this.content.length;
        if (length>4095){
            throw new IllegalArgumentException("content should not longer than 4095");
        }
        // 开始转换
        ByteBuffer allocate = ByteBuffer.allocate(4);
        allocate.putInt(length);
        byte[] array = allocate.array();
        array = Arrays.copyOfRange(array, 2, 4);
        this.contentLength = array;
    }

    public static void main(String[] args) {
        ByteBuffer allocate = ByteBuffer.allocate(4);
        allocate.putInt(4095);
        byte[] array = allocate.array();
        array = Arrays.copyOfRange(array, 2, 4);
    }

}

package com.zhy.things.data.service.impl;

import com.zhy.common.annotation.DataSource;
import com.zhy.common.enums.DataSourceType;
import com.zhy.common.things.domain.ThingsDataHis;
import com.zhy.things.data.mapper.ThingsDataHisMapper;
import com.zhy.things.data.service.ThingsDataHisService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wangfeng
 * @since 2023-11-29 14:43
 */
@Service
@DataSource(DataSourceType.SHARDING)
public class ThingsDataHisServiceImpl implements ThingsDataHisService {
    @Resource
    ThingsDataHisMapper thingsDataHisMapper;
    @Override
    public int insertThingsDataHis(ThingsDataHis record) {
        return thingsDataHisMapper.insertSelective(record);
    }

    @Override
    public void initTable() {
        thingsDataHisMapper.createTable();
    }

    @Override
    public List<ThingsDataHis> selectThingsDataHisList(ThingsDataHis record) {
        return thingsDataHisMapper.selectThingsDataHisList(record);
    }


}

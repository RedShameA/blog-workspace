package com.zhy.plugin.core.entity.domain.device;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zhy.common.annotation.Excel;
import com.zhy.common.core.domain.BaseEntity;
import com.zhy.things.common.constants.StationType;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author wangfeng
 * @since 2023-11-06 14:25
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ThingsDevice extends BaseEntity {
    @Excel(name = "设备编号", cellType = Excel.ColumnType.STRING)
    String deviceId;
    @Excel(name = "设备名", cellType = Excel.ColumnType.STRING)
    String deviceName;
    @Excel(name = "设备组织ID", cellType = Excel.ColumnType.NUMERIC)
    Long deviceOrgId;
    @Excel(name = "设备组织名", cellType = Excel.ColumnType.STRING)
    String deviceOrgName;
    @Excel(name = "产品ID", cellType = Excel.ColumnType.STRING)
    String productId;
    @Excel(name = "产品名", cellType = Excel.ColumnType.STRING)
    String productName;
    /* 测站类型 */
    @Excel(name = "测站类型", cellType = Excel.ColumnType.STRING)
    String stationType;
    public Set<StationType> getStationTypes() {
        return Arrays.stream(this.stationType.split(",")).map(StationType::match).collect(Collectors.toSet());
    }
    /* 转换出的列表 */
    List<StationType> stationTypes;
    @Excel(name = "设备描述", cellType = Excel.ColumnType.STRING)
    String deviceDesc;
    /* 最新一次心跳时间 */
    @Excel(name = "心跳时间", dateFormat = "yyyy-MM-dd HH:mm:ss", cellType = Excel.ColumnType.STRING)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    Date heartbeatTime;
    /* 激活时间，第一次上线的时间 */
    @Excel(name = "激活时间", dateFormat = "yyyy-MM-dd HH:mm:ss", cellType = Excel.ColumnType.STRING)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    Date registryTime;
    String metadata;
}

package com.zhy.things.web.controller;

import com.alibaba.fastjson2.JSONObject;
import com.zhy.common.constant.HttpStatus;
import com.zhy.common.core.controller.BaseController;
import com.zhy.common.core.domain.AjaxResult;
import com.zhy.common.core.page.PageDomain;
import com.zhy.common.core.page.TableDataInfo;
import com.zhy.common.core.page.TableSupport;
import com.zhy.common.utils.ServletUtils;
import com.zhy.plugin.core.entity.domain.plugin.ThingsPlugin;
import com.zhy.plugin.core.support.PluginSupport;
import com.zhy.plugin.store.PluginStatusStore;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author wangfeng
 * @since 2023-11-09 14:55
 */
@RestController
@RequestMapping("/things/plugin")
public class ThingsPluginController extends BaseController {

    /**
     * 查询plugin列表
     */
    @PreAuthorize("@ss.hasPermi('things:plugin:list')")
    @GetMapping("/list")
    public TableDataInfo list() {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        String search = ServletUtils.getParameter("search");
        Boolean status = ServletUtils.getParameterToBool("status");
        int pageNum = null == pageDomain.getPageNum() ? 1 : pageDomain.getPageNum();
        int pageSize = null == pageDomain.getPageSize() ? 10 : pageDomain.getPageSize();
        List<PluginStatusStore.PluginPackage> pluginList = PluginStatusStore.listAllPlugin(search, status);
        ArrayList<HashMap<String, Object>> ret = new ArrayList<>();
        int start = (pageNum - 1) * pageSize;
        for (int i = start; i < start + pageSize; i++) {
            if (i >= pluginList.size()) break;
            PluginStatusStore.PluginPackage e = pluginList.get(i);
            HashMap<String, Object> map = new HashMap<>();
            map.put("protocol", e.getPlugin().getProtocol());
            map.put("name", e.getPlugin().getName());
            map.put("version", e.getPlugin().getVersion());
            map.put("description", e.getPlugin().getDescription());
            map.put("status", e.isStatus());
            map.put("message", e.getMessage());
            // 枚举类返回前端特殊处理,要不然只会传string
            List<JSONObject> valueTypeList = e.getPluginSupport().getSupportedValueTypes().stream().map(JSONObject::from).collect(Collectors.toList());
            map.put("protocolTypeOptions", valueTypeList);
            map.put("functionOptions", e.getPluginSupport().getSupportedFunctions());
            ret.add(map);
        }

        TableDataInfo rspData = new TableDataInfo();
        rspData.setCode(HttpStatus.SUCCESS);
        rspData.setMsg("查询成功");
        rspData.setRows(ret);
        rspData.setTotal(pluginList.size());

        return rspData;
    }

    /**
     * 查询产品相关联的插件的 所有propertyType和functionId
     */
    @PreAuthorize("@ss.hasPermi('things:plugin:list')")
    @GetMapping("/getPluginInfo")
    public AjaxResult getPluginInfo(ThingsPlugin thingsPlugin){
        PluginSupport pluginSupport = PluginStatusStore.getPluginSupport(thingsPlugin.getProtocol());
        List<JSONObject> supportedValueTypes = pluginSupport.getSupportedValueTypes().stream().map(JSONObject::from).collect(Collectors.toList());
        List<Map<String, String>> supportedFunctions = pluginSupport.getSupportedFunctions();
        JSONObject ret = new JSONObject();
        ret.put("protocolTypeOptions", supportedValueTypes);
        ret.put("functionOptions", supportedFunctions);
        return success(ret);
    }

    ///**
    // * 导出product列表
    // */
    //@PreAuthorize("@ss.hasPermi('system:product:export')")
    //@Log(title = "product", businessType = BusinessType.EXPORT)
    //@PostMapping("/export")
    //public void export(HttpServletResponse response, ThingsProduct thingsProduct)
    //{
    //    List<ThingsProduct> list = thingsProductService.selectThingsProductList(thingsProduct);
    //    ExcelUtil<ThingsProduct> util = new ExcelUtil<ThingsProduct>(ThingsProduct.class);
    //    util.exportExcel(response, list, "product数据");
    //}
    //
    ///**
    // * 获取product详细信息
    // */
    //@PreAuthorize("@ss.hasPermi('system:product:query')")
    //@GetMapping(value = "/{id}")
    //public AjaxResult getInfo(@PathVariable("id") Long id)
    //{
    //    return success(thingsProductService.selectThingsProductById(id));
    //}
    //
    ///**
    // * 新增product
    // */
    //@PreAuthorize("@ss.hasPermi('system:product:add')")
    //@Log(title = "product", businessType = BusinessType.INSERT)
    //@PostMapping
    //public AjaxResult add(@RequestBody ThingsProduct thingsProduct)
    //{
    //    return toAjax(thingsProductService.insertThingsProduct(thingsProduct));
    //}
    //
    ///**
    // * 修改product
    // */
    //@PreAuthorize("@ss.hasPermi('system:product:edit')")
    //@Log(title = "product", businessType = BusinessType.UPDATE)
    //@PutMapping
    //public AjaxResult edit(@RequestBody ThingsProduct thingsProduct)
    //{
    //    return toAjax(thingsProductService.updateThingsProduct(thingsProduct));
    //}
    //
    ///**
    // * 删除product
    // */
    //@PreAuthorize("@ss.hasPermi('system:product:remove')")
    //@Log(title = "product", businessType = BusinessType.DELETE)
    //@DeleteMapping("/{ids}")
    //public AjaxResult remove(@PathVariable Long[] ids)
    //{
    //    return toAjax(thingsProductService.deleteThingsProductByIds(ids));
    //}

}

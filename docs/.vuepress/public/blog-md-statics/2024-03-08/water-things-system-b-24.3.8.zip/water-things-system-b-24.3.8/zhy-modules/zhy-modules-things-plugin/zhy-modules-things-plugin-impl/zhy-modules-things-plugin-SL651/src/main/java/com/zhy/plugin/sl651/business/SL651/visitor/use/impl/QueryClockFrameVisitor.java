package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkQueryClock;
import com.zhy.plugin.sl651.business.SL651.utils.ElementParseUtil;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;

@Slf4j
@Component
public class QueryClockFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkQueryClock> {

    @Override
    public String getFunctionCode() {
        return AppendixB._51.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("查询遥测站时间visitor");
        MessageContentUplinkQueryClock content = getContent(frame);
        byte[] messageTime = content.getMessageTime();
        Date date = ElementParseUtil.parseMessageTime(messageTime);
        System.out.println(date);
    }
}

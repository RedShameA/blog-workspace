package com.zhy.converter.mapper;


import com.zhy.converter.domain.StPptnR;

/**
 * 针对表【st_pptn_r(降水量表)】的数据库操作Mapper
 *
 * @author Red_A
 * @since 2023-11-24 13:14:54
 */
public interface StPptnRMapper {

    int deleteByPrimaryKey(Long id);

    int insertOrUpdate(StPptnR record);

    int insertSelective(StPptnR record);

    StPptnR selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(StPptnR record);

    int updateByPrimaryKey(StPptnR record);

}

package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import com.zhy.plugin.sl651.business.SL651.utils.ElementParseUtil;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.Map;

/**
 * 小时报
 *
 * @author wangfeng
 * @since 2023-07-26 15:15
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentUplinkHourly extends MessageContentUplink {


    Double[] rainData = new Double[12];

    Double[] waterLevelData = new Double[12];

    public Map<String, Double> doubleElements = new HashMap<>();


    @Override
    public void decode() {
        byte[] content = this.getBytes();
        ByteBuf buffer = Unpooled.wrappedBuffer(content);

        // 流水号
        byte[] serialNumber = new byte[2];
        buffer.readBytes(serialNumber);
        this.setSerialNumber(serialNumber);
        // 发报时间
        byte[] messageTime = new byte[6];
        buffer.readBytes(messageTime);
        this.setMessageTime(messageTime);
        while (buffer.isReadable()) {
            // 标识符
            byte[] flag = new byte[2];
            buffer.readBytes(flag);
            String flagStr = HexUtil.encodeHexStr(flag, false).substring(0, 2);
            int length;
            switch (flagStr) {
                case "F1": // 观测站
                    byte[] station = new byte[5];
                    buffer.readBytes(station);
                    byte stationType = buffer.readByte();
                    this.setStation(station);
                    this.setStationType(stationType);
                    break;
                case "F0": // 观测时间
                    byte[] collectTime = new byte[5];
                    buffer.readBytes(collectTime);
                    this.setCollectTime(collectTime);
                    this.setCollectTimeParse(ElementParseUtil.parseCollectTime(collectTime));
                    break;
                case "F4": // 1小时内每5分钟时段雨量
                    length = (flag[1] & 0xff) >> 3;
                    byte[] rainBytes = new byte[length];
                    buffer.readBytes(rainBytes);
                    ByteBuf rainDataBuffer = Unpooled.wrappedBuffer(rainBytes);
                    // 雨量是每个数据占1个字节
                    for (int i = 0; i < 12; i++) {
                        byte[] bytes = new byte[1];
                        rainDataBuffer.readBytes(bytes);
                        double v = Integer.valueOf(HexUtil.encodeHexStr(bytes), 16) / 10d;
                        rainData[i] = v;
                    }
                    break;
                case "F5": // 1小时内每5分钟时段水位
                    length = (flag[1] & 0xff) >> 3;
                    length = 24; // todo 这个160设备返回的是26，但应该是24才对
                    byte[] waterBytes = new byte[length];
                    buffer.readBytes(waterBytes);
                    ByteBuf waterDataBuffer = Unpooled.wrappedBuffer(waterBytes);
                    // 水位是每个数据占2个字节
                    for (int i = 0; i < 12; i++) {
                        byte[] bytes = new byte[2];
                        waterDataBuffer.readBytes(bytes);
                        double v = Integer.valueOf(HexUtil.encodeHexStr(bytes), 16) / 10d;
                        waterLevelData[i] = v;
                    }
                    break;
                default: // 其他要素串
                    length = (flag[1] & 0xff) >> 3;
                    byte[] elementData = new byte[length];
                    buffer.readBytes(elementData);
                    byte[] elementAll = ArrayUtil.addAll(flag, elementData);
                    Double aDouble = ElementParseUtil.parseDouble(elementAll);
                    doubleElements.put(flagStr, aDouble);
            }
        }
    }
}

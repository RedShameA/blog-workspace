package com.zhy.things.web.controller;

import com.zhy.common.annotation.Log;
import com.zhy.common.core.controller.BaseController;
import com.zhy.common.core.domain.AjaxResult;
import com.zhy.common.enums.BusinessType;
import com.zhy.common.things.domain.ThingsDeviceOrg;
import com.zhy.common.utils.StringUtils;
import com.zhy.common.utils.poi.ExcelUtil;
import com.zhy.things.web.service.IThingsDeviceOrgService;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author wangfeng
 * @since 2023-12-08 16:24
 */
@RestController
@RequestMapping("/things/device/org")
public class ThingsDeviceOrgController extends BaseController {

    @Resource
    IThingsDeviceOrgService thingsDeviceOrgService;

    @PreAuthorize("@ss.hasPermi('things:device:org:list')")
    @GetMapping("/tree")
    public AjaxResult getTree(){
        return success(thingsDeviceOrgService.getTree());
    }

    // @PreAuthorize("@ss.hasPermi('things:device:tree')")
    // @PostMapping("")
    // public AjaxResult addOrg(@RequestBody ThingsDeviceOrg thingsDeviceOrg){
    //     int i = thingsDeviceOrgService.addOrg(thingsDeviceOrg);
    //     return toAjax(i);
    // }
    // @PreAuthorize("@ss.hasPermi('things:device:tree')")
    // @PostMapping("/{id}")
    // public AjaxResult delOrg(@PathVariable Long id){
    //     if (thingsDeviceOrgService.hasChild(id)) {
    //         return warn("选中项下有子节点，禁止删除");
    //     }
    //     int i = thingsDeviceOrgService.delOrg(id);
    //     return toAjax(i);
    // }

    /**
     * 查询物联设备组织树列表
     */
    @PreAuthorize("@ss.hasPermi('things:device:org:list')")
    @GetMapping("/list")
    public AjaxResult list(ThingsDeviceOrg thingsDeviceOrg)
    {
        List<ThingsDeviceOrg> list = thingsDeviceOrgService.selectThingsDeviceOrgList(thingsDeviceOrg);
        return success(list);
    }

    /**
     * 查询部门列表（排除节点）
     */
    @PreAuthorize("@ss.hasPermi('things:device:org:list')")
    @GetMapping("/list/exclude/{deviceOrgId}")
    public AjaxResult excludeChild(@PathVariable(value = "deviceOrgId", required = false) Long deviceOrgId)
    {
        List<ThingsDeviceOrg> orgs = thingsDeviceOrgService.selectThingsDeviceOrgList(new ThingsDeviceOrg());
        orgs.removeIf(d -> d.getDeviceOrgId().intValue() == deviceOrgId || ArrayUtils.contains(StringUtils.split(d.getAncestors(), ","), deviceOrgId + ""));
        return success(orgs);
    }

    /**
     * 导出物联设备组织树列表
     */
    @PreAuthorize("@ss.hasPermi('things:device:org:export')")
    @Log(title = "物联设备组织树", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ThingsDeviceOrg thingsDeviceOrg)
    {
        List<ThingsDeviceOrg> list = thingsDeviceOrgService.selectThingsDeviceOrgList(thingsDeviceOrg);
        ExcelUtil<ThingsDeviceOrg> util = new ExcelUtil<>(ThingsDeviceOrg.class);
        util.exportExcel(response, list, "物联设备组织树数据");
    }

    /**
     * 获取物联设备组织树详细信息
     */
    @PreAuthorize("@ss.hasPermi('things:device:org:query')")
    @GetMapping(value = "/{deviceOrgId}")
    public AjaxResult getInfo(@PathVariable("deviceOrgId") Long deviceOrgId)
    {
        return success(thingsDeviceOrgService.selectThingsDeviceOrgByDeviceOrgId(deviceOrgId));
    }

    /**
     * 新增物联设备组织树
     */
    @PreAuthorize("@ss.hasPermi('things:device:org:add')")
    @Log(title = "物联设备组织树", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ThingsDeviceOrg thingsDeviceOrg)
    {
        return toAjax(thingsDeviceOrgService.insertThingsDeviceOrg(thingsDeviceOrg));
    }

    /**
     * 修改物联设备组织树
     */
    @PreAuthorize("@ss.hasPermi('things:device:org:edit')")
    @Log(title = "物联设备组织树", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ThingsDeviceOrg thingsDeviceOrg)
    {
        return toAjax(thingsDeviceOrgService.updateThingsDeviceOrg(thingsDeviceOrg));
    }

    /**
     * 删除物联设备组织树
     */
    @PreAuthorize("@ss.hasPermi('things:device:org:remove')")
    @Log(title = "物联设备组织树", businessType = BusinessType.DELETE)
    @DeleteMapping("/{deviceOrgIds}")
    public AjaxResult remove(@PathVariable Long[] deviceOrgIds)
    {
        return toAjax(thingsDeviceOrgService.deleteThingsDeviceOrgByDeviceOrgIds(deviceOrgIds));
    }
}

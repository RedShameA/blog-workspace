package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 通用上行报文
 * 适用功能码：
 * @author wangfeng
 * @since 2023-06-28 09:58
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MessageContentUplinkCommon extends MessageContentUplink {
    /**
     * 解码方法 <br>
     * 上行报文应自己去实现
     */
    @Override
    public void decode() {
        // do nothing
    }
}

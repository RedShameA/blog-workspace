package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkOperatingSettings;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 处理设置遥测站运行参数配置表
 * @author wangfeng
 * @since 2023/8/27 17:42
 */
@Slf4j
@Component
public class SetOperatingSettingsVisitor implements MessageFrameUseVisitor<MessageContentUplinkOperatingSettings> {
    @Override
    public String getFunctionCode() {
        return AppendixB._42.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("处理设置遥测站运行参数配置表");
        MessageContentUplinkOperatingSettings content = getContent(frame);
        Map<String, byte[]> settings = content.getSettings();
        settings.forEach((k, v)->{
            log.info("key: {}", k);
        });
    }
}

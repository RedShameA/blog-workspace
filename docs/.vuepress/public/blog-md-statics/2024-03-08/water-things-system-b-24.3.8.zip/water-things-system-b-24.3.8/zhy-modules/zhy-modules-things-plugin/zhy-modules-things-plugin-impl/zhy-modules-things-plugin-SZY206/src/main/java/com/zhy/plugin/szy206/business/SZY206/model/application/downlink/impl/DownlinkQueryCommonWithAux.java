package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application._AUX;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 下行查询通用（带密码时间）
 * @author wangfeng
 * @since 2023-09-26 11:46
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryCommonWithAux extends ApplicationSpaceDownlink {
    public DownlinkQueryCommonWithAux(AFN afn, _AUX aux) {
        this.applicationFunctionCode = afn.getFNCByte();
        this.aux = aux;
    }

    @Override
    public byte[] encode() {
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, aux.encode());
    }
}

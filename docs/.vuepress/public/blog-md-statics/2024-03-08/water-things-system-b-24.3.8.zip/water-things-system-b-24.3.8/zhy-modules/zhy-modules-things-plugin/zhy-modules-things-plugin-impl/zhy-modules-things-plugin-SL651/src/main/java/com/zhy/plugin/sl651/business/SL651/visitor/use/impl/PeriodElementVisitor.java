package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkPeriodElement;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * 查询时段数据报
 * @author wangfeng
 * @since 2023-07-31 13:20
 */
@Slf4j
@Component
public class PeriodElementVisitor implements MessageFrameUseVisitor<MessageContentUplinkPeriodElement> {
    @Override
    public String getFunctionCode() {
        return AppendixB._38.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("查询时段数据报visitor");
        MessageContentUplinkPeriodElement content = getContent(frame);
        System.out.println("content.getCollectTimeParse() = " + content.getCollectTimeParse());
        System.out.println("查询时段数据 雨量数据："+ Arrays.toString(content.getRainData()));
        System.out.println("查询时段数据 水位数据："+ Arrays.toString(content.getWaterLevelData()));
    }
}

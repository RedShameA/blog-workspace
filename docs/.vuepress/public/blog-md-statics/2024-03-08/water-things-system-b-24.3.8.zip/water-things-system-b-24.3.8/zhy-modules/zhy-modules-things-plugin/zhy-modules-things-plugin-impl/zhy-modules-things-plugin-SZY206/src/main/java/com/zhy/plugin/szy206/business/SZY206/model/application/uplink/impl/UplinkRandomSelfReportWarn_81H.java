package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.WaterQualityParameter_Enum;
import com.zhy.plugin.szy206.business.SZY206.model.application._AUX;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.StationWarnStatus;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.WaterQualityParameter;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;

/**
 * @Since 2023/9/27
 * @Author：houDeJian
 * @Record：81_随机自报报警数据(确认帧) note <br>
 * 此报文数据域 <br>
 * 前两个字节为报警状态 后两个字节为终端状态 <br>
 * 最后的Tp为报警时间 <br>
 * 只有水位、流量、水质 有报警数据(在报警状态和终端状态之间) 其余没有
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkRandomSelfReportWarn_81H extends ApplicationSpaceUplink {

    int controlAfn;
    /**
     * 告警状态
     */
    StationWarnStatus stationWarnStatus;
    /**
     * 水位结果
     */
    Double[] waterLevels;
    /**
     * 流量结果
     */
    Double[] waterFlows;
    /**
     * 水质结果
     */
    WaterQualityParameter waterQualityParameter;

    @SneakyThrows
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // 剩余字节 去除告警(4) 和Tp(5)
        int readable = buffer.readableBytes() - 4 - 5;
        // 报警和告警
        byte[] dangerBytes = new byte[4];

        // 前两个字节（报警状态）
        dangerBytes[0] = buffer.readByte();
        dangerBytes[1] = buffer.readByte();

        switch (controlAfn) {
            case 2:// 水位 4个字节
                this.waterLevels = getWaterLevels(readable, buffer);
                break;
            case 3:// 流量 5个字节
                this.waterFlows = getWaterFlows(readable, buffer);
                break;
            case 4:// 水质
                this.waterQualityParameter = getWaterQuality(buffer);
                break;
        }

        // 后两个字节（终端状态）
        dangerBytes[2] = buffer.readByte();
        dangerBytes[3] = buffer.readByte();
        this.stationWarnStatus = new StationWarnStatus().parse(dangerBytes);

        // 再后边是Tp
        byte[] tpBytes = new byte[5];
        buffer.readBytes(tpBytes);
        _AUX aux = new _AUX();
        aux.setContent(ArrayUtil.addAll(new byte[]{0, 0}, tpBytes));
        aux.decode();
        this.aux = aux;

    }

    private Double[] getWaterLevels(int readable, ByteBuf buffer) {
        // 水位仪表个数
        int n = readable / 4;
        Double[] waterLevels = new Double[n];
        byte[] waterLevelBytes = new byte[4];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(waterLevelBytes);
            double waterLevel;
            waterLevel = (waterLevelBytes[0] & 0b0000_1111) * 0.001d // 毫米位
                    + ((waterLevelBytes[0] & 0b1111_0000) >> 4) * 0.01d // 厘米位
                    + (waterLevelBytes[1] & 0b0000_1111) * 0.1d // 分米位
                    + ((waterLevelBytes[1] & 0b1111_0000) >> 4) // 米位
                    + (waterLevelBytes[2] & 0b0000_1111) * 10 // 十米位
                    + ((waterLevelBytes[2] & 0b1111_0000) >> 4) * 100 // 百米位
                    + (waterLevelBytes[3] & 0b0000_1111) * 1000; // 千米位
            waterLevel *= ((waterLevelBytes[3] & 0b1111_0000) >> 4) == 15 ? 1 : -1; // 正负位
            waterLevels[i] = waterLevel;
        }
        return waterLevels;
    }

    private WaterQualityParameter getWaterQuality(ByteBuf buffer) throws NoSuchFieldException, IllegalAccessException {
        byte[] parameter = new byte[5];
        WaterQualityParameter waterQualityParameter = new WaterQualityParameter();
        buffer.readBytes(parameter);
        // 怎么判断一个字节的八位中那些不为0
        for (int y = 0; y < 5; y++) {
            for (int i = 0; i <= 7; i++) {
                byte mask = (byte) (1 << i);
                if ((parameter[y] & mask) != 0) {
                    // 拼接水质元素名字
                    String parameterName = "D" + (8 * y + i);
                    byte[] array = 8 * y + i == 24 ? new byte[5] : new byte[4];
                    buffer.readBytes(array);
                    Double value;
                    if (8 * y + i == 24) {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        byte _byte5 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
                        value = (double) (byte5 * 100000000 + byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                    } else if (8 * y + i == 4) {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                    } else {
                        byte _byte1 = buffer.readByte();
                        byte _byte2 = buffer.readByte();
                        byte _byte3 = buffer.readByte();
                        byte _byte4 = buffer.readByte();
                        int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                        int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                        int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                        int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                        Integer decimalPlaces = WaterQualityParameter_Enum.getRight(parameterName);
                        double result = Math.pow(0.1, decimalPlaces);
                        value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1) * result;
                    }
                    System.out.println("D" + 8 * y + i + " 不为0");
                    waterQualityParameter.setParameterValue(parameterName, value);
                }
            }
        }
        return waterQualityParameter;
    }

    private Double[] getWaterFlows(int readable, ByteBuf buffer) {
        // 水位仪表个数
        int n = readable / 5;
        Double[] waterFlow = new Double[n];
        byte[] waterFlows = new byte[5];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(waterFlows);
            double waterLevel;
            waterLevel = (waterFlows[0] & 0b0000_1111) * 0.001d // 小数点后3位
                    + ((waterFlows[0] & 0b1111_0000) >> 4) * 0.01d // 小数点后2位
                    + (waterFlows[1] & 0b0000_1111) * 0.1d // 小数点后1位
                    + ((waterFlows[1] & 0b1111_0000) >> 4)
                    + (waterFlows[2] & 0b0000_1111) * 10
                    + ((waterFlows[2] & 0b1111_0000) >> 4) * 100
                    + (waterFlows[3] & 0b0000_1111) * 1000
                    + ((waterFlows[3] & 0b1111_0000) >> 4) * 10000
                    + (waterFlows[4] & 0b0000_1111) * 10000;
            waterLevel *= ((waterFlows[4] & 0b1111_0000) >> 4) == 15 ? 1 : -1; // 正负位
            waterFlow[i] = waterLevel;
        }
        return waterFlow;
    }

}

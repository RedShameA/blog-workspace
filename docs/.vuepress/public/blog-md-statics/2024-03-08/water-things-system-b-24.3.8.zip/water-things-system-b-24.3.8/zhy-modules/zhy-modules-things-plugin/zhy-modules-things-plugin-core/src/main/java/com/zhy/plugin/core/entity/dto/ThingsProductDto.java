package com.zhy.plugin.core.entity.dto;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONObject;
import com.zhy.common.core.domain.BaseEntity;
import com.zhy.plugin.core.entity.domain.product.ThingsProduct;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wangfeng
 * @since 2023-11-30 10:27
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ThingsProductDto extends BaseEntity {
    String productId;
    String productName;
    String productDesc;
    String protocol;
    String protocolName;
    /* 协议是否加载成功 */
    Boolean protocolStatus;
    //String metaData;
    List<ThingsProperty> properties = new ArrayList<>();
    List<ThingsFunction> functions = new ArrayList<>();

    public static ThingsProductDto fromThingsProduct(ThingsProduct from){
        if (null==from){
            return null;
        }
        ThingsProductDto entity = new ThingsProductDto();
        entity.productId = from.getProductId();
        entity.productName = from.getProductName();
        entity.productDesc = from.getProductDesc();
        entity.protocol = from.getProtocol();
        // 解析metadata
        JSONObject metadata = JSONObject.parseObject(from.getMetaData());
        JSONArray properties = metadata.getJSONArray("properties");
        JSONArray functions = metadata.getJSONArray("functions");
        for (Object json : properties) {
            entity.properties.add(ThingsProperty.fromJson((JSONObject) json));
        }
        for (Object json : functions) {
            entity.functions.add(ThingsFunction.fromJson((JSONObject) json));
        }
        return entity;
    }

    public ThingsProduct toThingsProduct(){
        ThingsProduct entity = new ThingsProduct();
        entity.setProductId(this.productId);
        entity.setProductName(this.productName);
        entity.setProductDesc(this.productDesc);
        entity.setProtocol(this.protocol);
        // 组装metadata
        JSONObject metadata = new JSONObject();
        JSONArray properties = new JSONArray();
        JSONArray functions = new JSONArray();
        metadata.put("properties", properties);
        metadata.put("functions", functions);
        for (ThingsProperty property : this.properties) {
            properties.add(property.toJson());
        }
        for (ThingsFunction function : this.functions) {
            functions.add(function.toJson());
        }
        entity.setMetaData(metadata.toJSONString());
        // 返回
        return entity;
    }
}


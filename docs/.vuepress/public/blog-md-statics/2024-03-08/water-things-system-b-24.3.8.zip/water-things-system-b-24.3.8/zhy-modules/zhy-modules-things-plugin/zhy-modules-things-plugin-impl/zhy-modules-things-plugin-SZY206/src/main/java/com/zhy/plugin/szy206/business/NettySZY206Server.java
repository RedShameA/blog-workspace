package com.zhy.plugin.szy206.business;

import com.zhy.plugin.szy206.business.SZY206.handler.*;
import com.zhy.plugin.szy206.business.SZY206.utils.ChannelUtil206;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.handler.timeout.IdleStateHandler;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * @author wangfeng
 * @since 2023-09-06 18:48
 */
@Slf4j
@Component
public class NettySZY206Server {

    private static final Logger LOGGER = LoggerFactory.getLogger(NettySZY206Server.class);


    /**
     * 服务端NIO线程组
     * bossGroup只处理连接请求，workerGroup处理与客户端的连接（业务处理）
     * 下面两个group含有的线程数默认等于cpu核心数*2，一般来说bossGroup需要的核心数少于workerGroup即可
     */
    private EventLoopGroup bossGroup = null;
    private EventLoopGroup workGroup = null;

    public ChannelFuture start() {
        String host = "0.0.0.0";
        int port = 2218;
        bossGroup = new NioEventLoopGroup(2);
        workGroup = new NioEventLoopGroup(8);
        ChannelFuture channelFuture = null;
        try {
            ServerBootstrap bootstrap = new ServerBootstrap();
            bootstrap.group(bossGroup, workGroup)
                    .channel(NioServerSocketChannel.class)
                    // 设置保持活动连接状态
                    .childOption(ChannelOption.SO_KEEPALIVE, true)
                    // 给workerGroup的EventLoop设置管道
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel socketChannel) throws Exception {
                            // socketChannel.pipeline().addLast("decoder", new SL651_2014Decoder());
                            socketChannel.pipeline().addLast("idle", new IdleStateHandler(0, 0, 5 * 60, TimeUnit.SECONDS));
                            socketChannel.pipeline().addLast("testing", new ChannelInboundHandlerAdapter() {
                                @Override
                                public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
                                    if (evt instanceof IdleStateEvent) {
                                        IdleStateEvent event = (IdleStateEvent) evt;
                                        if (event.state() == IdleState.ALL_IDLE) {
                                            log.warn("timeout: {}", ctx.channel().remoteAddress());
                                            ctx.channel().close();
                                        }
                                    } else {
                                        super.userEventTriggered(ctx, evt);
                                    }
                                }
                            });
                            // 字节校验处理，确保收到的完整消息没有损坏才能进行后续处理
                            socketChannel.pipeline().addLast("crc8", new Crc8Handler());
                            // logger
                            socketChannel.pipeline().addLast(new LoggingHandler(LogLevel.INFO));
                            // crc校验成功后进行消息的编解码
                            socketChannel.pipeline().addLast("codec", new SZY206_2016Codec());
                            // // 保存连接
                            socketChannel.pipeline().addLast("clients-active", new ChannelActiveHandler());
                            socketChannel.pipeline().addLast("clients-inactive", new ChannelInactiveHandler());
                            // 捕获解码完成的消息，并做处理
                            socketChannel.pipeline().addLast("message handler", new DealingHandler());
                        }
                    });
            // 绑定端口并同步等待
            channelFuture = bootstrap.bind(host, port).sync();
            LOGGER.info("========= netty server start on {} =========", port);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return channelFuture;
    }

    public void close() {
        workGroup.shutdownGracefully();
        bossGroup.shutdownGracefully();
        LOGGER.info("========= shutdown netty server success! =========");
    }

    private static class MyChannelInboundHandler extends ChannelInboundHandlerAdapter {
        @Override
        public void channelRegistered(ChannelHandlerContext channelHandlerContext) throws Exception {
            Channel channel = channelHandlerContext.channel();
            String id = "0020000116";
            ChannelUtil206.addChannel(id, channel);
            channelHandlerContext.fireChannelRegistered();
        }
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：58H-查询遥测终端水压上、下限
 */
public class DownlinkQueryWaterPressure_58H extends ApplicationSpaceDownlink {

    {
        applicationFunctionCode = AFN._58.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{applicationFunctionCode};
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;

/**
 * @Author：houDeJian
 * @Record：64H-查询遥终端的流量参数上限值(响应帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryFlow_64H extends ApplicationSpaceUplink {
    /**
     * 返回的N个流量参数上限值
     */
    ArrayList<Double> flowData=new ArrayList<>();
    String  waterWarn;
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        int i = buffer.readableBytes()-2;
        int n=i/5;
        for (int y = 0; y < n; y++) {
            byte _byte1 = buffer.readByte();
            byte _byte2 = buffer.readByte();
            byte _byte3 = buffer.readByte();
            byte _byte4 = buffer.readByte();
            byte _byte5 = buffer.readByte();
            int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
            int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
            int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
            int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
            int byte5 = (_byte5 & 0x0F);
            int sign=(_byte5>>4 & 0x0F)==15?-1:1;
            Double value= sign*(byte5* 100000 +byte4*1000+byte3*10+byte2*0.1+byte1*0.001);
            this.flowData.add(value);
        }
        byte[] waterWarnSpace = new byte[2];
        buffer.readBytes(waterWarnSpace);
        // todo 解析告警数据
        this.waterWarn = HexUtil.encodeHexStr(waterWarnSpace);

    }

}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：90H_复位遥测终端参数和状态
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkResetTelemetryStation_90H extends ApplicationSpaceDownlink {
    {
        applicationFunctionCode = AFN._90.getFNCByte();
    }

    /**
     * 复位状态 1或2
     */
    int status;

    @Override
    public byte[] encode() {
        byte setStatus;
        if (status == 1) {
            setStatus = 0x01;
        }else{
            setStatus = 0x02;
        }

        return ArrayUtil.addAll(new byte[]{applicationFunctionCode, setStatus}, this.aux.encode());
    }
}

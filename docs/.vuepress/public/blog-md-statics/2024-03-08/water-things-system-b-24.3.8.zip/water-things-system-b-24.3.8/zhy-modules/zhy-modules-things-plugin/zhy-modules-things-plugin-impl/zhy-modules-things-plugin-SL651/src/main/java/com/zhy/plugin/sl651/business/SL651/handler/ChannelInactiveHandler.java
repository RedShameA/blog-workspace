package com.zhy.plugin.sl651.business.SL651.handler;

import com.zhy.plugin.core.entity.domain.plugin.PluginDeviceOnlineStatus;
import com.zhy.plugin.core.support.PluginContext;
import com.zhy.plugin.sl651.business.SL651.utils.ChannelUtil;
import com.zhy.plugin.sl651.business.SL651.utils.StationUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

/**
 * 连接断开事件
 * @author wangfeng
 * @since 2023-06-26 15:54
 */
public class ChannelInactiveHandler extends ChannelInboundHandlerAdapter {
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        String id = ChannelUtil.getIdByChannel(ctx.channel());
        ChannelUtil.removeChannel(ctx.channel());
        StationUtil.removeOnline(id);
        PluginContext.produceDeviceOnlineStatus(new PluginDeviceOnlineStatus(id,false));
        super.channelInactive(ctx);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        String id = ChannelUtil.getIdByChannel(ctx.channel());
        ChannelUtil.removeChannel(ctx.channel());
        StationUtil.removeOnline(id);
        PluginContext.produceDeviceOnlineStatus(new PluginDeviceOnlineStatus(id,false));
        super.exceptionCaught(ctx, cause);
    }
}

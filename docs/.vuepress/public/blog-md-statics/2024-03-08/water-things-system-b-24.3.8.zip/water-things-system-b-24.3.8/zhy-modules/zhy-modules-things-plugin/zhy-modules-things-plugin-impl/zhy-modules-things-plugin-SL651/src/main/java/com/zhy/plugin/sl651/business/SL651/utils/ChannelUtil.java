package com.zhy.plugin.sl651.business.SL651.utils;


import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author wangfeng
 * @Description 管理netty channel
 * @Date 2023-05-03 13:41
 */
@Slf4j
public class ChannelUtil {

    public static ChannelGroup CHANNEL_MAP = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
    public static ConcurrentHashMap<String, Channel> ID_CHANNEL = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<Channel, String> CHANNEL_ID = new ConcurrentHashMap<>();

    public static ChannelGroup getChannelMap(){
        return CHANNEL_MAP;
    }

    public static boolean addChannel(String id, Channel channel){
        if (null==CHANNEL_ID.get(channel)){
            //if (null!=ID_CHANNEL.get(id)){
            //    log.error("遇到了id不同站，保留原有，丢弃当前请求");
            //    return false;
            //}
            if (null!=ID_CHANNEL.get(id)){
                log.info("遇到了同id的不同tcp链接，覆盖原有");
            }
            ID_CHANNEL.put(id, channel);
            CHANNEL_ID.put(channel, id);
            CHANNEL_MAP.add(channel);
            log.info("添加了一个上线并通过crc验证的channel：{}", id);
            log.info("当前有效连接数：{}, {}", ID_CHANNEL.size(), CHANNEL_MAP.size());
        }
        return true;
    }

    public static void  removeChannel(Channel channel){
        String id = CHANNEL_ID.remove(channel);
        if (null!=id){
            ID_CHANNEL.remove(id);
            log.info("移除了一个断线的channel：{}", id);
            log.info("当前有效连接数：{}, {}", ID_CHANNEL.size(), CHANNEL_MAP.size());
        }
    }

    public static void  removeChannel(String id){
        Channel channel = ID_CHANNEL.remove(id);
        if (null!=channel){
            CHANNEL_ID.remove(channel);
        }
    }
    public static Channel getChannel(String id){
        return ID_CHANNEL.get(id);
    }

    public static String getIdByChannel(Channel channel){
        return CHANNEL_ID.get(channel);
    }

    public static void findAndSend(String id, byte[] bytes){
        Channel channel = ID_CHANNEL.get(id);
        if (null!=channel){
            channel.writeAndFlush(Unpooled.copiedBuffer(bytes));
        }
    }

}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.HexUtil;
import com.google.common.primitives.Bytes;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl.UplinkQueryServerAddress_D1H;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * D2H 设置服务端地址 （山东）
 *
 * @author wangfeng
 * @since 2023-10-05 16:43
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetServerAddress_D2H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._D2.getFNCByte();
    }

    /**
     * 服务端地址ip
     */
    String ip;
    /**
     * 服务端地址端口
     */
    Integer port;

    @Override
    public byte[] encode() {
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode},
                calc(ip),
                HexUtil.decodeHex(Integer.toHexString(port))
        );
    }

    public static void main(String[] args) {
        DownlinkSetServerAddress_D2H downlinkSetServerAddressD2H = new DownlinkSetServerAddress_D2H();
        downlinkSetServerAddressD2H.ip = "127.0.0.1";
        downlinkSetServerAddressD2H.port = 10010;
        System.out.println(HexUtil.encodeHexStr(downlinkSetServerAddressD2H.encode()));

        UplinkQueryServerAddress_D1H d1H = new UplinkQueryServerAddress_D1H();
        d1H.decode(downlinkSetServerAddressD2H.encode());
        System.out.println(d1H.getIp());
        System.out.println(d1H.getPort());
    }

    private byte[] calc(String ip) {
        List<Byte> collect = Arrays.stream(ip.split("\\."))
                .map(Integer::new)
                .collect(Collectors.toList())
                .stream()
                .map(i -> {
                    Byte[] bytes = new Byte[2];
                    bytes[0] = (byte) (0b0000_1111 & (i / 100));
                    bytes[1] = (byte) (((0b0000_1111 & ((i % 100) / 10)) << 4) | (0b0000_1111 & (i % 10)));
                    return Arrays.asList(bytes);
                }).flatMap(Collection::stream).collect(Collectors.toList());
        return Bytes.toArray(collect);
    }
}

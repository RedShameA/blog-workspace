package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkRealTimeSpecify;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * 处理指定要素实时数据
 * @author wangfeng
 * @since 2023-07-27 17:43
 */
@Slf4j
@Component
public class RealTimeSpecifyVisitor implements MessageFrameUseVisitor<MessageContentUplinkRealTimeSpecify> {
    @Override
    public String getFunctionCode() {
        return AppendixB._3A.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("指定要素实时数据报visitor");
        MessageContentUplinkRealTimeSpecify content = getContent(frame);
        System.out.println("content.doubleElements = " + content.doubleElements);
        System.out.println("content.getRainData() = " + Arrays.toString(content.getRainData()));
        System.out.println("content.getWaterLevelData() = " + Arrays.toString(content.getWaterLevelData()));
    }
}

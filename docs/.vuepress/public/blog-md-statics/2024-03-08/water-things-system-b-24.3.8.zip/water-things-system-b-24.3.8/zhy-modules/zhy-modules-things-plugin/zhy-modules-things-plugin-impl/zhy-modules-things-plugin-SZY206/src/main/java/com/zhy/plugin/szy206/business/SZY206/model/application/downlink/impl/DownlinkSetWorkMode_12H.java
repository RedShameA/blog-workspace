package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 12H 设置遥测站的工作模式
 *
 * @Author：houDeJian
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetWorkMode_12H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode = AFN._12.getFNCByte();
    }

    /**
     * 0 兼容工作状态
     * 1 自报工作状态
     * 2 查询/应答
     * 3 调试/维修
     */
    private int workMode;


    @Override
    public byte[] encode() {
        if (workMode < 0 || workMode > 3) {
            throw new IllegalArgumentException("work mode must be 0、1、2、3");
        }
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode, (byte) workMode}, this.aux.encode());
    }

}

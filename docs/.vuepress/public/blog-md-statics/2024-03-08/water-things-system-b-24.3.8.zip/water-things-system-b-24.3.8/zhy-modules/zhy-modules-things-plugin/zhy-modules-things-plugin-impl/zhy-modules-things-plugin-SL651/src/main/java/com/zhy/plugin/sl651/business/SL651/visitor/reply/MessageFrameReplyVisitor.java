package com.zhy.plugin.sl651.business.SL651.visitor.reply;

import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.MessageContent;
import io.netty.channel.ChannelHandlerContext;

/**
 * @author wangfeng
 * @since 2023-07-05 08:44
 */

public interface MessageFrameReplyVisitor<T extends MessageContent> {
    /**
     * 返回需要处理的功能码
     * @return 功能码
     */
    String getFunctionCode();

    /**
     * 处理,报文正文对象只有最基本的 流水号、发报时间 两个参数，其他的自己现解析
     */
    void doReply(ChannelHandlerContext ctx, MessageFrame frame);

    default T getContent(MessageFrame frame){
        T ret = null;
        try{
            ret = (T) frame.getMessageContent();
        }catch (Exception ignored){
        }
        return  ret;
    }

}

package com.zhy.plugin.core.entity.domain.plugin;

import com.zhy.things.common.constants.ValueType;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author wangfeng
 * @since 2023-11-06 14:58
 */
@Data
public class ThingsPlugin {
    /* 标识插件的协议，不同插件之间唯一 */
    String protocol;
    String name;
    String version;
    String description;
    List<Map<String, String>> supportedFunctions;
    List<ValueType> supportedValueTypes;
}

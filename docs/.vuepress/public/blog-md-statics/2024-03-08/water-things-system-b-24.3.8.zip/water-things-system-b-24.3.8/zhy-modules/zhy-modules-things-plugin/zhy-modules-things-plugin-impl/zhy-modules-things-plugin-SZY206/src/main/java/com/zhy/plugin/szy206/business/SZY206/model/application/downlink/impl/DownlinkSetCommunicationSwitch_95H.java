package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：
 *          95-遥控中继站工作机切换
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetCommunicationSwitch_95H extends ApplicationSpaceDownlink {

    {
        applicationFunctionCode=AFN._95.getFNCByte();
    }
    @Override
    public byte[] encode() {
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, this.aux.encode());
    }
}

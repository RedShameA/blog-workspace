package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.constants.WaterQualityParameter_Enum;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.WaterQualityParameter;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.lang.reflect.Field;

/**
 * @Author：houDeJian
 * @Record：19H-设置遥测终端水质参数种类、上限值
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetUpWaterQualityParameter_19H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode =AFN._19.getFNCByte();
    }

    /**
     *  水质参数实体类
     */
    WaterQualityParameter waterQualityParameter;

    @Override
    public byte[] encode() {
        byte[] waterQualityType = byteData(waterQualityParameter);
        byte[] waterQualityBytes = waterQualityUpLimitValue(waterQualityParameter);
        return ArrayUtil.addAll(new byte[]{this.applicationFunctionCode},waterQualityType, waterQualityBytes, this.aux.encode());
    }

    /**
     * 判断对象不为空的
     */
    public int isNotNUll(Object object) {
        int n = 0;
        try {
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);
                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val != null) {
                    n += 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return n;
    }

    public byte[] byteData(Object object) {
        byte[] array = new byte[5];
        try {
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);
                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val != null) {
                    String name = f.getName();
                    String s = name.split("D")[1];
                    //放在那个数组中
                    int n = Integer.parseInt(s) / 8;
                    //字节数组中的位置
                    int n1 = Integer.parseInt(s) % 8;
                    array[n] = (byte) (array[n] | (1 << n1));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return array;
    }

    public byte[] waterQualityUpLimitValue(Object object) {
        int addValue = waterQualityParameter.getD24() == null ? 0 : 1;
        int isNotNull = isNotNUll(waterQualityParameter);
        byte[] waterQualityUpLimitValue=new byte[isNotNull*4+addValue];
        int n=0;
        try {
            //得到类对象
            Class stuCla = object.getClass();
            //得到属性集合
            Field[] fs = stuCla.getDeclaredFields();
            //遍历属性
            for (Field f : fs) {
                // 设置属性是可以访问的(私有的也可以)
                f.setAccessible(true);
                // 得到此属性的值
                Object val = f.get(object);
                //只要有1个属性不为空,那么就不是所有的属性值都为空
                if (val != null) {
                    String name = f.getName();
                    byte[] array = f.getName() == "D24" ? new byte[5] : new byte[4];
                    int sumLength = f.getName() == "D24" ? 10 : 8;
                    Integer decimalPlaces = WaterQualityParameter_Enum.getRight(name);
                    Integer totalWidth = sumLength - decimalPlaces;

                    String formatString = decimalPlaces != 0 ?
                            String.format("%0" + (sumLength+1) + "." + decimalPlaces + "f", val) :
                            String.format("%0" + sumLength + "d", val);
                    //去小数点
                    String replace = decimalPlaces != 0 ?formatString.replace(".", ""):formatString;
                    int byte1 = Integer.parseInt(replace.substring(replace.length() - 2, replace.length()));
                    int byte2 = Integer.parseInt(replace.substring(replace.length() - 4, replace.length() - 2));
                    int byte3 = Integer.parseInt(replace.substring(replace.length() - 6, replace.length() - 4));
                    int byte4 = Integer.parseInt(replace.substring(replace.length() - 8, replace.length() - 6));
                    byte _byte1 = (byte) ((byte1 / 10 << 4) | (byte1 % 10));
                    byte _byte2 = (byte) ((byte2 / 10 << 4) | (byte2 % 10));
                    byte _byte3 = (byte) ((byte3 / 10 << 4) | (byte3 % 10));
                    byte _byte4 = (byte) ((byte4 / 10 << 4) | (byte4 % 10));
                    waterQualityUpLimitValue[n++]=_byte1;
                    waterQualityUpLimitValue[n++]=_byte2;
                    waterQualityUpLimitValue[n++]=_byte3;
                    waterQualityUpLimitValue[n++]=_byte4;
                    if(f.getName() == "D24"){
                        int byte5 = Integer.parseInt(replace.substring(replace.length() - 10, replace.length() - 8));
                        byte _byte5 = (byte) ((byte5 / 10 << 4) | (byte5 % 10));
                        waterQualityUpLimitValue[n++]=_byte5;
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return waterQualityUpLimitValue;
    }

}

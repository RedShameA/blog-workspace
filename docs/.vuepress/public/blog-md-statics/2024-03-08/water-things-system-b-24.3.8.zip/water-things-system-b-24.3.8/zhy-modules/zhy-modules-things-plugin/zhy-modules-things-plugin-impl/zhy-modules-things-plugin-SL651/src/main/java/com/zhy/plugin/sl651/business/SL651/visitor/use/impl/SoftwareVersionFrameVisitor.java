package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkSoftwareVersion;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 处理终端软件版本报
 */
@Slf4j
@Component
public class SoftwareVersionFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkSoftwareVersion> {
    @Override
    public String getFunctionCode() {
        return AppendixB._45.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("终端软件版本报visitor");
        MessageContentUplinkSoftwareVersion content = getContent(frame);
        //Map<String, Double> doubleMap = content.getDoubleMap();
        String version = content.getVersion();
        Date collectTimeParse = content.getCollectTimeParse();
        System.out.println("-------");
        System.out.println(version);
        System.out.println("-------");

    }
}

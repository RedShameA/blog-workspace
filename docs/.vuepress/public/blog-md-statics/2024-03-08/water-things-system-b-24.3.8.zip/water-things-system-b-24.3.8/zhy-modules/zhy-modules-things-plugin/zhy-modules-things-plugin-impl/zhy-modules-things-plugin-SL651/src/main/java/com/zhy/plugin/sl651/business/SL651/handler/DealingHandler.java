package com.zhy.plugin.sl651.business.SL651.handler;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.utils.MessageFrameVisitorUtil;
import com.zhy.plugin.sl651.business.SL651.utils.WaitForResultUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import lombok.extern.slf4j.Slf4j;

/**
 * @author wangfeng
 * @since 2023-07-04 17:32
 */
@Slf4j
public class DealingHandler extends SimpleChannelInboundHandler<MessageFrame> {
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, MessageFrame messageFrame) throws Exception {
        // log.info("获取到了一个解码成功的对象");
        String functionCode = HexUtil.encodeHexStr(new byte[]{messageFrame.getFunctionCode()}).toUpperCase();
        MessageFrameVisitorUtil.doVisit(functionCode, ctx, messageFrame);
        WaitForResultUtil.fireResult(messageFrame);
        WaitForResultUtil.fireFirstInResult(messageFrame);
    }
}

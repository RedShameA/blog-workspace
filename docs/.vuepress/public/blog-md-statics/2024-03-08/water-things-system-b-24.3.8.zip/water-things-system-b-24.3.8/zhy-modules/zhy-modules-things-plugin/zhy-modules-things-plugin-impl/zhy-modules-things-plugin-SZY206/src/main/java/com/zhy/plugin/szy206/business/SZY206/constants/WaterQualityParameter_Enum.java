package com.zhy.plugin.szy206.business.SZY206.constants;

/**
 * @Author：houDeJian
 * @Record：
 */


public enum WaterQualityParameter_Enum {
    D0("水温", 3, 1),
    D1("PH值", 4, 2),
    D2("溶解氧", 4, 2),
    D3("高锰酸盐指数", 4, 2),
    D4("电导率", 5, 0),
    D5("氧还原电位", 5, 1),
    D6("浊度", 3, 0),
    D7("化学需氧量", 7, 1),
    D8("五日生化需氧量", 5, 1),
    D9("氨氮", 6, 2),
    D10("总氮", 5, 2),
    D11("铜", 7, 4),
    D12("锌", 6, 4),
    D13("氟化物", 5, 2),
    D14("硒", 7, 5),
    D15("砷", 7, 5),
    D16("汞", 7, 5),
    D17("镉", 7, 5),
    D18("六价铬", 5, 3),
    D19("铅", 7, 5),
    D20("氰化物", 5, 3),
    D21("挥发酶", 5, 3),
    D22("苯酚", 5, 2),
    D23("硫化物", 5, 3),
    D24("粪大肠菌群", 10, 0),
    D25("硫酸盐", 6, 2),
    D26("氯化物", 8, 2),
    D27("硝酸盐氮", 5, 2),
    D28("铁", 4, 2),
    D29("锰", 4, 2),
    D30("石油类", 4, 2),
    D31("阴阳离子表面活性剂", 4, 2),
    D32("六六六", 7, 6),
    D33("滴滴涕", 7, 6),
    D34("有机氯农药", 7, 6),
    D35("总磷", 5, 3),
    D36("叶绿素", 6, 3);


    private String TEXT;
    private Integer LEFT;
    private Integer RIGHT;

    public String getTEXT() {
        return TEXT;
    }

    public Integer getLEFT() {
        return LEFT;
    }

    public Integer getRIGHT() {
        return RIGHT;
    }

    WaterQualityParameter_Enum(String TEXT, Integer LEFT,Integer  RIGHT){
        this.TEXT = TEXT;
        this.RIGHT = RIGHT;
        this.LEFT = LEFT;
    }
    WaterQualityParameter_Enum(){

    }

    public static Integer getLeft(String parameter) {
        for (WaterQualityParameter_Enum enumValue : WaterQualityParameter_Enum.values()) {
            if (enumValue.name().equalsIgnoreCase(parameter)) {
                return enumValue.getLEFT();
            }
        }
        return null; // 如果参数没有匹配的枚举值，则返回null或者其他适当的值
    }
    public static Integer getRight(String parameter) {
        for (WaterQualityParameter_Enum enumValue : WaterQualityParameter_Enum.values()) {
            if (enumValue.name().equalsIgnoreCase(parameter)) {
                return enumValue.getRIGHT();
            }
        }
        return null; // 如果参数没有匹配的枚举值，则返回null或者其他适当的值
    }


}

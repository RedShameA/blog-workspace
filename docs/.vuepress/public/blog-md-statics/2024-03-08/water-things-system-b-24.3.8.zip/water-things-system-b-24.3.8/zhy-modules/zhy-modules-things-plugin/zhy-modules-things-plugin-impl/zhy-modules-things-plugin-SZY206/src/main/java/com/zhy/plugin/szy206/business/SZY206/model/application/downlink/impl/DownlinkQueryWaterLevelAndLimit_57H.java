package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;

/**
 * @Author：houDeJian
 * @Record：57H查询终端的水位基值和水位上下线
 */


public class DownlinkQueryWaterLevelAndLimit_57H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._57.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

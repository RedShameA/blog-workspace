package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：94-遥控终端或中继站通信机切换
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetCommunicationSwitch_94H extends ApplicationSpaceDownlink {

    {
        applicationFunctionCode=AFN._94.getFNCByte();
    }
    @Override
    public byte[] encode() {
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, this.aux.encode());
    }
}

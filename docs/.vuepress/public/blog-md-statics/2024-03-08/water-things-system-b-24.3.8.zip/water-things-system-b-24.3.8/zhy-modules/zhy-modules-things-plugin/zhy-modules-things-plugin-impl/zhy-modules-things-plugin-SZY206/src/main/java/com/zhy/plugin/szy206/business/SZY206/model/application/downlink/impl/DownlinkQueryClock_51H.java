package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 51H 查询遥测站时钟
 *
 * @Author：houDeJian
 * @Record：51-查询遥测终端、中继站时钟
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkQueryClock_51H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._51.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return new byte[]{this.applicationFunctionCode};
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application._AUX;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Calendar;
import java.util.Date;

/**
 * 51H --查询遥测站或中继站的时钟（解码）
 *
 * @Author：houDeJian
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryClock_51H extends ApplicationSpaceUplink {

    /**
     * 返回的时钟数据
     */
    Date date;

    @Override
    public void decode() {

        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // date
        byte _SECOND = buffer.readByte();
        byte _MINUTE = buffer.readByte();
        byte _HOUR = buffer.readByte();
        byte _DAY = buffer.readByte();
        byte _WEEK_MONTH = buffer.readByte();
        byte _YEAR = buffer.readByte();

        int second = ((_SECOND >> 4) * 10) + (_SECOND & 0b0000_1111);
        int minute = ((_MINUTE >> 4) * 10) + (_MINUTE & 0b0000_1111);
        int hour = ((_HOUR >> 4) * 10) + (_HOUR & 0b0000_1111);
        int day = ((_DAY >> 4) * 10) + (_DAY & 0b0000_1111);
        int month = ((_WEEK_MONTH >> 4 & 0b0000_0001) * 10) + (0b00001111 & _WEEK_MONTH) - 1;
        int year = ((_YEAR >> 4) * 10) + (_YEAR & 0b0000_1111) + 2000;

        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.SECOND, second);
        instance.set(Calendar.MINUTE, minute);
        instance.set(Calendar.HOUR_OF_DAY, hour);
        instance.set(Calendar.DAY_OF_MONTH, day);
        instance.set(Calendar.MONTH, month);
        instance.set(Calendar.YEAR, year);

        this.date = instance.getTime();
        // aux
        _AUX aux = new _AUX();
        buffer.readBytes(aux.getContent());
        aux.decode();
        this.aux = aux;
    }
}

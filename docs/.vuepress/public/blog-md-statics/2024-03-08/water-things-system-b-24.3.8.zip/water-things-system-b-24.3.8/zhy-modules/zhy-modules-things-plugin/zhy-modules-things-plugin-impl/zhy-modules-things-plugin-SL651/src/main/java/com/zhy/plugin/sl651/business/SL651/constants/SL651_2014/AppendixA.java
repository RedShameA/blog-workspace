package com.zhy.plugin.sl651.business.SL651.constants.SL651_2014;

/**
 * @Author wangfeng
 * @Description 水文协议 附录A
 * @Date 2023-05-03 09:41
 */
public enum AppendixA {

    _50("降水", "50", "P"),  // ①降水;②蒸发③气象
    _48("河道", "48", "H"),  // ①降水;②蒸发;③河道水情④气象⑤水质
    _4B("水库(湖泊)", "4B", "K"),  // ①降水;②蒸发;③水库水情④气象⑤水质
    _5A("闸坝", "5A", "Z"),  // ①降水;②蒸发;③闸坝水情④气象⑤水质
    _44("泵站", "44", "D"),  // ①降水;②蒸发;③泵站水情④气象⑤水质
    _54("潮汐", "54", "T"),  // ①降水;②蒸发;③潮汐水情④气象
    _4D("墒情", "4D", "M"),  // ①降水;②蒸发;③墒情
    _47("地下水", "47", "G"),  // ①埋深;②水质;③开采量
    _51("水质", "51", "Q"),  // ①水质;②流量;③水位
    _49("取水口", "49", "I"),  // ①水位; ②水质;③水量④水压等
    _4F("排水口", "4F", "O");  // ①水位; ②水质;③水量④水压等

    private String TEXT;
    private String HEX;
    private String ASC;

    public String getTEXT() {
        return TEXT;
    }

    public String getHEX() {
        return HEX;
    }

    public String getASC() {
        return ASC;
    }

    AppendixA(String TEXT, String HEX, String ASC){
        this.TEXT = TEXT; this.HEX = HEX; this.ASC = ASC;
    }

}

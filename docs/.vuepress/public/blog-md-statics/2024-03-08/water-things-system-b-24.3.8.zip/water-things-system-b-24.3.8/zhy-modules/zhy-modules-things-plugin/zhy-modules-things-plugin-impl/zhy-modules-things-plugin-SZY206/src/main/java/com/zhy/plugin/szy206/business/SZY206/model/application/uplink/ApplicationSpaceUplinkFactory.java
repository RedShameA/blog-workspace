package com.zhy.plugin.szy206.business.SZY206.model.application.uplink;


import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.szy206.business.SZY206.model.MessageFrame;
import com.zhy.plugin.szy206.business.SZY206.model.application.ApplicationSpace;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl.*;
import lombok.extern.slf4j.Slf4j;

/**
 * @author wangfeng
 * @since 2023-09-07 15:27
 */
@Slf4j
public class ApplicationSpaceUplinkFactory {

    public static void main(String[] args) {
        System.out.println(HexUtil.encodeHexStr(new byte[]{(byte) 99999}).toUpperCase());
    }

    /**
     * 根据功能码，解析 用户数据域 到对应的 用户数据域对象
     *
     * @param applicationSpaceContent 用户数据域字节
     */
    public static ApplicationSpace parseApplicationSpace(MessageFrame frame, byte[] applicationSpaceContent) {
        // 应用层功能码 AFN
        byte applicationFunctionCode = applicationSpaceContent[0];
        switch (HexUtil.encodeHexStr(new byte[]{applicationFunctionCode}).toUpperCase()) {
            case "02":
                return new UplinkLinkCheck_02H().decode(applicationSpaceContent);
            case "10":
                return new UplinkSetAddress_10H().decode(applicationSpaceContent);
            case "11":
                return new UplinkSetClock_11H().decode(applicationSpaceContent);
            case "12":
                return new UplinkSetWorkMode_12H().decode(applicationSpaceContent);
            case "17":
                return new UplinkSetWaterLevelAndLimit_17H().decode(applicationSpaceContent);
            case "19":
                return new UplinkSetWaterQualityUpParameter_19H().decode(applicationSpaceContent);
            case "1A":
                return new UplinkSetWaterQualityDownParameter_1AH().decode(applicationSpaceContent);
            case "1B":
                return new UplinkSetInitialWaterGauge_1BH().decode(applicationSpaceContent);
            case "1C":
                return new UplinkSetBootCode_1CH().decode(applicationSpaceContent);
            case "1D":
                return new UplinkSetForwardAddress_1DH().decode(applicationSpaceContent);
            case "1E":
                return new UplinkSetSwitchStatus_1EH().decode(applicationSpaceContent);
            case "1F":
                return new UplinkSetFlow_1FH().decode(applicationSpaceContent);
            case "30":
                return new UplinkSetICUseable_30H().decode(applicationSpaceContent);
            case "31":
                return new UplinkSetICDisable_31H().decode(applicationSpaceContent);
            case "32":
                return new UplinkSetOpenValueControl_32H().decode(applicationSpaceContent);
            case "33":
                return new UplinkSetExitValueControl_33H().decode(applicationSpaceContent);
            case "34":
                return new UplinkSetDefiniteValue_34H().decode(applicationSpaceContent);
            case "50":
                return new UplinkQueryAddress_50H().decode(applicationSpaceContent);
            case "51":
                return new UplinkQueryClock_51H().decode(applicationSpaceContent);
            case "52":
                return new UplinkQueryWorkMode_52H().decode(applicationSpaceContent);
            case "53":
                return new UplinkQuerySelfReport_53H().decode(applicationSpaceContent);
            case "54":// 查询遥测站需要查询的实时数据种类
                return new UplinkQueryRealDataType_54H().decode(applicationSpaceContent);
            case "55": // 查询现在充值量和剩余水量
                return new UplinkQueryCharge_55H().decode(applicationSpaceContent);
            case "56": // 查询剩余水量和报警值
                return new UplinkQuerySurplusWater_56H().decode(applicationSpaceContent);
            case "57":
                return new UplinkQueryWaterLevelAndLimit_57H().decode(applicationSpaceContent);
            case "58":
                return new UplinkQueryWaterPressure_58H().decode(applicationSpaceContent);
            case "59":
                return new UplinkQueryWaterQualityUpParamter_59H().decode(applicationSpaceContent);
            case "5A":
                return new UplinkQueryWaterQualityDownParamter_5AH().decode(applicationSpaceContent);
            case "5D":
                return new UplinkQueryEventRecording_5DH().decode(applicationSpaceContent);
            case "5E":
                return new UplinkQueryStationAndWarnStatus_5EH().decode(applicationSpaceContent);
            case "5F":
                return new UplinkQueryPumpWorkData_5FH().decode(applicationSpaceContent);
            case "60":
                return new UplinkQueryBootCode_60H().decode(applicationSpaceContent);
            case "61":
                return new UplinkQueryImageRecord_61H().decode(applicationSpaceContent);
            case "62":
                return new UplinkQueryForwardAddress_62H().decode(applicationSpaceContent);
            case "63":
                return new UplinkQuerySwitchStatus_63H().decode(applicationSpaceContent);
            case "64":
                return new UplinkQueryFlow_64H().decode(applicationSpaceContent);
            case "81":
                UplinkRandomSelfReportWarn_81H uplinkRandomSelfReportWarn81H = new UplinkRandomSelfReportWarn_81H();
                uplinkRandomSelfReportWarn81H.setControlAfn(frame.getControlSpace().getControlFNC());
                return uplinkRandomSelfReportWarn81H.decode(applicationSpaceContent);
            case "82": // 基本同自报实时数据 C0
                UplinkConfirmManualSet_82H uplinkConfirmManualSet82H = new UplinkConfirmManualSet_82H();
                uplinkConfirmManualSet82H.setControlAfn(frame.getControlSpace().getControlFNC());
                return uplinkConfirmManualSet82H.decode(applicationSpaceContent);
            case "90":
                return new UplinkResetTelemetryStation_90H().decode(applicationSpaceContent);
            case "91":
                return new UplinkSetClearHistoryData_91H().decode(applicationSpaceContent);
            case "92":
                return new UplinkSetOpenPumpValue_92H().decode(applicationSpaceContent);
            case "93":
                return new UplinkSetClosePumpValue_93H().decode(applicationSpaceContent);
            case "94":
                return new UplinkSetCommunicationSwitch_94H().decode(applicationSpaceContent);
            case "95":
                return new UplinkSetCommunicationSwitch_95H().decode(applicationSpaceContent);
            case "96":
                return new UplinkSetPassword_96H().decode(applicationSpaceContent);
            case "A0":
                return new UplinkSetNeedRealDataTypes_A0H().decode(applicationSpaceContent);
            case "A1":
                return new UplinkSetSelfReport_A1H().decode(applicationSpaceContent);
            case "B0":
                return new UplinkQueryRealTimeValue_B0H().decode(applicationSpaceContent);
            case "B1":
                return new UplinkQuerySolidStateData_B1H().decode(applicationSpaceContent);
            case "B2":
                return new UplinkQueryTerminalMemorySelfReportedData_B2H().decode(applicationSpaceContent);
            case "C0":
                UplinkRealTimeValue_C0H uplinkRealTimeValueC0H = new UplinkRealTimeValue_C0H();
                uplinkRealTimeValueC0H.setControlAfn(frame.getControlSpace().getControlFNC());
                return uplinkRealTimeValueC0H.decode(applicationSpaceContent);
            case "C1":
                UplinkRealTimeValue_C1H uplinkRealTimeValueC1H = new UplinkRealTimeValue_C1H();
                uplinkRealTimeValueC1H.setControlAfn(frame.getControlSpace().getControlFNC());
                return uplinkRealTimeValueC1H.decode(applicationSpaceContent);
            case "C3":
                return new UplinkProactiveTiming_C3H().decode(applicationSpaceContent);
            case "D1":
                return new UplinkQueryServerAddress_D1H().decode(applicationSpaceContent);
            case "D2":
                return new UplinkSetServerAddress_D2H().decode(applicationSpaceContent);
            case "E1":
                return new UplinkRemoteReportDanger_E1H().decode(applicationSpaceContent);







            default:
                UplinkUnSupported unSupported = new UplinkUnSupported();
                unSupported.decode(applicationSpaceContent);
                log.error("不支持的报文：{}", HexUtil.encodeHexStr(new byte[]{unSupported.getApplicationFunctionCode()}).toUpperCase() + "H");
                return unSupported;
        }
    }
}

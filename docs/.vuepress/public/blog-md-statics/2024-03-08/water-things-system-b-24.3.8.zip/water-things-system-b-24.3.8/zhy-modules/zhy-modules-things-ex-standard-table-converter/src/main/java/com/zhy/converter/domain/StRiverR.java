package com.zhy.converter.domain;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 河道水情表
 */
@Data
public class StRiverR {
    /**
     * 水情发生的时间
     */
    private Date tm;

    /**
     * 由全国统一编制的，用于标识涉及报送降水、蒸发、河道、水库、闸坝、泵站、潮沙、沙情、冰情、墒情、地下水、水文预报等信息的各类测站的站码。测站编码具有唯一性，由数字和大写字母组成的8位字符串，按《全国水文测站编码》执行。
     */
    private String stcd;

    /**
     * 测站断面相应时间的水位，计量单位为m
     */
    private Double z;

    /**
     * 测站测验断面相应时间通过的流量，计量单位为m³/s
     */
    private Double q;

    /**
     * 流量通过时相应的过流面积，计量单位为㎡，计至3位小数
     */
    private Double xsa;

    /**
     * 给定时间河道水文站实测流量时所测得的测验断面平均流速，计量单位为m/s
     */
    private Double xsavv;

    /**
     * 给定时间河道水文站实测流量时所测得的测验断面最大点流速，计量单位为
     * m/s
     */
    private Double xsmxv;

    /**
     * 给定时间河道洪水起涨、流向、干枯、断流和峰值等特征的描述代码，河水特征及其代码应按表37确定
     */
    private String flwchrcd;

    /**
     * 河道洪水水位的涨落信息，水势及其代码应按表38确定
     */
    private String wptn;

    /**
     * 流量的施测方法，测流方法及其代码应按表39确定
     */
    private String msqmt;

    /**
     * 过流断面面积的测量方法，测积方法及其代码应按表40确定
     */
    private String msamt;

    /**
     * 水流速度的测量方法，测速方法及其代码应按表41确定
     */
    private String msvmt;
}
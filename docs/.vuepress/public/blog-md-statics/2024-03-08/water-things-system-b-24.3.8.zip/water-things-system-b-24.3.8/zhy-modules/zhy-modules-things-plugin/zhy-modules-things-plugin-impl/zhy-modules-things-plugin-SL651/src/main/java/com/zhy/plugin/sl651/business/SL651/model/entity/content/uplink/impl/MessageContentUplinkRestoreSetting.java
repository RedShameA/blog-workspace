package com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl;

import cn.hutool.core.util.HexUtil;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.MessageContentUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;

/**
 * 恢复遥测站出厂设置上行报文解析
 */
@Data
public class MessageContentUplinkRestoreSetting extends MessageContentUplink {
    @Override
    public void decode() {
        // 正文内容
        byte[] content = this.getBytes();
        ByteBuf buffer = Unpooled.wrappedBuffer(content);

        // 流水号
        byte[] serialNumber = new byte[2];
        buffer.readBytes(serialNumber);
        this.setSerialNumber(serialNumber);
        // 发报时间
        byte[] messageTime = new byte[6];
        buffer.readBytes(messageTime);
        this.setMessageTime(messageTime);
        // 标识符
        byte[] flag = new byte[2];
        while (buffer.isReadable()) {
            buffer.readBytes(flag);
            String flagStr = HexUtil.encodeHexStr(flag, false).substring(0, 2);
            switch (flagStr) {
                //003B170718110432F1F10011223344
                case "F1": // 观测站
                    byte[] station = new byte[5];
                    buffer.readBytes(station);
                    this.setStation(station);
                    break;
            }
        }
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.StationWarnStatus;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;

/**
 * @Author：houDeJian
 * @Record：5E-查询遥测终端状态和报警状态(响应帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryStationAndWarnStatus_5EH extends ApplicationSpaceUplink {

    /**
     * 返回的遥测终端状态和报警状态
     */
    StationWarnStatus stationWarnStatus;

    @SneakyThrows
    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // 报警信息
        byte[] bytes = new byte[4];
        buffer.readBytes(bytes);
        this.stationWarnStatus = new StationWarnStatus().parse(bytes);
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Calendar;
import java.util.Date;

/**
 * 03H 遥测站主动校时 （山东）
 *
 * @author wangfeng
 * @since 2023-10-05 15:11
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkProactiveTiming_C3H extends ApplicationSpaceUplink {

    /**
     * 校时报文中携带的时间
     */
    Date date;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(this.content);
        // 功能码字节
        this.applicationFunctionCode = buffer.readByte();
        // 时间
        byte[] bytes = new byte[6];
        buffer.readBytes(bytes);
        this.date = this.calcDate(bytes);
    }

    private Date calcDate(byte[] bytes) {
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.MILLISECOND, 0);
        instance.set(Calendar.SECOND, this.calc(bytes[0]));
        instance.set(Calendar.MINUTE, this.calc(bytes[1]));
        instance.set(Calendar.HOUR_OF_DAY, this.calc(bytes[2]));
        instance.set(Calendar.DAY_OF_MONTH, this.calc(bytes[3])-1);
        instance.set(Calendar.MONTH, this.calc(bytes[4]) - 1);
        instance.set(Calendar.YEAR, this.calc(bytes[5]) + 2000);
        return instance.getTime();
    }

    private int calc(byte b) {
        return (b & 0b0000_1111) + (((b & 0b1111_0000) >> 4) * 10);
    }
}

package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.WaterQualityParameter_Enum;
import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import com.zhy.plugin.szy206.business.SZY206.model.parameter.WaterQualityParameter;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.SneakyThrows;
import org.apache.commons.lang3.tuple.Pair;

import java.util.*;

/**
 * @Since 2023/10/8
 * @Author：houDeJian
 * @Record：B1-查询遥测终端固态存储数据(响应帧)
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQuerySolidStateData_B1H extends ApplicationSpaceUplink {
    /**
     * startTime:开始时间
     * endTime:结束时间
     */
    HashMap<String, Date> queryData = new HashMap<>();
    /**
     * 可查参数编号
     * 0—雨量；
     * 1 —水位；
     * 2—流量（水量）；
     * 3—流速；
     * 4—闸位；
     * 5—功率；
     * 6—气压；
     * 7—风速（风向）；
     * 8—水温；
     * 9—水质；
     * 10—土壤含水率；
     * 11—水压；
     */
    int mum = 0;


    /**
     * 雨量结果
     */
    Double[] rain;

    /**
     * 水位结果
     */
    Double[] waterLevels;

    /**
     * 流量(水量) 左流量 右水量
     */
    Pair<Double, Double>[] flowAndWaters;

    /**
     * 流速
     */
    Double[] flowSpeeds;

    /**
     * 闸位
     */
    Double[] gateLevels;

    /**
     * 功率
     */
    Double[] powers;

    /**
     * 气压
     */
    Double[] pressure;

    /**
     * 风速、风向 0-8
     */
    List<Pair<Double, Double>> windSpeedAndDirectionList;

    /**
     * 水温
     */
    Double[] waterTemperature;
    /**
     * 水质参数
     */
    List<WaterQualityParameter> waterQualityParameterList;

    /**
     * 土壤含水率
     */
    Double[] soilWater;


    /**
     * 水压
     */
    Double[] waterPressures;


    @SneakyThrows
    @Override
    public void decode() {
        //功能码
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        this.applicationFunctionCode = buffer.readByte();
        //开始时间
        byte _HOUR = buffer.readByte();
        byte _DAY = buffer.readByte();
        byte _MONTH = buffer.readByte();
        byte _YEAR = buffer.readByte();
        int hour = ((_HOUR >> 4) * 10) + (_HOUR & 0b0000_1111);
        int day = ((_DAY >> 4) * 10) + (_DAY & 0b0000_1111);
        int month = ((_MONTH >> 4) * 10) + (_MONTH & 0b0000_1111)-1;
        int year = ((_YEAR >> 4) * 10) + (_YEAR & 0b0000_1111) + 2000;
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.HOUR_OF_DAY, hour);
        instance.set(Calendar.DAY_OF_MONTH, day);
        instance.set(Calendar.MONTH, month);
        instance.set(Calendar.YEAR, year);
        Date startTime = instance.getTime();
        queryData.put("startTime", startTime);

        //结束时间
        byte _HOUR1 = buffer.readByte();
        byte _DAY1 = buffer.readByte();
        byte _MONTH1 = buffer.readByte();
        byte _YEAR1 = buffer.readByte();
        int hour1 = ((_HOUR1 >> 4) * 10) + (_HOUR1 & 0b0000_1111);
        int day1 = ((_DAY1 >> 4) * 10) + (_DAY1 & 0b0000_1111);
        int month1 = ((_MONTH1 >> 4) * 10) + (_MONTH1 & 0b0000_1111)+1;
        int year1 = ((_YEAR1 >> 4) * 10) + (_YEAR1 & 0b0000_1111) + 2000;
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.HOUR_OF_DAY, hour1);
        instance1.set(Calendar.DAY_OF_MONTH, day1);
        instance1.set(Calendar.MONTH, month1);
        instance1.set(Calendar.YEAR, year1);
        Date endTime = instance1.getTime();
        queryData.put("endTime", endTime);

        //可查参数编号
        byte code = buffer.readByte();
        mum = code;
        int n = buffer.readableBytes();
        // 所查询的数据
        switch (mum) {
            case 0://雨量
                rain = getRain(buffer, n);
                break;
            case 1://水位
                waterLevels = getWaterLevels(n, buffer);
                break;
            case 2://流量（水量）
                flowAndWaters = getFlowAndWaters(n, buffer);
                break;
            case 3://流速
                flowSpeeds = getFlowSpeeds(n, buffer);
                break;
            case 4:
                // 闸位
                gateLevels = getGateLevels(n, buffer);
                break;
            case 5:// 功率
                powers = getPowers(n, buffer);
                break;
            case 6:// 气压
                pressure = getPressure(n,buffer);
                break;
            case 7:
                // 风速风向
                 windSpeedAndDirectionList= getWindSpeedAndDirection(n,buffer);
                break;
            case 8:// 水温
                waterTemperature = getWaterTemperature(n,buffer);
                break;
            case 9:// 水质
                waterQualityParameterList = getWaterQuality(n,buffer);
                break;
            case 10:// 土壤含水率
                soilWater = getSoilWater(n,buffer);
                break;
            case 11:// 水压
                waterPressures = getWaterPressures(n, buffer);
                break;

        }


    }


    private Double getVoltage(ByteBuf buffer) {
        byte[] voltageBytes = new byte[2];
        buffer.readBytes(voltageBytes);
        return ((voltageBytes[0] & 0b0000_1111) * 0.01d) // 小数后2位
                + (((voltageBytes[0] & 0b1111_0000) >> 4) * 0.01d) // 小数后1位
                + ((voltageBytes[1] & 0b0000_1111)) // 个位
                + (((voltageBytes[1] & 0b1111_0000) >> 4) * 10); // 十位
    }

    private Double[] getWaterPressures(int readable, ByteBuf buffer) {
        // 水压设备数
        int n = readable / 4;
        Double[] waterPressures = new Double[n];
        byte[] waterPressureBytes = new byte[4];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(waterPressureBytes);
            double waterPressure = (waterPressureBytes[0] & 0b0000_1111) * 0.01 // 小数点后2位
                    + ((waterPressureBytes[0] & 0b1111_0000) >> 4) * 0.1 // 小数点后1位
                    + (waterPressureBytes[1] & 0b0000_1111) // 个位
                    + ((waterPressureBytes[1] & 0b1111_0000) >> 4) * 10 // 十位
                    + (waterPressureBytes[2] & 0b0000_1111) * 100 // 百位
                    + ((waterPressureBytes[2] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (waterPressureBytes[3] & 0b0000_1111) * 10000 // 万位
                    + ((waterPressureBytes[3] & 0b1111_0000) >> 4) * 10_0000; // 十万位
            waterPressures[i] = waterPressure;
        }
        return waterPressures;
    }



    private Double[] getSoilWater(int readable,ByteBuf buffer) {
        int n=readable/2;
        Double[] soilWaters=new Double[n];
        for (int i = 0; i < n; i++) {
            byte[] soilWaterBytes = new byte[2];
            buffer.readBytes(soilWaterBytes);
            Double  soilWater=(soilWaterBytes[0] & 0b0000_1111) * 0.1 // 小数点后1位
                    + ((soilWaterBytes[0] & 0b1111_0000) >> 4) // 个位
                    + (soilWaterBytes[1] & 0b0000_1111) * 10 // 十位
                    + ((soilWaterBytes[1] & 0b1111_0000) >> 4) * 100; // 百位
            soilWaters[i]=soilWater;
        }

        return soilWaters;
    }

    private List<WaterQualityParameter> getWaterQuality(int readable,ByteBuf buffer) throws NoSuchFieldException, IllegalAccessException {
        List<WaterQualityParameter> waterQualityList=new ArrayList<>();
        int n=0;
        while (readable>0){
            byte[] parameter = new byte[5];
            WaterQualityParameter waterQualityParameter = new WaterQualityParameter();
            buffer.readBytes(parameter);
            // 怎么判断一个字节的八位中那些不为0
            for (int y = 0; y < 5; y++) {
                for (int i = 0; i <= 7; i++) {
                    byte mask = (byte) (1 << i);
                    if ((parameter[y] & mask) != 0) {
                        // 拼接水质元素名字
                        String parameterName = "D" + (8 * y + i);
                        if (8 * y + i == 24) {
                            byte _byte1 = buffer.readByte();
                            byte _byte2 = buffer.readByte();
                            byte _byte3 = buffer.readByte();
                            byte _byte4 = buffer.readByte();
                            byte _byte5 = buffer.readByte();
                            int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                            int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                            int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                            int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                            int byte5 = ((_byte5 >> 4 & 0x0F) * 10) + (_byte5 & 0x0F);
                            Double value = (double) (byte5 * 100000000 + byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                            waterQualityParameter.setParameterValue(parameterName, value);
                        } else if (8 * y + i == 4) {
                            byte _byte1 = buffer.readByte();
                            byte _byte2 = buffer.readByte();
                            byte _byte3 = buffer.readByte();
                            byte _byte4 = buffer.readByte();
                            int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                            int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                            int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                            int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                            Double value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1);
                            waterQualityParameter.setParameterValue(parameterName, value);
                        } else {
                            byte _byte1 = buffer.readByte();
                            byte _byte2 = buffer.readByte();
                            byte _byte3 = buffer.readByte();
                            byte _byte4 = buffer.readByte();
                            int byte1 = ((_byte1 >> 4 & 0x0F) * 10) + (_byte1 & 0x0F);
                            int byte2 = ((_byte2 >> 4 & 0x0F) * 10) + (_byte2 & 0x0F);
                            int byte3 = ((_byte3 >> 4 & 0x0F) * 10) + (_byte3 & 0x0F);
                            int byte4 = ((_byte4 >> 4 & 0x0F) * 10) + (_byte4 & 0x0F);
                            Integer decimalPlaces = WaterQualityParameter_Enum.getRight(parameterName);
                            double result = Math.pow(0.1, decimalPlaces);
                            Double value = (double) (byte4 * 1000000 + byte3 * 10000 + byte2 * 100 + byte1) * result;
                            waterQualityParameter.setParameterValue(parameterName, value);
                        }
                        System.out.println("D" + (8 * y + i) + " 不为0");

                    }
                }
            }
            waterQualityList.add(waterQualityParameter);
        }

        return waterQualityList;
    }

    private Double[] getWaterTemperature(int readable,ByteBuf buffer) {
        int n=readable/2;
        Double[] waterTemperatures = new Double[n];
        for (int i = 0; i < n; i++) {
            byte[] waterTemperatureBytes = new byte[2];
            buffer.readBytes(waterTemperatureBytes);
            double waterTemperature =(waterTemperatureBytes[0] & 0b0000_1111) * 0.1 // 小数点后1位
                    + ((waterTemperatureBytes[0] & 0b1111_0000) >> 4) // 个位
                    + (waterTemperatureBytes[1] & 0b0000_1111) * 10;//十位
            waterTemperatures[i]=waterTemperature;
        }

        return waterTemperatures;
    }

    private List<Pair<Double, Double>> getWindSpeedAndDirection(int readable,ByteBuf buffer) {

        int n=readable/3;
        ArrayList<Pair<Double, Double>> windSpeedAndDirectionList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            byte[] windBytes = new byte[3];
            buffer.readBytes(windBytes);
            double windSpeed = (windBytes[0] & 0b0000_1111) * 0.01 // 小数点后2位
                    + ((windBytes[0] & 0b1111_0000) >> 4) * 0.1 // 小数点后1位
                    + (windBytes[1] & 0b0000_1111) // 个位
                    + ((windBytes[1] & 0b1111_0000) >> 4) * 10 // 十位
                    + (windBytes[2] & 0b0000_1111) * 100; // 百位
            double windDirection = (windBytes[2] & 0b1111_0000);

            windSpeedAndDirectionList.add(Pair.of(windSpeed, windDirection));
        }

        return windSpeedAndDirectionList;
    }

    private Double[] getPressure(int readable, ByteBuf buffer) {
        int n = readable / 3;
        Double[] pressures = new Double[n];
        for (int i = 0; i < n; i++) {
            byte[] pressureBytes = new byte[3];
            buffer.readBytes(pressureBytes);
            Double pressure = (Double)(double)(pressureBytes[0] & 0b0000_1111) // 个位
                    + ((pressureBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                    + (pressureBytes[1] & 0b0000_1111) * 100 // 百位
                    + ((pressureBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (pressureBytes[2] & 0b0000_1111) * 1_0000;
            pressures[i]=pressure;
        }

        return   pressures;
    }

    private Double[] getPowers(int readable, ByteBuf buffer) {
        // 功率仪表数量
        int n = readable / 3;
        Double[] powers = new Double[n];
        byte[] powerBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(powerBytes);
            double power = (powerBytes[0] & 0b0000_1111) // 个位
                    + ((powerBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                    + (powerBytes[1] & 0b0000_1111) * 100 // 百位
                    + ((powerBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (powerBytes[2] & 0b0000_1111) * 1_0000 // 万位
                    + ((powerBytes[2] & 0b1111_0000) >> 4) * 10_0000; // 十万位
            powers[i] = power;
        }
        return powers;
    }

    private Double[] getGateLevels(int readable, ByteBuf buffer) {
        // 闸位仪表数量
        int n = readable / 3;
        Double[] gateLevels = new Double[n];
        byte[] gateLevelBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(gateLevelBytes);
            double gateLevel = (gateLevelBytes[0] & 0b0000_1111) * 0.01 // 厘米位
                    + ((gateLevelBytes[0] & 0b1111_0000) >> 4) * 0.1 // 分米位
                    + (gateLevelBytes[1] & 0b0000_1111) // 米位
                    + ((gateLevelBytes[1] & 0b1111_0000) >> 4) * 10 // 十米位
                    + (gateLevelBytes[2] & 0b0000_1111) * 100; // 百米位
            gateLevels[i] = gateLevel;
        }
        return gateLevels;
    }

    private Double[] getFlowSpeeds(int readable, ByteBuf buffer) {
        // 流速仪表数量
        int n = readable / 3;
        Double[] flowSpeeds = new Double[n];
        byte[] flowSpeedBytes = new byte[3];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(flowSpeedBytes);
            double flowSpeed = (flowSpeedBytes[0] & 0b0000_1111) * 0.001 // 小数点后3位
                    + ((flowSpeedBytes[0] & 0b1111_0000) >> 4) * 0.01 // 小数点后2位
                    + (flowSpeedBytes[1] & 0b0000_1111) * 0.1 // 小数点后1位
                    + ((flowSpeedBytes[1] & 0b1111_0000) >> 4) // 个位
                    + (flowSpeedBytes[2] & 0b0000_1111) * 10; // 十位
            flowSpeed *= ((flowSpeedBytes[2] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            flowSpeeds[i] = flowSpeed;
        }
        return flowSpeeds;
    }

    private Pair<Double, Double>[] getFlowAndWaters(int readable, ByteBuf buffer) {
        // 流量(水量)仪表数量
        int n = readable / (5 * 2);
        Pair[] flowAndWaters = new Pair[n];
        byte[] flowAndWaterBytes = new byte[5];
        for (int i = 0; i < n; i++) {
            double flow, water;
            // 流量
            buffer.readBytes(flowAndWaterBytes);
            flow = (flowAndWaterBytes[0] & 0b0000_1111) * 0.001d // 小数点后3
                    + ((flowAndWaterBytes[0] & 0b1111_0000) >> 4) * 0.01d // 小数点后2
                    + (flowAndWaterBytes[1] & 0b0000_1111) * 0.1d // 小数点后1
                    + ((flowAndWaterBytes[1] & 0b1111_0000) >> 4) // 个位
                    + (flowAndWaterBytes[2] & 0b0000_1111) * 10 // 十位
                    + ((flowAndWaterBytes[2] & 0b1111_0000) >> 4) * 100 // 百位
                    + (flowAndWaterBytes[3] & 0b0000_1111) * 1000 // 千位
                    + ((flowAndWaterBytes[3] & 0b1111_0000) >> 4) * 1_0000 // 万位
                    + (flowAndWaterBytes[4] & 0b0000_1111) * 10_0000; // 十万位
            flow *= ((flowAndWaterBytes[4] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            // 水量
            buffer.readBytes(flowAndWaterBytes);
            water = (flowAndWaterBytes[0] & 0b0000_1111) // 个位
                    + ((flowAndWaterBytes[0] & 0b1111_0000) >> 4) * 10 // 十位
                    + (flowAndWaterBytes[1] & 0b0000_1111) * 100 // 百位
                    + ((flowAndWaterBytes[1] & 0b1111_0000) >> 4) * 1000 // 千位
                    + (flowAndWaterBytes[2] & 0b0000_1111) * 1_0000 // 万位
                    + ((flowAndWaterBytes[2] & 0b1111_0000) >> 4) * 10_0000 // 十万位
                    + (flowAndWaterBytes[3] & 0b0000_1111) * 10_0000 // 百万位
                    + ((flowAndWaterBytes[3] & 0b1111_0000) >> 4) * 1000_0000 // 千万位
                    + (flowAndWaterBytes[4] & 0b0000_1111) * 10000_0000 // 万万位
                    + ((flowAndWaterBytes[4] & 0b1111_0000) >> 4) * 10_000_0000; // 十万万位
            flowAndWaters[i] = Pair.of(flow, water);
        }
        return flowAndWaters;
    }

    private Double[] getWaterLevels(int readable, ByteBuf buffer) {
        // 水位仪表个数
        int n = readable / 4;
        Double[] waterLevels = new Double[n];
        byte[] waterLevelBytes = new byte[4];
        for (int i = 0; i < n; i++) {
            buffer.readBytes(waterLevelBytes);
            double waterLevel;
            waterLevel = (waterLevelBytes[0] & 0b0000_1111) * 0.001d // 毫米位
                    + ((waterLevelBytes[0] & 0b1111_0000) >> 4) * 0.01d // 厘米位
                    + (waterLevelBytes[1] & 0b0000_1111) * 0.1d // 分米位
                    + ((waterLevelBytes[1] & 0b1111_0000) >> 4) // 米位
                    + (waterLevelBytes[2] & 0b0000_1111) * 10 // 十米位
                    + ((waterLevelBytes[2] & 0b1111_0000) >> 4) * 100 // 百米位
                    + (waterLevelBytes[3] & 0b0000_1111) * 1000; // 千米位
            waterLevel *= ((waterLevelBytes[3] & 0b1111_0000) >> 4) == 0 ? 1 : -1; // 正负位
            waterLevels[i] = waterLevel;
        }
        return waterLevels;
    }

    private Double[] getRain(ByteBuf buffer,int n) {
        Double[] aDouble = new Double[n/3];
        for (int i = 0; i < (n/3); i++) {
            byte[] rainBytes = new byte[3];
            buffer.readBytes(rainBytes);
            double v = ((rainBytes[0] & 0b0000_1111) * 0.1d) // 小数位
                    + ((rainBytes[0] & 0b1111_0000) >> 4) // 个位
                    + ((rainBytes[1] & 0b0000_1111) * 10) // 十位
                    + (((rainBytes[1] & 0b1111_0000) >> 4) * 100) // 百位
                    + ((rainBytes[2] & 0b0000_1111) * 1000) // 千位
                    + (((rainBytes[2] & 0b1111_0000) >> 4) * 10000);
            aDouble[i]=v;
        }
        return aDouble;
    }
}

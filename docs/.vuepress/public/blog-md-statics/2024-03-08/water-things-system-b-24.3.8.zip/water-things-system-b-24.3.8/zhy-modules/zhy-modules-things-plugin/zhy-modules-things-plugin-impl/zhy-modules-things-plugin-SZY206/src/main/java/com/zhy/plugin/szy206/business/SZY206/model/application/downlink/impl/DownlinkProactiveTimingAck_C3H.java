package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Calendar;
import java.util.Date;

/**
 * 03H 遥测站主动校时 回复报文 （山东）
 *
 * @author wangfeng
 * @since 2023-10-05 15:20
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkProactiveTimingAck_C3H extends ApplicationSpaceDownlink {

    {
        this.applicationFunctionCode = AFN._C3.getFNCByte();
    }

    /**
     * 校时报文中携带的时间
     */
    Date date = new Date();

    @Override
    public byte[] encode() {
        Calendar instance = Calendar.getInstance();
        instance.setTime(this.date);

        return new byte[]{
                this.applicationFunctionCode,
                this.calc(instance.get(Calendar.SECOND)),
                this.calc(instance.get(Calendar.MINUTE)),
                this.calc(instance.get(Calendar.HOUR_OF_DAY)),
                this.calc(instance.get(Calendar.DAY_OF_MONTH)),
                this.calc(instance.get(Calendar.MONTH) + 1),
                this.calc(instance.get(Calendar.YEAR) - 2000)
        };
    }

    public byte calc(int i) {
        return (byte) (((0b0000_1111 & (i / 10)) << 4) | (0b0000_1111 & (i % 10)));
    }

}

package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkAverage;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * 处理均匀时段水文信息报
 * @author wangfeng
 * @since 2023-07-05 09:16
 */
@Slf4j
@Component
public class AverageFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkAverage> {

    @Override
    public String getFunctionCode() {
        return AppendixB._31.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("均匀时段水文信息报visitor");
        MessageContentUplinkAverage content = getContent(frame);
        System.out.println("均匀时段雨量数据："+ Arrays.toString(content.getRainData()));
        System.out.println("均匀时段水位数据："+ Arrays.toString(content.getWaterLevelData()));
    }
}

package com.zhy.plugin.szy206.business.SZY206.db;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 已连接过的遥测站（206）
 * @author wangfeng
 * @since 2023-09-25 16:37
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FamiliarStation206 {

    private String stationId;

    private String password;

}

package com.zhy.plugin.szy206.business.SZY206.model.application.downlink.impl;

import cn.hutool.core.util.ArrayUtil;
import com.zhy.plugin.szy206.business.SZY206.constants.AFN;
import com.zhy.plugin.szy206.business.SZY206.model.application.downlink.ApplicationSpaceDownlink;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Author：houDeJian
 * @Record：30H-取消遥测终端IC卡功能有效
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DownlinkSetICDisable_31H extends ApplicationSpaceDownlink {
    {
        this.applicationFunctionCode= AFN._31.getFNCByte();
    }

    @Override
    public byte[] encode() {
        return ArrayUtil.addAll(new byte[]{applicationFunctionCode}, this.aux.encode());
    }
}

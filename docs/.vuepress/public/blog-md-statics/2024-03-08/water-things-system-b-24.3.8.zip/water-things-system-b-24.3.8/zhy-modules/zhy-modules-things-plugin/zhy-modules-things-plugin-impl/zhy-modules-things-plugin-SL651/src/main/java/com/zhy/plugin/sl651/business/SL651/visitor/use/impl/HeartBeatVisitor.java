package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import cn.hutool.core.date.DateUtil;
import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkHeartBeat;
import com.zhy.plugin.sl651.business.SL651.utils.ElementParseUtil;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 处理链路维持报
 * @author wangfeng
 * @since 2023-07-31 16:16
 */
@Slf4j
@Component
public class HeartBeatVisitor  implements MessageFrameUseVisitor<MessageContentUplinkHeartBeat> {
    @Override
    public String getFunctionCode() {
        return AppendixB._2F.getHEX();
    }

    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("链路维持报visitor: {}",
                DateUtil.formatDateTime(ElementParseUtil.parseMessageTime(getContent(frame).getMessageTime())));
    }
}

package com.zhy.plugin.sl651.business.SL651.visitor.use.impl;

import com.zhy.things.common.constants.ValueType;
import com.zhy.plugin.core.entity.domain.plugin.PluginMessage;
import com.zhy.plugin.core.support.PluginContext;
import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixB;
import com.zhy.plugin.sl651.business.SL651.constants.SL651_2014.AppendixC;
import com.zhy.plugin.sl651.business.SL651.model.entity.MessageFrame;
import com.zhy.plugin.sl651.business.SL651.model.entity.content.uplink.impl.MessageContentUplinkPlus;
import com.zhy.plugin.sl651.business.SL651.visitor.use.MessageFrameUseVisitor;
import io.netty.channel.ChannelHandlerContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;

/**
 * 处理加报报
 */
@Slf4j
@Component
public class PlusFrameVisitor implements MessageFrameUseVisitor<MessageContentUplinkPlus> {
    @Override
    public String getFunctionCode() {
        return AppendixB._33.getHEX();
    }
    @Override
    public void visit(ChannelHandlerContext ctx, MessageFrame frame) {
        log.info("加报报visitor");
        MessageContentUplinkPlus messageContentUplinkPlus = getContent(frame);
        Map<String, Double> doubleElements = messageContentUplinkPlus.getAnalyticValue();
        Date collectTime = messageContentUplinkPlus.getCollectTimeParse();
        String stcd = frame.getTelemetricStationParse();

        // 获取瞬时水温
        this.getAndNotNullAndProduce(doubleElements, AppendixC._03.getHEX(), ValueType.WATER_TEMPERATURE, stcd, collectTime);
        // 获取瞬时气压
        this.getAndNotNullAndProduce(doubleElements, AppendixC._08.getHEX(), ValueType.AIR_PRESSURE, stcd, collectTime);
        // 获取当前降雨量
        this.getAndNotNullAndProduce(doubleElements, AppendixC._20.getHEX(), ValueType.RAIN_IN_NOW, stcd, collectTime);
        // 获取瞬时流量、抽水流量
        this.getAndNotNullAndProduce(doubleElements, AppendixC._27.getHEX(), ValueType.WATER_FLOW, stcd, collectTime);
        // 获取瞬时风力
        this.getAndNotNullAndProduce(doubleElements, AppendixC._34.getHEX(), ValueType.WIND_LEVEL, stcd, collectTime);
        // 获取瞬时风速
        this.getAndNotNullAndProduce(doubleElements, AppendixC._35.getHEX(), ValueType.WIND_SPEED, stcd, collectTime);
        // 获取断面平均流速
        this.getAndNotNullAndProduce(doubleElements, AppendixC._36.getHEX(), ValueType.WATER_SECTIONAL_SPEED_AVERAGE, stcd, collectTime);
        // 获取当前瞬时流速
        this.getAndNotNullAndProduce(doubleElements, AppendixC._37.getHEX(), ValueType.WATER_SPEED_NOW, stcd, collectTime);
        // 获取当前电源电压
        this.getAndNotNullAndProduce(doubleElements, AppendixC._38.getHEX(), ValueType.SUPPLY_VOLTAGE, stcd, collectTime);
        // 获取瞬时水位、潮位
        this.getAndNotNullAndProduce(doubleElements, AppendixC._39.getHEX(), ValueType.WATER_LEVEL, stcd, collectTime);
        // 获取PH值
        this.getAndNotNullAndProduce(doubleElements, AppendixC._46.getHEX(), ValueType.WATER_QUALITY_PH, stcd, collectTime);
        // 获取溶解氧
        this.getAndNotNullAndProduce(doubleElements, AppendixC._47.getHEX(), ValueType.WATER_QUALITY_DOC, stcd, collectTime);
        // 获取电导率
        this.getAndNotNullAndProduce(doubleElements, AppendixC._48.getHEX(), ValueType.WATER_QUALITY_COND, stcd, collectTime);
        // 获取浊度
        this.getAndNotNullAndProduce(doubleElements, AppendixC._49.getHEX(), ValueType.WATER_QUALITY_TURB, stcd, collectTime);
        // 获取氨氮
        this.getAndNotNullAndProduce(doubleElements, AppendixC._4C.getHEX(), ValueType.WATER_QUALITY_NH4N, stcd, collectTime);
        // 获取总磷
        this.getAndNotNullAndProduce(doubleElements, AppendixC._4D.getHEX(), ValueType.WATER_QUALITY_TP, stcd, collectTime);
        // 获取水压1
        this.getAndNotNullAndProduce(doubleElements, AppendixC._58.getHEX(), ValueType.WATER_PRESSURE_1, stcd, collectTime);
        // 获取水压2
        this.getAndNotNullAndProduce(doubleElements, AppendixC._59.getHEX(), ValueType.WATER_PRESSURE_2, stcd, collectTime);
        // 获取水压3
        this.getAndNotNullAndProduce(doubleElements, AppendixC._5A.getHEX(), ValueType.WATER_PRESSURE_3, stcd, collectTime);
        // 获取水压4
        this.getAndNotNullAndProduce(doubleElements, AppendixC._5B.getHEX(), ValueType.WATER_PRESSURE_4, stcd, collectTime);
        // 获取水压5
        this.getAndNotNullAndProduce(doubleElements, AppendixC._5C.getHEX(), ValueType.WATER_PRESSURE_5, stcd, collectTime);
        // 获取水压6
        this.getAndNotNullAndProduce(doubleElements, AppendixC._5D.getHEX(), ValueType.WATER_PRESSURE_6, stcd, collectTime);
        // 获取水压7
        this.getAndNotNullAndProduce(doubleElements, AppendixC._5E.getHEX(), ValueType.WATER_PRESSURE_7, stcd, collectTime);
        // 获取水压8
        this.getAndNotNullAndProduce(doubleElements, AppendixC._5F.getHEX(), ValueType.WATER_PRESSURE_8, stcd, collectTime);


    }
    private void getAndNotNullAndProduce(Map<String, Double> elements, String hex, ValueType valueType, String stcd, Date collectTime) {
        Double a = elements.get(hex);
        if (ObjectUtils.isNotEmpty(a)) {
            PluginContext.produceMessage(PluginMessage.of(stcd, collectTime, valueType, a));
        }
    }
}

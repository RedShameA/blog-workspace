package com.zhy.things.web.controller;

import com.zhy.common.core.controller.BaseController;
import com.zhy.common.core.domain.AjaxResult;
import com.zhy.plugin.core.entity.domain.device.ThingsDevice;
import com.zhy.plugin.core.entity.domain.product.ThingsProduct;
import com.zhy.plugin.core.entity.dto.ThingsDeviceDto;
import com.zhy.plugin.store.DeviceStatusStore;
import com.zhy.things.web.service.IThingsDeviceService;
import com.zhy.things.web.service.IThingsProductService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author wangfeng
 * @since 2023-11-24 14:46
 */
@RestController
@RequestMapping("/things/device/rule")
public class ThingsDeviceForRuleController extends BaseController {

    @Resource
    private IThingsDeviceService thingsDeviceService;
    @Resource
    private IThingsProductService thingsProductService;



    /**
     * [规则引擎使用]查询所有product列表
     */
    @PreAuthorize("@ss.hasPermi('things:product:list')")
    @GetMapping("/product/list")
    public AjaxResult listAll(){
        return success(thingsProductService.selectThingsProductList(new ThingsProduct()));
    }
    /**
     * [规则引擎使用]查询指定产品id的device列表
     */
    @PreAuthorize("@ss.hasPermi('things:device:list')")
    @GetMapping("/device/list")
    public AjaxResult listAll(String productId){
        ThingsDeviceDto thingsDeviceDto = new ThingsDeviceDto();
        thingsDeviceDto.setProductId(productId);
        return success(thingsDeviceService.selectThingsDeviceList(thingsDeviceDto));
    }

    /**
     * [规则引擎使用]查询设备或产品的所有属性
     */
    @PreAuthorize("@ss.hasPermi('things:device:list')")
    @GetMapping("/property/list")
    public AjaxResult listProperties(String productId, String deviceId){
        if (StringUtils.isNoneBlank(deviceId)){
            return success(DeviceStatusStore.getAllProperties(deviceId));
        }
        if (StringUtils.isNoneBlank(productId)){
            return success(thingsProductService.getAllPropertiesById(productId));
        }
        return error("请选择产品或者设备");
    }
}

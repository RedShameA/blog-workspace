package com.zhy.plugin.szy206.business.SZY206.model.application.uplink.impl;

import com.zhy.plugin.szy206.business.SZY206.model.application.uplink.ApplicationSpaceUplink;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Calendar;
import java.util.Date;

/**
 * @since 2023/10/08
 * @author: 周志浩
 * @Record: B2H查询终端内存自报数据
 * <p>
 * 收到此回复上行帧表示时间段内没有未发送成功的数据
 * </p>
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UplinkQueryTerminalMemorySelfReportedData_B2H extends ApplicationSpaceUplink {

    /**
     * 起止时间
     * Pair: 左为起，右为止
     */
    Pair<Date,Date> queryDate;

    @Override
    public void decode() {
        ByteBuf buffer = Unpooled.wrappedBuffer(content);
        this.applicationFunctionCode = buffer.readByte();
        // 开始时间
        byte _MINUTE = buffer.readByte();
        byte _HOUR = buffer.readByte();
        byte _DAY = buffer.readByte();
        byte _MONTH = buffer.readByte();

        int minute = ((_MINUTE >> 4) * 10) + (_MINUTE & 0b0000_1111);
        int hour = ((_HOUR >> 4) * 10) + (_HOUR & 0b0000_1111);
        int day = ((_DAY >> 4) * 10) + (_DAY & 0b0000_1111);
        int month = ((_MONTH >> 4) * 10) + (_MONTH & 0b0000_1111);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.MILLISECOND, 0);
        instance.set(Calendar.SECOND, 0);
        instance.set(Calendar.MINUTE, minute);
        instance.set(Calendar.HOUR_OF_DAY, hour);
        instance.set(Calendar.DAY_OF_MONTH, day);
        instance.set(Calendar.MONTH, month - 1);
        Date startTime = instance.getTime();

        // 结束时间
        byte _MINUTE1 = buffer.readByte();
        byte _HOUR1 = buffer.readByte();
        byte _DAY1 = buffer.readByte();
        byte _MONTH1 = buffer.readByte();
        int minute1 = ((_MINUTE1 >> 4) * 10) + (_MINUTE1 & 0b0000_1111);
        int hour1 = ((_HOUR1 >> 4) * 10) + (_HOUR1 & 0b0000_1111);
        int day1 = ((_DAY1 >> 4) * 10) + (_DAY1 & 0b0000_1111);
        int month1 = ((_MONTH1 >> 4) * 10) + (_MONTH1 & 0b0000_1111);
        Calendar instance1 = Calendar.getInstance();
        instance.set(Calendar.MILLISECOND, 0);
        instance.set(Calendar.SECOND, 0);
        instance1.set(Calendar.MINUTE, minute1);
        instance1.set(Calendar.HOUR_OF_DAY, hour1);
        instance1.set(Calendar.DAY_OF_MONTH, day1);
        instance1.set(Calendar.MONTH, month1 - 1);
        Date endTime = instance1.getTime();
        queryDate = Pair.of(startTime,endTime);

    }
}

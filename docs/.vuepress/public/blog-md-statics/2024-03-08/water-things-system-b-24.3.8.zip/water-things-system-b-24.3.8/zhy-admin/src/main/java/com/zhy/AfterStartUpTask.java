package com.zhy;

import com.alibaba.fastjson2.JSONObject;
import com.zhy.common.things.domain.StandardMessage;
import com.zhy.common.things.domain.ThingsDataHis;
import com.zhy.converter.StandardTableConverter;
import com.zhy.plugin.store.DeviceMessageStore;
import com.zhy.ruleEngine.service.engine.RuleVerificationService;
import com.zhy.things.common.constants.StationType;
import com.zhy.things.common.constants.ValueType;
import com.zhy.things.data.service.ThingsDataHisService;
import com.zhy.things.ws.util.WebsocketSessionUtil;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Date;
import java.util.Set;

/**
 * @author wangfeng
 * @since 2023-12-12 18:00
 */
@Component
public class AfterStartUpTask {
    @Resource
    private RuleVerificationService ruleVerificationService;
    @Resource
    private ThingsDataHisService thingsDataHisService;

    /**
     * 添加设备消息需要转发到的方法
     */
    @PostConstruct
    public void task() {
        // 提供消息给规则引擎
        DeviceMessageStore.addMessageConsumer((Set<StationType> stationTypes, ValueType valueType, StandardMessage standardMessage) -> {
            ruleVerificationService.ruleVerification(standardMessage.clone());
        });
        // 提供消息给标准表保存工具
        DeviceMessageStore.addMessageConsumer((Set<StationType> stationTypes, ValueType valueType, StandardMessage standardMessage) -> {
            stationTypes.forEach(stationType -> gatewayToStandardTableSaver(stationType, valueType, standardMessage.clone()));
        });
        // 提供消息给物管历史表保存工具
        DeviceMessageStore.addMessageConsumer((Set<StationType> stationTypes, ValueType valueType, StandardMessage standardMessage) -> {
            gatewayToThingsTableSaver(standardMessage.clone());
        });
        // 提供给ws
        DeviceMessageStore.addMessageConsumer((Set<StationType> stationTypes, ValueType valueType, StandardMessage standardMessage) -> {
            gatewayToWs(standardMessage.clone(), valueType);
        });
    }

    // 标准表
    private void gatewayToStandardTableSaver(StationType stationType, ValueType valueType, StandardMessage standardMessage) {
        // 处理设备id，只取后8位
        int length = standardMessage.getDeviceId().length();
        if (length > 8) {
            int numChars = 8; // 要截取的位数
            int startIndex = length - numChars;
            standardMessage.setDeviceId(standardMessage.getDeviceId().substring(startIndex));
        }
        StandardTableConverter.handle(stationType, valueType, standardMessage);
    }

    // 物管历史表
    private void gatewayToThingsTableSaver(StandardMessage standardMessage) {
        ThingsDataHis thingsDataHis = new ThingsDataHis();
        thingsDataHis.setProductName(standardMessage.getProductName());
        thingsDataHis.setProductId(standardMessage.getProductId());
        thingsDataHis.setDeviceName(standardMessage.getDeviceName());
        thingsDataHis.setDeviceId(standardMessage.getDeviceId());
        thingsDataHis.setPropertyName(standardMessage.getPropertyName());
        thingsDataHis.setPropertyId(standardMessage.getPropertyId());
        thingsDataHis.setValue(standardMessage.getMessageValue());
        thingsDataHis.setValueTime(standardMessage.getMessageTime());
        thingsDataHis.setCreateTime(new Date());
        thingsDataHisService.insertThingsDataHis(thingsDataHis);
    }

    // ws
    private void gatewayToWs(StandardMessage standardMessage, ValueType valueType) {
        JSONObject json = new JSONObject();
        json.put("valueType", valueType.getType());
        json.put("deviceId", standardMessage.getDeviceId());
        json.put("messageValue", standardMessage.getMessageValue());
        json.put("messageTime", standardMessage.getMessageTime());
        WebsocketSessionUtil.send(json.toJSONString());
    }
}

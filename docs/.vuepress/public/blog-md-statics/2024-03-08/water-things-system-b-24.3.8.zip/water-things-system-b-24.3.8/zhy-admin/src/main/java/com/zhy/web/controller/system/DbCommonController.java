package com.zhy.web.controller.system;

import com.zhy.common.core.domain.AjaxResult;
import com.zhy.system.service.ICommonService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author yulei
 */
@RestController
@RequestMapping("/common")
public class DbCommonController {
    @Resource
    ICommonService commonService;

    @GetMapping("/dbInfo")
    public AjaxResult getDatabaseInfo() {
        return AjaxResult.success(commonService.getDatabaseInfo());
    }
}

package com.zhy.web.controller.system;

import com.zhy.common.constant.Constants;
import com.zhy.common.core.domain.AjaxResult;
import com.zhy.common.core.domain.entity.SysMenu;
import com.zhy.common.core.domain.entity.SysUser;
import com.zhy.common.core.domain.model.LoginBody;
import com.zhy.common.exception.ServiceException;
import com.zhy.common.utils.SecurityUtils;
import com.zhy.common.utils.sign.RsaUtils;
import com.zhy.common.utils.uuid.IdUtils;
import com.zhy.framework.security.oauth.CustomAuthRequest;
import com.zhy.framework.security.oauth.CustomAuthSourceBean;
import com.zhy.framework.web.service.SysLoginService;
import com.zhy.framework.web.service.SysPermissionService;
import com.zhy.system.service.ISysMenuService;
import lombok.extern.slf4j.Slf4j;
import me.zhyd.oauth.config.AuthConfig;
import me.zhyd.oauth.model.AuthCallback;
import me.zhyd.oauth.model.AuthResponse;
import me.zhyd.oauth.model.AuthUser;
import me.zhyd.oauth.request.AuthRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * 登录验证
 *
 * @author zhy
 */
@Slf4j
@RestController
public class SysLoginController {
    @Resource
    private SysLoginService loginService;

    @Resource
    private ISysMenuService menuService;

    @Resource
    private SysPermissionService permissionService;

    @Resource
    private CustomAuthSourceBean customAuthSourceBean;

    private AuthRequest getAuthRequest() {
        return new CustomAuthRequest(AuthConfig.builder()
                .clientId(customAuthSourceBean.getAppkey())
                .clientSecret(customAuthSourceBean.getSecret())
                .redirectUri(customAuthSourceBean.getRedirectUrl())
                .scopes(Collections.singletonList("userinfo"))
                .build());
    }

    @GetMapping("/preUnionLogin")
    public AjaxResult preUnionLogin() {
        AuthRequest authRequest = getAuthRequest();
        AjaxResult ajax = AjaxResult.success();

        String uuid = IdUtils.fastUUID();
        String authorizeUrl = authRequest.authorize(uuid);
        // 存储
        ajax.put("authorizeUrl", authorizeUrl);
        ajax.put("uuid", uuid);
        return ajax;
    }

    @PostMapping("/loginByUnion")
    public AjaxResult loginByUnion(HttpServletRequest request, @RequestBody AuthCallback callback) {
        String authMsg = "";
        try {
            AuthRequest authRequest = getAuthRequest();
            AuthResponse login = authRequest.login(callback);
            authMsg = login.getMsg();
            String username = ((AuthUser) login.getData()).getUsername();
            String token = loginService.loginByUnionUsername(request, username);
            AjaxResult ajax = AjaxResult.success();
            ajax.put(Constants.TOKEN, token);
            return ajax;
        } catch (ServiceException e) {
            log.error("oauth login error: {}", authMsg, e);
            throw new IllegalStateException("认证登录失败: " + e.getMessage());
        } catch (Exception e) {
            log.error("oauth login error: {}", authMsg, e);
            throw new IllegalStateException("认证登录失败");
        }
    }

    /**
     * 登录方法
     *
     * @param loginBody 登录信息
     * @return 结果
     */
    @PostMapping("/login")
    public AjaxResult login(@RequestBody LoginBody loginBody) throws Exception {
        AjaxResult ajax = AjaxResult.success();
        // 生成令牌
        String token = loginService.login(loginBody.getUsername(), RsaUtils.decryptByPrivateKey(loginBody.getPassword()), loginBody.getCode(),
                loginBody.getUuid());
        ajax.put(Constants.TOKEN, token);
        return ajax;
    }

    /**
     * 获取用户信息
     *
     * @return 用户信息
     */
    @GetMapping("getInfo")
    public AjaxResult getInfo() {
        SysUser user = SecurityUtils.getLoginUser().getUser();
        // 角色集合
        Set<String> roles = permissionService.getRolePermission(user);
        // 权限集合
        Set<String> permissions = permissionService.getMenuPermission(user);
        AjaxResult ajax = AjaxResult.success();
        ajax.put("user", user);
        ajax.put("roles", roles);
        ajax.put("permissions", permissions);
        return ajax;
    }

    /**
     * 获取路由信息
     *
     * @return 路由信息
     */
    @GetMapping("getRouters")
    public AjaxResult getRouters() {
        Long userId = SecurityUtils.getUserId();
        List<SysMenu> menus = menuService.selectMenuTreeByUserId(userId);
        return AjaxResult.success(menuService.buildMenus(menus));
    }
}

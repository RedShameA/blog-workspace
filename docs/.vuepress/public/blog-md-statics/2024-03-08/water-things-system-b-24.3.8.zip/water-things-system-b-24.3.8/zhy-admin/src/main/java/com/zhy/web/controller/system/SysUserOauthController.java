package com.zhy.system.controller;

import com.zhy.common.annotation.Log;
import com.zhy.common.core.controller.BaseController;
import com.zhy.common.core.domain.AjaxResult;
import com.zhy.common.core.page.TableDataInfo;
import com.zhy.common.enums.BusinessType;
import com.zhy.common.utils.poi.ExcelUtil;
import com.zhy.system.domain.SysUserOauth;
import com.zhy.system.service.ISysUserOauthService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * oauthController
 *
 * @author wangfeng
 * @date 2023-12-13
 */
@RestController
@RequestMapping("/system/oauth")
public class SysUserOauthController extends BaseController
{
    @Resource
    private ISysUserOauthService sysUserOauthService;

    /**
     * 查询oauth列表
     */
    @PreAuthorize("@ss.hasPermi('system:oauth:list')")
    @GetMapping("/list")
    public TableDataInfo list(SysUserOauth sysUserOauth)
    {
        startPage();
        List<SysUserOauth> list = sysUserOauthService.selectSysUserOauthList(sysUserOauth);
        return getDataTable(list);
    }

    /**
     * 导出oauth列表
     */
    @PreAuthorize("@ss.hasPermi('system:oauth:export')")
    @Log(title = "oauth", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, SysUserOauth sysUserOauth)
    {
        List<SysUserOauth> list = sysUserOauthService.selectSysUserOauthList(sysUserOauth);
        ExcelUtil<SysUserOauth> util = new ExcelUtil<SysUserOauth>(SysUserOauth.class);
        util.exportExcel(response, list, "oauth数据");
    }

    /**
     * 获取oauth详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:oauth:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(sysUserOauthService.selectSysUserOauthById(id));
    }

    /**
     * 新增oauth
     */
    @PreAuthorize("@ss.hasPermi('system:oauth:add')")
    @Log(title = "oauth", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysUserOauth sysUserOauth)
    {
        return toAjax(sysUserOauthService.insertSysUserOauth(sysUserOauth));
    }

    /**
     * 修改oauth
     */
    @PreAuthorize("@ss.hasPermi('system:oauth:edit')")
    @Log(title = "oauth", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysUserOauth sysUserOauth)
    {
        return toAjax(sysUserOauthService.updateSysUserOauth(sysUserOauth));
    }

    /**
     * 删除oauth
     */
    @PreAuthorize("@ss.hasPermi('system:oauth:remove')")
    @Log(title = "oauth", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(sysUserOauthService.deleteSysUserOauthByIds(ids));
    }
}

package com.zhy.common.things.domain;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * 标准消息
 *
 * @author wangfeng
 * @since 2023-11-06 10:39
 */

@Data
@Accessors(chain = true)
public class StandardMessage implements Cloneable{
    /**
     * 产品名
     */
    String productName;
    /**
     * 产品ID
     */
    String productId;
    /**
     * 设备名
     */
    String deviceName;
    /**
     * 设备id
     */
    String deviceId;
    /**
     * 属性名
     */
    String propertyName;
    /**
     * 属性id
     */
    String propertyId;
    /**
     * 消息发送时间
     */
    Date sendTime;
    /**
     * 值
     */
    Double messageValue;
    /**
     * 值时间
     */
    Date messageTime;


    @Override
    public StandardMessage clone() {
        try {
            StandardMessage clone = (StandardMessage) super.clone();
            clone.setSendTime((Date) sendTime.clone());
            clone.setMessageTime((Date) messageTime.clone());
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}

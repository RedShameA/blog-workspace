package com.zhy.common.things.domain;

import com.zhy.common.core.domain.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;

/**
 * 物联设备组织树
 * @author wangfeng
 * @since 2023-12-08 16:22
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ThingsDeviceOrg extends BaseEntity {
    /**
     * 设备组织id
     */
    private Long deviceOrgId;

    /**
     * 父id
     */
    private Long parentId;

    /**
     * 设备组织名
     */
    private String deviceOrgName;
    /**
     * 祖级列表
     */
    private String ancestors;
    /**
     * 排序
     */
    private Integer orderNum;


    private List<ThingsDeviceOrg> children = new ArrayList<>();;

}
package com.zhy.common.things.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
* 
* 
* @author wangfeng
* @since 2023-11-28 19:42
*/
/**
    * 历史数据表
    */
@Data
public class ThingsDataHis {
    private Long id;

    /**
     * 产品名
     */
    private String productName;

    /**
     * 产品id
     */
    private String productId;

    /**
     * 设备名
     */
    private String deviceName;

    /**
     * 设备id
     */
    private String deviceId;

    /**
     * 设备ID列表
     */
    private List<String> deviceIdList;


    /**
     * 属性名
     */
    private String propertyName;
    /**
     * 属性id
     */
    private String propertyId;

    /**
    * 数据值
    */
    private Double value;

    /**
    * 数据时间
    */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date valueTime;

    /**
    * 创建时间
    */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    /**
     * 告警开始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date alarmBeginTime;

    /**
     * 告警结束时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date alarmEndTime;

}
package com.zhy.common.core.domain.model;

/**
 * 用户注册对象
 *
 * @author zhy
 */
public class RegisterBody extends LoginBody
{

}

package com.zhy.things.common.constants;

import com.alibaba.fastjson2.annotation.JSONType;
import lombok.Getter;
import org.springframework.lang.Nullable;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * @author wangfeng
 * @since 2023-11-24 8:36
 */
@Getter
@JSONType(writeEnumAsJavaBean = true)
public enum StationType {
    MM("MM", "气象站"),
    BB("BB", "蒸发站"),
    DD("DD", "堰闸水文站"),
    TT("TT", "潮位站"),
    DP("DP", "泵站"),
    SS("SS", "墒情站"),
    PP("PP", "雨量站"),
    ZQ("ZQ", "河道水文站"),
    RR("RR", "水库水文站"),
    ZG("ZG", "地下水站"),
    ZB("ZB", "分洪水位站"),
    ;

    private final String type;
    private final String info;

    private static final Map<String, StationType> mappings = new HashMap<>(16);

    static {
        for (StationType value : values()) {
            mappings.put(value.getType().toUpperCase(Locale.ROOT), value);
        }
    }

    @Nullable
    public static StationType match(@Nullable String type) {
        return (type != null ? mappings.get(type.toUpperCase(Locale.ROOT)) : null);
    }


    StationType(String type, String info) {
        this.type = type;
        this.info = info;
    }

}

package com.zhy.things.common.constants;

import com.alibaba.fastjson2.annotation.JSONType;
import lombok.Getter;

/**
 * 水利产生的数据的类型，如雨量、水位等等
 *
 * @author wangfeng
 * @since 2023-11-23 17:00
 */
@Getter
@JSONType(writeEnumAsJavaBean = true)
public enum ValueType {
    /**
     * 仅用于监听，监听所有类型
     */
    LISTEN_ALL("*", "*", "all"),
    RAIN_IN_1M("RAIN_IN_1M", "number", "1分钟雨量"),
    RAIN_IN_5M("RAIN_IN_5M", "number", "5分钟雨量"),
    RAIN_IN_10M("RAIN_IN_10M", "number", "10分钟雨量"),
    RAIN_IN_30M("RAIN_IN_30M", "number", "30分钟雨量"),
    RAIN_IN_1H("RAIN_IN_1H", "number", "一小时雨量"),
    RAIN_IN_1D("RAIN_IN_1D", "number", "日降雨量"),
    RAIN_IN_NOW("RAIN_IN_NOW", "number", "当前降雨量"),
    RAIN_IN_ALL("RAIN_IN_ALL", "number", "降雨量累计值"),
    WIND_SPEED("WIND_SPEED", "number", "瞬时风速"),
    WIND_DIRECTION("WIND_DIRECTION", "number", "瞬时风向"),
    WIND_LEVEL("WIND_LEVEL", "number", "瞬时风力"),
    WATER_TEMPERATURE("WATER_TEMPERATURE", "number", "瞬时水温"),
    WATER_LEVEL("WATER_LEVEL", "number", "瞬时水位"),
    WATER_FLOW("WATER_FLOW", "number", "瞬时流量"),
    WATER_SPEED_MAX("WATER_SPEED_MAX", "number", "瞬时最大流速"),
    WATER_SECTIONAL_AREA("WATER_SECTIONAL_AREA", "number", "断面面积"),
    WATER_SECTIONAL_SPEED_AVERAGE("WATER_SECTIONAL_SPEED_AVERAGE", "number", "断面平均流速"),
    WATER_SPEED_NOW("WATER_SPEED_NOW", "number", "瞬时流速"),
    AIR_TEMPERATURE("AIR_TEMPERATURE", "number", "瞬时气温"),
    AIR_PRESSURE("AIR_PRESSURE", "number", "瞬时气压"),
    HUMIDITY("HUMIDITY", "number", "瞬时湿度"),
    // WATER_SPEED_AVERAGE("WATER_SPEED_AVERAGE", "number", "瞬时平均流速"),
   
    SUPPLY_VOLTAGE("SUPPLY_VOLTAGE", "number", "瞬时电源电压"),

    WATER_PRESSURE_1("WATER_PRESSURE_1", "number", "水压1"),
    WATER_PRESSURE_2("WATER_PRESSURE_2", "number", "水压2"),
    WATER_PRESSURE_3("WATER_PRESSURE_3", "number", "水压3"),
    WATER_PRESSURE_4("WATER_PRESSURE_4", "number", "水压4"),
    WATER_PRESSURE_5("WATER_PRESSURE_5", "number", "水压5"),
    WATER_PRESSURE_6("WATER_PRESSURE_6", "number", "水压6"),
    WATER_PRESSURE_7("WATER_PRESSURE_7", "number", "水压7"),
    WATER_PRESSURE_8("WATER_PRESSURE_8", "number", "水压8"),

    // 水质相关
    WATER_QUALITY_WTMP("WATER_QUALITY_WTMP", "number", "水温"),
    WATER_QUALITY_PH("WATER_QUALITY_PH", "number", "PH值"),
    WATER_QUALITY_COND("WATER_QUALITY_COND", "number", "电导率"),
    WATER_QUALITY_TURB("WATER_QUALITY_TURB", "number", "浑浊度"),
    WATER_QUALITY_DOC("WATER_QUALITY_DOC", "number", "溶解氧"),
    WATER_QUALITY_CODMN("WATER_QUALITY_CODMN", "number", "高锰酸盐指数"),
    WATER_QUALITY_CODCR("WATER_QUALITY_CODCR", "number", "化学需氧量"),
    WATER_QUALITY_TN("WATER_QUALITY_TN", "number", "总氮"),
    WATER_QUALITY_NH4N("WATER_QUALITY_NH4N", "number", "氨氮"),
    WATER_QUALITY_N02("WATER_QUALITY_N02", "number", "亚硝酸盐氮"),
    WATER_QUALITY_N03("WATER_QUALITY_N03", "number", "硝酸盐氮"),
    WATER_QUALITY_TP("WATER_QUALITY_TP", "number", "总磷"),
    WATER_QUALITY_TOC("WATER_QUALITY_TOC", "number", "总有机碳"),
    WATER_QUALITY_VLPH("WATER_QUALITY_VLPH", "number", "挥发酚"),
    WATER_QUALITY_CHLA("WATER_QUALITY_CHLA", "number", "叶绿素a"),
    WATER_QUALITY_F("WATER_QUALITY_F", "number", "氟化物"),
    WATER_QUALITY_ARS("WATER_QUALITY_ARS", "number", "砷"),
    WATER_QUALITY_HG("WATER_QUALITY_HG", "number", "汞"),
    WATER_QUALITY_CR6("WATER_QUALITY_CR6", "number", "铬（六价）"),
    WATER_QUALITY_CU("WATER_QUALITY_CU", "number", "铜"),
    WATER_QUALITY_PB("WATER_QUALITY_PB", "number", "铅"),
    WATER_QUALITY_CD("WATER_QUALITY_CD", "number", "镉"),
    WATER_QUALITY_ZN("WATER_QUALITY_ZN", "number", "锌"),
    WATER_QUALITY_SB("WATER_QUALITY_SB", "number", "锑"),

    ;


    final String type;
    final String varType; // boolean 或 number
    final String desc;

    ValueType(String type, String varType, String desc) {
        this.type = type;
        this.varType = varType;
        this.desc = desc;
    }
}

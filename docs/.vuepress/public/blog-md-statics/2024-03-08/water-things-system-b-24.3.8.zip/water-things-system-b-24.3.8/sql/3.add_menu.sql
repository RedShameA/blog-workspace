
-- 设备管理
INSERT INTO sys_menu (menu_name, parent_id, order_num, path, component,  is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
VALUES ('物联管理', 0, -100, 'things', null,  1, 0, 'M', '0', '0', '', 'monitor', 'admin', sysdate(), '', null, '设备管理菜单');
SELECT @menuParentId := LAST_INSERT_ID();

-- 2023.11.09，添加协议管理菜单
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('协议管理', @menuParentId, '10', 'plugin', 'things/plugin/index', 1, 0, 'C', '0', '0', 'things:plugin:list', 'component', 'admin', sysdate(), '', null, 'plugin菜单');
-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();
-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('协议查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'things:plugin:query',        '#', 'admin', sysdate(), '', null, '');


-- 2023.11.09，添加产品管理菜单
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('产品管理', @menuParentId, '20', 'product', 'things/product/index', 1, 0, 'C', '0', '0', 'things:product:list', 'tree', 'admin', sysdate(), '', null, 'product菜单');
-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();
-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('产品查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'things:product:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('产品新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'things:product:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('产品修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'things:product:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('产品删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'things:product:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('产品导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'things:product:export',       '#', 'admin', sysdate(), '', null, '');



-- 2023.11.09，添加设备管理菜单
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备管理', @menuParentId, '30', 'device', 'things/device/index', 1, 0, 'C', '0', '0', 'things:device:list', 'tool', 'admin', sysdate(), '', null, 'device菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'things:device:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'things:device:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'things:device:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'things:device:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'things:device:export',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备导入', @parentId, '6',  '#', '', 1, 0, 'F', '0', '0', 'things:device:import',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备功能使用', @parentId, '7',  '#', '', 1, 0, 'F', '0', '0', 'things:device:use',       '#', 'admin', sysdate(), '', null, '');


-- 2023.12.04，设备数据
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('历史数据', @menuParentId, '40', 'historyData', 'things/device/history/index.vue', 1, 0, 'C', '0', '0', 'ruleEngine:recordHis:list', 'education', 'admin', sysdate(), '', null, '设备数据菜单');


-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备组织管理',  @menuParentId, '50', 'org', 'things/device/org/index', 1, 0, 'C', '0', '0', 'things:device:org:list', 'tree-table', 'admin', sysdate(), '', null, '物联设备组织树菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备组织查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'things:device:org:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备组织新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'things:device:org:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备组织修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'things:device:org:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('设备组织删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'things:device:org:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('物联设备组织树导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'things:device:org:export',       '#', 'admin', sysdate(), '', null, '');






-- ------------------------------------------------------ 规则引擎 ------------------------------------------------------
INSERT INTO sys_menu (menu_name, parent_id, order_num, path, component,  is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
VALUES ('规则引擎', 0, -90, 'ruleEngine', null,  1, 0, 'M', '0', '0', '', 'date-range', 'admin', sysdate(), '', null, '设备管理菜单');
SELECT @menuParentId := LAST_INSERT_ID();

-- 2023.12.04，添加规则设置菜单
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('规则设置', @menuParentId, '1', 'sceneLinkage', 'ruleEngine/sceneLinkage/index', 1, 0, 'C', '0', '0', 'ruleEngine:sceneLinkage:list', 'tree-table', 'admin', sysdate(), '', null, '规则设置菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('规则查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:sceneLinkage:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('规则新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:sceneLinkage:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('规则修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:sceneLinkage:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('规则删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:sceneLinkage:remove',       '#', 'admin', sysdate(), '', null, '');


-- ------------------------------------------------------ 告警中心 ------------------------------------------------------
INSERT INTO sys_menu (menu_name, parent_id, order_num, path, component,  is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
VALUES ('告警中心', 0, -80, 'alarm', null,  1, 0, 'M', '0', '0', '', 'example', 'admin', sysdate(), '', null, '设备管理菜单');
SELECT @menuParentId := LAST_INSERT_ID();
-- 2023.12.04，告警记录
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('告警记录', @menuParentId, '1', 'alarmRecord', 'ruleEngine/alarm/index.vue', 1, 0, 'C', '0', '0', 'ruleEngine:record:list', 'dict', 'admin', sysdate(), '', null, '告警记录菜单');
-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('告警记录查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:record:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('告警记录新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:record:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('告警记录修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:record:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('告警记录删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:record:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('告警记录导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'ruleEngine:record:export',       '#', 'admin', sysdate(), '', null, '');


-- 2023.12.04，告警详情
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('告警详情', @menuParentId, '2', 'alarmdetail', 'ruleEngine/alarm/components/alarmdetail.vue', 1, 0, 'C', '1', '0', 'ruleEngine:recordHis:list', '#', 'admin', sysdate(), '', null, '告警详情菜单');



-- 2023.12.13，oauth用户管理
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('oauth用户管理', '1', '11', 'oauth', 'system/oauth/index', 1, 0, 'C', '0', '0', 'system:oauth:list', 'button', 'admin', sysdate(), '', null, 'oauth菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('oauth查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:oauth:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('oauth新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:oauth:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('oauth修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:oauth:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('oauth删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:oauth:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('oauth导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:oauth:export',       '#', 'admin', sysdate(), '', null, '');


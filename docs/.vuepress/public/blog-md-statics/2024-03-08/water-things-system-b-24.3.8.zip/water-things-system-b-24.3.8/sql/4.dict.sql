-- ------------------------------------------------------ 添加告警等级类型 ------------------------------------------------------
INSERT INTO `sys_dict_type` VALUES ('11', '告警等级', 'sys_alarm_level', '0', 'admin', '2023-12-01 10:38:53', '', null, '规则引擎中告警等级');
INSERT INTO `sys_dict_data` VALUES ('30', '0', '一级告警', '0', 'sys_alarm_level', null, 'default', 'N', '0', 'admin', '2023-12-01 10:39:14', '', null, null);
INSERT INTO `sys_dict_data` VALUES ('31', '0', '二级告警', '1', 'sys_alarm_level', null, 'default', 'N', '0', 'admin', '2023-12-01 10:39:26', '', null, null);
INSERT INTO `sys_dict_data` VALUES ('32', '0', '三级告警', '2', 'sys_alarm_level', null, 'default', 'N', '0', 'admin', '2023-12-01 10:47:29', '', null, null);
INSERT INTO `sys_dict_data` VALUES ('33', '0', '四级告警', '3', 'sys_alarm_level', null, 'default', 'N', '0', 'admin', '2023-12-01 10:47:41', '', null, null);

-- ------------------------------------------------------ 添加告警状态 ------------------------------------------------------
INSERT INTO `sys_dict_type` VALUES ('12', '告警状态', 'sys_alarm_status', '0', 'admin', '2023-12-01 10:38:53', '', null, '规则引擎中告警状态');
INSERT INTO `sys_dict_data` VALUES ('34', '0', '提醒', '0', 'sys_alarm_status', null, 'default', 'N', '0', 'admin', '2023-12-01 10:39:14', '', null, null);
INSERT INTO `sys_dict_data` VALUES ('35', '0', '一般', '1', 'sys_alarm_status', null, 'default', 'N', '0', 'admin', '2023-12-01 10:39:26', '', null, null);
INSERT INTO `sys_dict_data` VALUES ('36', '0', '严重', '2', 'sys_alarm_status', null, 'default', 'N', '0', 'admin', '2023-12-01 10:47:29', '', null, null);
INSERT INTO `sys_dict_data` VALUES ('37', '0', '紧急', '3', 'sys_alarm_status', null, 'default', 'N', '0', 'admin', '2023-12-01 10:47:41', '', null, null);

-- 物管平台业务sql
-- 每个模块的表按照下面格式进行分隔

-- ------------------------------------------------------ 设备管理 ------------------------------------------------------
-- 产品表 2023/11/13
create table things_product
(
    product_id   varchar(36)            not null primary key,
    product_name varchar(128)           null comment '产品名称',
    product_desc varchar(500)           null comment '产品描述',
    protocol     varchar(32)            not null comment '产品使用协议',
    metadata     text                   null comment '物模型相关数据',
    create_by    varchar(64) default '' null comment '创建者',
    create_time  datetime               null comment '创建时间',
    update_by    varchar(64) default '' null comment '更新者',
    update_time  datetime               null comment '更新时间',
    remark       text                   null comment '备注'
) comment '产品表';

-- 设备表 2023/11/13
create table things_device
(
    device_id      varchar(36)            not null comment '设备id，即stcd'
        primary key,
    station_type   varchar(100)            null comment '测站类型，用于此设备上数入哪个标准库',
    product_id     varchar(36)            not null comment '所属产品id',
    device_name    varchar(128)           not null comment '设备名称',
    device_desc    varchar(500)           null comment '设备描述',
    device_org_id  bigint                 null comment '关联的设备组织id',
    registry_time  datetime               null comment '注册时间，设备第一次上线的时间',
    metadata       text                   null comment '设备的物模型数据，设备的物模型数据可能比产品的不同，也可以继承自产品',
    heartbeat_time datetime               null comment '设备最新一次心跳的时间',
    create_by      varchar(64) default '' null comment '创建者',
    create_time    datetime               null comment '创建时间',
    update_by      varchar(64) default '' null comment '更新者',
    update_time    datetime               null comment '更新时间',
    remark         text                   null comment '备注'
)
    comment '设备表';

-- 设备组织管理 2023/12/11
create table things_device_org
(
    device_org_id   bigint auto_increment comment '设备组织id'
        primary key,
    parent_id       bigint                 null comment '父id',
    ancestors       varchar(100)           null comment '祖级列表',
    device_org_name varchar(64)            null comment '设备组织名',
    order_num       int                    null comment '排序',
    create_by       varchar(64) default '' null comment '创建者',
    create_time     datetime               null comment '创建时间',
    update_by       varchar(64) default '' null comment '更新者',
    update_time     datetime               null comment '更新时间'
)
    comment '物联设备组织树';
insert into things_device_org
values (1, 0, '0', '默认组织', 0, 'admin', sysdate(), '', null);


-- 历史数据表 2023/11/23
create table things_data_his_template
(
    id            bigint primary key auto_increment,
    product_name  varchar(50) null comment '产品名',
    product_id    varchar(36) null comment '产品id',
    device_name   varchar(50) null comment '设备名',
    device_id     varchar(36) null comment '设备id',
    property_name varchar(50) null comment '属性名',
    property_id   varchar(36) null comment '属性id',
    value         double      null comment '数据值',
    value_time    datetime    null comment '数据时间',
    create_time   datetime    null comment '创建时间'
) comment '历史数据表';

-- ------------------------------------------------------ 告警管理 ------------------------------------------------------

-- 告警记录表
CREATE TABLE `alarm_record`
(
    `id`               varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
    `device_id`        varchar(36) COLLATE utf8mb4_unicode_ci  DEFAULT NULL COMMENT '设备id',
    `device_name`        varchar(36) COLLATE utf8mb4_unicode_ci  DEFAULT NULL COMMENT '设备名称',
    `alarm_desc`       varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '告警描述',
    `property_id`      varchar(36) COLLATE utf8mb4_unicode_ci  DEFAULT NULL COMMENT '属性id',
    `alarm_level`      char(1) COLLATE utf8mb4_unicode_ci     NOT NULL COMMENT '告警等级 0-一级告警, 1-二级告警，2-三级告警,3-四级告警',
    `alarm_status`     char(1) COLLATE utf8mb4_unicode_ci     NOT NULL COMMENT '告警状态 0-提醒, 1-一般，2-严重,3-紧急',
    `alarm_begin_time` datetime                                DEFAULT NULL COMMENT '告警开始时间',
    `alarm_end_time`   datetime                                DEFAULT NULL COMMENT '告警结束时间',
    `alarm_state`      char(1) COLLATE utf8mb4_unicode_ci      DEFAULT NULL COMMENT '告警状态: 0-告警结束 1-告警中',
    `handle_time`      datetime                                DEFAULT NULL COMMENT '处理时间',
    `handle_state`     char(1) COLLATE utf8mb4_unicode_ci      DEFAULT NULL COMMENT '告警处理状态： 0-未处理 ，1-已处理',
    `create_by`        varchar(64) COLLATE utf8mb4_unicode_ci  DEFAULT NULL COMMENT '创建者',
    `create_time`      datetime                                DEFAULT NULL COMMENT '创建时间',
    `update_by`        varchar(64) COLLATE utf8mb4_unicode_ci  DEFAULT NULL COMMENT '更新者',
    `update_time`      datetime                                DEFAULT NULL COMMENT '更新时间',
    `remark`           text COLLATE utf8mb4_unicode_ci COMMENT '备注',
    PRIMARY KEY (`id`)
) comment '告警记录表';

-- ------------------------------------------------------ 规则引擎 ------------------------------------------------------

-- 规则引擎表
CREATE TABLE `rule_scene`
(
    `id`                 varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '场景联动ID',
    `rule_name`          varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '告警（场景）规则名称',
    `rule_description`   varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '场景联动描述',
    `alarm_level`        char(1) COLLATE utf8mb4_unicode_ci     NOT NULL COMMENT '告警等级 0-一级告警, 1-二级告警，2-三级告警,3-四级告警',
    `alarm_status`       char(1) COLLATE utf8mb4_unicode_ci     NOT NULL COMMENT '告警状态 0-提醒, 1-一般，2-严重,3-紧急',
    `trigger_type`       tinyint(1)                             NOT NULL COMMENT '触发类别: 0:定时任务，1：设备触发',
    `trigger_expression` text COLLATE utf8mb4_unicode_ci        NOT NULL COMMENT '触发表达式(包括规则体、定时时间、触发时间间隔)',
    `device_id`          text COLLATE utf8mb4_unicode_ci        NOT NULL COMMENT '设备id【一个或多个】',
    `product_id`         varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '产品id',
    `create_by`          varchar(64) COLLATE utf8mb4_unicode_ci  DEFAULT NULL COMMENT '创建者',
    `create_time`        datetime                                DEFAULT NULL COMMENT '创建时间',
    `update_by`          varchar(64) COLLATE utf8mb4_unicode_ci  DEFAULT NULL COMMENT '更新者',
    `update_time`        datetime                                DEFAULT NULL COMMENT '更新时间',
    `remark`             text COLLATE utf8mb4_unicode_ci COMMENT '备注',
    PRIMARY KEY (`id`)
) comment '规则引擎场景表';

-- ------------------------------------------------------ oauth ------------------------------------------------------

-- oauth认证映射表
create table sys_user_oauth
(
    id          bigint auto_increment comment '主键'
        primary key,
    oauth_name  varchar(30)            null comment '认证用户名',
    user_name   varchar(30)            null comment '本系统用户名',
    create_by   varchar(64) default '' null comment '创建者',
    create_time datetime               null comment '创建时间',
    update_by   varchar(64) default '' null comment '更新者',
    update_time datetime               null comment '更新时间'
)
    comment '认证用户和本系统用户的映射关系表';


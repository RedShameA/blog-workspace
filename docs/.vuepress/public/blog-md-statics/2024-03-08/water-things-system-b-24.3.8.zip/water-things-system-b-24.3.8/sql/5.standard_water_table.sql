-- 1. 降水量表
CREATE TABLE `st_pptn_r`
(
    `stcd` char(8)  NOT NULL COMMENT '由全国统一编制的，用于标识涉及报送降水、蒸发、河道、水库、闸坝、泵站、潮沙、沙情、冰情、墒情、地下水、水文预报等信息的各类测站的站码。测站编码具有唯一性，由数字和大写字母组成的8位字符串，按《全国水文测站编码》执行。',
    `tm`   datetime NOT NULL COMMENT '降水量值的截止时间',
    `drp`  decimal(5, 1) DEFAULT NULL COMMENT '表示指定时段内的降水量，计量单位为mm',
    `intv` decimal(5, 2) DEFAULT NULL COMMENT '描述测站所报时段降水量的统计时段长度，计量单位为h',
    `pdr`  decimal(5, 2) DEFAULT NULL COMMENT '描述指定时段的实际降雨时间。数据存储的格式是HH.NN,其中HH为小时数，取值为00~23;NN为分钟数，取值为01~59。当降水历时为整小时数时，可只列小时数',
    `dyp`  decimal(5, 1) DEFAULT NULL COMMENT '表示前一天8时至截至当天8时共计24h的累计降水量，计量单位为mm',
    `wth`  char(1)       DEFAULT NULL COMMENT '时间字段截至时刻的天气状况，用代码表示。天气状况代码应按表31确定取值',
    PRIMARY KEY (`tm`, `stcd`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE utf8mb4_unicode_ci COMMENT '降水量表';

-- 2. 河道水情表
CREATE TABLE `st_river_r`
(
    `stcd`     char(8)  NOT NULL COMMENT '由全国统一编制的，用于标识涉及报送降水、蒸发、河道、水库、闸坝、泵站、潮沙、沙情、冰情、墒情、地下水、水文预报等信息的各类测站的站码。测站编码具有唯一性，由数字和大写字母组成的8位字符串，按《全国水文测站编码》执行。',
    `tm`       datetime NOT NULL COMMENT '水情发生的时间',
    `z`        decimal(7, 3) DEFAULT NULL COMMENT '测站断面相应时间的水位，计量单位为m',
    `q`        decimal(9, 3) DEFAULT NULL COMMENT '测站测验断面相应时间通过的流量，计量单位为m³/s',
    `xsa`      decimal(9, 3) DEFAULT NULL COMMENT '流量通过时相应的过流面积，计量单位为㎡，计至3位小数',
    `xsavv`    decimal(5, 3) DEFAULT NULL COMMENT '给定时间河道水文站实测流量时所测得的测验断面平均流速，计量单位为m/s',
    `xsmxv`    decimal(5, 3) DEFAULT NULL COMMENT '给定时间河道水文站实测流量时所测得的测验断面最大点流速，计量单位为\nm/s',
    `flwchrcd` char(1)       DEFAULT NULL COMMENT '给定时间河道洪水起涨、流向、干枯、断流和峰值等特征的描述代码，河水特征及其代码应按表37确定',
    `wptn`     char(1)       DEFAULT NULL COMMENT '河道洪水水位的涨落信息，水势及其代码应按表38确定',
    `msqmt`    char(1)       DEFAULT NULL COMMENT '流量的施测方法，测流方法及其代码应按表39确定',
    `msamt`    char(1)       DEFAULT NULL COMMENT '过流断面面积的测量方法，测积方法及其代码应按表40确定',
    `msvmt`    char(1)       DEFAULT NULL COMMENT '水流速度的测量方法，测速方法及其代码应按表41确定',
    PRIMARY KEY (`tm`, `stcd`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE utf8mb4_unicode_ci COMMENT '河道水情表';

-- 3.
-- auto-generated definition
create table hyd_ri_wqamd_w
(
    spt   datetime(6)   not null comment '采样时间',
    stcd  varchar(8)    not null comment '测站编码',
    ars   double(8, 6)  null comment '砷-水中无机和有机化合物中砷的总量',
    cd    double(7, 5)  null comment '镉-水中镉的含量',
    chla  double(6, 4)  null comment '叶绿素a-水中藻类的光合作用色素叶绿素的含量',
    codcr double(7, 1)  null comment '化学需氧量-以重铬酸钾为氧化剂所能氧化的物质含量',
    codmn double(7, 1)  null comment '高锰酸盐指数-以高锰酸钾为氧化剂所能氧化的物质含量',
    cr6   double(5, 3)  null comment '砷-水中无机和有机化合物中砷的总量',
    cu    double(7, 4)  null comment '铜-水中铜的含量',
    doc   double(4, 2)  null comment '溶解氧-水中氢离子活度（H+）的负对数。小数不过二位',
    f     double(5, 2)  null comment '氟化物-水中游离的氛离子总量，以F-计',
    hg    double(9, 7)  null comment '砷-水中无机和有机化合物中砷的总量',
    n02   double(5, 3)  null comment '亚硝酸盐氮-水中亚硝酸盐含量，以N计',
    n03   double(5, 3)  null comment '硝酸盐氮-水中硝酸盐含量，以N计',
    nh3n  double(6, 3)  null comment '氨氮-水中的游离氨和按盐含量，以N计',
    pb    double(7, 5)  null comment '铅-水中铅的含量',
    sb    double(7, 5)  null comment '锑-水中锑的含量',
    tn    double(6, 3)  null comment '总氮-水中能被过硫酸钾氧化的无机氮和有机氮化合物总量',
    toc   double(4, 1)  null comment '总有机碳-水中溶解性和悬浮性有机物中存在的碳的总量',
    tp    double(8, 3)  null comment '总磷-水中经过强氧化后转变成正磷酸盐的各种无机磷和有机磷总量，以P计',
    turb  double(3, 0)  null comment '浑浊度-指水体着色的程度，它影响着水体的透光性和水生生物的生长。单位为度，记至整数',
    vlph  double(10, 6) null comment '挥发酚-随水蒸汽熘出的，并和4-氨基安替比林反应生成有色化合物的挥发酚类化合物含量，结果以苯酚计',
    wtmp  double(3, 1)  null comment '水温',
    zn    double(6, 4)  null comment '锌-水中锌的含量',
    cond  double(5, 0)  null comment '电导率-在特定条件下，规定尺寸单位立方体的水溶液相对面之间的测得的电阻倒数。单位为微西门/cm，计至整数',
    ph    double(4, 2)  null comment 'PH-水中氢离子活度（H+）的负对数。小数不过二位',
    primary key (spt, stcd)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE utf8mb4_unicode_ci COMMENT '水质自动监测数据表';
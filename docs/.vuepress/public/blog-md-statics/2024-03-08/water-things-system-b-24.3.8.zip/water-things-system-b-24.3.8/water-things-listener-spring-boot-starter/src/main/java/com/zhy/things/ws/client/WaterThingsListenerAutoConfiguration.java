package com.zhy.things.ws.client;

import com.zhy.things.ws.client.config.WaterThingsListenerProperties;
import com.zhy.things.ws.client.listener.WaterThingsListener;
import com.zhy.things.ws.client.websocket.WebsocketListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

/**
 * @author wangfeng
 * @since 2023-12-29 14:08
 */
@Slf4j
@Configuration
@EnableConfigurationProperties({WaterThingsListenerProperties.class})
public class WaterThingsListenerAutoConfiguration {

    @Resource
    WaterThingsListenerProperties properties;

    @Bean(name = "WebsocketListener")
    @ConditionalOnProperty(prefix = "water-things-listener", name = "water-things-system-url", matchIfMissing = true)
    public WebsocketListener websocketListener() {
        if (!properties.validate()) {
            return null;
        }
        WebsocketListener websocketListener = new WebsocketListener();
        websocketListener.start(properties.getUrl(), WaterThingsListener::consumeMessage);
        return websocketListener;
    }
}

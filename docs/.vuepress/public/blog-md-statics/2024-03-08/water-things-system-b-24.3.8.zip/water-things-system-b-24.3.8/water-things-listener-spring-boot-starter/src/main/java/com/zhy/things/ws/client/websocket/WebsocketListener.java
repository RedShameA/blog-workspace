package com.zhy.things.ws.client.websocket;

import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * @author wangfeng
 * @since 2023-12-28 20:19
 */
@Slf4j
public class WebsocketListener {
    OkHttpClient client;
    Request request;
    WebSocket webSocket;
    ScheduledExecutorService service = Executors.newScheduledThreadPool(1);
    String websocketUrl;
    Consumer<String> consumer;
    SocketListener socketListener;

    public void start(String websocketUrl, Consumer<String> consumer) {
        this.websocketUrl = websocketUrl;
        this.consumer = consumer;
        this.service.scheduleAtFixedRate(this::heartbeat, 0, 2, TimeUnit.SECONDS);
    }

    public void connect() {
        if (null == client) client = new OkHttpClient.Builder().build();
        client.dispatcher().cancelAll();
        if (null == request) request = new Request.Builder().url(websocketUrl).build();
        if (null==socketListener) socketListener = new SocketListener(consumer);
        webSocket = client.newWebSocket(request, socketListener);
    }

    public void heartbeat() {
        if (null == webSocket) connect();
        if (!webSocket.send("ping")) {
            log.info("water-things-listener reconnecting");
            connect();
        }
    }


    private static class SocketListener extends WebSocketListener {

        Consumer<String> consumer;

        public SocketListener(Consumer<String> consumer) {
            this.consumer = consumer;
        }

        @Override
        public void onMessage(@NotNull WebSocket webSocket, @NotNull String text) {
            super.onMessage(webSocket, text);
            consumer.accept(text);
        }

        @Override
        public void onOpen(@NotNull WebSocket webSocket, @NotNull Response response) {
            super.onOpen(webSocket, response);
            log.info("water-things-listener connected");
        }
    }
}

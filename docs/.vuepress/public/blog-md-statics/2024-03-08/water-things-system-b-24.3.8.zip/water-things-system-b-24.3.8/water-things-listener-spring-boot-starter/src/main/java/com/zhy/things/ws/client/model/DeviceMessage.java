package com.zhy.things.ws.client.model;

import com.zhy.things.common.constants.ValueType;
import lombok.Data;

import java.util.Date;

/**
 * @author wangfeng
 * @since 2023-12-29 15:14
 */
@Data
public class DeviceMessage {
    /**
     * 类型
     */
    ValueType valueType;
    /**
     * 设备ID
     */
    String deviceId;
    /**
     * 数据值
     * 如valueType.varType为boolean，则0为false，其他为true
     */
    Double messageValue;
    /**
     * 数据时间
     */
    Date messageTime;
}

package com.zhy.things.ws.client.config;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * uniapp个推配置项
 *
 * @author wangfeng
 * @since 2023-12-22 13:41
 */
@Data
@ConfigurationProperties(prefix = "water-things-listener")
public class WaterThingsListenerProperties {
    /**
     * 物管平台的地址，如：127.0.0.1:8080
     */
    String waterThingsSystemUrl;

    public String getUrl() {
        return "ws://" + waterThingsSystemUrl + "/websocket/device/message";
    }

    /**
     * 校验是否都配置好了
     */
    public boolean validate() {
        return StringUtils.isNotBlank(waterThingsSystemUrl);
    }
}

package com.zhy.things.ws.client.listener;

import com.alibaba.fastjson2.JSONObject;
import com.zhy.things.common.constants.ValueType;
import com.zhy.things.ws.client.model.DeviceMessage;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * @author wangfeng
 * @since 2023-12-29 14:55
 */
public class WaterThingsListener {

    public static final String DEVICE_ID_LISTEN_ALL = "*";

    private static final ConcurrentHashMap<String, ConcurrentHashMap<ValueType, ArrayList<Consumer<DeviceMessage>>>> map = new ConcurrentHashMap<>();

    public static void listen(String deviceId, ValueType valueType, Consumer<DeviceMessage> consumer) {
        ConcurrentHashMap<ValueType, ArrayList<Consumer<DeviceMessage>>> typesMap = map.computeIfAbsent(deviceId, key -> new ConcurrentHashMap<>());
        ArrayList<Consumer<DeviceMessage>> consumers = typesMap.computeIfAbsent(valueType, key -> new ArrayList<>());
        consumers.add(consumer);
    }

    public static void consumeMessage(String message) {
        try {
            DeviceMessage deviceMessage = JSONObject.parseObject(message, DeviceMessage.class);
            // 监听该设备ID的
            ConcurrentHashMap<ValueType, ArrayList<Consumer<DeviceMessage>>> typesMap = map.computeIfAbsent(deviceMessage.getDeviceId(), key -> new ConcurrentHashMap<>());
            // 监听所有设备ID的
            ConcurrentHashMap<ValueType, ArrayList<Consumer<DeviceMessage>>> typesMapAllId = map.computeIfAbsent(DEVICE_ID_LISTEN_ALL, key -> new ConcurrentHashMap<>());
            // 监听该设备ID、该数据类型的
            ArrayList<Consumer<DeviceMessage>> consumers_curr_id_curr_type = typesMap.computeIfAbsent(deviceMessage.getValueType(), key -> new ArrayList<>());
            // 监听该设备ID、所有类型的
            ArrayList<Consumer<DeviceMessage>> consumers_curr_id_all_type = typesMap.computeIfAbsent(ValueType.LISTEN_ALL, key -> new ArrayList<>());
            // 监听所有ID、这个类型的
            ArrayList<Consumer<DeviceMessage>> consumers_all_id_curr_type = typesMapAllId.computeIfAbsent(deviceMessage.getValueType(), key -> new ArrayList<>());
            // 监听所有ID、所有类型的
            ArrayList<Consumer<DeviceMessage>> consumers_all_id_all_type = typesMapAllId.computeIfAbsent(ValueType.LISTEN_ALL, key -> new ArrayList<>());

            ArrayList<Consumer<DeviceMessage>> consumers = new ArrayList<>();
            consumers.addAll(consumers_curr_id_curr_type);
            consumers.addAll(consumers_curr_id_all_type);
            consumers.addAll(consumers_all_id_curr_type);
            consumers.addAll(consumers_all_id_all_type);

            consumers.forEach(consumer -> {
                try {
                    consumer.accept(deviceMessage);
                } catch (Exception ignored) {
                }
            });
        } catch (Exception ignored) {
        }

    }

}

package com.zhy;

import com.alibaba.fastjson2.JSON;
import com.zhy.things.common.constants.ValueType;
import com.zhy.things.ws.client.listener.WaterThingsListener;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

/**
 * 启动程序
 *
 * @author zhy
 */
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class SysApplication {
    public static void main(String[] args) {
        // System.setProperty("spring.devtools.restart.enabled", "false");
        SpringApplication.run(SysApplication.class, args);
        System.out.println("----  系统启动成功   ----\n");


        WaterThingsListener.listen(WaterThingsListener.DEVICE_ID_LISTEN_ALL, ValueType.LISTEN_ALL, (message) -> {
            System.out.printf("测试：%s%n", JSON.toJSONString(message));
        });
    }
}

package com.zhy.auth.form;

/**
 * 用户注册对象
 *
 * @author zhy
 */
public class RegisterBody extends LoginBody
{

}

<template>
  <div id="app">
    <!-- <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </nav> -->
    <!-- -->
    <!-- <el-radio-group v-model="isCollapse" style="margin-bottom: 20px">
      <el-radio-button :label="false">展开</el-radio-button>
      <el-radio-button :label="true">收起</el-radio-button>
    </el-radio-group> -->
    <div class="content_index">
      <el-menu
        default-active="1-4-1"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose"
        :collapse="isCollapse"
      >
        <!-- <i class="el-icon-location"></i> -->
        <el-menu-item index="1" @click="templateConfig">
          <i class="el-icon-menu"></i>
          <span slot="title">模版配置</span>
        </el-menu-item>
        <el-menu-item index="2" @click="sysConfig">
          <i class="el-icon-menu"></i>
          <span slot="title">系统配置</span>
        </el-menu-item>
        <el-menu-item index="3" @click="areaDraw">
          <i class="el-icon-document"></i>
          <span slot="title">区域绘制</span>
        </el-menu-item>
        <el-menu-item index="4" @click="collectConfig">
          <i class="el-icon-setting"></i>
          <span slot="title">采集配置</span>
        </el-menu-item>
      </el-menu>
      <router-view />
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      isCollapse: false,
    };
  },
  methods: {
    templateConfig() {
      this.$router.push({
        path: "/templateConfig",
      });
    },
    sysConfig() {
      this.$router.push({
        path: "/sysConfig",
      });
    },
    areaDraw() {
      this.$router.push({
        path: "/areaDraw",
      });
    },
    collectConfig() {
      this.$router.push({
        path: "/collectConfig",
      });
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
  },
};
</script>
<style lang="scss">
.content_index {
  overflow-x: hidden;
}
body {
  margin: 0;
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
  width: 200px;
  height: 100vh;
}
.content_index {
  display: flex;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  // text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>

import Vue from 'vue'
import VueRouter from 'vue-router'
// import HomeView from '../views/HomeView.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    // component: HomeView
  },
  {
    path: '/sysConfig',
    name: 'sysConfig',
    component: () => import('../views/config/sysConfig.vue')
  },
  {
    path: '/areaDraw',
    name: 'areaDraw',
    component: () => import('../views/config/areaDraw.vue')
  },
  {
    path: '/collectConfig',
    name: 'collectConfig',
    component: () => import('../views/config/collectConfig.vue')
  },
  {
    path: '/templateConfig',
    name: 'templateConfig',
    component: () => import('../views/config/templateConfig.vue')
  }
]
const originalPush = VueRouter.prototype.push;

VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router


// /**
//      * 参数ID，主键
//      */
//     private Integer paraId;

//     /**
//      * 参数父ID，没有父ID时， 值为-1
//      */
//     private Integer paraParentId;

//     /**
//      * 参数key，
//      */
//     private String paraKey;

//     /**
//      * 参数名
//      */
//     private String label;

//     /**
//      * 参数类型
//      */
//     private String tag;

//     /**
//      * 排序
//      */
//     private Integer paraOrd;

//     /**
//      * 是否必须
//      */
//     private Integer require;

//     /**
//      * 验证方式
//      */
//     private String validate;

//     /**
//      * 单位
//      */
//     private String unit;

//     /**
//      * 参数描述
//      */
//     private String helpMsg;

//     /**
//      * 该参数默认值
//      */
//     private String value;

//     /**
//      * 批量id查询
//      */
//     private String ids;

//     /**
//      * 更新次数
//      */
//     private Integer upc;

//     /**
//      * 关联记录ID，比如AI分析的话，这里就是具体点位的ID，比如离岗存在点位表里面的记录ID
//      */
//     private String linkId;

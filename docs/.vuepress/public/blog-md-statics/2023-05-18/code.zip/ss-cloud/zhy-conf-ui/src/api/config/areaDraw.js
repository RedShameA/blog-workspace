import request from '@/util/request'
//列表
export function modelTree() {
  return request({
    url: '/api/config/IpctreeList',
    method: 'get'
  })
}
// export function lastestImage(params) {
//   return request({
//     url: '/iot/image/images/lastest_image',
//     method: 'get',
//     params
//   })
// }
//通道/预设位
export function channelAndPreset(id) {
  return request({
    url: '/api/config/channelAndPreset/' + id,
    method: 'get',
  })
}
//
export function selectIotParaTemplateForAreaWithoutCoorList(params) {
  return request({
    url: '/api/paraTemplate/selectTypeList',
    method: 'get',
    params
  })
}
//根据检测类型paraId查询参数列表/paraTemplate/selectListById
export function selectListById(params) {
  return request({
    url: '/api/paraTemplate/selectListById',
    method: 'get',
    params: params
  })
}
//确定
export function updateAddParaValue(data) {
  return request({
    url: '/api/cfg/paraValue/addParaValue',
    method: 'post',
    data
  })
}

//列表---修改，删除
export function updateParaValue(data) {
  return request({
    url: '/api/cfg/paraValue/updateParaValue',
    method: 'put',
    data
  })
}
//列表
export function selectIotParaTemplateForCoorList(id) {
  return request({
    url: '/api/cfg/paraValue/selectPointValueList?id=' + id,
    method: 'get',
  })
}
export function selectParamValue (linkId, paraId) {
  return request({
    url: '/api/cfg/paraValue/selectParamValue?linkId=' + linkId + '&paraId=' + paraId,
    method: 'get'
  })
}
//删除
export function deleteParaValueByLinkId(id) {
  return request({
    url: '/api/cfg/paraValue/deleteParaValueByParaId?linkId=' + id,
    method: 'delete',
  })
}
//图片
export function lastestImage(params) {
  return request({
    url: '/api/paraTemplate/selectImg',
    method: 'get',
    params
  })
}
//修改
// export function updateParaValue(data) {
//   return request({
//     url: '/cfg/paraValue/updateParaValue',
//     method: 'put',
//     data
//   })
// }
//布防日程
// export function scheduleList(params) {
//   return request({
//     url: '/api/paraTemplate/selectTypeList',
//     method: 'get',
//     params
//   })
// }

// export function selectIotParaTemplateForCoorList(presetId) {
//   return request({
//     url: '/cfg/paraTemplate/selectIotParaTemplateForCoorList?presetId=' + presetId,
//     method: 'post',
//   })
// }

// export function selectIotParaTemplateForAreaWithoutCoorList(id) {
//   return request({
//     url: '/cfg/paraTemplate/selectIotParaTemplateForAreaWithoutCoorList?linkId=' + id,
//     method: 'post',
//   })
// }

// export function updateParaValueForAreaList(data) {
//   return request({
//     url: '/cfg/paraValue/updateParaValueForAreaList',
//     method: 'post',
//     data
//   })
// }
//布防日程
// export function scheduleList(params) {
//   return request({
//     url: '/cfg/schedule/list',
//     method: 'get',
//     params
//   })
// }
export function addSchedule(data) {
  return request({
    url: '/cfg/schedule',
    method: 'post',
    data
  })
}
// export function editSchedule(data) {
//   return request({
//     url: '/cfg/schedule',
//     method: 'put',
//     data
//   })
// }
export function deleteSchedule(id) {
  return request({
    url: '/cfg/schedule/' + id,
    method: 'delete',
  })
}

<template>
  <div class="app-container clearfix" id="areaDraw">
    <div class="left fl" style="width: 220px; margin-right: 50px">
      <div class="head-container">
        <el-input
          v-model="modelName"
          placeholder="请输入设备名称"
          clearable
          size="small"
          prefix-icon="el-icon-search"
          style="margin-bottom: 20px"
        />
      </div>
      <div class="head-container devTree">
        <el-tree
          :data="modelOption"
          :props="defaultProps"
          :expand-on-click-node="false"
          :filter-node-method="filterNode"
          ref="tree"
          :highlight-current="true"
          default-expand-all
          @node-click="handleNodeClick"
        >
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <span :class="data.devNode ? 'device' : ''"
              ><i class="el-icon-video-camera" v-if="data.devNode"></i>
              {{ node.label }}
            </span>
          </span>
        </el-tree>
      </div>
    </div>
    <div class="center fl" style="width: calc(100% - 300px)">
      <div class="wrap">
        <img alt="" ref="drawImg"   style="display:none"/>
        <canvas
          id="picCanvas"
          ref="picCanvas"
          width="800"
          height="350"
          @contextmenu.prevent="lastestImagePic && mousedownHandler($event)"
          @click.prevent="lastestImagePic && mousedownHandler($event)"
          @mousemove="points.length >= 1 && mousemoveHandler($event)"
        >
          <!--  -->
        </canvas>
        <div class="block fr" style="margin-right: 34px">
          <div class="demonstration" style="margin-bottom: 15px">
            通道和预置位:
          </div>
          <el-cascader
            :key="cascaderKey"
            v-model="channelAndPresetValue"
            :options="channelAndPresetOptions"
            :props="{ label: 'label', value: 'id' }"
          ></el-cascader>
          <!-- @change="lastestImage" -->

          <el-row>
            <el-button
              v-if="channelAndPresetValue"
              type="primary"
              style="margin-top: 10px"
              @click="drawAll"
              >整体绘制</el-button
            >
          </el-row>
        </div>
      </div>

      <div class="right wrap" style="margin-top: 20px">
        <!-- :cell-style="TableRowStyle" -->
        <el-table v-loading="loading" :data="drawList">
          <el-table-column type="index" width="55" label="序号" align="center">
            <template slot-scope="scope">
              <span
                :style="{ backgroundColor: initColor(scope.$index) }"
                class="tableIndex"
                >{{ scope.$index + 1 }}</span
              >
            </template>
          </el-table-column>
          <el-table-column
            label="检测类型"
            prop="paraName"
            width="130"
            :show-overflow-tooltip="true"
          />
          <el-table-column
            label="坐标"
            prop="paraValue"
            :show-overflow-tooltip="true"
            width="150"
          />
          <el-table-column
            label="操作"
            align="center"
            class-name="small-padding fixed-width"
          >
            <template slot-scope="scope" v-if="scope.row.roleId !== 1">
              <el-button
                size="mini"
                type="text"
                icon="el-icon-edit"
                @click="editParaValueById(scope.row)"
                >修改</el-button
              >
              <el-button
                size="mini"
                type="text"
                icon="el-icon-delete"
                @click="deleteParaValueByLinkId(scope.row.linkId)"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>

    <el-dialog title="隐患检测配置" :visible.sync="open" width="700px">
      <el-row :gutter="20">
        <el-col :span="8">
          <div style="margin-bottom: 20px">检测类型</div>
          <!-- <el-row
            v-for="(item, i) in coorList"
            :key="i"
            style="margin-top: 10px; text-align: right"
          >
            <el-button
              style="width: 100%; text-align: center"
              @click="chooseCoor(item)"
              :disabled="disabled"
              :type="
                chooseCoorItem && item.paraId == chooseCoorItem.paraId
                  ? 'primary'
                  : ''
              "
            >
              {{ item.label }}
            </el-button>
          </el-row> -->
          <el-select
            v-model="valueType"
            value-key="paraId"
            placeholder="请选择"
            @change="changeItem"
          >
            <el-option
              v-for="item in coorList"
              :key="item.paraId"
              :label="item.label"
              :value="item"
            >
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="16" style="padding-left: 30px">
          <div
            v-for="(item, i) in selectListByIdOne"
            :key="i"
            style="margin-top: 10px"
          >
            <el-row>
              <el-col :span="6">
                <span style="color: red">*</span>{{ item.label }}
              </el-col>
              <el-col :span="18">
                <el-select
                  v-if="item.label == '告警等级'"
                  v-model="item.value"
                  placeholder="告警等级"
                  clearable
                >
                  <el-option
                    v-for="dict in alarmLevelList"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  />
                </el-select>
                <el-select
                  v-else-if="item.label == '布防日程'"
                  v-model="item.value"
                  placeholder="布防日程"
                  clearable
                >
                  <!-- <el-option
                    v-for="dict in scheduleListArr"
                    :key="dict.scheduleId"
                    :label="dict.scheduleName"
                    :value="dict.scheduleId"
                  /> -->
                </el-select>
                <el-input
                  v-else-if="item.label == '设备编号'"
                  v-model="item.value"
                />
                <el-input
                  v-else-if="item.label == '穿戴识别项'"
                  v-model="item.value"
                />
                <el-input-number
                  v-else
                  v-model="item.value"
                  :step="1"
                  step-strictly
                  :max="item.validate * 1 || 1000"
                  :min="0"
                />
                <el-tooltip
                  class="item"
                  effect="dark"
                  :content="item.helpMsg"
                  placement="top-start"
                >
                  <i class="el-icon-info tipsIcon" style="margin-left: 5px"></i>
                </el-tooltip>
              </el-col>
            </el-row>
          </div>
        </el-col>
      </el-row>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="open = false">取 消</el-button>
      </div>
      <el-dialog
        title="日程信息"
        append-to-body
        :visible.sync="scheduleTimeOpen"
      >
        <el-row :gutter="15" class="previewTime">
          <el-col :span="6">
            <el-row
              v-for="(item, index) in scheduleListArr1"
              :key="item.scheduleId"
            >
              <el-button
                :type="item.scheduleId === 'mrrc' ? 'info' : 'primary'"
                :plain="item.scheduleId !== 'mrrc'"
                @click="chooseActive(index)"
                >{{ item.scheduleName }}</el-button
              >
            </el-row>
            <el-row class="operator" style="width: 100px">
              <el-col :span="12">
                <el-tooltip
                  class="item"
                  effect="dark"
                  content="新增日程"
                  placement="top-start"
                >
                  <i class="el-icon-circle-plus" @click="addScheduleDialog"></i>
                </el-tooltip>
              </el-col>
              <el-col :span="12" style="text-align: right">
                <el-tooltip
                  class="item"
                  effect="dark"
                  content="删除日程"
                  placement="top-start"
                  v-if="
                    activeSchedule.scheduleId &&
                    activeSchedule.scheduleId !== 'mrrc'
                  "
                >
                  <i class="el-icon-delete-solid" @click="deleteSchedule"></i>
                </el-tooltip>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="18">
            <el-row>
              <div class="formTitle">{{ activeSchedule.scheduleName }}</div>
              <el-divider></el-divider>
              <el-form
                :disabled="activeSchedule.scheduleId === 'mrrc'"
                ref="scheduleTime"
                :model="activeSchedule"
              >
                <el-form-item label="星期一">
                  <el-time-picker
                    :clearable="false"
                    is-range
                    v-model="activeSchedule.monday"
                    range-separator="至"
                    start-placeholder="开始时间"
                    end-placeholder="结束时间"
                    placeholder="选择时间范围"
                    value-format="HH:mm:ss"
                  >
                  </el-time-picker>
                </el-form-item>
                <el-form-item label="星期二">
                  <el-time-picker
                    :clearable="false"
                    is-range
                    v-model="activeSchedule.tuesday"
                    range-separator="至"
                    start-placeholder="开始时间"
                    end-placeholder="结束时间"
                    placeholder="选择时间范围"
                    value-format="HH:mm:ss"
                  >
                  </el-time-picker>
                </el-form-item>
                <el-form-item label="星期三">
                  <el-time-picker
                    :clearable="false"
                    is-range
                    v-model="activeSchedule.wednesday"
                    range-separator="至"
                    start-placeholder="开始时间"
                    end-placeholder="结束时间"
                    placeholder="选择时间范围"
                    value-format="HH:mm:ss"
                  >
                  </el-time-picker>
                </el-form-item>
                <el-form-item label="星期四">
                  <el-time-picker
                    :clearable="false"
                    is-range
                    v-model="activeSchedule.thursday"
                    range-separator="至"
                    start-placeholder="开始时间"
                    end-placeholder="结束时间"
                    placeholder="选择时间范围"
                    value-format="HH:mm:ss"
                  >
                  </el-time-picker>
                </el-form-item>
                <el-form-item label="星期五">
                  <el-time-picker
                    :clearable="false"
                    is-range
                    v-model="activeSchedule.friday"
                    range-separator="至"
                    start-placeholder="开始时间"
                    end-placeholder="结束时间"
                    placeholder="选择时间范围"
                    value-format="HH:mm:ss"
                  >
                  </el-time-picker>
                </el-form-item>
                <el-form-item label="星期六">
                  <el-time-picker
                    :clearable="false"
                    is-range
                    v-model="activeSchedule.saturday"
                    range-separator="至"
                    start-placeholder="开始时间"
                    end-placeholder="结束时间"
                    placeholder="选择时间范围"
                    value-format="HH:mm:ss"
                  >
                  </el-time-picker>
                </el-form-item>
                <el-form-item label="星期天">
                  <el-time-picker
                    :clearable="false"
                    is-range
                    v-model="activeSchedule.sunday"
                    range-separator="至"
                    start-placeholder="开始时间"
                    end-placeholder="结束时间"
                    placeholder="选择时间范围"
                    value-format="HH:mm:ss"
                  >
                  </el-time-picker>
                </el-form-item>
              </el-form>

              <div class="dialog-footer" style="text-align: right">
                <el-button
                  type="primary"
                  v-if="activeSchedule.scheduleId !== 'mrrc'"
                  @click="submitScheduleTime"
                  >保 存</el-button
                >
                <el-button @click="scheduleTimeOpen = false">取 消</el-button>
              </div>
            </el-row>
          </el-col>
        </el-row>
        <el-dialog
          title="添加日程"
          append-to-body
          :visible.sync="addScheduleDialogOpen"
        >
          <el-form
            :model="addSchedule"
            :rules="addScheduleRules"
            ref="addScheduleForm"
          >
            <el-form-item label="日程名称" prop="scheduleName">
              <el-input
                v-model="addSchedule.scheduleName"
                type="text"
              ></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="submitAddScheduleForm"
              >确 定</el-button
            >
            <el-button @click="addScheduleDialogOpen = false">取 消</el-button>
          </div>
        </el-dialog>
      </el-dialog>
    </el-dialog>
  </div>
</template>
<script>
import {
  modelTree,
  lastestImage,
  channelAndPreset,
  selectIotParaTemplateForCoorList,
  deleteParaValueByLinkId,
  selectIotParaTemplateForAreaWithoutCoorList,
  updateAddParaValue,
  scheduleList,
  addSchedule,
  editSchedule,
  deleteSchedule,
  selectListById,
  updateParaValue, selectParamValue,
} from "@/api/config/areaDraw";
const colors = [
  "#2ecc71",
  "#00bbd9",
  "#e74a25",
  "#ffb136",
  "#0283cc",
  "#e6f78f",
  "#b3424a",
  "#845538",
  "#c77eb5",
  "#dea32c",
  "#76becc",
];

export default {
  dicts: ["sys_alarm_level"],
  data() {
    return {
      valueType: "",
      selectListByIdOne: [],
      maxNum: 5000,
      modelOption: undefined,
      modelName: undefined,
      defaultProps: {
        children: "children",
        label: "label",
      },
      chooseDevice: undefined,
      basicPath: process.env.VUE_APP_BASE_API,
      lastestImagePic: {
        imageName: undefined,
        imageUri: undefined,
      },
      picCanvas: undefined, //canvas
      ctx: undefined, //画笔
      points: [],
      pointsArr: [],
      w: undefined, //高度
      channelAndPresetValue: undefined,
      channelAndPresetOptions: [],
      loading: false,
      drawList: [],
      open: false,
      chooseCoorItem: undefined,
      coorList: [],
      coe: undefined,
      disabled: false,
      linkId: undefined,
      img: undefined,
      cascaderKey: 0,
      //由于没有字典模块先写死
      alarmLevelList: [
        { label: "一级告警", value: "0" },
        { label: "二级告警", value: "2" },
        { label: "三级告警", value: "3" },
        { label: "四级告警", value: "4" },
        { label: "五级告警", value: "5" },
      ],
      scheduleTimeOpen: false,
      scheduleListArr: [],
      activeSchedule: {},

      addScheduleDialogOpen: false,
      addSchedule: {
        scheduleName: undefined,
        monday: "00:00:00-23:59:59",
        thursday: "00:00:00-23:59:59",
        wednesday: "00:00:00-23:59:59",
        tuesday: "00:00:00-23:59:59",
        friday: "00:00:00-23:59:59",
        saturday: "00:00:00-23:59:59",
        sunday: "00:00:00-23:59:59",
      },
      addScheduleRules: {
        scheduleName: [
          { required: true, trigger: "change", message: "请输入日程名称" },
        ],
      },
      //防止里面的新增影响外面的下拉，重新赋值一遍
      scheduleListArr1: [],
      img1:''
    };
  },
  watch: {
    // 根据名称筛选树
    modelName(val) {
      this.$refs.tree.filter(val);
    },
    open(val) {
      if (!val) {
        this.cancel();
        this.selectIotParaTemplateForCoorList();
      }
    },
  },
  created() {
    this.modelTree();
  },
  mounted() {
    this.img = this.$refs.drawImg;
  },
  destroyed() {
    this.picCanvas = null;
    this.ctx = null;
  },
  methods: {
    //布控时间
    previewTime() {
      // let item = {...this.scheduleListArr[0]}
      // this.activeSchedule = this.initActive(item);

      this.activeSchedule = this.initActive(this.scheduleListArr1[0]);
      this.scheduleTimeOpen = true;
    },
    initActive(arr) {
      arr.monday =
        typeof arr.monday === "string" ? arr.monday.split("-") : arr.monday;
      arr.thursday =
        typeof arr.thursday === "string"
          ? arr.thursday.split("-")
          : arr.thursday;
      arr.wednesday =
        typeof arr.wednesday === "string"
          ? arr.wednesday.split("-")
          : arr.wednesday;
      arr.tuesday =
        typeof arr.tuesday === "string" ? arr.tuesday.split("-") : arr.tuesday;
      arr.friday =
        typeof arr.friday === "string" ? arr.friday.split("-") : arr.friday;
      arr.saturday =
        typeof arr.saturday === "string"
          ? arr.saturday.split("-")
          : arr.saturday;
      arr.sunday =
        typeof arr.sunday === "string" ? arr.sunday.split("-") : arr.sunday;
      return arr;
    },
    chooseActive(index) {
      // let item = {...this.scheduleListArr[index]}
      // this.activeSchedule = this.initActive(item);
      this.activeSchedule = this.initActive(this.scheduleListArr1[index]);
    },
    addScheduleDialog() {
      this.addScheduleDialogOpen = true;
      this.addSchedule.scheduleName = "日程" + this.scheduleListArr1.length;
    },
    submitAddScheduleForm() {
      this.$refs["addScheduleForm"].validate((valid) => {
        if (valid) {
          let item = { ...this.addSchedule };
          this.scheduleListArr1.push(item);
          this.activeSchedule = this.initActive(item);
          this.addScheduleDialogOpen = false;
        }
      });
    },
    submitScheduleTime() {
      this.$modal.confirm("确认保存").then(() => {
        let params = { ...this.activeSchedule };
        params.monday = params.monday.join("-");
        params.tuesday = params.tuesday.join("-");
        params.wednesday = params.wednesday.join("-");
        params.thursday = params.thursday.join("-");
        params.friday = params.friday.join("-");
        params.saturday = params.saturday.join("-");
        params.sunday = params.sunday.join("-");
        if (params.scheduleId) {
          //修改
          editSchedule(params).then((res) => {
            this.$modal.msgSuccess("操作成功");
            this.scheduleTimeOpen = false;
            this.scheduleList();
          });
        } else {
          //新增
          addSchedule(params).then((res) => {
            this.$modal.msgSuccess("操作成功");
            this.scheduleTimeOpen = false;
            this.scheduleList();
          });
        }
      });
    },
    deleteSchedule() {
      this.$modal.confirm("确认删除该日程").then(() => {
        deleteSchedule(this.activeSchedule.scheduleId).then((res) => {
          this.$modal.msgSuccess("操作成功");
          this.scheduleList();
          this.activeSchedule = this.initActive(this.scheduleListArr1[0]);
        });
      });
    },
    initCanvas() {
      this.picCanvas = this.$refs.picCanvas;
      this.ctx = this.picCanvas.getContext("2d");
    },
    toInteger(val) {
      let reg = /^[0-9]+$/;
      if (!reg.test(val)) {
        this.$message.warning("只能输入整数排序");
        // 用以在dom渲染挂载后重新触发dom渲染挂载
        this.$nextTick(() => {
          val = parseInt(val);
        });
      }
    },
    initMax(label) {
      return (
        {
          重复告警间隔: 21600,
          消警间隔: 7200,
          告警间隔: 86400,
        }[label] || 3000
      );
    },

    modelTree() {
      modelTree().then((res) => {
        this.modelOption = res.data;
        this.defaultFirstTreeNode();
      });
    },
    //默认选取第一个
    defaultFirstTreeNode() {
      let firstTreeNode = undefined;
      if (this.modelOption.length > 0) {
        firstTreeNode = this.checkHaveChildren(this.modelOption[0]);
      }
      this.handleNodeClick(firstTreeNode);
    },
    //判断是否有children
    checkHaveChildren(obj) {
      if (obj.hasOwnProperty("children")) {
        return this.checkHaveChildren(obj.children[0]);
      } else {
        return obj;
      }
    },
    // 筛选节点
    filterNode(value, data) {
      if (!value) return true;
      return data.label.indexOf(value) !== -1;
    },
    // 节点单击事件
    handleNodeClick(data) {
      console.log("data.id===", data.id);
      // if (!data.devNode) {
      //   return;
      // }
      this.chooseDevice = data.id;
      this.channelAndPreset(data.id);
    },
    //递归删除children
    deleteChildren(arr) {
      let childs = arr;
      for (let i = childs.length; i--; i > 0) {
        if (childs[i].children) {
          if (childs[i].children.length) {
            this.deleteChildren(childs[i].children);
          } else {
            delete childs[i].children;
          }
        }
      }
      return arr;
    },
    //获取通道号预置位
    channelAndPreset() {
      // this.channelAndPresetOptions = [];
      channelAndPreset(this.chooseDevice).then((res) => {
        // this.channelAndPresetOptions = res.data;
        let arrNew = this.deleteChildren(res.data);
        this.channelAndPresetOptions = arrNew;
        //此处因为通道modelClassId不是所需channel的值，重新赋值
        // this.channelAndPresetOptions[0].modelClassId =
        //   this.channelAndPresetOptions[0].params.channelNo;
        // this.cascaderKey++;
        // debugger
        // this.channelAndPresetValue = [
        //   this.channelAndPresetOptions[0].params.channelNo,
        //   this.channelAndPresetOptions[0].children[0].modelClassId,
        // ];
        this.channelAndPresetValue = [
          this.channelAndPresetOptions[0].id,
          this.channelAndPresetOptions[0].children[0].id,
        ];
        this.resetCanvas();
        this.lastestImage();
      });
    },
    resetCanvas() {
      this.pointsArr = [];
      this.initCanvas();
    },
    //查询绘制坐标
    selectIotParaTemplateForCoorList() {
      this.loading = true;
      // c15ebfa7d0ca4b83ad71751f9ee7308b
      selectIotParaTemplateForCoorList(this.channelAndPresetValue[1]).then(
        (res) => {
          this.loading = false;
          this.drawList = res.rows;
          this.pointsArr = [];
          // for (let i = 0; i < this.drawList.length; i++) {
          //   // if (this.drawList[i].value == "-1;-1") {
          //   //   continue;
          //   // }
          //   let arr = JSON.parse(this.drawList[i].value);
          //   let arr1 = [];
          //   for (let i = 0; i < arr.length; i++) {
          //     arr1.push({ x: arr[i][0] * this.coe, y: arr[i][1] * this.coe });
          //   }
          //   this.pointsArr.push(arr1);
          // }
          this.drawPolygon([]);
        }
      );
    },
    lastestImage() {
      //console.log(this.channelAndPresetValue);
      lastestImage(
        {
          ipcId:1,
          chanelId:this.channelAndPresetValue[0],
          presetId:this.channelAndPresetValue[1]
      //   deviceId: this.chooseDevice,
      //   channelId: this.channelAndPresetValue[0],
      //   presetId: this.channelAndPresetValue[1],
      }
      ).then((res) => {
        this.lastestImagePic = res.data;
        // this.coe = this.picCanvas.height / this.lastestImagePic.imageHeight;
        // this.w = this.coe * this.lastestImagePic.imageWidth;
        // this.picCanvas.width = this.w;
        this.img.src = 'data:image/jpg;base64,'+res.data
        this.$forceUpdate()
        // console.log('this.img.src===',this.img.src);
          // this.basicPath +
          // "/iot/image/" +
          // this.lastestImagePic.imageName +
          // "?imageUri=" +
          // this.lastestImagePic.thumbnailUri;
          // setTimeout(()=>{

          // },3000)
        this.img.onload = () => {
          this.selectIotParaTemplateForCoorList();

        };
      });

    },
    deleteParaValueByLinkId(id) {
      deleteParaValueByLinkId(id).then((res) => {
        this.$message.success("删除成功");
        this.selectIotParaTemplateForCoorList();
      });
    },
    //修改
    editParaValueById(item) {
      this.selectIotParaTemplateForAreaWithoutCoorList(item);
    },
    //默认选择第一项隐患配置
    defaultChooseFirstCoor() {
      this.chooseCoor(this.coorList[0].paraId);
      // console.log("this.coorList[0].paraId", this.coorList[0].paraId);
      this.valueType = this.coorList[0];
      this.selectListById(this.coorList[0].paraId);
    },
    //根据检测类型paraId查询参数列表
    selectListById(id) {
      this.paramsId = {
        paraId: id,
      };
      selectListById(this.paramsId).then((res) => {
        if (res.code == 200) {
          // debugger
          this.selectListByIdOne = res.data;
        }
      });
    },
    changeItem(value) {
      console.log("changeItem", value);
      this.chooseCoor(value.paraId);
    },
    chooseCoor(paraId) {
      this.selectListById(paraId);
    },
    renderContent(h, { node, data, store }) {
      return (
        <span class="custom-tree-node">
          <span>{node.label}</span>
        </span>
      );
    },
    submitForm: function () {
      console.log("selectListByIdOne====", this.selectListByIdOne);
      console.log("=============", this.valueType);
      // let params = {
      //   paraName: this.valueType.label,
      //   child: this.selectListByIdOne,
      //   id: this.channelAndPresetValue[1],
      //   paraId: this.valueType.paraId,
      //   paraParentId: this.valueType.paraParentId,
      //   paraValue: "[[-1,-1]]",
      // };
      // updateAddParaValue(params).then((res) => {
      //   this.$message.success("成功");
      //   this.open = false;
      // });

      if (this.disabled) {
        //修改
        let params = {
          paraName: this.valueType.label,
          child: this.selectListByIdOne,
          id: this.channelAndPresetValue[1],
          paraId: this.valueType.paraId,
          paraParentId: this.valueType.paraParentId,
          paraValue: "[[-1,-1]]",
        };
        updateParaValue(params).then((res) => {
          this.$message.success("修改成功");
          this.open = false;
        });
      } else {
        //新增或者整体绘制
        let pointsArr = [];
        for (let i = 0; i < this.points.length; i++) {
          pointsArr.push([
            Math.round(this.points[i].x ),
            Math.round(this.points[i].y ),
          ]);
        }
        let params = {
          paraName: this.valueType.label,
          paraKey: this.valueType.paraKey,
          child: this.selectListByIdOne,
          id: this.channelAndPresetValue[1],
          paraId: this.valueType.paraId,
          paraParentId: this.valueType.paraParentId,
          paraValue: pointsArr.length ? JSON.stringify(pointsArr) : "[[-1,-1]]",
        };
        updateAddParaValue(params).then((res) => {
          this.$message.success("新增成功");
          this.open = false;
        });
      }
    },
    cancel() {
      this.coorList = undefined;
      this.chooseCoorItem = undefined;
      this.points = [];
      this.disabled = false;
    },
    drawImg() {
      this.ctx.drawImage(
        this.img,
        0,
        0,
        this.picCanvas.width,
        this.picCanvas.height
      );
    },
    drawLine(event) {
      // debugger
      this.points.push({
        x: event.offsetX,
        y: event.offsetY,
      });
      this.drawPolygon(this.points);
    },
    mousemoveHandler(event) {
      this.drawPolygon(
        this.points.concat({
          x: event.offsetX,
          y: event.offsetY,
        })
      );
    },
    drawPolygon(points) {
      // debugger
      this.ctx.clearRect(0, 0, this.w, 350);
      this.drawImg();
      var colorLength = colors.length;
      if (this.pointsArr.length > 0) {
        this.pointsArr.forEach((item, index) => {
          this.ctx.beginPath();
          this.ctx.strokeStyle = colors[index % colorLength];
          this.ctx.moveTo(item[0].x, item[0].y);
          for (var i = 1; i < item.length; i++) {
            this.ctx.lineTo(item[i].x, item[i].y);
          }
          this.ctx.closePath();
          this.ctx.stroke();
        });
      }
      if (points.length > 0) {
        // debugger
        this.ctx.beginPath();
        this.ctx.strokeStyle = colors[this.pointsArr.length % colorLength];
        this.ctx.moveTo(points[0].x, points[0].y);
        for (var i = 1; i < points.length; i++) {
          this.ctx.lineTo(points[i].x, points[i].y);
        }
        this.ctx.closePath();
        this.ctx.stroke();
      }
    },
    mousedownHandler(event) {
      // debugger
      if (event.button == 0) {
        this.drawLine(event);
      } else if (event.button === 2) {
        if (this.points.length >= 2) {
          // debugger
          this.drawLine(event);
          this.selectIotParaTemplateForAreaWithoutCoorList();
        }
      }
    },
    //整体绘制
    drawAll() {
      this.selectIotParaTemplateForAreaWithoutCoorList();
      // this.scheduleList();
    },
    //
    selectIotParaTemplateForAreaWithoutCoorList(item) {
      // debugger;
      let linkId = (item && item.paraId) || undefined;
      selectIotParaTemplateForAreaWithoutCoorList(linkId).then((res) => {
        this.open = true;
        this.coorList = this.handleTree(res.data, "paraId", "paraParentId");
        //  debugger
        if (item) {
          this.disabled = true;
          this.linkId = linkId;
          this.valueType = item;
          this.selectListByIdOne = item;
          this.chooseCoor(item.paraId);
          return;
          // deubgger
          // for (let i = 0; this.coorList.length; i++) {
          //   if (item.paraId == this.coorList[i].paraId) {
          //     this.selectListByIdOne = item;
          //     return;
          //   }
          // }
        }
        this.defaultChooseFirstCoor();
      });
    },
    scheduleList() {
      scheduleList().then((res) => {
        this.scheduleListArr = res.rows;
        this.scheduleListArr1 = [...this.scheduleListArr];
      });
    },
    initColor(rowIndex) {
      let background = colors[rowIndex % colors.length];
      return background;
    },
    // //行背景色
    // TableRowStyle({ row, column, rowIndex, columnIndex }) {
    //   // 注意，这里返回的是一个对象
    //   let rowBackground = {};
    //   if (columnIndex == 0) {
    //     rowBackground.background = colors[rowIndex % colors.length];
    //     return rowBackground;
    //   }
    // },
  },
};
</script>
<style scoped>
.device {
  color: #8d8e91;
}
.block {
  display: inline-block;
  margin-left: 15px;
  vertical-align: top;
}
.wrap {
  display: flex;
  box-shadow: 0 0 5px #909399;
  padding: 15px;
}
::v-deep .previewTime .el-button {
  width: 100px !important;
  margin-bottom: 8px;
}
::v-deep .operator .el-tooltip {
  cursor: pointer;
}
::v-deep .operator .el-icon-circle-plus {
  color: #67c23a;
}
::v-deep .operator .el-icon-delete-solid {
  color: #f56c6c;
}
.formTitle {
  font-size: 18px;
  font-weight: bolder;
}
#areaDraw {
  min-width: 1300px;
  display: flex;
  padding: 20px;
}
</style>
<style>
#areaDraw .el-input {
  /* margin-left: 10px; */
  width: 160px;
}
.tipsIcon:before {
  font-size: 18px;
}
.devTree {
  height: calc(100vh - 170px);
  overflow: auto;
}
.devTree::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
.tableIndex {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 12px;
}
</style>

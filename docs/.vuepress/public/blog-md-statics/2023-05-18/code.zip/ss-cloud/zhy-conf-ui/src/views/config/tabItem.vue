<script>
import render from "./render";

export default {
  components: {
    render
  },
  props: ["element", "index", "list"],
  render(h) {
    return this.colFormItem(h, this.element, this.index, this.list);
  },
  // <svg-icon icon-class="question" />
  methods: {
    colFormItem(h, element) {
      // console.log("this.element", element);
      return (
        <el-col>
          <el-form-item label-width="200px" label={element.label}>
            <render
              key={element.paraKey}
              conf={element}
              onInput={(event) => {
                this.$set(element, "paraValue", event);
              }}
            />
            <el-tooltip
              class="item"
              effect="dark"
              content={element.helpMsg}
              placement="left-start"
              style="margin-left:15px"
            >
            <i class="el-icon-question" style="font-size: 18px;" />
            </el-tooltip>
            <el-button
              type="primary"
              style="margin-left:25px"
              onClick={(e) => {
                this.$emit("submit", element);
              }}
            >
              提交
            </el-button>
          </el-form-item>
        </el-col>
      );
    },
  },
};
</script>

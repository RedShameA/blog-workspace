<template>
  <div class="app-container">
    <el-row>
      <el-form label-width="200px">
        <tab-item
          v-for="(element, index) in list"
          :key="element.paraKey"
          :list="list"
          :element="element"
          :index="index"
          @submit="submit"
        />
        <div class="footer fl">
          <el-button
            type="primary"
            style="margin-left: 25px"
            @click="submit('')"
          >
            全部提交
          </el-button>
        </div>
      </el-form>
    </el-row>
  </div>
</template>
<script>
import TabItem from "./tabItem";
import { selectSysList, updateSysEdit } from "@/api/config/sysConfig";
export default {
  components: {
    TabItem,
  },
  data() {
    return {
      list: [],
    };
  },

  created() {
    this.selectSysList();
  },
  methods: {
    selectSysList() {
      selectSysList().then((res) => {
        this.list = res.data;
        // this.list[0].value = this.list[0].paraValue
        // this.list[0].tag = 'el-input'
      });
    },
    updateParaValue(params) {
      if (params) {
        updateSysEdit(params).then((res) => {
          this.$message.success("提交成功");
        });
      } else {
        updateSysEdit({
          list: this.list,
        }).then((res) => {
          this.$message.success("提交成功");
        });
      }
    },
    submit(e) {
      // this.$modal.confirm("是否确认？").then(() => {
      this.updateParaValue(e);
      // });
    },
  },
};
</script>
<style scoped>
.footer {
  text-align: center;
  margin-top: 20px;
  width: 100%;
}
</style>

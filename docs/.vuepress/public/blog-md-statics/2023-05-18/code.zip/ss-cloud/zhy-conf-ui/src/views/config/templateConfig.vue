<template>
  <div class="templateConfig">
    <div class="btns" style="margin-bottom: 2vh">
      <el-button
        type="primary"
        icon="el-icon-plus"
        size="small"
        @click="addRow()"
        >新 增</el-button
      >
    </div>
    <el-table :data="dataList" class="table-fixed" style="width: 100%">
      <el-table-column prop="paraId" label="参数ID" width="100">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.paraId"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="paraParentId" label="参数父ID" width="100">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.paraParentId"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="paraKey" label="参数key" width="130">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.paraKey"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="label" label="参数名" width="130">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.label"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="tag" label="参数类型" width="130">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.tag"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="paraOrd" label="排序" width="80">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.paraOrd"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="required" label="是否必须" width="80">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.required"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="validate" label="验证方式" width="130">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.validate"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="unit" label="单位" width="80">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.unit"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="helpMsg" label="参数信息" width="130">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.helpMsg"
            :disabled="!(scope.row.isEdit || scope.row.isAdd)"
          />
        </template>
      </el-table-column>
      <el-table-column
        prop="capitalAmount"
        align="center"
        label="操作"
        width="120"
      >
        <template slot-scope="scope">
          <el-button
            @click="saveNew(scope.row)"
            v-show="scope.row.isAdd"
            type="text"
            size="small"
            icon="el-icon-edit"
            >保存(新增)</el-button
          >
          <el-button
            @click="deleteRow(scope.$index)"
            v-show="scope.row.isAdd"
            type="text"
            size="small"
            icon="el-icon-delete"
            >取消(新增)</el-button
          >
          <el-button
            @click="update(scope.row)"
            v-show="scope.row.isEdit"
            type="text"
            size="small"
            icon="el-icon-edit"
            >保存(修改)</el-button
          >
          <el-button
            @click="cancel(scope.row)"
            v-show="scope.row.isEdit"
            type="text"
            size="small"
            icon="el-icon-delete"
            >取消(修改)</el-button
          >
          <el-button
            @click="edit(scope.row)"
            v-show="!scope.row.isEdit && !scope.row.isAdd"
            type="text"
            size="small"
            icon="el-icon-edit"
            >编辑</el-button
          >
          <el-button
            @click="deleteRows(scope.row.paraId)"
            v-show="!scope.row.isEdit && !scope.row.isAdd"
            type="text"
            size="small"
            icon="el-icon-edit"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      background
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      :total="total"
      @pagination="getList"
    >
    </pagination>
  </div>
</template>

<script>
import {
  paraTemplate,
  addParaTemplate,
  delParaTemplate,
  updateParaTemplate
} from "@/api/config/sysConfig";
export default {
  data() {
    return {
      dataList: [],
      total: 0,
      queryParams: {
        pageNum: 1,
        pageSize: 10,
      },
    };
  },
  created() {
    this.getList();
  },
  methods: {
    getList() {
      paraTemplate(this.queryParams).then((res) => {
        if (res.code == 200) {
          this.dataList = res.rows;
          this.total = res.total
        }
      });
    },
    addRow() {
      let row = {
        isEdit: false,
        isAdd: true,
      };
      this.dataList.push(row);
    },
    //新增取消 - 删除行
    deleteRow(index) {
      this.dataList.splice(index, 1);
    },
    //修改取消
    cancel(row) {
      row.isEdit = false;
    },
    edit(row) {
      // debugger
      // this.$nextTick(()=>{
      this.$set(row, "isEdit", true);
      // row.isEdit = true;
      // this.$forceUpdate()
      // })
    },
    saveNew(row) {
      row.isEdit = false;
      row.isAdd = false;
      //保存逻辑
      addParaTemplate(row).then((res) => {
        if (res.code == 200) {
          this.$message.success('保存成功')
        }
      });
    },
    update(row) {
      row.isEdit = false;
      //修改逻辑
      updateParaTemplate(row).then((res) => {
        if(res.code == 200) {
          this.$message.success('保存成功')
        }
      })
    },
    //删除行
    deleteRows(id) {
      delParaTemplate(id).then((res) => {
        if (res.code == 200) {
          // console.log("CHENGGONG");
          this.$message.success('删除成功')
          this.getList();
        }
      });
    },
  },
};
</script>
<style lang="scss">
.templateConfig {
  padding: 20px;
  td {
    padding: 0 !important;
  }
}
.el-input.is-disabled .el-input__inner {
  background-color: #fff !important;
  border-color: #e4e7ed;
  color: #c0c4cc;
  cursor: not-allowed;
}
.el-input__inner {
  border: 0px solid #dcdfe6 !important;
}
.pagination-container {
  float: right;
}
/* /deep/ */
</style>

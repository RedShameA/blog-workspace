import request from '@/util/request';
//列表
export function paraTemplate(params) {
  return request({
    url: '/api/paraTemplate/selectList',
    method: 'get',
    params: params
  })
}
// 新增
export function addParaTemplate(data) {
  return request({
    url: '/api/paraTemplate',
    method: 'post',
    data: data
  })
}
//删除
export function delParaTemplate(paraId) {
  return request({
    url: '/api/paraTemplate/' + paraId,
    method: 'delete'
  })
}

//修改
export function updateParaTemplate(data) {
  return request({
    url: '/api/paraTemplate',
    method: 'put',
    data: data
  })
}
//系统配置
//列表
export function selectSysList(params) {
  return request({
    url: '/api/paraTemplate/selectSysList',
    method: 'get',
    params: params
  })
}
//更新
export function updateSysEdit(data) {
  return request({
    url: '/api/paraTemplate/sysEdit',
    method: 'put',
    data: data
  })
}

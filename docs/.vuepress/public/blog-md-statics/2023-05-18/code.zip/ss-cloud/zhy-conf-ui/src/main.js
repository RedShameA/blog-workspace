import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
// 分页组件
import Pagination from "@/components/Pagination";

import { parseTime, resetForm, addDateRange, selectDictLabel, selectDictLabels, handleTree, getColorRandom, initD } from "@/util/zhy";
Vue.use(ElementUI);

//全局挂载组件
Vue.component('Pagination', Pagination)
Vue.prototype.handleTree = handleTree
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

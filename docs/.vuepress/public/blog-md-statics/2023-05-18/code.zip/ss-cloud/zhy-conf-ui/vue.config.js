const { defineConfig } = require('@vue/cli-service')
// const port = 9401 // 端口
const path = require('path')
function resolve(dir) {
  return path.join(__dirname, dir)
}

module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave: false,
  devServer: {
    host: '0.0.0.0',
    port: 9401,
    proxy: {
      // detail: https://cli.vuejs.org/config/#devserver-proxy
      ['/api']: {
        target:`http://192.168.1.69:9401`, 
        changeOrigin: true,
        pathRewrite: {
          ['^' + '/api']: ''
        }
      },
  }
},
configureWebpack: {
  name: '',
  resolve: {
    alias: {
      '@': resolve('src')
    }
  }
},

})

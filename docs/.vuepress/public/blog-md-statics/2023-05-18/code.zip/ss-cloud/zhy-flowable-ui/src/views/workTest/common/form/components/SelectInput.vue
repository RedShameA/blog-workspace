<template>
  <div>
    <div v-if="mode === 'DESIGN'">
      <el-select class="max-fill" v-if="!expanding" size="medium" v-model="_value" disabled :placeholder="placeholder"/>
      <el-radio-group v-model="_value" v-else>
        <el-radio disabled v-for="(op, index) in options" :key="index" :label="op.value">{{op.label}}</el-radio>
      </el-radio-group>
    </div>
    <div v-else>
      <el-select class="max-fill" v-if="!expanding" v-model="_value" size="medium" clearable :placeholder="placeholder">
        <el-option v-for="(op, index) in options" :key="index" :value="op.value" :label="op.label"></el-option>
      </el-select>
      <el-radio-group v-model="_value" v-else>
        <el-radio v-for="(op, index) in options" :key="index" :label="op.value">{{op.label}}</el-radio>
      </el-radio-group>
    </div>
  </div>
</template>

<script>
import componentMinxins from '../ComponentMinxins'
import { getDicts } from "@/api/system/dict/data";
export default {
  mixins: [componentMinxins],
  name: "SelectInput",
  components: {},
  props:{
    value:{
      type: String,
      default: null
    },
    placeholder:{
      type: String,
      default: '请选择选项'
    },
    expanding:{
      type: Boolean,
      default: false
    },
    dataFrom: {
      type: Number,
      default: 1,
    },
    optionselectType: {
      type: String,
      default: "",
    },
    options:{
      type:Array,
      default(){
        return []
      }
    }
  },
  data() {
    return {
    }
  },
  created() {
    this.init();
  },
  methods: {
    init() {
      if (this.dataFrom === 1 && this.optionselectType) {
        getDicts(this.optionselectType).then((res) => {
          this.options = res.data.map((r) => {
            return { label: r.dictLabel, value: r.dictValue };
          });
        });
      }
    },
  }
}
</script>

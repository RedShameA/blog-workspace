import request from '@/utils/request.js'


// 查询组织架构树
export function getOrgTree(param) {
  return request({
    url: 'flowable/oa/org/tree',
    method: 'get',
    params: param
  })
}

// 查询系统角色
export function getRole() {
  return request({
    url: 'flowable/oa/org/role',
    method: 'get'
  })
}

// 搜索人员
export function getUserByName(param) {
  return request({
    url: 'flowable/oa/org/tree/search',
    method: 'get',
    params: param
  })
}

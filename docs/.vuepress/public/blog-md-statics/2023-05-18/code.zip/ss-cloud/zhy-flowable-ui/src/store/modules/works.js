const works = {
  state: {
    design: {},
    selectedNode: {},
    nodeMap: new Map(),
    selectFormItem: null,
    isEdit: null,
    runningList: [],
    noTakeList: [],
    endList: [],
  },

  mutations: {
    selectedNode(state, val) {
      state.selectedNode = val
    },
    loadForm(state, val){
      state.design = val
    },
    setIsEdit(state, val){
      state.isEdit = val
    }
  },

  actions: {
  }
}

export default works

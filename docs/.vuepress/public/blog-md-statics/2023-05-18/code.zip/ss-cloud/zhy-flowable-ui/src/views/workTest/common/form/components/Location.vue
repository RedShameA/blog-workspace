<template>

</template>

<script>
export default {
  name: "Location",
  components: {},
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>

<template>
  <div class="senior-setup">
    <!-- 高级设置 -->
    <el-tabs tab-position="left">
      <el-tab-pane label="数据展示设置">
        <div>数据展示设置</div>
        <el-divider></el-divider>
        <el-form label-position="top" label-width="80px">
          <!--  <el-form-item label="审批同意时是否签字">-->
          <!--    <el-switch inactive-text="无需签字" active-text="需要签字"-->
          <!--               v-model="setup.sign"></el-switch>-->
          <!--    <div class="sign-tip">如果此处设置为 <b>需要签字</b>，则所有审批人“同意时” <b>必须签字</b></div>-->
          <!--  </el-form-item>-->
          <!--  {starter} {startTime} {processName} 以及 {流程表单id} -->
          <el-form-item label="标题设置">
            <el-radio-group
              v-model="setup.titleSetting"
              @change="titleSettingChange"
            >
              <el-radio :label="1">默认</el-radio>
              <el-radio :label="2">自定义模式</el-radio>
            </el-radio-group>
            <el-select
              v-model="setup.titleExpr"
              multiple
              filterable
              allow-create
              :disabled="setup.titleSetting === 1"
              default-first-option
              placeholder="请选择标签"
              style="display: block"
            >
              <el-option
                v-for="item in titleOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
            <div class="sign-tip">可在输入框中输入文字来创建新的条目</div>
          </el-form-item>
          <!--  失去焦点事件会设置此项（建议限制只能选择5个， 多了性能会有问题、前端展示也不好看） -->
          <el-form-item label="摘要设置">
            <el-select
              size="small"
              placeholder="请选择摘要展示"
              multiple
              v-model="setup.descExpr"
              :multiple-limit="5"
              style="display: block"
            >
              <el-option
                v-for="(condition, cindex) in conditionList"
                :label="condition.title"
                :key="condition.id"
                :value="condition.id"
              ></el-option>
            </el-select>
            <div class="sign-tip">此处最多设置五项</div>
            <!-- <el-input
              type="textarea"
              :autosize="{ minRows: 2 }"
              placeholder="摘要设置"
              v-model="ttt"
            /> -->
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <!-- <el-tab-pane label="配置管理">配置管理</el-tab-pane> -->
      <!-- <el-tab-pane label="角色管理">角色管理</el-tab-pane>
      <el-tab-pane label="定时任务补偿">定时任务补偿</el-tab-pane> -->
    </el-tabs>
  </div>
</template>

<script>
import { spawn } from "child_process";
import { ValueType } from "@/views/workTest/common/form/ComponentsConfigExport";
export default {
  name: "FormProSetting",
  computed: {
    setup() {
      return this.$store.state.works.design.settings;
    },
    formItems() {
      return this.$store.state.works.design.formItems;
    },
    conditionList() {
      //构造可用条件选项
      const conditionItems = [];
      this.formItems.forEach((item) =>
        this.filterCondition(item, conditionItems)
      );
      return conditionItems;
    },
  },
  data() {
    return {
      ttt: "",
      titleValues: [],
      supportTypes: [
        ValueType.number,
        ValueType.string,
        ValueType.date,
        ValueType.dept,
        ValueType.user,
      ],
      titleOptions: [
        {
          value: "#{starter}",
          label: "创建人",
        },
        {
          value: "#{startTime}",
          label: "创建时间",
        },
        {
          value: "#{processName}",
          label: "表单名称",
        },
      ],
    };
  },
  methods: {
    filterCondition(item, list) {
      if (item.name === "SpanLayout") {
        item.props.items.forEach((sub) => this.filterCondition(sub, list));
      } else if (
        this.supportTypes.indexOf(item.valueType) > -1 &&
        item.props.required
      ) {
        list.push({
          title: item.title,
          id: item.id,
          valueType: item.valueType,
        });
      }
    },
    titleSettingChange() {
      if (this.setup.titleSetting === 1) {
        this.setup.titleExpr = ["#{starter}", "的", "#{processName}"];
      } else {
        this.setup.titleExpr = [];
      }
    },
    // descChange(str) {
    //   let array = new Array();
    //   this.$store.state.works.design.formItems.forEach((item) => {
    //     array.push(item.id);
    //   });

    //    = array;
    //   console.log(this.$store.state.works.design.settings.descExpr);
    //   this.ttt = array.join(",");
    // },
    validate() {
      return [];
    },
  },
};
</script>

<style lang="less" scoped>
.senior-setup {
  overflow: auto;
  margin: 0 auto;
  width: 800px;
  height: calc(100vh - 105px);
  background: #ffffff;
  margin-top: 10px;
  padding: 15px 20px;

  .sign-tip {
    color: #949495;
    font-size: small;
    margin-left: 20px;
  }
}
</style>

<template>

</template>

<script>
export default {
  name: "MoneyInput",
  components: {},
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>

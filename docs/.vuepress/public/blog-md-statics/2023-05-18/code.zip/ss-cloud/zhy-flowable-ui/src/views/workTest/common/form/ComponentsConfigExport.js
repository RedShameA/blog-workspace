export const ValueType = {
  string: 'String',
  object: 'Object',
  array: 'Array',
  number: 'Number',
  date: 'Date',
  user: 'User',
  dept: 'Dept',
  dateRange: 'DateRange'
}

export const baseComponents = [
  {
    name: '布局控件',
    components: [
      {
        title: '分栏',
        name: 'SpanLayout',
        icon: 'iconfont icon-fenlan',
        value: [],
        valueType: ValueType.array,
        props: {
          items:[]
        }
      }
    ]
  }, {
    name: '基础控件',
    components: [
      {
        title: '单行输入框',
        name: 'TextInput',
        icon: 'iconfont icon-danhangshuru',
        value: '',
        span:24,
        valueType: ValueType.string,
        props: {
          required: false,
          enablePrint: true,
          maxlength: 52
        }
      },
      {
        title: '多行输入框',
        name: 'TextareaInput',
        icon: 'iconfont icon-duohangshuru',
        value: '',
        valueType: ValueType.string,
        span:24,
        props: {
          required: false,
          enablePrint: true
        }
      },
      {
        title: '数字输入框',
        name: 'NumberInput',
        icon: 'iconfont icon-shuzishuru',
        value: undefined,
        valueType: ValueType.number,
        span:24,
        props: {
          required: false,
          enablePrint: true,
        }
      },
      // {
      //   title: '金额输入框',
      //   name: 'AmountInput',
      //   icon: 'iconfont icon-zhufangbutiezhanghu',
      //   value: '',
      //   valueType: ValueType.number,
      //   props: {
      //     required: false,
      //     enablePrint: true,
      //     showChinese: true
      //   }
      // },
      {
        title: '单选框',
        name: 'SelectInput',
        icon: 'iconfont icon-danxuan',
        value: '',
        valueType: ValueType.string,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          expanding: false,
          options: [],
          dataFrom:1,
          optionselectType:''
        }
      },
      {
        title: '多选框',
        name: 'MultipleSelect',
        icon: 'iconfont icon-duoxuan',
        value: [],
        valueType: ValueType.array,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          expanding: false,
          options: [],
          dataFrom:1,
          optionselectType:''
        }
      },
      {
        title: '日期',
        name: 'DateTime',
        icon: 'iconfont icon-riqixuanze',
        value: '',
        valueType: ValueType.date,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          format: 'yyyy-MM-dd HH:mm',
        }
      },
      {
        title: '日期区间',
        name: 'DateTimeRange',
        icon: 'iconfont icon-riqiqujian',
        valueType: ValueType.dateRange,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          placeholder: ['开始时间', '结束时间'],
          format: 'yyyy-MM-dd HH:mm',
          showLength: false
        }
      },
      {
        title: '说明文字',
        name: 'Description',
        icon: 'iconfont icon-tishifu',
        value: '',
        valueType: ValueType.string,
        span:24,
        props: {
          required: false,
          enablePrint: true
        }
      },
      {
        title: '上传图片',
        name: 'ImageUpload',
        icon: 'iconfont icon-tupian',
        value: [],
        valueType: ValueType.array,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          maxSize: 5, //图片最大大小MB
          maxNumber: 10, //最大上传数量
          enableZip: true //图片压缩后再上传
        }
      },
      {
        title: '上传附件',
        name: 'FileUpload',
        icon: 'iconfont icon-fujian',
        value: [],
        valueType: ValueType.array,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          onlyRead: false, //是否只读，false只能在线预览，true可以下载
          maxSize: 100, //文件最大大小MB
          maxNumber: 10, //最大上传数量
          fileTypes: [] //限制文件上传类型
        },
      },
      {
        title: '人员选择',
        name: 'UserPicker',
        icon: 'el-icon-user',
        value: [],
        valueType: ValueType.user,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          multiple: false
        }
      },
      {
        title: '部门选择',
        name: 'DeptPicker',
        icon: 'iconfont icon-map-site',
        value: [],
        valueType: ValueType.dept,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          multiple: false
        }
      },
      
    ]
  }, {
    name: '扩展组件',
    components: [
      {
        title: '明细表',
        name: 'TableList',
        icon: 'icon-biaoge iconfont',
        value: [],
        valueType: ValueType.array,
        span:24,
        props: {
          required: false,
          enablePrint: true,
          showBorder: true,
          rowLayout: true,
          showSummary: false,
          summaryColumns: [],
          maxSize: 0, //最大条数，为0则不限制
          columns:[] //列设置
        }
      }
    ]
  }
]



export default {
  baseComponents
}


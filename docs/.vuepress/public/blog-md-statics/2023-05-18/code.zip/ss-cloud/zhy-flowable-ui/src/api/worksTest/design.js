import request from '@/utils/request.js'
import { tansParams } from "@/utils/ruoyi"

// 查询表单组
export function getFormGroups(param) {
  return request({
    url: 'flowable/settings/form/group',
    method: 'get',
    params: param
  })
}

// 表单group排序
export function groupSort(param) {
  return request({
    url: 'flowable/settings/sort/group',
    method: 'put',
    data: param
  })
}

// 表单item排序
export function itemSort(param) {
  return request({
    url: 'flowable/settings/sort/item',
    method: 'put',
    data: param
  })
}



// 更新表单组
export function updateGroup(param, method) {
  return request({
    url: 'flowable/settings/form/group',
    method: method,
    params: param
  })
}

// 获取表单分组
export function getGroup() {
  return request({
    url: 'flowable/settings/form/group/list',
    method: 'get'
  })
}

// 更新表单
export function updateForm(param) {
  return request({
    url: 'flowable/settings/form',
    method: 'put',
    params: param
  })
}

export function createForm(param){
  return request({
    url: 'flowable/settings/form',
    method: 'post',
    data: param
  })
}

// 查询表单详情
export function getFormDetail(id) {
  return request({
    url: 'flowable/settings/form/detail/' + id,
    method: 'get'
  })
}

export function getFormDetailV2(templateId) {
  return request({
    url: 'flowable/process/process/detail',
    method: 'get',
    params: {
      templateId
    }
  })
}

// 更新表单详情
export function updateFormDetail(param) {
  return request({
    url: 'flowable/settings/form/detail',
    method: 'put',
    data: param
  })
}


// 发起流程
export function startProcess(param) {
  return request({
    url: 'flowable/process/process/start',
    method: 'POST',
    data: param
  })
}

// 查询我发起的
export function applyList(data) {
  return request({
    url: 'flowable/process/listOwnProcess',
    method: 'get',
    params: data
  })
}

// 查看我的待办
export function todoList(data) {
  return request({
    url: 'flowable/process/listTask',
    method: 'get',
    params: data
  })
}

// 查看我的已办
export function doneList(data) {
  return request({
    url: 'flowable/process/listAlreadyProcess',
    method: 'get',
    params: data
  })
}
// 查询流程详情
export function getProcessInstanceInfo(processInstanceId, taskId) {
  return request({
    url: 'flowable/process/process/instanceInfo',
    method: 'POST',
    data: { processInstanceId, taskId }
  })
}
//抄送给我的
export function ccList(data) {
  return request({
    url: 'flowable/process/listCCProcess',
    method: 'get',
    params: data
  })
}
//已读未读
export function readCC(data) {
  return request({
    url: 'flowable/process/process/readCC',
    method: 'put',
    headers: { "Content-Type": 'application/x-www-form-urlencoded' },
    data: tansParams(data)
  })
}

export function listProcessTypes(){
  return request({
    url: 'flowable/process/listProcessTypes',
    method: 'get'
  })
}
//审批通过
export function approvalAgree(data) {
  return request({
    url: 'flowable/process/process/agree',
    method: 'POST',
    data
  })
}
//评论
export function comment(data) {
  return request({
    url: 'flowable/process/process/comments',
    method: 'POST',
    data
  })
}
//审批驳回
export function refuse(data) {
  return request({
    url: 'flowable/process/process/refuse',
    method: 'POST',
    data
  })
}
export function tianqi(data) {
  return request({
    url: 'https://restapi.amap.com/v3/ip',
    method: 'POST',
    data
  })
}

<template>
  <div>
    <div v-if="mode === 'DESIGN'">
      <el-button size="small" icon="el-icon-paperclip" round
        >选择文件</el-button
      >
      <ellipsis
        :row="1"
        :content="placeholder + sizeTip"
        hoverTip
        slot="tip"
        class="el-upload__tip"
      />
    </div>
    <div v-else>
      <el-upload
        :file-list="_value"
        :action="uploadUrl"
        :limit="maxSize"
        with-credentials
        :multiple="maxSize > 0"
        :data="uploadParams"
        :headers="headers"
        :on-success="handleSuccess"
        :on-remove="handleRemove"
        :auto-upload="true"
        :before-upload="beforeUpload"
        :on-error="handleUploadError"
        :show-file-list="false"
      >
        <el-button size="small" icon="el-icon-paperclip" round
          >选择文件</el-button
        >
        <ellipsis
          :row="1"
          :content="placeholder + sizeTip"
          hoverTip
          slot="tip"
          class="el-upload__tip"
        />
      </el-upload>
      <transition-group
        class="upload-file-list el-upload-list el-upload-list--text"
        name="el-fade-in-linear"
        tag="ul"
      >
        <li
          :key="file.url"
          class="el-upload-list__item ele-upload-list__item-content"
          v-for="(file, index) in _value"
        >
          <el-link
            size="mini"
            type="text"
            target="_blank"
            @click="download(file.url, file.name)"
            ><span class="el-icon-document">
              {{ file.name }}
            </span></el-link
          >
          <div class="ele-upload-list__item-content-action">
            <el-link
              :underline="false"
              @click="handleDelete(index)"
              type="danger"
              >删除</el-link
            >
          </div>
        </li>
      </transition-group>
    </div>
  </div>
</template>

<script>
import componentMinxins from "../ComponentMinxins";
import { getToken } from "@/utils/auth";
import { downloadFile } from "@/api/common/fileInfo";
export default {
  mixins: [componentMinxins],
  name: "ImageUpload",
  components: {},
  props: {
    placeholder: {
      type: String,
      default: "请选择附件",
    },
    value: {
      type: Array,
      default: () => {
        return [];
      },
    },
    maxSize: {
      type: Number,
      default: 100,
    },
    maxNumber: {
      type: Number,
      default: 10,
    },
    fileTypes: {
      type: Array,
      default: () => {
        return ["doc", "xls", "ppt", "txt", "pdf"];
      },
    },
  },
  computed: {
    headers() {
      return {
        Authorization: "Bearer " + getToken(),
      };
    },
    uploadUrl() {
      return process.env.VUE_APP_BASE_API + "/file/upload";
    },
    sizeTip() {
      if (this.fileTypes.length > 0) {
        return ` | 只允许上传[${String(this.fileTypes).replaceAll(
          ",",
          "、"
        )}]格式的文件，且单个附件不超过${this.maxSize}MB`;
      }
      return this.maxSize > 0 ? ` | 单个附件不超过${this.maxSize}MB` : "";
    },
  },
  data() {
    return {
      disabled: false,
      uploadParams: {},
      fileIds: [],
      baseUrl: process.env.VUE_APP_BASE_API,
    };
  },
  methods: {
    beforeUpload(file) {
      // 校检文件类型
      if (this.fileTypes.length) {
        let fileExtension = "";
        if (file.name.lastIndexOf(".") > -1) {
          fileExtension = file.name.slice(file.name.lastIndexOf(".") + 1);
        }
        const isTypeOk = this.fileTypes.some((type) => {
          //if (file.type.indexOf(type) > -1) return true;
          //if (fileExtension && fileExtension.indexOf(type) > -1) return true;
          if (fileExtension.toLowerCase() === type.toLowerCase()) {
            return true;
          }
          return false;
        });
        if (!isTypeOk) {
          this.$modal.msgError(
            `文件格式不正确, 请上传${this.fileTypes.join("/")}格式文件!`
          );
          return false;
        }
      }
      // 校检文件大小
      if (this.maxSize) {
        const isLt = file.size / 1024 / 1024 < this.maxSize;
        if (!isLt) {
          this.$modal.msgError(`上传文件大小不能超过 ${this.maxSize} MB!`);
          return false;
        }
      }
      this.number++;
      //文件数量限制，这里在本组件处理，不走el-upload处理
      if (this.number > this.limitNumber) {
        this.overflowLimitNumber();
        return false;
      }
      this.$modal.loading("正在上传文件，请稍候...");
      return true;
    },
    handleSuccess(res, file, fileList) {
      this.$modal.closeLoading();
      fileList.forEach((e) => {
        if (e.status == "success") {
          e.url = e.response.data.url;
        }
      });
      this._value = fileList;
    },
    handleUploadError(err) {
      this.$modal.msgError("上传失败，请重试");
      this.$modal.closeLoading()
    },
    handleRemove(file, fileList) {
      fileList.forEach((e) => {
        if (e.status == "success") {
          e.url = e.response.data.url;
        }
      });
    },
    handleDelete(index) {
      this._value.splice(index, 1);
      this.fileIds.splice(index, 1);
    },
    download(url, fileName) {
      //调用下载文件请求
      downloadFile(this.baseUrl, url, fileName);
    },
  },
};
</script>

<style lang="less" scoped></style>

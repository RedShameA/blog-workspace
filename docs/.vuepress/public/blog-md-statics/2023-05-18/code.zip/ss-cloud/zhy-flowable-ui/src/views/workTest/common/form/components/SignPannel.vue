<template>

</template>

<script>
export default {
  name: "SignPannel",
  components: {},
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>

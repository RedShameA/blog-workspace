<template>
  <div>
    <div v-if="mode === 'DESIGN'">
      <el-input-number size="medium" class="max-fill" controls-position="right" :placeholder="placeholder" type="number"/>
    </div>
    <div v-else>
      <el-input-number v-model="_value" class="max-fill" size="medium"  controls-position="right" :placeholder="placeholder" type="number"/>
    </div>
  </div>
</template>

<script>
import componentMinxins from '../ComponentMinxins'

export default {
  mixins: [componentMinxins],
  name: "NumberInput",
  components: {},
  props:{
    value:{
      type: Number,
      default: null
    },
    placeholder:{
      type: String,
      default: '请输入数值'
    }
  },
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>

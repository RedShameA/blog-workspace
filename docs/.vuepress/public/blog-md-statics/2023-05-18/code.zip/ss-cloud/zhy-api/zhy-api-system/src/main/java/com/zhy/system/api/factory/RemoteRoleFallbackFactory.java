package com.zhy.system.api.factory;

import com.zhy.common.core.domain.R;
import com.zhy.common.core.web.domain.AjaxResult;
import com.zhy.system.api.RemoteLogService;
import com.zhy.system.api.RemoteRoleService;
import com.zhy.system.api.domain.SysLogininfor;
import com.zhy.system.api.domain.SysOperLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

/**
 * 日志服务降级处理
 *
 * @author zhy
 */
@Component
public class RemoteRoleFallbackFactory implements FallbackFactory<RemoteRoleService>
{
    private static final Logger log = LoggerFactory.getLogger(RemoteRoleFallbackFactory.class);


    @Override
    public RemoteRoleService create(Throwable cause) {

        log.error("日志服务调用失败:{}", cause.getMessage());
        return new RemoteRoleService() {
            @Override
            public AjaxResult listAllUserIdByRole(Long roleId) {
                return null;
            }
        };
    }


}

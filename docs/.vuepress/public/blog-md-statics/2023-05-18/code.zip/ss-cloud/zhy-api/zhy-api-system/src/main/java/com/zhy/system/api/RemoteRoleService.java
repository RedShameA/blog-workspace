package com.zhy.system.api;

import com.zhy.common.core.constant.SecurityConstants;
import com.zhy.common.core.constant.ServiceNameConstants;
import com.zhy.common.core.domain.R;
import com.zhy.common.core.web.domain.AjaxResult;
import com.zhy.system.api.domain.SysLogininfor;
import com.zhy.system.api.domain.SysOperLog;
import com.zhy.system.api.factory.RemoteLogFallbackFactory;
import com.zhy.system.api.factory.RemoteRoleFallbackFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

/**
 * 日志服务
 *
 * @author zhy
 */
// @FeignClient(contextId = "remoteRoleService", value = ServiceNameConstants.SYSTEM_SERVICE, fallbackFactory = RemoteRoleFallbackFactory.class, url = "http://172.33.0.2:9201")
// @FeignClient(contextId = "remoteRoleService", value = ServiceNameConstants.SYSTEM_SERVICE, fallbackFactory = RemoteRoleFallbackFactory.class, url = "http://localhost:9201")
@FeignClient(contextId = "remoteRoleService", value = ServiceNameConstants.SYSTEM_SERVICE, fallbackFactory = RemoteRoleFallbackFactory.class)
public interface RemoteRoleService
{
    /**
     * 获取所有用户信息
     * @param roleId
     * @return
     */
    @GetMapping("/role/listAllUserId/{roleId}")
    public AjaxResult listAllUserIdByRole(@PathVariable("roleId") Long roleId);
}

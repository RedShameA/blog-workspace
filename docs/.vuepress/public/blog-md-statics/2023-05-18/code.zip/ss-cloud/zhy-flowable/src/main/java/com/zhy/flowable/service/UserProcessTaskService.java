package com.zhy.flowable.service;

import com.zhy.flowable.entity.dto.ProcessFrontDTO;

import java.util.Map;

/**
 * @Author wangfeng
 * @Description 用户 待办/已办/发起/待阅
 * @Date 2022-12-27 15:46
 */
public interface UserProcessTaskService {
    /**
     * 待办任务
     * @param userId
     * @param processFrontDto
     * @return
     */
    Map listTask(String userId, ProcessFrontDTO processFrontDto);

    /**
     * 已办任务
     * @param userId
     * @param processFrontDto
     * @return
     */
    Map listAlreadyTask(String userId, ProcessFrontDTO processFrontDto);

    /**
     * 已办流程
     * @param userId
     * @param processFrontDto
     * @return
     */
    Map listAlreadyProcess(String userId, ProcessFrontDTO processFrontDto);

    /**
     * 已发流程
     * @param userId
     * @param processFrontDto
     * @return
     */
    Map listOwnProcess(String userId, ProcessFrontDTO processFrontDto);

    /**
     * 待阅流程
     * @param userId
     * @param processFrontDto
     * @return
     */
    Map listCCProcess(String userId, ProcessFrontDTO processFrontDto);

}

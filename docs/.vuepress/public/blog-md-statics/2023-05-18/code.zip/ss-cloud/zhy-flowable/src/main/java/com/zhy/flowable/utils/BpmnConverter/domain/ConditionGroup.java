package com.zhy.flowable.utils.BpmnConverter.domain;

import lombok.Data;

import java.util.List;

/**
 * @Author wangfeng
 * @Description 网关条件组的单个实体
 * @Date 2023-01-03 16:19
 */
@Data
public class ConditionGroup {
  private String groupType;
  private List<Condition> conditions;
  private List<String> cids;
}

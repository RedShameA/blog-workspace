package com.zhy.flowable.entity;

import lombok.Data;

/**
 * {
 * "id": "field6131501574832",
 * "title": "单行文本输入",
 * "required": true,
 * "perm": "R"
 * }
 */
@Data
public class FormOperates {
    private String id;

    private String title;

    private Boolean required;

    private String perm;
}

package com.zhy.flowable.listener;

import cn.hutool.core.date.DateUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.zhy.flowable.constats.CommonConstants;
import com.zhy.flowable.utils.BpmnConverter.BpmnUtil;
import org.flowable.bpmn.model.Process;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.delegate.TaskListener;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.service.delegate.DelegateTask;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;

/**
 * @Author wangfeng
 * @Description task完成时，处理标题和摘要
 * @Date 2023-01-09 14:54
 */
@Component
public class TaskCompleteTaskListener implements TaskListener {
    @Override
    public void notify(DelegateTask delegateTask) {
        String processInstanceId = delegateTask.getProcessInstanceId();
        String processDefinitionId = delegateTask.getProcessDefinitionId();
        Map<String, Object> variables = delegateTask.getVariables();
        RuntimeService runtimeService = SpringUtil.getBean(RuntimeService.class);
        ProcessInstance processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        Date startTime = processInstance.getStartTime();
        RepositoryService repositoryService = SpringUtil.getBean(RepositoryService.class);
        Process mainProcess = repositoryService.getBpmnModel(processDefinitionId).getMainProcess();
        String processName = mainProcess.getName();
        // 3个特殊变量
        variables.put("startTime", DateUtil.format(startTime, "yyyy-MM-dd HH:mm"));
        variables.put("processName", processName);
        variables.put("starter", variables.getOrDefault(CommonConstants.PROCESS_VAR_STARTER_NICKNAME, ""));

        delegateTask.setVariable(CommonConstants.PROCESS_TITLE, BpmnUtil.renderProcessTitle(variables, mainProcess));
        delegateTask.setVariable(CommonConstants.PROCESS_DESC, BpmnUtil.renderProcessDesc(variables, mainProcess));

        // 设置发起时间
        if (delegateTask.getTaskDefinitionKey().equalsIgnoreCase("root")){
            HistoryService historyService = SpringUtil.getBean(HistoryService.class);
            HistoricProcessInstance instance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
            delegateTask.setVariable(CommonConstants.PROCESS_VAR_START_TIME, instance.getStartTime());
            delegateTask.setVariable(CommonConstants.PROCESS_VAR_END_TIME, null);
        }
    }
}

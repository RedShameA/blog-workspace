package com.zhy.flowable.entity.dto;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @Author wangfeng
 * @Description 流程待办已办前端DTO 传递分页/搜索参数
 * @Date 2022-12-28 10:45
 */
@Data
public class ProcessFrontDTO {
    private Integer pageNum;
    private Integer pageSize;

    /**
     * 搜索
     */
    private String search;

    /**
     * 流程类型
     */
    private String processType;

    /**
     * 流程状态
     */
    private String processStatus;

    /**
     * 发起人
     */
    private String starter;

    /**
     * 抄送已读
     * 0：未读 1：已读 -1：全部
     */
    private Integer readed;

    /**
     * 启动时间范围、结束时间范围
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTimeStart;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTimeEnd;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTimeStart;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTimeEnd;

    /**
     *
     */


    /**
     * 默认第1页
     * @return
     */
    public Integer getPageNum() {
        return pageNum==null?1:pageNum;
    }

    /**
     * 默认size10
     * @return
     */
    public Integer getPageSize() {
        return pageSize==null?10:pageSize;
    }

    public Integer getStart(){
        return getPageSize() * (getPageNum()-1);
    }

}

package com.zhy.flowable.entity.vo;

import lombok.Data;

import java.util.Date;

/**
 * @author syk
 * @Description 操作信息 在对审批进行同意拒绝时附带的信息
 * @Date 15:57 2023/1/4
 */
@Data
public class OptionVO {
    // 内容
    private String comments;

    // 评论人
    private String userId;

    // 名称
    private String userName;

    //时间
    private Date createTime;
}

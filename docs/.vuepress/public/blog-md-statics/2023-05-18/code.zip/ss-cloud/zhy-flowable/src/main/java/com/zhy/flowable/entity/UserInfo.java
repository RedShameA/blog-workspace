package com.zhy.flowable.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * {
 * "id": 381496,
 * "name": "旅人",
 * "type": "user",
 * "sex": false,
 * "selected": false
 * }
 */
@Data
public class UserInfo implements Serializable {
    private String id;

    private String name;

    private String type;

    private String sex;

    private Boolean selected;
}

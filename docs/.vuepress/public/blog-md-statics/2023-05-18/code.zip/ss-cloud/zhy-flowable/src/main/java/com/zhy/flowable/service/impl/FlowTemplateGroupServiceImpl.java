package com.zhy.flowable.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhy.flowable.entity.FlowTemplateGroup;
import com.zhy.flowable.entity.bo.FlowTemplateGroupBo;
import com.zhy.flowable.mapper.FlowTemplateGroupMapper;
import com.zhy.flowable.service.FlowTemplateGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FlowTemplateGroupServiceImpl extends ServiceImpl<FlowTemplateGroupMapper, FlowTemplateGroup> implements FlowTemplateGroupService {
    @Autowired
    private FlowTemplateGroupMapper flowTemplateGroupMapper;

    @Override
    public List<FlowTemplateGroupBo> getAllTemplateAndGroup() {
        return flowTemplateGroupMapper.getAllTemplateAndGroup();
    }
}

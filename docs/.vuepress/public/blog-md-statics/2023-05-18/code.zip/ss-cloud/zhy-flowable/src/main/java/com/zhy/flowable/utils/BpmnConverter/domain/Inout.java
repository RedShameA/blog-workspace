package com.zhy.flowable.utils.BpmnConverter.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @Author wangfeng
 * @Description
 * @Date 2022-12-30 15:27
 */
@Data
@AllArgsConstructor
public class Inout {
    private String in;
    private String out;
}

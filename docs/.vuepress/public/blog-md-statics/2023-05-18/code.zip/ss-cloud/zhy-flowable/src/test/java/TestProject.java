import org.junit.Test;

public class TestProject {

    @Test
    public void testTime() {
        System.out.println(System.currentTimeMillis());
    }
}

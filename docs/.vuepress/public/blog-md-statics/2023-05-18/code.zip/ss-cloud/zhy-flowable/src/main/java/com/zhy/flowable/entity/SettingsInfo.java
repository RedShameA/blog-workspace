package com.zhy.flowable.entity;

import cn.hutool.system.UserInfo;
import lombok.Data;

import java.util.List;

@Data
public class SettingsInfo {

    private List<String> commiter;

    private List<UserInfo> admin;

    private Boolean sign;

//    private JSONObject notify;
}

package com.zhy.flowable.entity.vo;

import lombok.Data;

import java.util.Date;

/**
 * @author syk
 * @Description 评论数据
 * @Date 16:01 2023/1/4
 */
@Data
public class CommentVO {
    // 内容
    private String comments;

    // 评论人
    private String userId;

    // 名称
    private String userName;

    //时间
    private Date createTime;
}

package com.zhy.flowable.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhy.flowable.entity.FlowProcessTemplates;
import com.zhy.flowable.mapper.FlowProcessTemplateMapper;
import com.zhy.flowable.service.FlowProcessTemplateService;
import org.springframework.stereotype.Service;

@Service
public class FlowProcessTemplateServiceImpl extends ServiceImpl<FlowProcessTemplateMapper, FlowProcessTemplates> implements FlowProcessTemplateService {
}

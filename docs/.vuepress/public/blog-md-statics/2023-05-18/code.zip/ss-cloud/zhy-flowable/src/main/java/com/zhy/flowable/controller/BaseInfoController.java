package com.zhy.flowable.controller;

import com.zhy.common.core.domain.R;
import com.zhy.common.core.web.domain.AjaxResult;
import com.zhy.system.api.RemoteUserService;
import com.zhy.system.api.domain.vo.OrgTreeVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @author syk
 * @Description 基本信息后台接口
 * @Date 13:02 2022/12/22
 */
@RestController
@RequestMapping("/oa/org")
public class BaseInfoController {

    @Autowired
    private RemoteUserService remoteUserService;

    /**
     * 查询人员信息树
     *
     * @param deptId
     * @return
     */
    @GetMapping("/tree")
    public AjaxResult tree(@RequestParam(defaultValue = "100") Long deptId, @RequestParam(defaultValue = "all") String type) {
        R<List<OrgTreeVo>> userTree = remoteUserService.userTree(deptId, type);
        return AjaxResult.success(userTree.getData());
    }

    /**
     * 首字母模糊搜索用户
     *
     * @param userName 用户名/拼音/首字母
     * @return 匹配到的用户
     */
    @GetMapping("tree/search")
    public Object getOrgTreeUser(@RequestParam(defaultValue = "u") String userName) {
        return remoteUserService.getOrgTreeUser(userName.trim());
    }


}

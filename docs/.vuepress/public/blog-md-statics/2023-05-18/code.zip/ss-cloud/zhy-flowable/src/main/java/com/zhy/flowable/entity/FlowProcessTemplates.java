package com.zhy.flowable.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 流程模板表
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FlowProcessTemplates {
    // 模板id
    @TableId
    private String templateId;

    @TableField(exist = false)
    private String formId;

    @TableField(exist = false)
    private String formName;

    // 模板名
    private String templateName;

    // 配置信息
    private String settings;

    // 表单属性
    private String formItems;

    // 表单流程
    private String process;

    // 表单图标
    private String icon;

    // 表单背景色
    private String background;

    // 表单提醒方式
//    private String notify;

    // 谁能提交
    private String whoCommit;

    // 谁能编辑
    private String whoEdit;

    // 谁能导出
    private String whoExport;

    // 备注
    private String remark;

    // 模板分组
    private Integer groupId;

    // 是否停用
    private Boolean isStop;

    // 创建人
    private String createBy;

    // 创建时间
    private Date createTime;

    // 更新人
    private String updateBy;

    //更新时间
    private Date updateTime;

    @TableField(exist = false)
    private String logo;

    @TableField(exist = false)
    private String processDefinitionId;
}

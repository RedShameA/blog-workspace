package com.zhy.flowable.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhy.flowable.entity.FlowTemplateGroup;
import com.zhy.flowable.entity.bo.FlowTemplateGroupBo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FlowTemplateGroupMapper extends BaseMapper<FlowTemplateGroup> {

    @Select("SELECT fg.group_id, tg.id, fg.group_name, pt.template_id, pt.remark, pt.is_stop, pt.create_time, pt.update_time, pt.template_name, " +
            "pt.icon, pt.background FROM flow_process_templates pt LEFT JOIN flow_template_group tg ON pt.template_id = tg.template_id\n" +
            "RIGHT JOIN flow_form_groups fg ON tg.group_id = fg.group_id ORDER BY fg.sort_num ASC, tg.sort_num ASC")
    List<FlowTemplateGroupBo> getAllTemplateAndGroup();
}

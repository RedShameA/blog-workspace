package com.zhy.flowable.utils.BpmnConverter.domain;

import lombok.Data;

import java.util.List;

/**
 * @Author wangfeng
 * @Description
 * @Date 2022-12-30 16:49
 */
@Data
public class ProcessNode {
    /**
     * 节点ID
     * 当前流程内唯一，由前端随机生成
     */
    private String id;
    /**
     * 父级节点ID
     * 用来向上搜索，关联子父
     */
    private String parentId;
    /**
     * 节点类型
     * ROOT(发起人，根节点)
     * APPROVAL(审批)
     * CC(抄送)
     * CONDITIONS(条件组)
     * CONCURRENTS（并行节点组）
     * CONDITION(条件子分支)
     * CONCURRENT（并行子分支）
     * DELAY(延时节点)
     * TRIGGER(触发器)
     * EMPTY(空节点，占位)
     */
    private String type;
    /**
     * 节点名称
     * 显示在设计器中卡片头部名称
     */
    private String name;
    /**
     * 节点属性设置
     * 节点的设置项内容
     */
    private Props props;
    /**
     * 子节点项
     * 节点下方的子节点，无限嵌套，内部字段与当前结构相同
     */
    private ProcessNode children;
    /**
     * 子分支项
     * 当type 为 CONDITIONS / CONCURRENTS 时，该项存在，内容为条件或并行节点内的所有分支
     */
    private List<ProcessNode> branchs;

    // 发起人，根节点
    public static String ROOT = "ROOT";
    // 审批
    public static String APPROVAL = "APPROVAL";
    // 抄送
    public static String CC = "CC";
    // 并行节点组
    public static String CONCURRENTS = "CONCURRENTS";
    // 并行子分支
    public static String CONCURRENT = "CONCURRENT";
    // 条件组
    public static String CONDITIONS = "CONDITIONS";
    // 条件子分支
    public static String CONDITION = "CONDITION";
    // 延时节点
    public static String DELAY = "DELAY";
    // 触发器
    public static String TRIGGER = "TRIGGER";
    // 空节点，占位
    public static String EMPTY = "EMPTY";

}

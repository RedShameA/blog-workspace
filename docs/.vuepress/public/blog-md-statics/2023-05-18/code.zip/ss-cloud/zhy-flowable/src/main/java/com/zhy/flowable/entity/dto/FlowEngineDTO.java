package com.zhy.flowable.entity.dto;

import lombok.Data;

/**
 *
 */
@Data
public class FlowEngineDTO {
    //表单Id
    private String formId;

    //表单名
    private String formName;

    //表单logo
    private String logo;

    //表单配置
    private String settings;

    //分组信息
    private Integer groupId;

    //表单属性
    private String formItems;

    //流程
    private String process;

    //备注
    private String remark;

}

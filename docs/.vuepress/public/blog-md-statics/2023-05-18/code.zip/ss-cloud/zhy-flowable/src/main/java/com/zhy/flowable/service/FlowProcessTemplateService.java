package com.zhy.flowable.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zhy.flowable.entity.FlowProcessTemplates;

public interface FlowProcessTemplateService extends IService<FlowProcessTemplates> {
}

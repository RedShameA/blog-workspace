package com.zhy.flowable.controller;

import com.zhy.common.core.web.domain.AjaxResult;
import com.zhy.flowable.entity.FlowFormGroups;
import com.zhy.flowable.entity.FlowProcessTemplates;
import com.zhy.flowable.entity.FlowTemplateGroup;
import com.zhy.flowable.entity.dto.FlowEngineDTO;
import com.zhy.flowable.entity.vo.TemplateGroupVo;
import com.zhy.flowable.service.SettingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/settings")
public class SettingsController {

    @Autowired
    private SettingsService settingsService;

    /**
     * 新增表单分组
     *
     * @param name
     * @return
     */
    @PostMapping("/form/group")
    public AjaxResult formGroup(@RequestParam String name) {
        boolean save = settingsService.createFormGroup(name);
        return save ? AjaxResult.success("新增表单成功") : AjaxResult.error("该表单名已存在");
    }

    /**
     * 修改分组
     *
     * @param name
     * @return
     */
    @PutMapping("/form/group")
    public AjaxResult updateFormGroup(@RequestParam int id, @RequestParam String name) {
        boolean save = settingsService.updateFormGroup(id, name);
        return save ? AjaxResult.success("修改表单成功") : AjaxResult.error("该表单名已存在");
    }

    /**
     * 删除分组
     *
     * @param id
     * @return
     */
    @DeleteMapping("/form/group")
    public AjaxResult deleteFormGroup(@RequestParam Integer id) {
        boolean remove = settingsService.deleteFormGroup(id);
        return remove ? AjaxResult.success("删除表单成功") : AjaxResult.error("删除表单失败");
    }

    /**
     * 查询所有表单分组
     *
     * @return
     */
    @GetMapping("/form/group")
    public AjaxResult getFormGroups() {
        List<TemplateGroupVo> formGroups = settingsService.getFormGroups();
        return AjaxResult.success(formGroups);
    }


    /**
     * 保存表单
     *
     * @return
     */
    @PostMapping("/form")
    public AjaxResult form(@RequestBody FlowEngineDTO flowEngineDTO) {
        settingsService.saveForm(flowEngineDTO);
        return AjaxResult.success("表单创建成功");
    }

    /**
     * 修改表单
     *
     * @return
     */
    @PutMapping("/form")
    public AjaxResult updateForm(@RequestParam String templateId,
                                 @RequestParam String type,
                                 @RequestParam(required = false) Integer groupId) {
        Map<String, Object> form = settingsService.updateForm(templateId, type, groupId);
        boolean status = Boolean.parseBoolean(form.get("status").toString());
        return status ? AjaxResult.success(form.get("msg")) : AjaxResult.error(form.get("msg").toString());
    }

    /**
     * 编辑表单详情
     *
     * @param template 表单模板信息
     * @return 修改结果
     */
    @PutMapping("form/detail")
    public AjaxResult updateFormDetail(@RequestBody FlowProcessTemplates template) {
        settingsService.updateFormDetail(template);
        return AjaxResult.success("重新发布表单成功!");
    }

    /**
     * 查询表单模板数据
     *
     * @param templateId 模板id
     * @return 模板详情数据
     */
    @GetMapping("form/detail/{formId}")
    public AjaxResult getFormTemplateById(@PathVariable("formId") String templateId) {
        FlowProcessTemplates templates = settingsService.getFormTemplateById(templateId);
        return AjaxResult.success(templates);
    }

    /**
     * 表单组排序
     * @param formGroups
     * @return
     */
    @PutMapping("/sort/group")
    public AjaxResult groupSort(@RequestBody List<FlowFormGroups> formGroups){
        settingsService.groupSort(formGroups);
        return AjaxResult.success("表单组排序成功");
    }

    /**
     * 表单排序
     * @param flowTemplateGroups
     * @return
     */
    @PutMapping("/sort/item")
    public AjaxResult itemSort(@RequestBody List<FlowTemplateGroup> flowTemplateGroups){
        settingsService.itemSort(flowTemplateGroups);
        return AjaxResult.success("表单排序成功");
    }

}

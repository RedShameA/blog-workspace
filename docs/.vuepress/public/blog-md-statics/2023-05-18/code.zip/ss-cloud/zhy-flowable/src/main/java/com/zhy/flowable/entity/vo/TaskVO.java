package com.zhy.flowable.entity.vo;

import com.zhy.flowable.entity.UserInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author syk
 * @Description 任务视图
 * @Date 14:30 2022/12/30
 */
@Data
public class TaskVO {
    //任务Id
    private String taskId;

    //实例Id
    private String processInstanceId;

    //审批类型
    private String processDefinitionName;

    //发起人
    private UserInfo startUser;

    //发起时间
    private Date startTime;

    //节点到达时间
    private Date taskCreatedTime;

    //最近节点
    private String currentActivityName;

    //审批状态
    private String businessStatus;

    //结束时间
    private Date endTime;

    //总用时
    private String duration;
}

package com.zhy.flowable.listener;

import com.zhy.common.core.utils.SpringUtils;
import com.zhy.flowable.constats.CommonConstants;
import org.flowable.engine.HistoryService;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;
import org.flowable.engine.history.HistoricProcessInstance;
import org.springframework.stereotype.Component;


/**
 * @author syk
 * @Description 任务结束监听器
 * @Date 9:37 2023/1/3
 */
@Component
public class ProcessListener implements ExecutionListener {
    @Override
    public void notify(DelegateExecution delegateExecution) {
        HistoryService historyService = SpringUtils.getBean(HistoryService.class);
        String processInstanceId = delegateExecution.getProcessInstanceId();
        HistoricProcessInstance instance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        // 流程结束时间和流程状态
        delegateExecution.setVariable(CommonConstants.PROCESS_VAR_END_TIME, instance.getEndTime());
        delegateExecution.setVariable(CommonConstants.PROCESS_STATUS, CommonConstants.BUSINESS_STATUS_4);
    }
}

package com.zhy.flowable.constats;

public interface WorkFlowConstants {
    String PROCESS_PREFIX = "Flowable";
    String START_EVENT_ID = "startEventNode";
    String END_EVENT_ID = "endEventNode";
    String EXPRESSION_CLASS = "exUtils.";

    // 驳回后直接结束
    String TO_END = "TO_END";

    String TO_BEFORE = "TO_BEFORE";
    String TO_NODE = "TO_NODE";


}

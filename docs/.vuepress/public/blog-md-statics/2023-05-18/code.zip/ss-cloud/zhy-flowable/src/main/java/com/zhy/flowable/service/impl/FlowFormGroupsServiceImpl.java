package com.zhy.flowable.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhy.flowable.entity.FlowFormGroups;
import com.zhy.flowable.mapper.FlowFormGroupsMapper;
import com.zhy.flowable.service.FlowFormGroupsService;
import org.springframework.stereotype.Service;

@Service
public class FlowFormGroupsServiceImpl extends ServiceImpl<FlowFormGroupsMapper, FlowFormGroups> implements FlowFormGroupsService {
}

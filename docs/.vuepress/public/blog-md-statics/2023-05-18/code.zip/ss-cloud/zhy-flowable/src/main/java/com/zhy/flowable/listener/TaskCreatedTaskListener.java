package com.zhy.flowable.listener;

import com.zhy.flowable.utils.SpringContextHolder;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.delegate.TaskListener;
import org.flowable.task.service.delegate.DelegateTask;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @Author wangfeng
 * @Description task创建并指派之后，进行任务自动处理(拒绝or通过)
 * @Date 2023-01-03 13:23
 */
@Component
public class TaskCreatedTaskListener implements TaskListener {
    @Resource
    private TaskService taskService;
    @Override
    public void notify(DelegateTask delegateTask) {
        String taskDefinitionKey = delegateTask.getTaskDefinitionKey();
        if("root".equalsIgnoreCase(taskDefinitionKey)){
            taskService.complete(delegateTask.getId());
        }else{
            if("0".equals(delegateTask.getAssignee())){
                Object autoRefuse = delegateTask.getVariableLocal(taskDefinitionKey+"autoRefuse");
                if(null == autoRefuse){
                    taskService.addComment(delegateTask.getId(),delegateTask.getProcessInstanceId(),"opinion","审批人为空,自动通过");
                    taskService.complete(delegateTask.getId());
                }
                else{
                    taskService.addComment(delegateTask.getId(),delegateTask.getProcessInstanceId(),"opinion","审批人为空,自动驳回");
                    RuntimeService runtimeService = SpringContextHolder.getBean(RuntimeService.class);
                    runtimeService.deleteProcessInstance(delegateTask.getProcessInstanceId(),"审批人为空,自动驳回");
                }
            }
        }
    }
}

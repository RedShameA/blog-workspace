package com.zhy.flowable.service.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.zhy.flowable.constats.CommonConstants;
import com.zhy.flowable.entity.FlowCC;
import com.zhy.flowable.entity.dto.ProcessFrontDTO;
import com.zhy.flowable.entity.vo.ProcessVo;
import com.zhy.flowable.mapper.FlowCCMapper;
import com.zhy.flowable.service.FlowCCService;
import com.zhy.flowable.service.UserProcessTaskService;
import org.flowable.engine.HistoryService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.history.HistoricProcessInstanceQuery;
import org.flowable.engine.impl.persistence.entity.HistoricProcessInstanceEntityImpl;
import org.flowable.task.api.Task;
import org.flowable.task.api.TaskQuery;
import org.flowable.task.api.history.HistoricTaskInstance;
import org.flowable.task.api.history.HistoricTaskInstanceQuery;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author wangfeng
 * @Description 统一查询
 * 搜索框：发起人昵称、流程标题、流程摘要  模糊
 * 发起人：发起人精确
 * 流程类型：流程类型精确
 * 流程状态：流程状态精确
 * 开始结束时间：时间范围
 * @Date 2022-12-27 15:47
 */

@Service
public class UserProcessTaskServiceImpl implements UserProcessTaskService {

    @Resource
    TaskService taskService;
    @Resource
    HistoryService historyService;
    @Resource
    private FlowCCService flowCCService;
    @Resource
    private FlowCCMapper flowCCMapper;


    private Map getReturnMap(List list, long count){
        Map<String, Object> map = new HashMap<>(2);
        map.put("totalCount", count);
        map.put("data", list);
        return map;
    }

    /**
     * 获取VO待办
     * @param userId
     * @return
     */
    @Override
    public Map listTask(String userId, ProcessFrontDTO processFrontDto) {
        TaskQuery query = this.listTaskOriginQuery(userId, processFrontDto);
        long count = query.count();
        List<Task> list = query.listPage(processFrontDto.getStart(), processFrontDto.getPageSize());
        // 转换VO
        List<ProcessVo> collect = list.stream().map(e -> {
            ProcessVo vo = new ProcessVo();
            vo.convertFrom(e);
            return vo;
        }).collect(Collectors.toList());
        Map map = this.getReturnMap(collect, count);
        return map;
    }


    /**
     * 获取原始待办query
     * @param processFrontDto
     * @param userId
     * @return
     */
    private TaskQuery listTaskOriginQuery(String userId, ProcessFrontDTO processFrontDto){
        HashSet<String> groups = new HashSet<>();
        groups.add("test");
        TaskQuery query = taskService.createTaskQuery();
        // 必要条件 参与人或参与组
        query.or(); // 开始or
        query.taskAssignee(userId);
        query.endOr();
        // 条件筛选
        if (StrUtil.isNotBlank(processFrontDto.getSearch())){
            query.or();
            query.processVariableValueLikeIgnoreCase(CommonConstants.PROCESS_VAR_STARTER_NICKNAME, "%"+processFrontDto.getSearch()+"%");
            query.processVariableValueLikeIgnoreCase(CommonConstants.PROCESS_TITLE, "%"+processFrontDto.getSearch()+"%");
            query.processVariableValueLikeIgnoreCase(CommonConstants.PROCESS_DESC, "%"+processFrontDto.getSearch()+"%");
            query.endOr();
        }
        // 发起人筛选
        if (StrUtil.isNotBlank(processFrontDto.getStarter())){
            query.processVariableValueEqualsIgnoreCase(CommonConstants.PROCESS_VAR_STARTER_ID, processFrontDto.getStarter());
        }
        // 流程类型筛选
        if (StrUtil.isNotBlank(processFrontDto.getProcessType())){
            query.or();
            query.processDefinitionKey(processFrontDto.getProcessType());
            query.processDefinitionName(processFrontDto.getProcessType());
            query.endOr();
        }
        // 流程状态
        if (ObjectUtil.isNotNull(processFrontDto.getProcessStatus())){
            if (!processFrontDto.getProcessStatus().equals(CommonConstants.BUSINESS_STATUS_ALL)){
                query.processVariableValueEquals(CommonConstants.PROCESS_STATUS, processFrontDto.getProcessStatus());
            }
        }
        //----时间----
        if (ObjectUtil.isNotNull(processFrontDto.getStartTimeStart())){
            query.processVariableValueGreaterThanOrEqual(CommonConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeStart());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getStartTimeEnd())){
            query.processVariableValueLessThanOrEqual(CommonConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeEnd());
        }
        // if (ObjectUtil.isNotNull(processFrontDto.getEndTimeStart())){
        //     query.processVariableValueGreaterThanOrEqual(CommonConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeStart());
        // }
        // if (ObjectUtil.isNotNull(processFrontDto.getEndTimeEnd())){
        //     query.processVariableValueLessThanOrEqual(CommonConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeEnd());
        // }
        query.orderByTaskCreateTime().desc(); //按照到达时间排序
        return query;
    }

    /**
     * 获取vo已办task
     * @param userId
     * @return
     */
    @Override
    public Map listAlreadyTask(String userId, ProcessFrontDTO processFrontDto) {
        HistoricTaskInstanceQuery query = this.listHistoryTaskOriginQuery(userId, processFrontDto);
        long count = query.count();
        List<HistoricTaskInstance> list = query.listPage(processFrontDto.getStart(), processFrontDto.getPageSize());
        // 转换VO
        List<ProcessVo> collect = list.stream().map(e -> {
            ProcessVo vo = new ProcessVo();
            vo.convertFrom(e);
            return vo;
        }).collect(Collectors.toList());
        Map map = this.getReturnMap(collect, count);
        return map;
    }

    /**
     * 获取原始已办理task query
     * @param userId
     * @param processFrontDto
     * @return
     */
    private HistoricTaskInstanceQuery listHistoryTaskOriginQuery(String userId, ProcessFrontDTO processFrontDto){
        HistoricTaskInstanceQuery query = historyService.createHistoricTaskInstanceQuery()
                // 必要条件 办理人
                .taskAssignee(userId);
        // 条件筛选
        if (StrUtil.isNotBlank(processFrontDto.getSearch())){
            query.or();
            query.processVariableValueLikeIgnoreCase(CommonConstants.PROCESS_VAR_STARTER_NICKNAME, "%"+processFrontDto.getSearch()+"%");
            query.processVariableValueLikeIgnoreCase(CommonConstants.PROCESS_TITLE, "%"+processFrontDto.getSearch()+"%");
            query.processVariableValueLikeIgnoreCase(CommonConstants.PROCESS_DESC, "%"+processFrontDto.getSearch()+"%");
            query.endOr();
        }
        if (StrUtil.isNotBlank(processFrontDto.getStarter())){
            query.processVariableValueEqualsIgnoreCase(CommonConstants.PROCESS_VAR_STARTER_ID, processFrontDto.getStarter());
        }
        //----流程----
        if (StrUtil.isNotBlank(processFrontDto.getProcessType())){
            query.or();
            query.processDefinitionKey(processFrontDto.getProcessType());
            query.processDefinitionName(processFrontDto.getProcessType());
            query.endOr();
        }
        if (ObjectUtil.isNotNull(processFrontDto.getProcessStatus())){
            if (!processFrontDto.getProcessStatus().equals(CommonConstants.BUSINESS_STATUS_ALL)){
                query.processVariableValueEquals(CommonConstants.PROCESS_STATUS, processFrontDto.getProcessStatus());
            }
        }
        //----时间----
        if (ObjectUtil.isNotNull(processFrontDto.getStartTimeStart())){
            query.processVariableValueGreaterThanOrEqual(CommonConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeStart());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getStartTimeEnd())){
            query.processVariableValueLessThanOrEqual(CommonConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeEnd());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getEndTimeStart())){
            query.processVariableValueGreaterThanOrEqual(CommonConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeStart());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getEndTimeEnd())){
            query.processVariableValueLessThanOrEqual(CommonConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeEnd());
        }
        query.orderByHistoricTaskInstanceStartTime().desc();//按照结束时间排序
        return query;
    }

    /**
     * 获取VO已参与流程
     * @param userId
     * @return
     */
    @Override
    public Map listAlreadyProcess(String userId, ProcessFrontDTO processFrontDto) {
        HistoricProcessInstanceQuery query = listHistoryProcessOriginQuery(userId, processFrontDto);
        long count = query.count();
        List<HistoricProcessInstance> list = query.listPage(processFrontDto.getStart(), processFrontDto.getPageSize());
        // 转换VO
        List<ProcessVo> collect = list.stream().map(e -> {
            ProcessVo vo = new ProcessVo();
            vo.convertFrom(e);
            return vo;
        }).collect(Collectors.toList());
        Map map = this.getReturnMap(collect, count);
        return map;
    }

    /**
     * 获取原始已参与流程query
     * @param userId
     * @param processFrontDto
     * @return
     */
    private HistoricProcessInstanceQuery listHistoryProcessOriginQuery(String userId, ProcessFrontDTO processFrontDto){
        HashSet<String> groups = new HashSet<>();
        groups.add("test");
        HistoricProcessInstanceQuery query = historyService.createHistoricProcessInstanceQuery();
        query.includeProcessVariables();
        // 必要条件 参与人或参与组
        query.or(); // 开始or
        query.involvedUser(userId);
        query.endOr();
        // 条件筛选
        if (StrUtil.isNotBlank(processFrontDto.getSearch())){
            query.or();
            query.variableValueLikeIgnoreCase(CommonConstants.PROCESS_VAR_STARTER_NICKNAME, "%"+processFrontDto.getSearch()+"%");
            query.variableValueLikeIgnoreCase(CommonConstants.PROCESS_TITLE, "%"+processFrontDto.getSearch()+"%");
            query.variableValueLikeIgnoreCase(CommonConstants.PROCESS_DESC, "%"+processFrontDto.getSearch()+"%");
            query.endOr();
        }
        if (StrUtil.isNotBlank(processFrontDto.getStarter())){
            query.variableValueEqualsIgnoreCase(CommonConstants.PROCESS_VAR_STARTER_ID, processFrontDto.getStarter());
        }
        //----流程----
        if (StrUtil.isNotBlank(processFrontDto.getProcessType())){
            query.or();
            query.processDefinitionKey(processFrontDto.getProcessType());
            query.processDefinitionName(processFrontDto.getProcessType());
            query.endOr();
        }
        if (ObjectUtil.isNotNull(processFrontDto.getProcessStatus())){
            if (!processFrontDto.getProcessStatus().equals(CommonConstants.BUSINESS_STATUS_ALL)){
                query.variableValueEquals(CommonConstants.PROCESS_STATUS, processFrontDto.getProcessStatus());
            }
        }
        //----时间----
        if (ObjectUtil.isNotNull(processFrontDto.getStartTimeStart())){
            query.variableValueGreaterThanOrEqual(CommonConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeStart());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getStartTimeEnd())){
            query.variableValueLessThanOrEqual(CommonConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeEnd());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getEndTimeStart())){
            query.variableValueGreaterThanOrEqual(CommonConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeStart());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getEndTimeEnd())){
            query.variableValueLessThanOrEqual(CommonConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeEnd());
        }
        query.orderByProcessInstanceStartTime().desc(); //按照结束时间排序
        return query;
    }

    /**
     * 获取VO已发流程
     * @param userId
     * @param processFrontDto
     * @return
     */
    @Override
    public Map listOwnProcess(String userId, ProcessFrontDTO processFrontDto) {
        HistoricProcessInstanceQuery query = listOwnProcessOriginQuery(userId, processFrontDto);
        long count = query.count();
        List<HistoricProcessInstance> list = query.listPage(processFrontDto.getStart(), processFrontDto.getPageSize());
        // 转换VO
        List<ProcessVo> collect = list.stream().map(e -> {
            ProcessVo vo = new ProcessVo();
            vo.convertFrom(e);
            return vo;
        }).collect(Collectors.toList());
        Map map = this.getReturnMap(collect, count);
        return map;
    }

    /**
     * 获取原始已发流程query
     * @param userId
     * @param processFrontDto
     * @return
     */
    private HistoricProcessInstanceQuery listOwnProcessOriginQuery(String userId, ProcessFrontDTO processFrontDto){
        HashSet<String> groups = new HashSet<>();
        groups.add("test");
        HistoricProcessInstanceQuery query = historyService.createHistoricProcessInstanceQuery();
        query.includeProcessVariables();
        // 必要条件 发起人
        query.startedBy(userId); //发起人
        // 条件筛选
        if (StrUtil.isNotBlank(processFrontDto.getSearch())){
            query.or();
            query.variableValueLikeIgnoreCase(CommonConstants.PROCESS_VAR_STARTER_NICKNAME, "%"+processFrontDto.getSearch()+"%");
            query.variableValueLikeIgnoreCase(CommonConstants.PROCESS_TITLE, "%"+processFrontDto.getSearch()+"%");
            query.variableValueLikeIgnoreCase(CommonConstants.PROCESS_DESC, "%"+processFrontDto.getSearch()+"%");
            query.endOr();
        }
        if (StrUtil.isNotBlank(processFrontDto.getStarter())){
            query.variableValueEqualsIgnoreCase(CommonConstants.PROCESS_VAR_STARTER_ID, processFrontDto.getStarter());
        }
        //----流程----
        if (StrUtil.isNotBlank(processFrontDto.getProcessType())){
            query.or();
            query.processDefinitionKey(processFrontDto.getProcessType());
            query.processDefinitionName(processFrontDto.getProcessType());
            query.endOr();
        }
        if (ObjectUtil.isNotNull(processFrontDto.getProcessStatus())){
            if (!processFrontDto.getProcessStatus().equals(CommonConstants.BUSINESS_STATUS_ALL)){
                query.variableValueEquals(CommonConstants.PROCESS_STATUS, processFrontDto.getProcessStatus());
            }
        }
        //----时间----
        if (ObjectUtil.isNotNull(processFrontDto.getStartTimeStart())){
            query.variableValueGreaterThanOrEqual(CommonConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeStart());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getStartTimeEnd())){
            query.variableValueLessThanOrEqual(CommonConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeEnd());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getEndTimeStart())){
            query.variableValueGreaterThanOrEqual(CommonConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeStart());
        }
        if (ObjectUtil.isNotNull(processFrontDto.getEndTimeEnd())){
            query.variableValueLessThanOrEqual(CommonConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeEnd());
        }
        query.orderByProcessInstanceStartTime().desc(); //按照发起时间排序
        return query;
    }

    /**
     * 获取待阅流程
     * @param userId
     * @param processFrontDto
     * @return
     */
    @Override
    public Map listCCProcess(String userId, ProcessFrontDTO processFrontDto) {
        Long count = flowCCMapper.selectFlowCCListCount(processFrontDto, userId);
        if (count==0){
            Map map = this.getReturnMap(null, count);
            return map;
        }
        List<FlowCC> list = flowCCMapper.selectFlowCCListPage(processFrontDto, userId);
        Set<String> instanceIdSet = list.stream().map(FlowCC::getProcessInstanceId).collect(Collectors.toSet());
        List<HistoricProcessInstance> historicProcessInstanceList = historyService.createHistoricProcessInstanceQuery().processInstanceIds(instanceIdSet).includeProcessVariables().list();
        // 转换VO
        List<ProcessVo> collect = list.stream().map(e -> {
            ProcessVo vo = new ProcessVo();
            HistoricProcessInstance eInstance = null;
            for (HistoricProcessInstance instance : historicProcessInstanceList) {
                if (((HistoricProcessInstanceEntityImpl) instance).getProcessInstanceId().equals(e.getProcessInstanceId())){
                    eInstance = instance;
                }
            }
            vo.convertFrom(e, eInstance);
            return vo;
        }).collect(Collectors.toList());
        Map map = this.getReturnMap(collect, count);
        return map;
    }

    /**
     * 获取原始待阅流程query
     * @param userId
     * @param processFrontDto
     * @return
     */
    // private HistoricProcessInstanceQuery listCCProcessOriginQuery(String userId, ProcessFrontDTO processFrontDto){
    //     HashSet<String> groups = new HashSet<>();
    //     groups.add("test");
    //     HistoricProcessInstanceQuery query = historyService.createHistoricProcessInstanceQuery();
    //     // 必要条件 抄送人
    //     query.variableValueLikeIgnoreCase(ProcessFrontConstants.PROCESS_CC, "%,"+userId+",%"); //抄送人
    //     // 条件筛选
    //     if (StrUtil.isNotBlank(processFrontDto.getSearch())){
    //         query.or();
    //         query.processInstanceNameLikeIgnoreCase("%"+processFrontDto.getSearch()+"%");
    //         query.variableValueLikeIgnoreCase(ProcessFrontConstants.PROCESS_VAR_STARTER_NICKNAME, "%"+processFrontDto.getSearch()+"%");
    //         query.endOr();
    //     }
    //     if (StrUtil.isNotBlank(processFrontDto.getStarter())){
    //         query.variableValueEqualsIgnoreCase(ProcessFrontConstants.PROCESS_VAR_STARTER_ID, processFrontDto.getStarter());
    //     }
    //     //----流程----
    //     if (StrUtil.isNotBlank(processFrontDto.getProcessType())){
    //         query.or();
    //         query.processDefinitionKey(processFrontDto.getProcessType());
    //         query.processDefinitionName(processFrontDto.getProcessType());
    //         query.endOr();
    //     }
    //     if (ObjectUtil.isNotNull(processFrontDto.getProcessStatus())){
    //         if (!processFrontDto.getProcessStatus().equals(ProcessFrontConstants.ProcessStatus.ALL.get())){
    //             query.variableValueEquals(ProcessFrontConstants.PROCESS_VAR_PROCESS_STATUS, processFrontDto.getProcessStatus());
    //         }
    //     }
    //     //----时间----
    //     if (ObjectUtil.isNotNull(processFrontDto.getStartTimeStart())){
    //         query.variableValueGreaterThanOrEqual(ProcessFrontConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeStart());
    //     }
    //     if (ObjectUtil.isNotNull(processFrontDto.getStartTimeEnd())){
    //         query.variableValueLessThanOrEqual(ProcessFrontConstants.PROCESS_VAR_START_TIME, processFrontDto.getStartTimeEnd());
    //     }
    //     if (ObjectUtil.isNotNull(processFrontDto.getEndTimeStart())){
    //         query.variableValueGreaterThanOrEqual(ProcessFrontConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeStart());
    //     }
    //     if (ObjectUtil.isNotNull(processFrontDto.getEndTimeEnd())){
    //         query.variableValueLessThanOrEqual(ProcessFrontConstants.PROCESS_VAR_END_TIME, processFrontDto.getEndTimeEnd());
    //     }
    //     query.orderByProcessInstanceStartTime().desc(); //按照发起时间排序
    //     return query;
    // }










}

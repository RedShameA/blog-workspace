package com.zhy.flowable.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhy.flowable.entity.FlowProcessTemplates;
import com.zhy.flowable.entity.bo.FlowTemplateGroupBo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FlowProcessTemplateMapper extends BaseMapper<FlowProcessTemplates> {
    @Select("select CONCAT('Flowable', template_id) as template_id, template_name from flow_process_templates")
    List<FlowTemplateGroupBo> listProcesses();
}

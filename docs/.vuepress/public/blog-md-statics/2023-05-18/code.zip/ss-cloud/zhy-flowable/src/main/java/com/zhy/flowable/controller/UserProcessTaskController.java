package com.zhy.flowable.controller;

import com.zhy.common.core.web.controller.BaseController;
import com.zhy.common.core.web.domain.AjaxResult;
import com.zhy.common.security.utils.SecurityUtils;
import com.zhy.flowable.entity.bo.FlowTemplateGroupBo;
import com.zhy.flowable.entity.dto.ProcessFrontDTO;
import com.zhy.flowable.entity.vo.TemplateGroupVo;
import com.zhy.flowable.service.SettingsService;
import com.zhy.flowable.service.UserProcessTaskService;
import org.flowable.engine.delegate.event.AbstractFlowableEngineEventListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @Author wangfeng
 * @Description 用户 待办/已办/发起/待阅
 * @Date 2022-12-27 15:43
 */
@RestController
@RequestMapping("/process")
public class UserProcessTaskController extends BaseController {

    @Resource
    UserProcessTaskService processTaskService;
    @Resource
    SettingsService settingsService;


    @GetMapping("/listTask")
    public AjaxResult listTask(ProcessFrontDTO processFrontDto){
        String username = SecurityUtils.getLoginUser().getUserid().toString();
        Map map = processTaskService.listTask(username, processFrontDto);
        return AjaxResult.success(map);
    }


    @GetMapping("/listAlreadyTask")
    public AjaxResult listAlreadyTask(ProcessFrontDTO processFrontDto){
        String username = SecurityUtils.getLoginUser().getUserid().toString();
        Map map = processTaskService.listAlreadyTask(username, processFrontDto);
        return AjaxResult.success(map);
    }


    @GetMapping("/listAlreadyProcess")
    public AjaxResult listAlreadyProcess(ProcessFrontDTO processFrontDto){
        String username = SecurityUtils.getLoginUser().getUserid().toString();
        Map map = processTaskService.listAlreadyProcess(username, processFrontDto);
        return AjaxResult.success(map);
    }

    @GetMapping("/listOwnProcess")
    public AjaxResult listOwnProcess(ProcessFrontDTO processFrontDto){
        String username = SecurityUtils.getLoginUser().getUserid().toString();
        Map map = processTaskService.listOwnProcess(username, processFrontDto);
        return AjaxResult.success(map);
    }

    @GetMapping("/listCCProcess")
    public AjaxResult listCCProcess(ProcessFrontDTO processFrontDto){
        String username = SecurityUtils.getLoginUser().getUserid().toString();
        Map map = processTaskService.listCCProcess(username, processFrontDto);
        return AjaxResult.success(map);
    }

    @GetMapping("/listProcessTypes")
    public AjaxResult listProcessTypes(){
        List<FlowTemplateGroupBo> list = settingsService.listProcesses();
        return AjaxResult.success(list);
    }
}

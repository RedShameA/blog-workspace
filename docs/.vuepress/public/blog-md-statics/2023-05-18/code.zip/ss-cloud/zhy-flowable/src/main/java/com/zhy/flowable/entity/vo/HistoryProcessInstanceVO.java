package com.zhy.flowable.entity.vo;

import com.zhy.flowable.entity.UserInfo;
import lombok.Data;

import java.util.Date;

/**
 * @author syk
 * @Description 流程视图对象
 * @Date 13:33 2022/12/30
 */
@Data
public class HistoryProcessInstanceVO {
    //实例Id
    private String processInstanceId;

    //标题
    private String title;

    //简介
    private String desc;

    //审批类型
    private String processDefinitionName;

    //发起人
    private UserInfo startUser;

    //开始时间
    private Date startTime;

    //结束时间
    private Date endTime;

    //当前节点
    private String currentActivityName;

    //审批状态
    private String businessStatus;

    //总用时
    private String duration;
}

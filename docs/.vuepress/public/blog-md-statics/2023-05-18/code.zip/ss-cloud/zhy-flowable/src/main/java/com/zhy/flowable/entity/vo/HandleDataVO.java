package com.zhy.flowable.entity.vo;

import com.alibaba.fastjson.JSONObject;
import com.zhy.flowable.entity.ChildNode;
import com.zhy.flowable.entity.FlowProcessTemplates;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author syk
 * @Description 流程详细信息视图
 * @Date 14:15 2023/1/4
 */
@Data
public class HandleDataVO {
    // 任务id
    private String taskId;

    // 流程实例Id
    private String processInstanceId;

    // 表单数据
    private JSONObject formData;

    // 是否签名
    private Boolean signFlag;

    // 流程模板
    private FlowProcessTemplates processTemplates;

    // 当前节点json数据 如果有taskId的话才返回
    private ChildNode currentNode;

    // 结束的节点
    List<String> endList;

    // 正在运行的节点
    List<String> runningList;

    // 还没运行的节点
    List<String> noTakeList;

    //流程图
    List<TaskDetailVO> processList;
}

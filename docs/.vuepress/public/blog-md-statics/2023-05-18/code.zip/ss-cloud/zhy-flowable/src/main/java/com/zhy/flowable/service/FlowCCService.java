package com.zhy.flowable.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zhy.flowable.entity.FlowCC;
import com.zhy.system.api.domain.SysUser;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @Author wangfeng
 * @Description 抄送service
 * @Date 2023-01-04 16:29
 */
public interface FlowCCService extends IService<FlowCC> {

    IPage<FlowCC> listPage(Integer pageNo, int pageSize, Long userId, Boolean all);

    Boolean readCC(Integer id);
}

package com.zhy.flowable.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zhy.flowable.entity.FlowComment;

/**
 * @author syk
 * @Description 评论service
 * @Date 13:49 2023/2/2
 */
public interface FlowCommentService extends IService<FlowComment> {


}

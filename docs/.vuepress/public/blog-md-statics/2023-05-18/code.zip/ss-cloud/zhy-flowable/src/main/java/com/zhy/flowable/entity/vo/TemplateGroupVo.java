package com.zhy.flowable.entity.vo;

import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TemplateGroupVo {

    private Integer id;

    private String name;

    private List<Template> items;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Template {

        private String formId;

        private Integer tgId;

        private String formName;

        private String icon;

        private Boolean isStop;

        private String remark;

        private JSONObject logo;

        private String background;

        private String createTime;

        private String updateTime;

        private String templateId;
    }


}

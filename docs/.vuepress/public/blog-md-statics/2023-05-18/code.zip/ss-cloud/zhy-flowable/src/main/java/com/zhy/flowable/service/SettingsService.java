package com.zhy.flowable.service;

import com.zhy.flowable.entity.FlowFormGroups;
import com.zhy.flowable.entity.FlowProcessTemplates;
import com.zhy.flowable.entity.FlowTemplateGroup;
import com.zhy.flowable.entity.bo.FlowTemplateGroupBo;
import com.zhy.flowable.entity.dto.FlowEngineDTO;
import com.zhy.flowable.entity.vo.TemplateGroupVo;

import java.util.List;
import java.util.Map;

public interface SettingsService {
    boolean createFormGroup(String name);

    boolean updateFormGroup(int id, String name);

    boolean deleteFormGroup(int id);

    List<TemplateGroupVo> getFormGroups();

    List<FlowTemplateGroupBo> listProcesses();

    void saveForm(FlowEngineDTO flowEngineDTO);

    Map<String, Object> updateForm(String templateId, String type, Integer groupId);

    void updateFormDetail(FlowProcessTemplates template);

    FlowProcessTemplates getFormTemplateById(String templateId);

    void groupSort(List<FlowFormGroups> formGroups);

    void itemSort(List<FlowTemplateGroup> flowTemplateGroups);
}

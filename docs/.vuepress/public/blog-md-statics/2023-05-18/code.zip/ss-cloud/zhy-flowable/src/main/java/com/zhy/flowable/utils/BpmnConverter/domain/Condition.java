package com.zhy.flowable.utils.BpmnConverter.domain;

import lombok.Data;

import java.util.List;

/**
 * @Author wangfeng
 * @Description 条件实体
 * @Date 2023-01-03 16:26
 */
@Data
public class Condition {
    private String id;
    private String title;
    private String valueType;
    private String compare;
    private List<Object> value;
}

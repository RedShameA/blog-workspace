package com.zhy.flowable.exception;

/**
 * @author syk
 * @Description 流程异常封装
 * @Date 16:02 2022/12/30
 */
public class WorkFlowException extends RuntimeException {
    public WorkFlowException(String message) {
        super(message);
    }
}

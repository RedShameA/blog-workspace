package com.zhy.flowable.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zhy.system.api.domain.SysUser;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author wangfeng
 * @Description 抄送实体
 * @Date 2023-01-04 16:16
 */
@Data
@Builder
@TableName("flow_cc")
@AllArgsConstructor
@NoArgsConstructor
public class FlowCC {

    //id
    @TableId
    private Integer id;
    // 抄送用户id
    private Long userId;
    // 流程id
    private String processInstanceId;
    // 发起抄送的任务id
    private String activityId;
    // 抄送标题
    private String ccTitle;
    // 抄送简介
    private String ccDesc;
    // 是否已读
    private Boolean readed;
    // 已读时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date readTime;


    /** 创建者 */
    private String createBy;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    /** 更新者 */
    private String updateBy;

    /** 更新时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;



}

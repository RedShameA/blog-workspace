package com.zhy.flowable.entity.vo;

import com.zhy.flowable.entity.UserInfo;
import lombok.Data;

import java.io.Serializable;

@Data
public class UserInfoVO extends UserInfo implements Serializable {
    // 是否已读
    private Boolean readed;
}

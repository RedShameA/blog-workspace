package com.zhy.flowable.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhy.flowable.entity.FlowCC;
import com.zhy.flowable.entity.FlowComment;
import com.zhy.flowable.mapper.FlowCCMapper;
import com.zhy.flowable.mapper.FlowCommentMapper;
import com.zhy.flowable.service.FlowCCService;
import com.zhy.flowable.service.FlowCommentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @author syk
 * @Description
 * @Date 13:50 2023/2/2
 */
@Service
public class FlowCommentServiceImpl extends ServiceImpl<FlowCommentMapper, FlowComment> implements FlowCommentService {
    @Resource
    FlowCommentMapper flowCommentMapper;

}

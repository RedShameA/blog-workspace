package com.zhy.flowable.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhy.flowable.entity.FlowCC;
import com.zhy.flowable.entity.dto.ProcessFrontDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Author wangfeng
 * @Description 抄送实体mapper
 * @Date 2023-01-04 16:29
 */
@Mapper
public interface FlowCCMapper extends BaseMapper<FlowCC> {
    Long selectFlowCCListCount(@Param("dto") ProcessFrontDTO processFrontDTO, @Param("userId") String userId);
    List<FlowCC> selectFlowCCListPage(@Param("dto") ProcessFrontDTO processFrontDTO, @Param("userId") String userId);
}

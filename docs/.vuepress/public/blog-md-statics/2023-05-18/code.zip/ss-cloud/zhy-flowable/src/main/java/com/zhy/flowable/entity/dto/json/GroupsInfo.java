package com.zhy.flowable.entity.dto.json;

import lombok.Data;

import java.util.List;

@Data
public class GroupsInfo {
    private String groupType;

    private List<ConditionInfo> conditions;

    private List<String> cids;

}

package com.zhy.flowable.listener;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.zhy.common.core.domain.R;
import com.zhy.flowable.entity.FlowCC;
import com.zhy.flowable.service.FlowCCService;
import com.zhy.flowable.utils.BpmnConverter.BpmnUtil;
import com.zhy.flowable.utils.BpmnConverter.domain.ProcessNode;
import com.zhy.flowable.utils.BpmnConverter.domain.Props;
import com.zhy.system.api.RemoteUserService;
import com.zhy.system.api.domain.SysUser;
import org.flowable.bpmn.model.Process;
import org.flowable.bpmn.model.ServiceTask;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

/**
 * @Author wangfeng
 * @Description 抄送监听器
 * @Date 2023-01-04 10:50
 */
@Component("ccExecutionListener")
public class CCExecutionListener implements JavaDelegate {
    @Resource
    RuntimeService runtimeService;
    @Resource
    RepositoryService repositoryService;
    @Resource
    private RemoteUserService remoteUserService;
    @Resource
    private FlowCCService flowCCService;
    @Override
    public void execute(DelegateExecution execution) {
        // 获取当前任务的props
        String processInstanceId = execution.getProcessInstanceId();
        String currentActivityId = execution.getCurrentActivityId();
        Process mainProcess = repositoryService.getBpmnModel(execution.getProcessDefinitionId()).getMainProcess();
        String title = mainProcess.getName();
        ServiceTask task = (ServiceTask) mainProcess.getFlowElement(currentActivityId);
        String nodeString = BpmnUtil.getTaskNodeString(task);
        ProcessNode node = JSONObject.parseObject(nodeString, new TypeReference<ProcessNode>(){});
        Props props = node.getProps();
        List<Map<String, String>> assignedUser = props.getAssignedUser();

        HashSet<Long> realCCUserSet = new HashSet<>();
        // 获取所有需要抄送的用户
        assignedUser.forEach(map->{
            String type = map.get("type");
            String id = map.get("id");
            if ("user".equalsIgnoreCase(type)){
                realCCUserSet.add(Long.parseLong(id));
            }else{
                ArrayList<String> depts = new ArrayList<>();
                depts.add(id);
                R<List<SysUser>> usersByDeptId = remoteUserService.getUsersByDeptId(depts);
                usersByDeptId.getData().forEach(sysUser -> realCCUserSet.add(sysUser.getUserId()));
            }
        });
        // 获取流程变量，动态添加抄送人
        if (props.getShouldAdd()){
            JSONArray assignees = execution.getVariable("assignees", JSONArray.class);
            for (Object assignee : assignees) {
                if (assignee instanceof JSONObject){
                    if (((JSONObject) assignee).getString("id").equalsIgnoreCase(currentActivityId)) {
                        List<Map<String, String>> users = ((JSONObject) assignee).getObject("user", new TypeReference<List<Map<String, String>>>(){});
                        users.forEach(map->{
                            String type = map.get("type");
                            String id = map.get("id");
                            if ("user".equalsIgnoreCase(type)){
                                realCCUserSet.add(Long.parseLong(id));
                            }else{
                                ArrayList<String> depts = new ArrayList<>();
                                depts.add(id);
                                R<List<SysUser>> usersByDeptId = remoteUserService.getUsersByDeptId(depts);
                                usersByDeptId.getData().forEach(sysUser -> realCCUserSet.add(sysUser.getUserId()));
                            }
                        });
                    }
                }
            }
        }


        realCCUserSet.forEach(userId->{
            // 逐个保存抄送
            FlowCC flowCC = FlowCC.builder()
                    .userId(userId)
                    .processInstanceId(processInstanceId)
                    .activityId(currentActivityId)
                    .ccTitle(title)
                    .ccDesc("")
                    .readed(false)
                    .createTime(new Date()).build();
            flowCCService.save(flowCC);
        });
        System.out.println("抄送人ID：" + realCCUserSet);
        // String id = execution.getId();
        // runtimeService.getVariables(id);
        System.out.println("到达抄送任务：" + execution.getCurrentActivityId());
    }
}

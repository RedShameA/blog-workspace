package com.zhy.flowable.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zhy.flowable.entity.FlowCC;
import com.zhy.flowable.mapper.FlowCCMapper;
import com.zhy.flowable.service.FlowCCService;
import com.zhy.system.api.domain.SysUser;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @Author wangfeng
 * @Description 抄送service
 * @Date 2023-01-04 16:30
 */
@Service
public class FlowCCServiceImpl extends ServiceImpl<FlowCCMapper, FlowCC> implements FlowCCService {
    @Resource
    FlowCCMapper flowCCMapper;
    @Override
    public IPage<FlowCC> listPage(Integer pageNo, int pageSize, Long userId, Boolean all) {
        Page<FlowCC> page = new Page<>();
        page.setCurrent(pageNo);
        page.setSize(pageSize);
        LambdaQueryWrapper<FlowCC> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(FlowCC::getUserId, userId);
        wrapper.orderByDesc(FlowCC::getCreateTime);
        if (!all){
            wrapper.eq(FlowCC::getReaded, false);
        }
        return this.page(page, wrapper);
    }

    @Override
    public Boolean readCC(Integer id) {
        /*LambdaUpdateWrapper<FlowCC> wrapper = new LambdaUpdateWrapper<>();
        wrapper.eq(FlowCC::getId, id)
                .eq(FlowCC::getReaded, false)
                .set(FlowCC::getReaded, true)
                .set(FlowCC::getReadTime, new Date());*/
        FlowCC flowCC = FlowCC.builder()
                .id(id)
                .readed(true)
                .readTime(new Date()).build();
        return this.updateById(flowCC);
    }
}

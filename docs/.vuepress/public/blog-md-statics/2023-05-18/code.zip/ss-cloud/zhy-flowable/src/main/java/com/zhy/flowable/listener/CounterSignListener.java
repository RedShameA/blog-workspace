package com.zhy.flowable.listener;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.map.MapUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.zhy.common.core.domain.R;
import com.zhy.flowable.entity.ChildNode;
import com.zhy.flowable.entity.Properties;
import com.zhy.flowable.entity.UserInfo;
import com.zhy.flowable.enums.AssigneeTypeEnums;
import com.zhy.flowable.exception.WorkFlowException;
import com.zhy.flowable.utils.SpringContextHolder;
import com.zhy.system.api.RemoteUserService;
import com.zhy.system.api.domain.SysUser;
import org.flowable.bpmn.model.Process;
import org.flowable.bpmn.model.UserTask;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.zhy.flowable.constats.CommonConstants.FORM_VAR;
import static com.zhy.flowable.constats.CommonConstants.START_USER_INFO;
import static com.zhy.flowable.utils.BpmnModelUtils.getChildNode;

/**
 * @author syk
 * @Description 流程节点监听器
 * @Date 9:38 2023/1/3
 */
@Component
public class CounterSignListener implements ExecutionListener {
    @Resource
    private RepositoryService repositoryService;

    @Override
    public void notify(DelegateExecution execution) {
        String currentActivityId = execution.getCurrentActivityId();
        Process mainProcess = repositoryService.getBpmnModel(execution.getProcessDefinitionId()).getMainProcess();
        UserTask userTask = (UserTask) mainProcess.getFlowElement(currentActivityId);
        String dingDing = mainProcess.getAttributeValue("http://flowable.org/bpmn", "ZHY");
        JSONObject jsonObject = JSONObject.parseObject(dingDing, new TypeReference<JSONObject>() {
        });
        String processJson = jsonObject.getString("processJson");
        ChildNode childNode = JSONObject.parseObject(processJson, new TypeReference<ChildNode>() {
        });
        List<String> assigneeList = new ArrayList<>();
        String variable = currentActivityId + "assigneeList";
        List usersValue = (List) execution.getVariable(variable);
        if (usersValue == null) {
            ChildNode currentNode = getChildNode(childNode, currentActivityId);
            if (currentNode == null) {
                throw new WorkFlowException("查找审批人失败,请联系管理员重试");
            }
            Properties props = currentNode.getProps();
            String assignedType = props.getAssignedType();
            Map<String, Object> nobody = props.getNobody();
            if (AssigneeTypeEnums.ASSIGN_USER.getTypeName().equals(assignedType)) {
                List<UserInfo> assignedUser = props.getAssignedUser();
                for (UserInfo userInfo : assignedUser) {
                    assigneeList.add(userInfo.getId());
                }
            } else if (AssigneeTypeEnums.SELF_SELECT.getTypeName().equals(assignedType)) {
                // 自选审核人 可以多选
                JSONObject formJson = execution.getVariable(FORM_VAR, JSONObject.class);
                // 从参数中找出当前节点对应的审批人
                JSONObject assignes = formJson.getJSONObject("assignees");
                List list = JSONObject.parseObject(assignes.getJSONArray(currentActivityId).toJSONString(), List.class);
                for (Object o : list) {
                    UserInfo userInfo = JSONObject.parseObject(o.toString(), UserInfo.class);
                    if ("user".equals(userInfo.getType())) {
                        assigneeList.add(userInfo.getId());
                    } else if ("dept".equals(userInfo.getType())) {
                        // 查询部门下所有的员工 并放入审批列表
                        RemoteUserService userService = SpringContextHolder
                                .getBean(RemoteUserService.class);
                        R<List<SysUser>> users = userService.getUsersByDeptId(Arrays.asList(userInfo.getId()));
                        List<String> userIds = users.getData().stream().map(u -> u.getUserId().toString()).collect(Collectors.toList());
                        assigneeList.addAll(userIds);
                    }
                }
            } else if (AssigneeTypeEnums.LEADER_TOP.getTypeName().equals(assignedType)) {
                throw new WorkFlowException("暂不做这个功能,等发版!");
            } else if (AssigneeTypeEnums.LEADER.getTypeName().equals(assignedType)) {
                throw new WorkFlowException("当前只是简单的系统 没有RBAC功能,各位可以自己实现!");
            } else if (AssigneeTypeEnums.ROLE.getTypeName().equals(assignedType)) {
                throw new WorkFlowException("当前只是简单的系统 没有RBAC功能,各位可以自己实现!");
            } else if (AssigneeTypeEnums.SELF.getTypeName().equals(assignedType)) {
                // 审核人为发起人
                String startUserInfo = execution.getVariable(START_USER_INFO, String.class);
                UserInfo userInfo = JSONObject.parseObject(startUserInfo, new TypeReference<UserInfo>() {
                });
                assigneeList.add(userInfo.getId());
            } else if (AssigneeTypeEnums.FORM_USER.getTypeName().equals(assignedType)) {
                String formUser = props.getFormUser();
                List<JSONObject> assigneeUsers = execution.getVariable(formUser, List.class);
                if (assigneeUsers != null) {
                    for (JSONObject assigneeUser : assigneeUsers) {
                        assigneeList.add(assigneeUser.getString("id"));
                    }
                }
            }
            if (CollUtil.isEmpty(assigneeList)) {
                String handler = MapUtil.getStr(nobody, "handler");
                if ("TO_PASS".equals(handler)) {
                    // 自动通过
                    assigneeList.add("100000");
                    execution.setVariable(variable, assigneeList);
                } else if ("TO_REFUSE".equals(handler)) {
                    // 自动驳回
                    execution.setVariable("autoRefuse", Boolean.TRUE);
                    assigneeList.add("100000");
                    execution.setVariable(variable, assigneeList);
                } else if ("TO_ADMIN".equals(handler)) {
                    // 交给管理员
                    assigneeList.add("1");
                    execution.setVariable(variable, assigneeList);
                } else if ("TO_USER".equals(handler)) {
                    // 指派给指定人
                    Object assignedUserObj = nobody.get("assignedUser");
                    if (assignedUserObj != null) {
                        List<JSONObject> assignedUser = (List<JSONObject>) assignedUserObj;
                        if (assignedUser.size() > 0) {
                            for (JSONObject object : assignedUser) {
                                assigneeList.add(object.getString("id"));
                            }
                            execution.setVariable(variable, assigneeList);
                        } else {
                            assigneeList.add("100000");
                            execution.setVariable(variable, assigneeList);
                        }

                    }

                } else {
                    throw new WorkFlowException("找不到审批人,请检查配置!!!");
                }
            } else {
                execution.setVariable(variable, assigneeList);
            }
        } else {
        }
    }
}

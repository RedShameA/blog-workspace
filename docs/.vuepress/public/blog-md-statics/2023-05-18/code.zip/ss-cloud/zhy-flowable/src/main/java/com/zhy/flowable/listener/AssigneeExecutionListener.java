package com.zhy.flowable.listener;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.zhy.common.core.domain.R;
import com.zhy.common.core.web.domain.AjaxResult;
import com.zhy.flowable.entity.UserInfo;
import com.zhy.flowable.service.WebSocketService;
import com.zhy.flowable.utils.BpmnConverter.domain.ProcessNode;
import com.zhy.flowable.utils.BpmnConverter.domain.Props;
import com.zhy.flowable.utils.SpringContextHolder;
import com.zhy.system.api.RemoteRoleService;
import com.zhy.system.api.RemoteUserService;
import com.zhy.system.api.domain.SysUser;
import org.flowable.bpmn.model.ExtensionElement;
import org.flowable.bpmn.model.Process;
import org.flowable.bpmn.model.UserTask;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.PipedReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.zhy.flowable.constats.CommonConstants.FORM_VAR;
import static com.zhy.flowable.constats.CommonConstants.START_USER_INFO;

/**
 * @Author wangfeng
 * @Description 处理task的指派
 * @Date 2023-01-03 11:05
 */

@Component
public class AssigneeExecutionListener implements ExecutionListener {
    @Resource
    private RepositoryService repositoryService;


    @Override
    public void notify(DelegateExecution execution) {
        // 获取当前任务的props
        String currentActivityId = execution.getCurrentActivityId();
        String processInstanceId = execution.getProcessInstanceId();
        Process mainProcess = repositoryService.getBpmnModel(execution.getProcessDefinitionId()).getMainProcess();
        UserTask userTask = (UserTask) mainProcess.getFlowElement(currentActivityId);
        // 解析节点
        List<ExtensionElement> extensionElements = userTask.getExtensionElements().get("node");
        String nodeString = extensionElements.get(0).getElementText();
        ProcessNode node = JSONObject.parseObject(nodeString, new TypeReference<ProcessNode>() {
        });
        Props props = node.getProps();

        // 获取发起人信息
        String startUserInfo = execution.getVariable(START_USER_INFO, String.class);
        UserInfo startInfo = JSONObject.parseObject(startUserInfo, new TypeReference<UserInfo>() {
        });

        // 会签 集合 名
        String assigneeListCollectionName = currentActivityId + "assigneeList";
        List<String> assigneeList = (List<String>) execution.getVariable(assigneeListCollectionName);
        // 因为会进来很多次 但只有第一次是空的 所以只在为空的时候操作
        if (null == assigneeList) {
            assigneeList = new ArrayList<>();
            String assignedType = props.getAssignedType();
            if ("ASSIGN_USER".equalsIgnoreCase(assignedType)) {
                // 指定人员审批
                List<Map<String, String>> assignedUser = props.getAssignedUser();
                // 这会只能选人员，直接添加id即可
                for (Map<String, String> map : assignedUser) {
                    assigneeList.add(map.get("id"));
                }
            } else if ("SELF_SELECT".equalsIgnoreCase(assignedType)) {
                // 发起人自选
                JSONObject formJson = execution.getVariable(FORM_VAR, JSONObject.class);
                // 从参数中找出当前节点对应的审批人
                JSONArray assignes = formJson.getJSONArray("assignees");
                List<JSONObject> list = JSONObject.parseObject(assignes.toJSONString(), List.class);
                List<JSONObject> idList = list.stream().filter(a -> node.getId().equals(a.getString("id"))).collect(Collectors.toList());
                if (CollUtil.isNotEmpty(idList)) {
                    JSONObject objects = idList.get(0);
                    JSONArray user = objects.getJSONArray("user");
                    List userList = JSONObject.parseObject(user.toJSONString(), List.class);
                    for (Object o : userList) {
                        UserInfo userInfo = JSONObject.parseObject(o.toString(), UserInfo.class);
                        // 添加审批人
                        if ("user".equals(userInfo.getType())) {
                            assigneeList.add(userInfo.getId());
                        } else if ("dept".equals(userInfo.getType())) {
                            // 查询部门下所有的员工 并放入审批列表
                            RemoteUserService userService = SpringContextHolder
                                    .getBean(RemoteUserService.class);
                            R<List<SysUser>> users = userService.getUsersByDeptId(Arrays.asList(userInfo.getId()));
                            List<String> userIds = users.getData().stream().map(u -> u.getUserId().toString()).collect(Collectors.toList());
                            assigneeList.addAll(userIds);
                        }
                    }
                }
            } else if ("LEADER".equalsIgnoreCase(assignedType)) {
                // 发起人的主管 todo

            } else if ("ROLE".equalsIgnoreCase(assignedType)) {
                // 指定角色
                RemoteRoleService roleService = SpringContextHolder
                        .getBean(RemoteRoleService.class);
                List<Map<String, String>> role = props.getRole();
                for (Map<String, String> map : role) {
                    String id = map.get("id");
                    AjaxResult ajaxResult = roleService.listAllUserIdByRole(Long.valueOf(id));
                    List<Long> userIds = (List<Long>) ajaxResult.get("data");
                    List<String> collect = userIds.stream().map(String::valueOf).collect(Collectors.toList());
                    assigneeList.addAll(collect);
                }
            } else if ("SELF".equalsIgnoreCase(assignedType)) {
                // 发起人自己

                assigneeList.add(startInfo.getId());
            } else if ("REFUSE".equalsIgnoreCase(assignedType)) {
                // 直接拒绝
                assigneeList.add("0");
                execution.setVariable(currentActivityId + "autoRefuse", Boolean.TRUE); // 在taskListener里自动拒绝 即驳回
            } else if ("FORM_USER".equalsIgnoreCase(assignedType)) {
                // 指定表单内联系人
                String formItemId = props.getFormUser();
                JSONArray userArray = execution.getVariable(formItemId, JSONArray.class);
                for (Object o : userArray) {
                    if (o instanceof JSONObject) {
                        String id = ((JSONObject) o).getString("id");
                        assigneeList.add(id);
                    }
                }
            }

            if (CollUtil.isEmpty(assigneeList)) {
                // 没有审批人时的处理方法
                Map<String, Object> nobady = props.getNobady();
                String handler = (String) nobady.get("handler");
                if ("PASS".equalsIgnoreCase(handler)) {
                    // 直接通过
                    assigneeList.add("0");
                } else if ("TO_ADMIN".equalsIgnoreCase(handler)) {
                    // 转交主管理员 todo
                    assigneeList.add("0");
                } else if ("TO_USER".equalsIgnoreCase(handler)) {
                    // 转交转交指定人员
                    List<Map<String, String>> nobadyHandler = (List<Map<String, String>>) nobady.get("handler");
                    // 这会只能选人员，直接添加id即可
                    for (Map<String, String> map : nobadyHandler) {
                        assigneeList.add(map.get("id"));
                    }
                } else if ("TO_REFUSE".equalsIgnoreCase(handler)) {
                    // 直接拒绝
                    assigneeList.add("0");
                    execution.setVariable(currentActivityId + "autoRefuse", Boolean.TRUE); // 在taskListener里自动拒绝 即驳回
                }
            }
            execution.setVariable(assigneeListCollectionName, assigneeList);
            // 推送
            WebSocketService webSocketService = SpringContextHolder
                    .getBean(WebSocketService.class);
            for (String s : assigneeList) {
                webSocketService.addTask(s, processInstanceId, startInfo.getName(), mainProcess.getName());
            }
        }
    }
}

package com.zhy.flowable.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zhy.common.core.domain.R;
import com.zhy.common.core.exception.ServiceException;
import com.zhy.common.core.utils.DateUtils;
import com.zhy.common.core.web.domain.AjaxResult;
import com.zhy.common.security.utils.SecurityUtils;
import com.zhy.flowable.constats.CommonConstants;
import com.zhy.flowable.constats.WorkFlowConstants;
import com.zhy.flowable.entity.Properties;
import com.zhy.flowable.entity.*;
import com.zhy.flowable.entity.dto.HandleDataDTO;
import com.zhy.flowable.entity.dto.StartProcessInstanceDTO;
import com.zhy.flowable.entity.vo.*;
import com.zhy.flowable.service.FlowCCService;
import com.zhy.flowable.service.FlowCommentService;
import com.zhy.flowable.service.FlowProcessTemplateService;
import com.zhy.flowable.service.WebSocketService;
import com.zhy.flowable.utils.BpmnConverter.domain.ProcessNode;
import com.zhy.flowable.utils.BpmnConverter.domain.Props;
import com.zhy.flowable.utils.MapUtils;
import com.zhy.flowable.utils.SpringContextHolder;
import com.zhy.system.api.RemoteUserService;
import com.zhy.system.api.domain.SysUser;
import org.apache.commons.lang3.StringUtils;
import org.flowable.bpmn.model.Process;
import org.flowable.bpmn.model.*;
import org.flowable.common.engine.impl.identity.Authentication;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricActivityInstance;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.impl.persistence.entity.ExecutionEntity;
import org.flowable.engine.repository.ProcessDefinition;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.task.Attachment;
import org.flowable.engine.task.Comment;
import org.flowable.task.api.Task;
import org.flowable.task.api.history.HistoricTaskInstance;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

import static com.zhy.flowable.constats.CommonConstants.*;
import static com.zhy.flowable.utils.BpmnConverter.domain.ProcessNode.APPROVAL;

/**
 * @author syk
 * @Description flowable流程相关查询接口
 * @Date 16:43 2022/12/27
 */
@RestController
@RequestMapping("/process")
public class FlowableController {
    @Autowired
    private RepositoryService repositoryService;

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private TaskService taskService;

    @Autowired
    private HistoryService historyService;

    @Autowired
    private FlowProcessTemplateService flowProcessTemplateService;
    @Resource
    private FlowCCService flowCCService;

    @Autowired
    private FlowCommentService flowCommentService;

    @Resource
    private RemoteUserService remoteUserService;

    @Autowired
    WebSocketService webSocketService;


    /**
     * 通过模板id查询流程
     *
     * @param templateId
     * @return
     */
    @GetMapping("/process/detail")
    public AjaxResult getProcessDetail(@RequestParam("templateId") String templateId) {
        FlowProcessTemplates template = flowProcessTemplateService.getById(templateId);
        template.setLogo(template.getIcon());
        template.setFormId(template.getTemplateId());
        template.setFormName(template.getTemplateName());

        //查询已发布的表单信息
        ProcessDefinition definition = repositoryService.createProcessDefinitionQuery().processDefinitionKey(WorkFlowConstants.PROCESS_PREFIX + templateId).latestVersion().singleResult();
        //判断是否已部署
        if (definition == null) {
            return AjaxResult.error("该流程未启用!");
        }

        template.setProcessDefinitionId(definition.getId());
        return AjaxResult.success(template);
    }


    /**
     * 启动流程
     *
     * @return
     */
    @PostMapping("/process/start")
    public AjaxResult startProcess(@RequestBody StartProcessInstanceDTO startProcessInstanceDTO) {
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        JSONObject formData = startProcessInstanceDTO.getFormData();
//        UserInfo startUserInfo = startProcessInstanceDTO.getStartUserInfo();
        //拼接发起人
        UserInfo startUserInfo = new UserInfo();
        startUserInfo.setId(sysUser.getUserId().toString());
        startUserInfo.setName(sysUser.getNickName());
        startUserInfo.setType("user");
        startUserInfo.setSex(sysUser.getSex());
        startUserInfo.setSelected(false);
        // 设置流程发起人
        Authentication.setAuthenticatedUserId(sysUser.getUserId().toString());
        Map<String, Object> variables = new HashMap<>();
        variables.put(CommonConstants.FORM_VAR, formData);
        variables.put(CommonConstants.PROCESS_VAR_STARTER_NICKNAME, startUserInfo.getName());
        variables.put(CommonConstants.PROCESS_VAR_STARTER_ID, startUserInfo.getId());
        variables.put(START_USER_INFO, JSONObject.toJSONString(startUserInfo));
        variables.put(CommonConstants.PROCESS_STATUS, CommonConstants.BUSINESS_STATUS_1);
        variables.put("root", sysUser.getUserId());
        Map formDataMap = JSONObject.parseObject(formData.toJSONString(), Map.class);
        variables.putAll(formDataMap);
        // 启动流程
        ProcessInstance processInstance = runtimeService.createProcessInstanceBuilder().processDefinitionId(startProcessInstanceDTO.getProcessDefinitionId()).variables(variables).businessStatus(CommonConstants.BUSINESS_STATUS_1).start();
        if (ObjectUtil.isEmpty(processInstance)) {
            return AjaxResult.error("流程启动失败");
        }
        return AjaxResult.success(processInstance.getId());
    }

    /**
     * 查看我发起的流程
     *
     * @return
     */
    @GetMapping("/process/applyList")
    public AjaxResult applyList(@RequestParam Integer pageNo, @RequestParam int pageSize) {
        //获取当前登陆人
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        String currentUser = sysUser.getUserId().toString();
        //分页查询流程
        List<HistoricProcessInstance> listPage = historyService.createHistoricProcessInstanceQuery().includeProcessVariables().startedBy(currentUser).orderByProcessInstanceStartTime().desc().listPage((pageNo - 1) * pageSize, pageSize);

        //获取总数
        long count = historyService.createHistoricProcessInstanceQuery().startedBy(currentUser).count();

        List<HistoryProcessInstanceVO> instanceVOS = new ArrayList<>(listPage.size());
        for (HistoricProcessInstance instance : listPage) {
            HistoryProcessInstanceVO instanceVO = new HistoryProcessInstanceVO();
            instanceVO.setProcessInstanceId(instance.getId());
            instanceVO.setProcessDefinitionName(instance.getProcessDefinitionName());
            instanceVO.setStartTime(instance.getStartTime());
            instanceVO.setEndTime(instance.getEndTime());
            Boolean flag = instance.getEndTime() == null ? false : true;
            instanceVO.setCurrentActivityName(getCurrentName(instance.getId(), flag, instance.getProcessDefinitionId()));
            instanceVO.setBusinessStatus(MapUtil.getStr(instance.getProcessVariables(), CommonConstants.PROCESS_STATUS));
            //拼接发起人信息
            UserInfo userInfo = new UserInfo();
            userInfo.setId(sysUser.getUserId().toString());
            userInfo.setName(sysUser.getNickName());
            userInfo.setType("user");
            userInfo.setSex(sysUser.getSex());
            userInfo.setSelected(false);
            instanceVO.setStartUser(userInfo);
            //计算用时
            long totalTimes = instance.getEndTime() == null ? (Calendar.getInstance().getTimeInMillis() - instance.getStartTime().getTime()) : (instance.getEndTime().getTime() - instance.getStartTime().getTime());
            long dayCount = totalTimes / (1000 * 60 * 60 * 24);//计算天
            long restTimes = totalTimes % (1000 * 60 * 60 * 24);//剩下的时间用于计于小时
            long hourCount = restTimes / (1000 * 60 * 60);//小时
            restTimes = restTimes % (1000 * 60 * 60);
            long minuteCount = restTimes / (1000 * 60);
            String spendTimes = dayCount + "天" + hourCount + "小时" + minuteCount + "分";
            instanceVO.setDuration(spendTimes);

            instanceVOS.add(instanceVO);
        }
        Page<HistoryProcessInstanceVO> page = new Page<>();
        page.setRecords(instanceVOS);
        page.setCurrent(pageNo);
        page.setSize(pageSize);
        page.setTotal(count);
        return AjaxResult.success(page);
    }

    /**
     * 我的待办
     *
     * @param pageNo
     * @param pageSize
     * @return
     */
    @GetMapping("/process/todoList")
    public AjaxResult myTodoList(@RequestParam Integer pageNo, @RequestParam int pageSize) {
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        List<Task> tasks = taskService.createTaskQuery().taskAssignee(sysUser.getUserId().toString()).includeProcessVariables().orderByTaskCreateTime().desc().listPage((pageNo - 1) * pageSize, pageSize);

        long count = taskService.createTaskQuery().taskAssignee(sysUser.getUserId().toString()).count();
        List<TaskVO> taskVOs = new ArrayList<>(tasks.size());

        for (Task task : tasks) {
            TaskVO taskVO = new TaskVO();
            taskVO.setTaskId(task.getId());
            taskVO.setProcessInstanceId(task.getProcessInstanceId());

            //查询当前流程实例信息
            HistoricProcessInstance instance = historyService.createHistoricProcessInstanceQuery().processInstanceId(task.getProcessInstanceId()).singleResult();
            taskVO.setStartTime(instance.getStartTime());

            //审批类型
            BpmnModel bpmnModel = repositoryService.getBpmnModel(task.getProcessDefinitionId());
            Map<String, Object> processVariables = task.getProcessVariables();
            taskVO.setProcessDefinitionName(bpmnModel.getMainProcess().getName());

            //发起人
            taskVO.setStartUser(JSONObject.parseObject(MapUtil.getStr(processVariables, START_USER_INFO), new TypeReference<UserInfo>() {
            }));

            //最近节点名
            List<String> activeActivityIds = runtimeService.getActiveActivityIds(task.getProcessInstanceId());
            String activityId = activeActivityIds.get(0);
            FlowElement flowElement = bpmnModel.getMainProcess().getFlowElement(activityId);
            taskVO.setCurrentActivityName(flowElement.getName());
            taskVO.setBusinessStatus(MapUtil.getStr(processVariables, CommonConstants.PROCESS_STATUS));
            taskVO.setTaskCreatedTime(task.getCreateTime());
            taskVOs.add(taskVO);
        }
        //返回结果
        Page<TaskVO> page = new Page<>();
        page.setRecords(taskVOs);
        page.setCurrent(pageNo);
        page.setSize(pageSize);
        page.setTotal(count);
        return AjaxResult.success(page);
    }

    /**
     * 我的已办
     *
     * @param pageNo
     * @param pageSize
     * @return
     */
    @GetMapping("/process/doneList")
    public AjaxResult myDoneList(@RequestParam Integer pageNo, @RequestParam int pageSize) {
        //获取当前登陆人
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        //根据分页信息查询所有已办流程
        List<HistoricTaskInstance> tasks = historyService.createHistoricTaskInstanceQuery().taskAssignee(sysUser.getUserId().toString()).includeProcessVariables().finished().orderByTaskCreateTime().desc().listPage((pageNo - 1) * pageSize, pageSize);

        // 总数
        long count = historyService.createHistoricTaskInstanceQuery().taskAssignee(sysUser.getUserId().toString()).count();
        List<TaskVO> taskVOs = new ArrayList<>(tasks.size());

        for (HistoricTaskInstance task : tasks) {
            HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(task.getProcessInstanceId()).singleResult();
            //是否已完成
            Boolean flag = historicProcessInstance.getEndTime() == null ? false : true;
            BpmnModel bpmnModel = repositoryService.getBpmnModel(task.getProcessDefinitionId());
            Map<String, Object> processVariables = task.getProcessVariables();
            TaskVO taskVO = new TaskVO();
            taskVO.setTaskId(task.getId());
            taskVO.setProcessInstanceId(task.getProcessInstanceId());
            taskVO.setProcessDefinitionName(bpmnModel.getMainProcess().getName());

            //发起人信息
            taskVO.setStartUser(JSONObject.parseObject(MapUtil.getStr(processVariables, START_USER_INFO), new TypeReference<UserInfo>() {
            }));
            taskVO.setStartTime(historicProcessInstance.getStartTime());
            taskVO.setCurrentActivityName(getCurrentName(task.getProcessInstanceId(), flag, task.getProcessDefinitionId()));
            taskVO.setBusinessStatus(MapUtil.getStr(processVariables, CommonConstants.PROCESS_STATUS));
            taskVO.setEndTime(task.getEndTime());

            //总用时
            long totalTimes = task.getEndTime() == null ? (Calendar.getInstance().getTimeInMillis() - task.getStartTime().getTime()) : (task.getEndTime().getTime() - task.getStartTime().getTime());
            long dayCount = totalTimes / (1000 * 60 * 60 * 24);//计算天
            long restTimes = totalTimes % (1000 * 60 * 60 * 24);//剩下的时间用于计于小时
            long hourCount = restTimes / (1000 * 60 * 60);//小时
            restTimes = restTimes % (1000 * 60 * 60);
            long minuteCount = restTimes / (1000 * 60);
            String spendTimes = dayCount + "天" + hourCount + "小时" + minuteCount + "分";
            taskVO.setDuration(spendTimes);
            taskVOs.add(taskVO);
        }
        //返回分页结果
        Page<TaskVO> page = new Page<>();
        page.setRecords(taskVOs);
        page.setTotal(count);
        page.setCurrent(pageNo);
        page.setSize(pageSize);
        return AjaxResult.success(page);
    }

    /**
     * 获取最新节点名称
     *
     * @param processInstanceId
     * @param flag
     * @param processDefinitionId
     * @return
     */
    private String getCurrentName(String processInstanceId, Boolean flag, String processDefinitionId) {
        if (flag) {
            return "流程已结束";
        }
        List<String> activeActivityIds = runtimeService.getActiveActivityIds(processInstanceId);
        String activityId = activeActivityIds.get(0);
        BpmnModel bpmnModel = repositoryService.getBpmnModel(processDefinitionId);
        FlowElement flowElement = bpmnModel.getMainProcess().getFlowElement(activityId);
        return flowElement.getName();
    }

    /**
     * 抄送列表分页
     *
     * @param pageNo   页码
     * @param pageSize 单页数量
     * @param all      是否返回所有抄送信息，包括已读
     * @return
     */
    @GetMapping("/process/ccList")
    public AjaxResult myCCList(@RequestParam Integer pageNo, @RequestParam int pageSize, @RequestParam(defaultValue = "0") Boolean all) {
        //获取当前登陆人
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        IPage<FlowCC> flowCCIPage = flowCCService.listPage(pageNo, pageSize, sysUser.getUserId(), all);
        List<FlowCC> records = flowCCIPage.getRecords();
        // 根据抄送数据中的processInstanceId查询对应任务
        List<HistoryProcessInstanceVO> instanceVOS = new ArrayList<>();
        for (FlowCC record : records) {
            HistoricProcessInstance instance = historyService.createHistoricProcessInstanceQuery().processInstanceId(record.getProcessInstanceId()).includeProcessVariables().singleResult();
            HistoryProcessInstanceVO instanceVO = new HistoryProcessInstanceVO();
            instanceVO.setProcessInstanceId(instance.getId());
            instanceVO.setProcessDefinitionName(instance.getProcessDefinitionName());
            instanceVO.setStartTime(instance.getStartTime());
            instanceVO.setEndTime(instance.getEndTime());
            Boolean flag = instance.getEndTime() == null ? false : true;
            instanceVO.setCurrentActivityName(getCurrentName(instance.getId(), flag, instance.getProcessDefinitionId()));
            instanceVO.setBusinessStatus(MapUtil.getStr(instance.getProcessVariables(), CommonConstants.PROCESS_STATUS));
            //拼接发起人信息
            UserInfo userInfo = new UserInfo();
            userInfo.setId(sysUser.getUserId().toString());
            userInfo.setName(sysUser.getNickName());
            userInfo.setType("user");
            userInfo.setSex(sysUser.getSex());
            userInfo.setSelected(false);
            instanceVO.setStartUser(userInfo);
            //计算用时
            long totalTimes = instance.getEndTime() == null ? (Calendar.getInstance().getTimeInMillis() - instance.getStartTime().getTime()) : (instance.getEndTime().getTime() - instance.getStartTime().getTime());
            long dayCount = totalTimes / (1000 * 60 * 60 * 24);//计算天
            long restTimes = totalTimes % (1000 * 60 * 60 * 24);//剩下的时间用于计于小时
            long hourCount = restTimes / (1000 * 60 * 60);//小时
            restTimes = restTimes % (1000 * 60 * 60);
            long minuteCount = restTimes / (1000 * 60);
            String spendTimes = dayCount + "天" + hourCount + "小时" + minuteCount + "分";
            instanceVO.setDuration(spendTimes);

            instanceVOS.add(instanceVO);
        }
        //返回分页结果
        Page<HistoryProcessInstanceVO> page = new Page<>();
        page.setRecords(instanceVOS);
        page.setTotal(records.size());
        page.setCurrent(pageNo);
        page.setSize(pageSize);
        return AjaxResult.success(page);
    }

    /**
     * 审批通过
     *
     * @param handleDataDTO
     * @return
     */
    @PostMapping("/process/agree")
    public AjaxResult agree(@RequestBody HandleDataDTO handleDataDTO) {
        // 获取当前登录人
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();

        Task task = taskService.createTaskQuery().taskId(handleDataDTO.getTaskId()).includeProcessVariables().singleResult();
        JSONObject formData = handleDataDTO.getFormData();
        Map<String, Object> map = new HashMap<>();
        if (formData != null && formData.size() > 0) {
            // 添加审批表单参数内容
            Map formValue = JSONObject.parseObject(formData.toJSONString(), new TypeReference<Map>() {
            });
            map.putAll(formValue);
            map.put(CommonConstants.FORM_VAR, formData);
        }

        //增加当前节点操作
        Map<String, Object> variables = runtimeService.getVariables(task.getProcessInstanceId());
        List<Map<String, String>> taskOption = null;
        if (ObjectUtil.isNotEmpty(variables.get("taskOption"))) {
            taskOption = MapUtils.castListMap(variables.get("taskOption"), String.class, String.class);
        } else {
            taskOption = new ArrayList<>();
        }
        Map<String, String> option = new HashMap<>();
        option.put(task.getId(), "agree");
        taskOption.add(option);
        map.put("taskOption", taskOption);

        runtimeService.setVariables(task.getProcessInstanceId(), map);
        String comments = handleDataDTO.getComment();
        // 添加评论

        if (StringUtils.isNotBlank(comments)) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("opinion")
                    .build();
            flowCommentService.save(comment);
        }

        // 审批人信息
        Authentication.setAuthenticatedUserId(sysUser.getUserId().toString());

        taskService.complete(task.getId());

        // 推送
        String startUserInfo = task.getProcessVariables().get(START_USER_INFO).toString();
        String processTitle = task.getProcessVariables().get(PROCESS_TITLE).toString();
        UserInfo startInfo = JSONObject.parseObject(startUserInfo, new TypeReference<UserInfo>() {
        });
        webSocketService.addTask(sysUser.getUserId().toString(), task.getProcessInstanceId(), startInfo.getName(), processTitle);

        return AjaxResult.success();
    }

    /**
     * 审批驳回
     *
     * @param handleDataDTO
     * @return
     */
    @PostMapping("/process/refuse")
    public AjaxResult refuse(@RequestBody HandleDataDTO handleDataDTO) {
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        // 审批人信息
        Authentication.setAuthenticatedUserId(sysUser.getUserId().toString());
        String comments = handleDataDTO.getComment();
        JSONObject formData = handleDataDTO.getFormData();

        // 当前审批任务
        String taskId = handleDataDTO.getTaskId();
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();

        Map<String, Object> map = new HashMap<>();
        // 表单内容参数
        if (formData != null && formData.size() > 0) {
            Map formValue = JSONObject.parseObject(formData.toJSONString(), new TypeReference<Map>() {
            });
            map.putAll(formValue);
            map.put(CommonConstants.FORM_VAR, formData);
        }

        // 添加审批状态
        map.put(CommonConstants.PROCESS_STATUS, CommonConstants.BUSINESS_STATUS_3);

        //增加当前节点操作
        Map<String, Object> variables = runtimeService.getVariables(task.getProcessInstanceId());
        List<Map<String, String>> taskOption = null;
        if (ObjectUtil.isNotEmpty(variables.get("taskOption"))) {
            taskOption = MapUtils.castListMap(variables.get("taskOption"), String.class, String.class);
        } else {
            taskOption = new ArrayList<>();
        }
        Map<String, String> option = new HashMap<>();
        option.put(taskId, "refuse");
        taskOption.add(option);
        map.put("taskOption", taskOption);

        runtimeService.setVariables(task.getProcessInstanceId(), map);

        // 添加评论
        if (StringUtils.isNotBlank(comments)) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("opinion")
                    .build();
            flowCommentService.save(comment);
        }

        // 签字信息
        if (StringUtils.isNotBlank(handleDataDTO.getSignInfo())) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("sign")
                    .build();
            flowCommentService.save(comment);
        }

        // 解析流程
        String processDefinitionId = task.getProcessDefinitionId();
        Process mainProcess = repositoryService.getBpmnModel(processDefinitionId).getMainProcess();

        // 查询当前流程节点
        List<HistoricActivityInstance> instanceList = historyService.createHistoricActivityInstanceQuery().processInstanceId(task.getProcessInstanceId()).list();
        HistoricActivityInstance historicActivityInstance = instanceList.stream().filter(i -> taskId.equals(i.getTaskId())).findAny().orElse(null);
        UserTask userTask = (UserTask) mainProcess.getFlowElement(historicActivityInstance.getActivityId());
        List<ExtensionElement> extensionElements = userTask.getExtensionElements().get("node");
        String nodeString = extensionElements.get(0).getElementText();
        ProcessNode node = JSONObject.parseObject(nodeString, new TypeReference<ProcessNode>() {
        });
        Props props = node.getProps();
        // 根据指定的逻辑判断驳回后的操作
        // 解析节点
        Map<String, String> refuse = props.getRefuse();
        if (ObjectUtil.isNotEmpty(refuse)) {
            // 讨论驳回逻辑
            if (WorkFlowConstants.TO_END.equals(refuse.get("type"))) {
                // 驳回后直接结束
                runtimeService.deleteProcessInstance(task.getProcessInstanceId(), "拒绝");
            } else if (WorkFlowConstants.TO_BEFORE.equals(refuse.get("type"))) {
                // 驳回后返回上一节点
                // 根据顺序倒序排序
                // todo 暂时仅适用于串行审批 会签审批待完成
                Date startTime = historicActivityInstance.getStartTime();
                List<HistoricActivityInstance> collect = instanceList.stream().filter(i -> i.getStartTime().toInstant().isBefore(startTime.toInstant())).sorted(Comparator.comparing(HistoricActivityInstance::getStartTime).reversed()).collect(Collectors.toList());
                HistoricActivityInstance lastNode = null;
                for (HistoricActivityInstance activityInstance : collect) {
                    if (!"sequenceFlow".equals(activityInstance.getActivityType()) && !"exclusiveGateway".equals(activityInstance.getActivityType())) {
                        // 只要不是连线数据 直接获取并退出循环
                        lastNode = activityInstance;
                        break;
                    }
                }
                // 跳到上一节点
                runtimeService.createChangeActivityStateBuilder().processInstanceId(task.getProcessInstanceId()).moveActivityIdTo(task.getTaskDefinitionKey(), lastNode.getActivityId()).changeState();
            } else if (WorkFlowConstants.TO_NODE.equals(refuse.get("type"))) {
                // 驳回后退到指定节点
                runtimeService.createChangeActivityStateBuilder().processInstanceId(task.getProcessInstanceId()).moveActivityIdTo(task.getTaskDefinitionKey(), refuse.get("target")).changeState();
            }
        }

        // 推送
        String startUserInfo = task.getProcessVariables().get(START_USER_INFO).toString();
        UserInfo startInfo = JSONObject.parseObject(startUserInfo, new TypeReference<UserInfo>() {
        });
        webSocketService.removeTask(sysUser.getUserId().toString(), task.getProcessInstanceId(), startInfo.getName(), mainProcess.getName());
        return AjaxResult.success();
    }

    /**
     * 审批撤销
     *
     * @param handleDataDTO
     * @return
     */
    @PostMapping("/process/revoke")
    public AjaxResult revoke(@RequestBody HandleDataDTO handleDataDTO) {
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        Authentication.setAuthenticatedUserId(sysUser.getUserId().toString());
        // 评论信息
        String comments = handleDataDTO.getComment();
        // 表单参数
        JSONObject formData = handleDataDTO.getFormData();
        String taskId = handleDataDTO.getTaskId();
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        Map<String, Object> map = new HashMap<>();
        if (formData != null && formData.size() > 0) {
            Map formValue = JSONObject.parseObject(formData.toJSONString(), new TypeReference<Map>() {
            });
            map.putAll(formValue);
            map.put(CommonConstants.FORM_VAR, formData);
        }
        // 状态改为撤销
        map.put(CommonConstants.PROCESS_STATUS, CommonConstants.BUSINESS_STATUS_2);
        runtimeService.setVariables(task.getProcessInstanceId(), map);
        // 添加评论
        if (StringUtils.isNotBlank(comments)) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("opinion")
                    .build();
            flowCommentService.save(comment);
        }
        // todo 添加附件

        //签名信息
        if (StringUtils.isNotBlank(handleDataDTO.getSignInfo())) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("sign")
                    .build();
            flowCommentService.save(comment);
        }
        runtimeService.deleteProcessInstance(task.getProcessInstanceId(), "撤销");
        return AjaxResult.success();
    }


    /**
     * 审批转办
     *
     * @param handleDataDTO
     * @return
     */
    @PostMapping("/process/assignee")
    public AjaxResult assignee(@RequestBody HandleDataDTO handleDataDTO) {
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        Authentication.setAuthenticatedUserId(sysUser.getUserId().toString());
        String comments = handleDataDTO.getComment();
        JSONObject formData = handleDataDTO.getFormData();
        String taskId = handleDataDTO.getTaskId();
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        Map<String, Object> map = new HashMap<>();
        if (formData != null && formData.size() > 0) {
            Map formValue = JSONObject.parseObject(formData.toJSONString(), new TypeReference<Map>() {
            });
            map.putAll(formValue);
            map.put(CommonConstants.FORM_VAR, formData);
        }
        map.put(CommonConstants.PROCESS_STATUS, CommonConstants.BUSINESS_STATUS_3);
        runtimeService.setVariables(task.getProcessInstanceId(), map);
        if (StringUtils.isNotBlank(comments)) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("opinion")
                    .build();
            flowCommentService.save(comment);
        }

        if (StringUtils.isNotBlank(handleDataDTO.getSignInfo())) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("sign")
                    .build();
            flowCommentService.save(comment);
        }
        taskService.setAssignee(taskId, handleDataDTO.getTransferUserInfo().getId());
        return AjaxResult.success();
    }


    /**
     * 审批退回
     *
     * @param handleDataDTO
     * @return
     */
    @PostMapping("/process/rollback")
    public AjaxResult rollback(@RequestBody HandleDataDTO handleDataDTO) {
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        Authentication.setAuthenticatedUserId(sysUser.getUserId().toString());
        String comments = handleDataDTO.getComment();
        JSONObject formData = handleDataDTO.getFormData();
        String taskId = handleDataDTO.getTaskId();
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        Map<String, Object> map = new HashMap<>();
        if (formData != null && formData.size() > 0) {
            Map formValue = JSONObject.parseObject(formData.toJSONString(), new TypeReference<Map>() {
            });
            map.putAll(formValue);
            map.put(CommonConstants.FORM_VAR, formData);
        }

        //增加当前节点操作
        Map<String, Object> variables = runtimeService.getVariables(task.getProcessInstanceId());
        List<Map<String, String>> taskOption = null;
        if (ObjectUtil.isNotEmpty(variables.get("taskOption"))) {
            taskOption = MapUtils.castListMap(variables.get("taskOption"), String.class, String.class);
        } else {
            taskOption = new ArrayList<>();
        }
        Map<String, String> option = new HashMap<>();
        option.put(taskId, "rollback");
        taskOption.add(option);
        map.put("taskOption", taskOption);

        map.put(CommonConstants.PROCESS_STATUS, CommonConstants.BUSINESS_STATUS_3);
        runtimeService.setVariables(task.getProcessInstanceId(), map);
        if (StringUtils.isNotBlank(comments)) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("opinion")
                    .build();
            flowCommentService.save(comment);
        }

        if (StringUtils.isNotBlank(handleDataDTO.getSignInfo())) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("sign")
                    .build();
            flowCommentService.save(comment);
        }
        //todo 暂时将审批退回到指定节点
        runtimeService.createChangeActivityStateBuilder().processInstanceId(task.getProcessInstanceId()).moveActivityIdTo(task.getTaskDefinitionKey(), handleDataDTO.getRollbackId());
        return AjaxResult.success();
    }


    /**
     * 审批加签
     *
     * @param handleDataDTO
     * @return
     */
    @PostMapping("/process/addMulti")
    public AjaxResult addMulti(@RequestBody HandleDataDTO handleDataDTO) {
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        Authentication.setAuthenticatedUserId(sysUser.getUserId().toString());
        String comments = handleDataDTO.getComment();
        JSONObject formData = handleDataDTO.getFormData();
        String taskId = handleDataDTO.getTaskId();
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        Map<String, Object> map = new HashMap<>();
        if (formData != null && formData.size() > 0) {
            Map formValue = JSONObject.parseObject(formData.toJSONString(), new TypeReference<Map>() {
            });
            map.putAll(formValue);
            map.put(CommonConstants.FORM_VAR, formData);
        }
        map.put(CommonConstants.PROCESS_STATUS, CommonConstants.BUSINESS_STATUS_3);
        runtimeService.setVariables(task.getProcessInstanceId(), map);
        if (StringUtils.isNotBlank(comments)) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("opinion")
                    .build();
            flowCommentService.save(comment);
        }

        if (StringUtils.isNotBlank(handleDataDTO.getSignInfo())) {
            FlowComment comment = FlowComment.builder()
                    .comment(comments)
                    .activityId(task.getId())
                    .processInstanceId(task.getProcessInstanceId())
                    .userId(sysUser.getUserId())
                    .createBy(sysUser.getUserId().toString())
                    .createTime(DateUtils.getNowDate())
                    .type("sign")
                    .build();
            flowCommentService.save(comment);
        }

        Map<String, Object> variableMap = new HashMap<>();
        variableMap.put("assigneeName", handleDataDTO.getMultiAddUserInfo().getId());
        ExecutionEntity execution = (ExecutionEntity) runtimeService.addMultiInstanceExecution(task.getTaskDefinitionKey(), task.getProcessInstanceId(), variableMap);
        return AjaxResult.success();
    }

    /**
     * 评论
     *
     * @param handleDataDTO
     * @return
     */
    @PostMapping("/process/comments")
    public AjaxResult comments(@RequestBody HandleDataDTO handleDataDTO) {
        SysUser sysUser = SecurityUtils.getLoginUser().getSysUser();
        String comments = handleDataDTO.getComment();
        FlowComment comment = FlowComment.builder()
                .userId(sysUser.getUserId())
                .comment(comments)
                .createBy(sysUser.getUserId().toString())
                .processInstanceId(handleDataDTO.getProcessInstanceId())
                .createTime(DateUtils.getNowDate()).build();

        boolean save = flowCommentService.save(comment);
        return save ? AjaxResult.success() : AjaxResult.error();
    }

    @PostMapping("/process/instanceInfo")
    public AjaxResult instanceInfo(@RequestBody HandleDataDTO handleDataDTO) {
        // 根据实例id查询实例详情
        String processInstanceId = handleDataDTO.getProcessInstanceId();
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).includeProcessVariables().singleResult();

        // 根据流程id 查询模板数据
        String processDefinitionKey = historicProcessInstance.getProcessDefinitionKey();
        FlowProcessTemplates templates = flowProcessTemplateService.getById(processDefinitionKey.replace(WorkFlowConstants.PROCESS_PREFIX, ""));
        templates.setLogo(templates.getIcon());
        templates.setFormId(templates.getTemplateId());
        templates.setFormName(templates.getTemplateName());
        templates.setProcessDefinitionId(historicProcessInstance.getProcessDefinitionId());

        // 拼接详情数据
        HandleDataVO handleDataVO = new HandleDataVO();

        Map<String, Object> variables = historicProcessInstance.getProcessVariables();
        handleDataVO.setProcessInstanceId(historicProcessInstance.getId());
        handleDataVO.setFormData((JSONObject) variables.get(CommonConstants.FORM_VAR));
        UserInfo startUser = JSONObject.parseObject(variables.get(START_USER_INFO).toString(), UserInfo.class);

        // 流程数据
        String process = templates.getProcess();
        ChildNode childNode = JSONObject.parseObject(process, ChildNode.class);

        // 当前流程节点
        if (StringUtils.isNotBlank(handleDataDTO.getTaskId())) {
            ChildNode currentNode = null;
            HistoricTaskInstance historicTaskInstance = historyService.createHistoricTaskInstanceQuery().taskId(handleDataDTO.getTaskId()).singleResult();
            currentNode = getChildNode(childNode, historicTaskInstance.getTaskDefinitionKey());
            handleDataVO.setCurrentNode(currentNode);
        }

        //签名信息
        SettingsInfo settingsInfo = JSONObject.parseObject(templates.getSettings(), SettingsInfo.class);
        handleDataVO.setSignFlag(settingsInfo.getSign());
        if (handleDataVO.getCurrentNode() != null) {
            ChildNode currentNode = handleDataVO.getCurrentNode();
            Boolean sign = currentNode.getProps().getSign();
            handleDataVO.setSignFlag(sign);
        }


        // 查询当前实例所有历史数据并按开始时间排序
        List<HistoricActivityInstance> list = historyService.createHistoricActivityInstanceQuery().processInstanceId(historicProcessInstance.getId()).list();


        // 根据节点Id进行分组
        HashMap<String, List<HistoricActivityInstance>> historicActivityInstanceMap = new HashMap<>();
        for (HistoricActivityInstance historicActivityInstance : list) {
            List<HistoricActivityInstance> historicActivityInstances = historicActivityInstanceMap.get(historicActivityInstance.getActivityId());
            if (historicActivityInstances == null) {
                historicActivityInstances = new ArrayList<>();
                historicActivityInstances.add(historicActivityInstance);
                historicActivityInstanceMap.put(historicActivityInstance.getActivityId(), historicActivityInstances);
            } else {
                historicActivityInstances.add(historicActivityInstance);
                historicActivityInstanceMap.put(historicActivityInstance.getActivityId(), historicActivityInstances);
            }
        }

        //节点属性
        Process mainProcess = repositoryService.getBpmnModel(historicProcessInstance.getProcessDefinitionId()).getMainProcess();
        Collection<FlowElement> flowElements = mainProcess.getFlowElements();


        // 节点详情
        List<String> runningList = new ArrayList<>();
        List<String> noTakeList = new ArrayList<>();
        List<String> endList = new ArrayList<>();
        handleDataVO.setRunningList(runningList);
        handleDataVO.setNoTakeList(noTakeList);
        handleDataVO.setEndList(endList);

        // 附件及评论列表
        List<FlowComment> processInstanceComments = flowCommentService.list(new LambdaQueryWrapper<FlowComment>().eq(FlowComment::getProcessInstanceId, historicProcessInstance.getId()));
        List<Attachment> processInstanceAttachments = taskService.getProcessInstanceAttachments(historicProcessInstance.getId());

        // 历史任务详情
        List<HistoricTaskInstance> taskList = historyService.createHistoricTaskInstanceQuery().processInstanceId(historicProcessInstance.getId()).orderByHistoricTaskInstanceStartTime().asc().list();
        Map<String, List<HistoricTaskInstance>> taskMap = taskList.stream().collect(Collectors.groupingBy(t -> t.getTaskDefinitionKey()));

        // 节点操作详情
        List<Map<String, String>> taskOption = null;
        if (ObjectUtil.isNotEmpty(variables.get("taskOption"))) {
            taskOption = MapUtils.castListMap(variables.get("taskOption"), String.class, String.class);
        }

        List<TaskDetailVO> processList = new ArrayList<>();
        List<Map<String, String>> finalTaskOption = taskOption;

        JSONObject formData = (JSONObject) variables.get(FORM_VAR);
        JSONArray assignees = formData.getJSONArray("assignees");
        List<JSONObject> assigneesList = JSONObject.parseObject(assignees.toJSONString(), List.class);
        List<String> userIds = new ArrayList<>();
        if (CollUtil.isNotEmpty(assigneesList)) {
            for (JSONObject object : assigneesList) {
                JSONArray user = object.getJSONArray("user");
                List userList = JSONObject.parseObject(user.toJSONString(), List.class);
                for (Object o : userList) {
                    UserInfo userInfo = JSONObject.parseObject(o.toString(), UserInfo.class);
                    // 添加审批人
                    if ("user".equals(userInfo.getType())) {
                        userIds.add(userInfo.getId());
                    } else if ("dept".equals(userInfo.getType())) {
                        // 查询部门下所有的员工 并放入审批列表
                        RemoteUserService userService = SpringContextHolder.getBean(RemoteUserService.class);
                        R<List<SysUser>> assigneeUsers = userService.getUsersByDeptId(Arrays.asList(userInfo.getId()));
                        List<String> users = assigneeUsers.getData().stream().map(u -> u.getUserId().toString()).collect(Collectors.toList());
                        userIds.addAll(users);
                    }
                }
            }

        }

        List<SysUser> users = remoteUserService.getUsersByUserId(userIds).getData();

        for (FlowElement flowElement : flowElements) {
            List<HistoricActivityInstance> historicActivityInstanceList = historicActivityInstanceMap.get(flowElement.getId());
            if (CollUtil.isNotEmpty(historicActivityInstanceList)) {
                for (HistoricActivityInstance historicActivityInstance : historicActivityInstanceList) {
                    if (historicActivityInstance.getEndTime() != null) {
                        if ("userTask".equals(historicActivityInstance.getActivityType())) {
                            // 在所有的历史节点中过滤出当前已完成节点
                            endList.add(historicActivityInstance.getActivityId());
                        }
                        // 完成节点
                    } else {
                        // 正运行节点
                        if ("userTask".equals(historicActivityInstance.getActivityType())) {
                            // 在所有的历史节点中过滤出当前未完成节点
                            if (endList.contains(historicActivityInstance.getActivityId())) {
                                endList.remove(historicActivityInstance.getActivityId());
                                runningList.add(historicActivityInstance.getActivityId());
                            } else {
                                runningList.add(historicActivityInstance.getActivityId());
                            }
                        }
                    }
                }
            } else {
                // 未运行节点
                noTakeList.add(flowElement.getId());
            }
        }
        handleDataVO.setProcessTemplates(templates);

        List<FlowCC> ccList = flowCCService.list(new LambdaQueryWrapper<FlowCC>().eq(FlowCC::getProcessInstanceId, processInstanceId));


        processList = analysisNode(processList, childNode, taskMap, formData, processInstanceComments, processInstanceAttachments, startUser, finalTaskOption, ccList, users);

        // 评论数据放入
        List<FlowComment> comments = processInstanceComments.stream().filter(c -> c.getActivityId() == null).collect(Collectors.toList());
        List<TaskDetailVO> commentDetailVO = new ArrayList<>();
        if (CollUtil.isNotEmpty(comments)) {
            comments.forEach(c -> {
                List<FlowComment> arrayList = new ArrayList<>();
                arrayList.add(c);
                TaskDetailVO detailVO = new TaskDetailVO();
                detailVO.setEndTime(c.getCreateTime());
                detailVO.setCommentVOList(arrayList);
                detailVO.setType("COMMENT");
                String assignee = users.stream().filter(u -> c.getUserId().equals(u.getUserId())).findFirst().get().getNickName();
                detailVO.setAssignee(assignee);
                commentDetailVO.add(detailVO);
            });
            processList.addAll(commentDetailVO);
        }

        // 将流程信息按照结束时间进行正序排序
        processList.sort(new Comparator<TaskDetailVO>() {
            @Override
            public int compare(TaskDetailVO o1, TaskDetailVO o2) {
                // 存在结束时间为空的任务
                // 时间为空说明未完成 排后面
                if (o1.getEndTime() == null) {
                    return 1;
                }
                if (o2.getEndTime() == null) {
                    return -1;
                }
                if (o1.getEndTime().after(o2.getEndTime())) {
                    return 1;
                } else {
                    // 保证抄送节点在最后面
                    if (o1.getEndTime().before(o2.getEndTime())) {

                    }
                    return -1;
                }
            }
        });
        handleDataVO.setProcessList(processList);
        return AjaxResult.success(handleDataVO);
    }

    /**
     * 在整个流程中查询指定节点
     *
     * @param childNode
     * @param nodeId
     * @return
     */
    public static ChildNode getChildNode(ChildNode childNode, String nodeId) {
        Map<String, ChildNode> childNodeMap = new HashMap<>();
        if (StringUtils.isNotBlank(childNode.getId())) {
            getChildNode(childNode, childNodeMap);
        }

        Set<String> set = childNodeMap.keySet();
        for (String s : set) {
            if (StringUtils.isNotBlank(s)) {
                if (s.equals(nodeId)) {
                    return childNodeMap.get(s);
                }
            }
        }
        return null;
    }

    private static void getChildNode(ChildNode childNode, Map<String, ChildNode> childNodeMap) {
        childNodeMap.put(childNode.getId(), childNode);
        List<ChildNode> branchs = childNode.getBranchs();
        ChildNode children = childNode.getChildren();
        if (branchs != null && branchs.size() > 0) {
            for (ChildNode branch : branchs) {
                if (StringUtils.isNotBlank(branch.getId())) {
                    childNodeMap.put(branch.getId(), branch);
                    getChildNode(branch, childNodeMap);
                }
            }
        }

        if (children != null) {
            childNodeMap.put(children.getId(), children);
            getChildNode(children, childNodeMap);
        }

    }

    /**
     * 解析节点数据
     *
     * @param processList
     * @param childNode
     * @param taskMap
     * @param processInstanceComments
     * @param processInstanceAttachments
     * @param formData
     * @param startUser
     * @param finalTaskOption
     * @param ccList
     * @param users
     */
    private static List<TaskDetailVO> analysisNode(List<TaskDetailVO> processList, ChildNode childNode, Map<String, List<HistoricTaskInstance>> taskMap, JSONObject formData, List<FlowComment> processInstanceComments, List<Attachment> processInstanceAttachments, UserInfo startUser, List<Map<String, String>> finalTaskOption, List<FlowCC> ccList, List<SysUser> users) {
        // 到达最后节点
        if (ObjectUtil.isEmpty(childNode)) {
            return processList;
        }
        Properties props = childNode.getProps();
        TaskDetailVO detailVO = new TaskDetailVO();

        // 解析节点
        if (ProcessNode.ROOT.equals(childNode.getType())) {
            // 发起人
            detailVO.setNodeId(childNode.getId());
            detailVO.setAssignee(startUser.getName());
            HistoricTaskInstance instance = taskMap.get(childNode.getId()).get(0);
            detailVO = addTaskDetailVO(detailVO, childNode, instance, processInstanceComments, processInstanceAttachments, finalTaskOption);
            processList.add(detailVO);
            ChildNode children = childNode.getChildren();
            analysisNode(processList, children, taskMap, formData, processInstanceComments, processInstanceAttachments, startUser, finalTaskOption, ccList, users);
        } else if (ProcessNode.APPROVAL.equals(childNode.getType())) {
            // 审批节点
            // 当前节点已完成或正在处理的任务
            List<HistoricTaskInstance> instances = taskMap.get(childNode.getId());
            List<String> assigneeList = new ArrayList<>();

            String assignedType = props.getAssignedType();
            if ("ASSIGN_USER".equalsIgnoreCase(assignedType)) {
                // 指定人员审批
                List<UserInfo> assignedUser = props.getAssignedUser();
                for (UserInfo userInfo : assignedUser) {
                    assigneeList.add(userInfo.getId());
                }
            } else if ("SELF_SELECT".equalsIgnoreCase(assignedType)) {
                // 发起人自选 那拿到所有审批人数据
                JSONArray assignes = formData.getJSONArray("assignees");
                List<JSONObject> list = JSONObject.parseObject(assignes.toJSONString(), List.class);
                // 当前节点审批人列表
                List<JSONObject> idList = list.stream().filter(a -> childNode.getId().equals(a.getString("id"))).collect(Collectors.toList());
                if (CollUtil.isNotEmpty(idList)) {
                    JSONObject objects = idList.get(0);
                    JSONArray user = objects.getJSONArray("user");
                    List userList = JSONObject.parseObject(user.toJSONString(), List.class);
                    for (Object o : userList) {
                        UserInfo userInfo = JSONObject.parseObject(o.toString(), UserInfo.class);
                        // 添加审批人
                        if ("user".equals(userInfo.getType())) {
                            assigneeList.add(userInfo.getId());
                        } else if ("dept".equals(userInfo.getType())) {
                            // 查询部门下所有的员工 并放入审批列表
                            RemoteUserService userService = SpringContextHolder.getBean(RemoteUserService.class);
                            R<List<SysUser>> assigneeUsers = userService.getUsersByDeptId(Arrays.asList(userInfo.getId()));
                            List<String> userIds = assigneeUsers.getData().stream().map(u -> u.getUserId().toString()).collect(Collectors.toList());
                            assigneeList.addAll(userIds);
                        }
                    }
                }

            } else if ("SELF".equalsIgnoreCase(assignedType)) {
                // 发起人自己
                assigneeList.add(startUser.getId());
            } else if ("LEADER".equalsIgnoreCase(assignedType)) {
                // 发起人的主管 todo
            } else if ("ROLE".equalsIgnoreCase(assignedType)) {
                // 指定角色
                // TODO: 2023/2/1  
            } else if ("REFUSE".equalsIgnoreCase(assignedType)) {
                // 不加入审批人列表
                // TODO: 2023/2/1  
            } else if ("FORM_USER".equalsIgnoreCase(assignedType)) {
                // 指定表单内联系人
                // TODO: 2023/2/1
            }
            if (CollUtil.isNotEmpty(instances)) {
                for (HistoricTaskInstance instance : instances) {
                    // 多个审批节点
                    TaskDetailVO taskDetailVO = new TaskDetailVO();
                    String assignee = users.stream().filter(u -> instance.getAssignee().equals(u.getUserId().toString())).findFirst().get().getNickName();
                    taskDetailVO.setNodeId(childNode.getId());
                    taskDetailVO.setAssignee(assignee);
                    taskDetailVO = addTaskDetailVO(taskDetailVO, childNode, instance, processInstanceComments, processInstanceAttachments, finalTaskOption);
                    processList.add(taskDetailVO);
                }

                List<String> complateAssignees = instances.stream().map(i -> i.getAssignee()).collect(Collectors.toList());
                if (CollUtil.isNotEmpty(complateAssignees)) {
                    assigneeList.removeAll(complateAssignees);
                }
            }
            for (String s : assigneeList) {
                TaskDetailVO taskDetailVO = new TaskDetailVO();
                String assignee = users.stream().filter(u -> s.equals(u.getUserId().toString())).findFirst().get().getNickName();
                taskDetailVO.setNodeId(childNode.getId());
                taskDetailVO.setAssignee(assignee);
                taskDetailVO.setName(childNode.getName());
                taskDetailVO.setType(APPROVAL);
                taskDetailVO.setStatus(CommonConstants.NOT_STARTED);
                processList.add(taskDetailVO);
            }

            ChildNode children = childNode.getChildren();
            analysisNode(processList, children, taskMap, formData, processInstanceComments, processInstanceAttachments, startUser, finalTaskOption, ccList, users);
        } else if (ProcessNode.CONCURRENTS.equals(childNode.getType())) {
            // 并行分支
            for (ChildNode branch : childNode.getBranchs()) {
                analysisNode(processList, branch, taskMap, formData, processInstanceComments, processInstanceAttachments, startUser, finalTaskOption, ccList, users);
            }
        } else if (ProcessNode.CC.equals(childNode.getType())) {

            detailVO.setNodeId(childNode.getId());
            detailVO.setName(childNode.getName());
            detailVO.setType(ProcessNode.CC);
            // 抄送节点
            if (CollUtil.isNotEmpty(ccList)) {
                List<String> ccUserIdList = ccList.stream().map(c -> c.getUserId().toString()).collect(Collectors.toList());
                List<UserInfoVO> ccUserList = new ArrayList<>();
                RemoteUserService userService = SpringContextHolder.getBean(RemoteUserService.class);
                R<List<SysUser>> ccUsers = userService.getUsersByUserId(ccUserIdList);
                List<SysUser> data = ccUsers.getData();
                for (SysUser user : data) {
                    UserInfoVO userInfoVO = new UserInfoVO();
                    userInfoVO.setId(user.getUserId().toString());
                    userInfoVO.setName(user.getNickName());
                    userInfoVO.setType("user");
                    userInfoVO.setSex(user.getSex());
                    List<FlowCC> collect = ccList.stream().filter(c -> user.getUserId().equals(c.getUserId())).collect(Collectors.toList());
                    FlowCC flowCC = collect.get(0);
                    userInfoVO.setReaded(flowCC.getReaded());
                    ccUserList.add(userInfoVO);
                }

                detailVO.setCcList(ccUserList);
                detailVO.setEndTime(ccList.get(0).getCreateTime());
                detailVO.setStatus(CommonConstants.COMPLATE);
                processList.add(detailVO);
            } else {
                // 还未走到抄送节点
                List<UserInfo> ccUsers = props.getAssignedUser();
                List<UserInfoVO> ccUserList = ccUsers.stream().map(c -> {
                    UserInfoVO userInfoVO = new UserInfoVO();
                    BeanUtils.copyProperties(c, userInfoVO);
                    userInfoVO.setReaded(false);
                    return userInfoVO;
                }).collect(Collectors.toList());
                detailVO.setCcList(ccUserList);
                detailVO.setEndTime(null);
                detailVO.setStatus(CommonConstants.NOT_STARTED);
                processList.add(detailVO);
            }
            ChildNode children = childNode.getChildren();
            analysisNode(processList, children, taskMap, formData, processInstanceComments, processInstanceAttachments, startUser, finalTaskOption, ccList, users);
        }
        return processList;
    }

    /**
     * 拼接任务信息
     *
     * @param detailVO
     * @param task
     * @param processInstanceComments
     * @param processInstanceAttachments
     * @param finalTaskOption
     * @return
     */
    private static TaskDetailVO addTaskDetailVO(TaskDetailVO detailVO, ChildNode childNode, HistoricTaskInstance task, List<FlowComment> processInstanceComments, List<Attachment> processInstanceAttachments, List<Map<String, String>> finalTaskOption) {
        detailVO.setActivityId(task.getTaskDefinitionKey());
        detailVO.setNodeId(childNode.getId());
        detailVO.setTaskId(task.getId());
        detailVO.setCreateTime(task.getCreateTime());
        detailVO.setEndTime(task.getEndTime() == null ? null : task.getEndTime());
        detailVO.setName(task.getName());
        ChildNode node = getChildNode(childNode, task.getTaskDefinitionKey());
        detailVO.setType(node.getType());

        // 取出操作附加评论
        List<FlowComment> commentList = processInstanceComments.stream().filter(c -> task.getId().equals(c.getActivityId()) && "opinion".equals(c.getType())).collect(Collectors.toList());
        detailVO.setCommentVOList(commentList);
        List<Attachment> attachmentList = processInstanceAttachments.stream().filter(a -> a.getTaskId().equals(task.getId())).collect(Collectors.toList());
        detailVO.setAttachmentVOList(attachmentList);
        if (ProcessNode.ROOT.equals(childNode.getType())) {
            // 发起人直接状态设置为已完成
            detailVO.setStatus(CommonConstants.COMPLATE);
        } else if (CollUtil.isNotEmpty(finalTaskOption)) {

            Optional<Map<String, String>> status = finalTaskOption.stream().filter(t -> {
                return ObjectUtil.isNotEmpty(t.get(task.getId()));
            }).findFirst();
            if (status.isPresent()) {
                detailVO.setStatus(status.get().get(task.getId()));
            } else {
                detailVO.setStatus(CommonConstants.RUNNING);
            }
        } else {
            // 当前节点为第一个审批节点
            detailVO.setStatus(CommonConstants.RUNNING);
        }
        return detailVO;
    }

    /* public void collectUserTaskInfo(List<Comment> processInstanceComments,
                                     List<Attachment> processInstanceAttachments,
                                     HistoricActivityInstance historicActivityInstance,
                                     List<TaskDetailVO> voList,
                                     List<HistoricActivityInstance> activityInstanceList) {
         for (HistoricActivityInstance activityInstance : activityInstanceList) {
             TaskDetailVO taskDetailVO = new TaskDetailVO();
             taskDetailVO.setTaskId(activityInstance.getTaskId());
             taskDetailVO.setActivityId(activityInstance.getActivityId());
             taskDetailVO.setName(activityInstance.getActivityName());
             taskDetailVO.setCreateTime(activityInstance.getStartTime());
             taskDetailVO.setEndTime(activityInstance.getEndTime());

             //查询当前节点签名数据
             Comment signComment = processInstanceComments.stream().filter(c -> c.getTaskId().equals(historicActivityInstance.getTaskId()) && "sign".equals(c.getType())).findFirst().orElse(null);
             if (signComment != null) {
                 taskDetailVO.setSignImage(signComment.getFullMessage());
             }

             // 操作信息
             List<Comment> optionComments = processInstanceComments.stream().filter(c -> c.getTaskId().equals(historicActivityInstance.getTaskId()) && "opinion".equals(c.getType())).collect(Collectors.toList());

             if (CollUtil.isNotEmpty(optionComments)) {
                 List<OptionVO> optionVOS = new ArrayList<>();
                 for (Comment option : optionComments) {
                     OptionVO optionVO = new OptionVO();
                     optionVO.setUserId(option.getUserId());
                     if (option.getUserId() != null) {
                         R<String> info = remoteUserService.getInfo(Long.parseLong(option.getUserId()));
                         optionVO.setUserName(info.getData());
                     }
                     optionVO.setComments(option.getFullMessage());
                     optionVO.setCreateTime(option.getTime());
                     optionVOS.add(optionVO);
                 }
                 taskDetailVO.setOptionVOList(optionVOS);
             }

             //评论数据
             List<Comment> comments = processInstanceComments.stream().filter(c -> c.getTaskId().equals(historicActivityInstance.getTaskId()) && "comment".equals(c.getType())).collect(Collectors.toList());
             if (CollUtil.isNotEmpty(comments)) {
                 List<CommentVO> commentVOS = new ArrayList<>();
                 for (Comment comment : comments) {
                     CommentVO commentVO = new CommentVO();
                     commentVO.setUserId(comment.getUserId());
                     if (comment.getUserId() != null) {
                         R<String> info = remoteUserService.getInfo(Long.parseLong(comment.getUserId()));
                         commentVO.setUserName(info.getData());
                     }
                     commentVO.setComments(comment.getFullMessage());
                     commentVO.setCreateTime(comment.getTime());
                     commentVOS.add(commentVO);
                 }
                 taskDetailVO.setCommentVOList(commentVOS);
             }


             //查询当前节点附件数据

             List<Attachment> attachments = processInstanceAttachments.stream().filter(h -> h.getTaskId().equals(historicActivityInstance.getTaskId())).collect(Collectors.toList());
             if (CollUtil.isNotEmpty(attachments)) {
                 List<AttachmentVO> attachmentVOList = new ArrayList<>();
                 for (Attachment attachment : attachments) {
                     AttachmentVO attachmentVO = new AttachmentVO();
                     attachmentVO.setId(attachment.getId());
                     attachmentVO.setName(attachment.getName());
                     attachmentVO.setUrl(attachment.getUrl());
                     attachmentVOList.add(attachmentVO);
                 }
                 taskDetailVO.setAttachmentVOList(attachmentVOList);
             }
             voList.add(taskDetailVO);
         }
     }*/
    @GetMapping("/deletePro")
    public AjaxResult deletePro(@RequestParam("instanceId") String instanceId) {
        ProcessInstance processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(instanceId).singleResult();
        if (null != processInstance) {
            runtimeService.deleteProcessInstance(instanceId, "流程实例删除");
        } else {
            historyService.deleteHistoricProcessInstance(instanceId);
        }

        return AjaxResult.success();
    }


    /**
     * 把抄送设为已读
     *
     * @param id 抄送id
     * @return
     */
    @PutMapping("/process/readCC")
    public AjaxResult readCC(@RequestParam Integer id) {
        Boolean aBoolean = flowCCService.readCC(id);
        return aBoolean ? AjaxResult.success() : AjaxResult.error();
    }

    /**
     * 删除已完成的流程
     *
     * @param processInstanceId
     * @return
     */
    @DeleteMapping("/deleteProcess")
    public AjaxResult deleteProcess(String processInstanceId) {
        try {
            historyService.deleteHistoricProcessInstance(processInstanceId);
        } catch (Exception e) {
            throw new ServiceException("无法删除还未完成的流程");
        }
        return AjaxResult.success();
    }
}

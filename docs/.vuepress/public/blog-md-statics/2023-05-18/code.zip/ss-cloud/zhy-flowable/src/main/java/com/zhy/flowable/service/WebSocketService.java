package com.zhy.flowable.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.stream.Collectors;

/**
 * @author syk
 * @Description websocket服务端
 * @Date 8:50 2023/2/3
 */

/**
 * @ServerEndpoint 是一个类层次的注解，功能是将当前类定义为一个WebSocket的服务端
 * 注解的值将被用于监听用户连接的终端访问URL地址,客户端可以通过这个URL来连接到WebSocket服务器端
 */
@Component
@ServerEndpoint("/websocket/{userId}")
public class WebSocketService {

    private static ConcurrentHashMap<String, CopyOnWriteArraySet<WebSocketService>> userwebSocketMap = new ConcurrentHashMap<>();

    public static ConcurrentHashMap<String, CopyOnWriteArraySet<ConcurrentHashMap>> userTaskSocketMap = new ConcurrentHashMap<>();

    private String userId;


    /*
     * 与某个客户端的连接会话，需要通过它来给客户端发送数据
     */
    private Session session;

    /**
     * 连接建立成功调用的方法
     *
     * @param session 可选的参数。session为与某个客户端的连接会话，需要通过它来给客户端发送数据
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("userId") final String userId) {
        this.session = session;
        this.userId = userId;
        System.out.println("session:" + session);
        System.out.println("userId:" + userId);
        if (!existUser(userId)) {
            initUserInfo(userId);
        } else {
            CopyOnWriteArraySet<WebSocketService> webSocketTestSet = getUserSocketSet(userId);
            webSocketTestSet.add(this);
        }

        // 发送一次未办任务
        sendTask(userId);

    }


    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose() {
        CopyOnWriteArraySet<WebSocketService> webSocketTestSet = userwebSocketMap.get(userId);
        //从set中删除
        webSocketTestSet.remove(this);
    }

    /**
     * 收到客户端消息后调用的方法
     *
     * @param message 客户端发送过来的消息
     * @param session 可选的参数
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        CopyOnWriteArraySet<WebSocketService> webSocketSet = userwebSocketMap.get(userId);
       /* System.out.println("来自客户端" + userId + "的消息:" + message);
        //群发消息
        for (WebSocketTest item : webSocketSet) {
            try {
                item.sendMessage(message);
            } catch (IOException e) {
                e.printStackTrace();
                continue;
            }
        }*/
    }


    /**
     * 发生错误时调用
     *
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        System.out.println("发生错误");
        error.printStackTrace();
    }


    /**
     * 这个方法与上面几个方法不一样。没有用注解，是根据自己需要添加的方法。
     *
     * @param message
     * @throws IOException
     */

    public void sendMessage(String message) throws IOException {
        System.out.println("服务端推送" + userId + "的消息:" + message);
        this.session.getAsyncRemote().sendText(message);
    }


    /**
     * 这个方法与上面几个方法不一样。没有用注解，是根据自己需要添加的方法。   我是在有代办消息时 调用此接口 向指定用户发送消息
     *
     * @param message
     * @throws IOException
     */

    public void sendMessage(String userId, String message) throws IOException {
        System.out.println("服务端推送" + userId + "的消息:" + message);
        CopyOnWriteArraySet<WebSocketService> webSocketSet = userwebSocketMap.get(userId);
        //群发消息
        for (WebSocketService item : webSocketSet) {
            try {
                item.session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                e.printStackTrace();
                continue;
            }
        }
    }


    /**
     * 在有待办任务时 调用此接口 向指定用户发送消息
     */
    public void sendTask(String userId) {
        System.out.println("服务端推送" + userId + "的消息");
        if (userwebSocketMap.containsKey(userId)) {
            CopyOnWriteArraySet<WebSocketService> webSocketSet = userwebSocketMap.get(userId);
            //群发消息
            for (WebSocketService item : webSocketSet) {
                try {
                    if (userTaskSocketMap.containsKey(userId)) {
                        CopyOnWriteArraySet<ConcurrentHashMap> concurrentHashMaps = userTaskSocketMap.get(userId);
                        List<String> collect = concurrentHashMaps.stream().map(l -> JSONObject.toJSONString(l)).collect(Collectors.toList());
                        item.session.getBasicRemote().sendText(collect.toString());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    continue;
                }
            }
        }

    }

    /**
     * 在有待办任务时 调用此接口 添加任务
     */
    public void addTask(String userId, String processInstanceId, String startUser, String processTitle) {
        CopyOnWriteArraySet<ConcurrentHashMap> set;
        if (userTaskSocketMap.containsKey(userId)) {
            set = userTaskSocketMap.get(userId);
        } else {
            set = new CopyOnWriteArraySet<>();
        }
        ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();
        map.put("processInstanceId", processInstanceId);
        map.put("taskName", startUser + "发起的" + processTitle);
        set.add(map);
        userTaskSocketMap.put(userId, set);
        sendTask(userId);
    }

    /**
     * 任务完成或驳回后 调用此接口 移除任务
     */
    public void removeTask(String userId, String processInstanceId, String startUser, String processTitle) {
        CopyOnWriteArraySet<ConcurrentHashMap> set = userTaskSocketMap.get(userId);
        ConcurrentHashMap<String, String> hashMap = new ConcurrentHashMap<>();
        hashMap.put("processInstanceId", processInstanceId);
        hashMap.put("taskName", startUser + "发起的" + processTitle);
        set.remove(hashMap);
        userTaskSocketMap.put(userId, set);
        sendTask(userId);
    }


    public boolean existUser(String userId) {
        return userwebSocketMap.containsKey(userId);
    }

    public CopyOnWriteArraySet<WebSocketService> getUserSocketSet(String userId) {
        return userwebSocketMap.get(userId);
    }


    private void initUserInfo(String userId) {
        CopyOnWriteArraySet<WebSocketService> webSocketTestSet = new CopyOnWriteArraySet<>();
        webSocketTestSet.add(this);
        userwebSocketMap.put(userId, webSocketTestSet);
    }
}

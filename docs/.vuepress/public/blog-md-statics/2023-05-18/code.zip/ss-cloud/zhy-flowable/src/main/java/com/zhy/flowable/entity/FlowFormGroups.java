package com.zhy.flowable.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FlowFormGroups implements Serializable {
    private static final long serialVersionUID = -5688639476635963746L;


    //id
    @TableId(type = IdType.ASSIGN_ID)
    private Integer groupId;

    //组名
    private String groupName;

    //排序号
    private Integer sortNum;

    //创建时间
    private Date createTime;

    //更新时间
    private Date updateTime;

    //创建人
    private String createBy;

    //更新人
    private String updateBy;

}

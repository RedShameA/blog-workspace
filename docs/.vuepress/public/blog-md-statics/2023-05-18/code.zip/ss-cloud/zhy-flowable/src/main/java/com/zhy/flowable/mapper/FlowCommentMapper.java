package com.zhy.flowable.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhy.flowable.entity.FlowCC;
import com.zhy.flowable.entity.FlowComment;
import com.zhy.flowable.entity.dto.ProcessFrontDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author syk
 * @Description 评论mapper
 * @Date 13:51 2023/2/2
 */
@Mapper
public interface FlowCommentMapper extends BaseMapper<FlowComment> {
}

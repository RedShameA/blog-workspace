package com.zhy.flowable.entity.vo;

import com.zhy.flowable.entity.FlowCC;
import com.zhy.flowable.entity.FlowComment;
import liquibase.pro.packaged.O;
import lombok.Data;
import org.flowable.engine.task.Attachment;
import org.flowable.engine.task.Comment;

import java.util.Date;
import java.util.List;

/**
 * @author syk
 * @Description 任务详情VO
 * @Date 15:02 2023/1/4
 */
@Data
public class TaskDetailVO {
    // 任务Id
    private String taskId;

    // 节点id
    private String activityId;

    //
    private String nodeId;

    // 节点名
    private String name;

    // 审批人
    private String assignee;

    // 创建时间
    private Date createTime;

    // 结束时间
    private Date endTime;

    // 签名图片
    private String signImage;

    // 附件列表
    private List<Attachment> attachmentVOList;

    //
    private List<OptionVO> optionVOList;

    // 评论列表
    private List<FlowComment> commentVOList;

    // 任务操作
    private String status;

    // 节点类型
    private String type;

    // 抄送人信息
    private List<UserInfoVO> ccList;
}

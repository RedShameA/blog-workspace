package com.zhy.flowable.entity.vo;

import lombok.Data;

/**
 * @author syk
 * @Description 附件信息
 * @Date 16:03 2023/1/4
 */
@Data
public class AttachmentVO {
    private String id;

    // 附件名
    private String name;

    // 附件url
    private String url;
}

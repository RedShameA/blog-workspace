package com.zhy.flowable.entity.dto;

import com.alibaba.fastjson.JSONObject;
import com.zhy.flowable.entity.UserInfo;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author syk
 * @Description 启动流程对象
 * @Date 8:43 2022/12/30
 */
@Data
public class StartProcessInstanceDTO {
    private String processDefinitionId;

    private JSONObject formData;

    private Map<String, List<UserInfo>> processUsers;

    private UserInfo startUserInfo;
}

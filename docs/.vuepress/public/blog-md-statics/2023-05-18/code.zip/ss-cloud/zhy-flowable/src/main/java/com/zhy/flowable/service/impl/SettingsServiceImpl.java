package com.zhy.flowable.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.zhy.common.security.utils.SecurityUtils;
import com.zhy.flowable.constats.WorkFlowConstants;
import com.zhy.flowable.entity.*;
import com.zhy.flowable.entity.bo.FlowTemplateGroupBo;
import com.zhy.flowable.entity.dto.FlowEngineDTO;
import com.zhy.flowable.entity.vo.TemplateGroupVo;
import com.zhy.flowable.exception.WorkFlowException;
import com.zhy.flowable.mapper.FlowFormGroupsMapper;
import com.zhy.flowable.mapper.FlowProcessTemplateMapper;
import com.zhy.flowable.service.FlowFormGroupsService;
import com.zhy.flowable.service.FlowProcessTemplateService;
import com.zhy.flowable.service.FlowTemplateGroupService;
import com.zhy.flowable.service.SettingsService;
import com.zhy.flowable.utils.BpmnConverter.BpmnConverter;
import com.zhy.flowable.utils.BpmnConverter.domain.ProcessNode;
import com.zhy.flowable.utils.BpmnModelUtils;
import com.zhy.flowable.utils.IdWorker;
import com.zhy.system.api.model.LoginUser;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.flowable.bpmn.BpmnAutoLayout;
import org.flowable.bpmn.model.Process;
import org.flowable.bpmn.model.*;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.delegate.ExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Service
public class SettingsServiceImpl implements SettingsService {
    @Autowired
    private FlowFormGroupsService flowFormGroupsService;

    @Autowired
    private FlowTemplateGroupService flowTemplateGroupService;

    @Autowired
    private FlowProcessTemplateService flowProcessTemplateService;

    @Autowired
    private RepositoryService repositoryService;

    @Autowired
    private RuntimeService runtimeService;
    @Autowired
    private FlowProcessTemplateMapper flowProcessTemplateMapper;

    @Autowired
    private IdWorker idWorker;


    @Override
    public boolean createFormGroup(String name) {
        LambdaQueryWrapper<FlowFormGroups> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(FlowFormGroups::getGroupName, name);

        long count = flowFormGroupsService.count(lambdaQueryWrapper);

        LoginUser loginUser = SecurityUtils.getLoginUser();

        if (count > 0) {
            //不能创建重复表单名
            return false;
        }
        lambdaQueryWrapper.clear();
        lambdaQueryWrapper.orderByDesc(FlowFormGroups::getSortNum).last("limit 1");
        FlowFormGroups one = flowFormGroupsService.getOne(lambdaQueryWrapper);
        int maxSort = 1;
        if (ObjectUtil.isNotEmpty(one)) {
            maxSort = one.getSortNum() + 1;
        }

        FlowFormGroups formGroups = FlowFormGroups.builder().groupName(name)
                .sortNum(maxSort)
                .createTime(new Date())
                .createBy(loginUser.getSysUser().getUserName())
                .build();

        boolean save = flowFormGroupsService.save(formGroups);
        return save;
    }

    @Override
    public boolean updateFormGroup(int id, String name) {
        LambdaQueryWrapper<FlowFormGroups> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(FlowFormGroups::getGroupName, name).ne(FlowFormGroups::getGroupId, id);

        long count = flowFormGroupsService.count(lambdaQueryWrapper);

        LoginUser loginUser = SecurityUtils.getLoginUser();

        if (count > 0) {
            //不能创建重复表单名
            return false;
        }
        FlowFormGroups formGroups = FlowFormGroups.builder()
                .groupId(id)
                .groupName(name)
                .updateBy(loginUser.getSysUser().getUserName())
                .updateTime(new Date())
                .build();

        boolean update = flowFormGroupsService.updateById(formGroups);

        return update;
    }

    @Override
    public boolean deleteFormGroup(int id) {
        boolean remove = flowFormGroupsService.removeById(id);
        return remove;
    }

    @Override
    public List<TemplateGroupVo> getFormGroups() {
        List<FlowTemplateGroupBo> templateGroupBos = flowTemplateGroupService.getAllTemplateAndGroup();
        Map<Integer, List<FlowTemplateGroupBo>> coverMap = new LinkedHashMap<>();
        templateGroupBos.forEach(t -> {
            if (coverMap.containsKey(t.getGroupId())) {
                coverMap.get(t.getGroupId()).add(t);
            } else {
                List<FlowTemplateGroupBo> list = new ArrayList<FlowTemplateGroupBo>();
                list.add(t);
                coverMap.put(t.getGroupId(), list);
            }
        });

        List<TemplateGroupVo> results = new ArrayList<>();
        coverMap.forEach((key, val) -> {
            List<TemplateGroupVo.Template> templates = new ArrayList<>();
            val.forEach(v -> {
                if (ObjectUtil.isNotNull(v.getTemplateId())) {
                    templates.add(TemplateGroupVo.Template.builder()
                            .formId(v.getTemplateId())
                            .tgId(v.getId())
                            .remark(v.getRemark())
                            .formName(v.getTemplateName())
                            .icon(v.getIcon())
                            .isStop(v.getIsStop())
                            .updateTime(DateFormatUtils.format(v.getUpdateTime() == null ? v.getCreateTime() : v.getUpdateTime(), "yyyy年MM月dd日 HH时:mm分:ss秒"))
                            .background(v.getBackground())
                            .templateId(v.getTemplateId())
                            .logo(JSONObject.parseObject(v.getBackground(), new TypeReference<JSONObject>() {
                            }))
                            .build());
                }
            });
            results.add(TemplateGroupVo.builder().id(key).name(val.get(0).getGroupName()).items(templates).build());
        });
        return results;
    }

    @Override
    public List<FlowTemplateGroupBo> listProcesses() {
        return flowProcessTemplateMapper.listProcesses();
    }

    @Override
    public void saveForm(FlowEngineDTO flowEngineDTO) {
        //当前登录人信息
        LoginUser loginUser = SecurityUtils.getLoginUser();
        //对流程信息进行解析
        String process = flowEngineDTO.getProcess();
        ChildNode childNode = JSONObject.parseObject(process, ChildNode.class);

        //对配置信息进行解析
        String settings = flowEngineDTO.getSettings();
        SettingsInfo settingsInfo = JSONObject.parseObject(settings, SettingsInfo.class);

        //拼接模板对象
        FlowProcessTemplates template = FlowProcessTemplates.builder()
                .templateId(idWorker.nextId() + "")
                .templateName(flowEngineDTO.getFormName())
                .icon(flowEngineDTO.getLogo())
                .groupId(flowEngineDTO.getGroupId())
                .background(flowEngineDTO.getLogo())
                .settings(settings)
                .whoCommit(settingsInfo.getAdmin().toString())
                .whoEdit(settingsInfo.getAdmin().toString())
                .whoExport(settingsInfo.getAdmin().toString())
//                .notify(settingsInfo.getNotify().toJSONString())
                .formItems(flowEngineDTO.getFormItems())
                .process(process)
                .isStop(false)
                .createBy(loginUser.getSysUser().getUserName())
                .createTime(new Date())
                .remark(flowEngineDTO.getRemark())
                .build();
        //保存模板
        flowProcessTemplateService.save(template);
        //获取最大sort
        LambdaUpdateWrapper<FlowTemplateGroup> wrapper = new LambdaUpdateWrapper<>();
        wrapper.eq(FlowTemplateGroup::getGroupId, template.getGroupId());
        wrapper.orderByDesc(FlowTemplateGroup::getSortNum).last(" limit 1");
        FlowTemplateGroup one = flowTemplateGroupService.getOne(wrapper);
        int maxSort = 1;
        if (ObjectUtil.isNotEmpty(one)) {
            maxSort = one.getSortNum() + 1;
        }

        //保存模板分组信息
        FlowTemplateGroup flowTemplateGroup = new FlowTemplateGroup();
        flowTemplateGroup.setTemplateId(template.getTemplateId());
        flowTemplateGroup.setGroupId(template.getGroupId());
        flowTemplateGroup.setSortNum(maxSort);
        flowTemplateGroup.setCreateTime(new Date());
        flowTemplateGroupService.save(flowTemplateGroup);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("processJson", process);
        jsonObject.put("formJson", flowEngineDTO.getFormItems());

        //发布表单
        ProcessNode processNode = JSONObject.parseObject(process, new TypeReference<ProcessNode>() {
        });
        BpmnModel bpmnModel = BpmnConverter.toBpmnModel(processNode, flowEngineDTO.getRemark(),
                flowEngineDTO.getFormName(), flowEngineDTO.getGroupId(), flowTemplateGroup.getTemplateId(),
                settings, flowEngineDTO.getFormItems());

        // BpmnModel bpmnModel = assemBpmnModel(jsonObject, childNode, flowEngineDTO.getRemark(), flowEngineDTO.getFormName(), flowEngineDTO.getGroupId(), flowTemplateGroup.getTemplateId());
        repositoryService.createDeployment()
                .addBpmnModel(flowEngineDTO.getFormName() + ".bpmn", bpmnModel)
                .name(flowEngineDTO.getFormName())
                .category(flowEngineDTO.getGroupId() + "")
                .deploy();
    }

    @Override
    public Map<String, Object> updateForm(String templateId, String type, Integer groupId) {
        Map<String, Object> result = new HashMap<>();

        boolean isStop = "stop".equals(type);
        if ("using".equals(type) || isStop) {
            //停用与开启使用一套逻辑
            flowProcessTemplateService.updateById(FlowProcessTemplates.builder()
                    .templateId(templateId).isStop(isStop).build());
        } else if ("delete".equals(type)) {
            //删除表单
            flowProcessTemplateService.removeById(templateId);
            LambdaQueryWrapper<FlowTemplateGroup> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(FlowTemplateGroup::getTemplateId, templateId);
            flowTemplateGroupService.remove(wrapper);
        } else if ("move".equals(type)) {
            //移动表单分组
            // TODO: 2022/12/27 增加groupId的判断
            if (ObjectUtil.isEmpty(groupId)) {
                result.put("status", false);
                result.put("msg", "分组Id不可为空!");
                return result;
            }
            LambdaUpdateWrapper<FlowTemplateGroup> wrapper = new LambdaUpdateWrapper<>();
            wrapper.set(FlowTemplateGroup::getGroupId, groupId);
            wrapper.eq(FlowTemplateGroup::getTemplateId, templateId);
            flowTemplateGroupService.update(wrapper);
        } else {
            result.put("status", false);
            result.put("msg", "不支持该操作!");
            return result;
        }
        result.put("status", true);
        result.put("msg", "操作成功");
        return result;
    }

    @Override
    public void updateFormDetail(FlowProcessTemplates template) {
        //先判断当前表单是否已发起
        String processDefinitionId = template.getProcessDefinitionId();
        if (!ObjectUtil.isEmpty(processDefinitionId)) {
            long count = runtimeService.createProcessInstanceQuery().processDefinitionId(processDefinitionId).count();
            if (count > 0) {
                throw new WorkFlowException("流程已发起，不可修改!");
            }
        }
        String settings = template.getSettings();

        SettingsInfo settingsInfo = JSONObject.parseObject(settings, SettingsInfo.class);
        //更新模板信息
        FlowProcessTemplates processTemplate = flowProcessTemplateService.getById(template.getTemplateId());
        processTemplate.setTemplateName(template.getFormName());
        processTemplate.setGroupId(template.getGroupId());
        processTemplate.setFormItems(template.getFormItems());
        processTemplate.setSettings(settings);
        processTemplate.setProcess(template.getProcess());
        processTemplate.setIcon(template.getIcon());
        processTemplate.setBackground(template.getBackground());
//        processTemplate.setNotify(settingsInfo.getNotify().toJSONString());
        String adminInfo = JSONObject.toJSONString(settingsInfo.getAdmin());

        processTemplate.setWhoCommit(adminInfo);
        processTemplate.setWhoEdit(adminInfo);
        processTemplate.setWhoExport(adminInfo);
        processTemplate.setRemark(template.getRemark());
        processTemplate.setUpdateTime(new Date());
        flowProcessTemplateService.updateById(processTemplate);

        //重新生成bpmn文件
        ChildNode childNode = JSONObject.parseObject(template.getProcess(), ChildNode.class);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("processJson", template.getProcess());
        jsonObject.put("formJson", template.getFormItems());
        String process = template.getProcess();
        ProcessNode processNode = JSONObject.parseObject(process, new TypeReference<ProcessNode>() {
        });
        BpmnModel bpmnModel = BpmnConverter.toBpmnModel(processNode, template.getRemark(), template.getFormName(),
                template.getGroupId(), template.getTemplateId(), settings, template.getFormItems());
        // BpmnModel bpmnModel = assemBpmnModel(jsonObject, childNode, template.getRemark(), template.getFormName(), template.getGroupId(), template.getTemplateId());
        repositoryService.createDeployment()
                .addBpmnModel(template.getFormName() + ".bpmn", bpmnModel)
                .name(template.getFormName())
                .category(template.getGroupId() + "")
                .deploy();
    }

    @Override
    public FlowProcessTemplates getFormTemplateById(String templateId) {
        FlowProcessTemplates processTemplates = flowProcessTemplateService.getById(templateId);
        processTemplates.setLogo(processTemplates.getIcon());
        processTemplates.setFormId(processTemplates.getTemplateId());
        processTemplates.setFormName(processTemplates.getTemplateName());
        return processTemplates;
    }

    @Override
    public void groupSort(List<FlowFormGroups> formGroups) {
        for (int i = 0; i < formGroups.size(); i++) {
            FlowFormGroups group = formGroups.get(i);
            LambdaUpdateWrapper<FlowFormGroups> wrapper = new LambdaUpdateWrapper<>();
            wrapper.eq(FlowFormGroups::getGroupId, group.getGroupId());
            wrapper.set(FlowFormGroups::getSortNum, i);
            flowFormGroupsService.update(wrapper);
        }

    }

    @Override
    public void itemSort(List<FlowTemplateGroup> flowTemplateGroups) {
        for (int i = 0; i < flowTemplateGroups.size(); i++) {
            FlowTemplateGroup flowTemplateGroup = flowTemplateGroups.get(i);
            LambdaUpdateWrapper<FlowTemplateGroup> wrapper = new LambdaUpdateWrapper<>();
            wrapper.eq(FlowTemplateGroup::getTemplateId, flowTemplateGroup.getTemplateId());
            wrapper.set(FlowTemplateGroup::getSortNum, i);
            flowTemplateGroupService.update(wrapper);
        }
    }

    private BpmnModel assemBpmnModel(JSONObject jsonObject, ChildNode childNode, String remark,
                                     String formName, Integer groupId, String templateId) {
        BpmnModel bpmnModel = new BpmnModel();
        List<SequenceFlow> sequenceFlows = new ArrayList<>();
        Map<String, ChildNode> childNodeMap = new HashMap<>();
        bpmnModel.setTargetNamespace(groupId + "");
        ExtensionAttribute extensionAttribute = new ExtensionAttribute();
        extensionAttribute.setName("ZHY");
        extensionAttribute.setNamespace("http://flowable.org/bpmn");
        extensionAttribute.setValue(jsonObject.toJSONString());
        Process process = new Process();
        process.setId(WorkFlowConstants.PROCESS_PREFIX + templateId);
        process.setName(formName);
        process.setDocumentation(remark);
        process.addAttribute(extensionAttribute);
        bpmnModel.addProcess(process);

        StartEvent startEvent = BpmnModelUtils.createStartEvent();
        process.addFlowElement(startEvent);
        String lastNode = null;
        try {
            lastNode = BpmnModelUtils.create(startEvent.getId(), childNode, process, bpmnModel, sequenceFlows, childNodeMap);
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        EndEvent endEvent = BpmnModelUtils.createEndEvent();
        process.addFlowElement(endEvent);
        process.addFlowElement(BpmnModelUtils.connect(lastNode, endEvent.getId(), sequenceFlows, childNodeMap, process));
        List<FlowableListener> executionListeners = new ArrayList<>();
        FlowableListener flowableListener = new FlowableListener();
        flowableListener.setEvent(ExecutionListener.EVENTNAME_END);
        flowableListener.setImplementationType(ImplementationType.IMPLEMENTATION_TYPE_DELEGATEEXPRESSION);
        flowableListener.setImplementation("${processListener}");
        executionListeners.add(flowableListener);
        process.setExecutionListeners(executionListeners);
        new BpmnAutoLayout(bpmnModel).execute();
        return bpmnModel;
    }
}

package com.zhy.flowable.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhy.flowable.entity.FlowFormGroups;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FlowFormGroupsMapper extends BaseMapper<FlowFormGroups> {
}

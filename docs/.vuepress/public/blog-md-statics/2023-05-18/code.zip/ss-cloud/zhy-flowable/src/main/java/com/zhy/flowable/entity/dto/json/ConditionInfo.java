package com.zhy.flowable.entity.dto.json;

import lombok.Data;

import java.util.List;

@Data
public class ConditionInfo {
    private String id;

    private String title;

    private String valueType;

    private String compare;

    private List<Object> value;
}

package com.zhy.flowable.enums;

/**
 * @author syk
 * @Description
 * @Date 16:03 2022/12/30
 */
public enum AssigneeTypeEnums {
  ASSIGN_USER("ASSIGN_USER"),
  SELF_SELECT("SELF_SELECT"),
  LEADER_TOP("LEADER_TOP"),
  LEADER("LEADER"),
  ROLE("ROLE"),
  SELF("SELF"),
  FORM_USER("FORM_USER");

  private String typeName;

  AssigneeTypeEnums(String typeName) {
    this.typeName = typeName;
  }

  public String getTypeName() {
    return typeName;
  }

  public void setTypeName(String typeName) {
    this.typeName = typeName;
  }
}

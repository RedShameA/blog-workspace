package com.zhy.flowable;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients(basePackages = "com.zhy")
@SpringBootApplication(scanBasePackages = "com.zhy")
public class ZhyFlowableApplication {
    public static void main(String[] args) {
        SpringApplication.run(ZhyFlowableApplication.class, args);
        System.out.println("(♥◠‿◠)ﾉﾞ  工作流程启动成功   ლ(´ڡ`ლ)ﾞ");

    }
}


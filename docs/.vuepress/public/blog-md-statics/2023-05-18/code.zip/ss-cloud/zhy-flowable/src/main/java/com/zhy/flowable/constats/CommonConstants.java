package com.zhy.flowable.constats;

public interface CommonConstants {
    String FORM_VAR = "formData";

    String PROCESS_STATUS = "processStatus";

    String START_USER_INFO = "startUser";

    String PROCESS_TITLE = "process_title";

    String PROCESS_DESC = "process_desc";

    // 流程发起人id
    String PROCESS_VAR_STARTER_ID = "process_starter_id";
    // 流程发起人昵称
    String PROCESS_VAR_STARTER_NICKNAME = "process_starter_nickname";
    // 流程启动时间
    String PROCESS_VAR_START_TIME = "process_start_time";
    // 流程结束时间
    String PROCESS_VAR_END_TIME = "process_end_time";


    String BUSINESS_STATUS_ALL = "-1"; //所有状态
    String BUSINESS_STATUS_1 = "1"; //正在处理

    String BUSINESS_STATUS_2 = "2";//撤销

    String BUSINESS_STATUS_3 = "3";//驳回

    String BUSINESS_STATUS_4 = "4";//已结束

    String COMPLATE = "agree"; //完成

    String REJECT = "refuse";//驳回

    String NOT_STARTED = "notStarted";//未开始

    String RUNNING = "running";//进行中
}

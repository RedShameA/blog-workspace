package com.zhy.flowable.enums;

public enum ModeEnums {
    AND("AND"),
    OR("OR"),
    NEXT("NEXT");

    private String typeName;

    ModeEnums(String typeName) {
        this.typeName = typeName;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }
}

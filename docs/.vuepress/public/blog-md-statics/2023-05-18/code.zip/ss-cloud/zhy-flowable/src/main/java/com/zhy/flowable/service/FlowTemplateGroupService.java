package com.zhy.flowable.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zhy.flowable.entity.FlowTemplateGroup;
import com.zhy.flowable.entity.bo.FlowTemplateGroupBo;

import java.util.List;

public interface FlowTemplateGroupService extends IService<FlowTemplateGroup> {
    List<FlowTemplateGroupBo> getAllTemplateAndGroup();
}

package com.zhy.flowable.utils.BpmnConverter.domain;

import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @Author wangfeng
 * @Description
 * @Date 2023-01-01 00:14
 */
@Data
public class Props {


    //------发起

    // 发起人权限，哪些 人/部门 可以发起这个审批
    //    id
    //    name
    //    type [user, dept] 根据类型判断是人或者部门
    // ALSO
    // 审批任务 指定审批人员 assignedType 为 ASSIGN_USER 时不为空 只能user
    // ALSO
    // 指定抄送人员
    private List<Map<String, String>> assignedUser;

    //------审批任务

    //审批处理的类型 ASSIGN_USER 指定人员、SELF_SELECT 发起人自选、LEADER_TOP 连续多级主管、LEADER 主管、ROLE 指定角色、SELF 发起人自己、REFUSE 自动拒绝、FORM_USER指定表单联系人
    private String assignedType;
    // 多人审批时的审批模式，AND 会签、OR 或签、NEXT 顺序依次审批
    // 角色或者自选的时候用到
    private String mode;
    //审批同意时是否需要签字
    private Boolean sign;
    // 审批人为空时的规则
    // handler String  PASS 直接通过、 TO_ADMIN 转交主管理员、TO_USER 转交指定人员
    // assignedUser [] //TO_USER 时的指定人员
    private Map<String, Object> nobady;
    //审批超时限制设置
    // timeout 超时时间限制
    //   unit String 时间单位 M分钟、H小时、D天,
    //   value Integer 时间值
    // handler 超时后的处理规则
    //   type String PASS 自动通过、REFUSE 自动驳回、NOTIFY 发送通知进行提醒
    //   notify
    //      once Boolean 是否只提醒一次
    //      hour Integer 重复提醒，几小时提醒一次
    private Map<String, Map<String, Object>> timeLimit;
    // 指定审批人员 ASSIGN_USER 时不为空
    // private List<String> assignedUser;
    // 发起人自选
    //    是否多选 true/false
    private Map<String, Boolean> selfSelect;
    // 连续多级主管
    //   endCondition String 结束条件 TOP 直到最上级主管、 LEVEL 指定不超过多少级主管
    //   endLevel Integer 指定级别主管审批后结束本节点
    private Map<String, Object> leaderTop;
    // 指定主管审批
    //   level Integer 发起人指定级别主管
    private Map<String, Integer> leader;
    // 指定角色审批
    //   id 角色id
    //   name 角色name
    private List<Map<String, String>> role;
    // 驳回设置
    //    type String TO_END 驳回直接结束流程、TO_NODE 驳回到指定节点、TO_BEFORE 驳回到上一级
    //    target String 驳回到指定ID的节点
    private Map<String, String> refuse;
    //类型为指定表单联系人时，对应表单组件ID
    private String formUser;


    //------条件节点CONDITION

    //条件组逻辑关系 OR、AND
    private String groupsType;
    //  "(A AND B) OR C" //自定义表达式，灵活构建逻辑关系
    private String expression;
    // groups
    //    groupType String 条件组内条件关系 OR、AND
    //    conditions
    //       cid String 组件ID，通过组件ID索引到表单设计器中的组件
    //       compare String ">=", //比较运算符 >大于
    //       value [], //比较值，如果只需要比较一个值，那么只取value[0]
    private List<ConditionGroup> groups;


    //--------抄送 CC

    // 允许发起人自选抄送人
    private Boolean shouldAdd;
    // 指定抄送人员
    // private List assignedUser;


    //---------延迟处理节点 DELAY

    // 延时类型 FIXED:到达当前节点后延时固定时长 、AUTO:延时到 dateTime设置的时间
    // ALSO
    // 触发器节点 触发的动作类型 WEBHOOK、EMAIL
    private String type;
    // 延时时间
    private Integer time;
    // 时间单位 D天 H小时 M分钟
    private String unit;
    // 如果当天没有超过设置的此时间点，就延时到这个指定的时间，到了就直接跳过不延时
    private String DateTime;

    //---------触发器节点 TRIGGER

    // 触发的动作类型 WEBHOOK、EMAIL
    // private String type;

    // http触发器 todo
    private Map<String, Object> http;
    // email触发器 todo
    private Map<String, Object> email;

}

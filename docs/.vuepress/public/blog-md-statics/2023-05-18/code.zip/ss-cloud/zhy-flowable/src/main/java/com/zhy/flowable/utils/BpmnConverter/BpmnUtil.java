package com.zhy.flowable.utils.BpmnConverter;

import cn.hutool.core.date.DateUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
import com.zhy.common.core.utils.SpringUtils;
import com.zhy.flowable.constats.CommonConstants;
import com.zhy.flowable.constats.WorkFlowConstants;
import com.zhy.flowable.entity.FlowProcessTemplates;
import com.zhy.flowable.entity.UserInfo;
import com.zhy.flowable.service.FlowProcessTemplateService;
import org.flowable.bpmn.model.*;
import org.flowable.bpmn.model.Process;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RepositoryService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.variable.api.history.HistoricVariableInstance;

import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author wangfeng
 * @Description
 * @Date 2022-12-30 15:28
 */
public class BpmnUtil{

    public static void main(String[] args) {
        HashMap<String, Object> variables = new HashMap<>();
        variables = new HashMap<>();
        variables.put("starter", "王峰");
        variables.put("processName", "请假流程");
        variables.put("startTime", new Date());
        // System.out.println(renderProcessTitle("#{starter} = #{processName}"));
        // System.out.println(renderProcessDesc(null, null, "Flowable5058013873496064"));
    }

    public static String renderProcessTitle(Map<String, Object> variables, Process mainProcess){
        // settings
        Map<String, List<ExtensionElement>> extensionElements = mainProcess.getExtensionElements();
        List<ExtensionElement> settingsExtensionElement = extensionElements.getOrDefault("settings", null);
        if (null == settingsExtensionElement){
            return "";
        }
        String settingStr = settingsExtensionElement.get(0).getElementText();
        JSONObject setting = JSONObject.parseObject(settingStr);
        if (!setting.containsKey("titleExpr")){
            return "";
        }
        String titleExprStr = setting.getString("titleExpr");
        JSONArray array = JSONArray.parseArray(titleExprStr);
        List<String> collect = array.stream().map(String::valueOf).collect(Collectors.toList());
        String titleExpr = String.join("", collect);
        // titleExpr
        String pattern = "#\\{(.*?)\\}";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(titleExpr);
        ArrayList<HashMap<String, String>> list = new ArrayList<>();
        // 遍历表达式
        while (m.find()) {
            HashMap<String, String> map = new HashMap<>();
            map.put("replace", m.group());
            map.put("key", m.group(1));
            list.add(map);
        }
        String title = new String(titleExpr);
        // 替换变量
        for (HashMap<String, String> map : list) {
            String replace = map.get("replace");
            String key = map.get("key");
            Object value = "";

            Object orDefault = variables.getOrDefault(key, null);
            if (null != orDefault){
                value = orDefault;
            }
            title = title.replace(replace, null==value?"":value.toString());
        }
        return title;
    }

    public static String renderProcessDesc(Map<String, Object> variables, Process mainProcess){
        // settings
        Map<String, List<ExtensionElement>> extensionElements = mainProcess.getExtensionElements();
        List<ExtensionElement> settingsExtensionElement = extensionElements.getOrDefault("settings", null);
        if (null == settingsExtensionElement){
            return "";
        }
        String settingStr = settingsExtensionElement.get(0).getElementText();
        JSONObject setting = JSONObject.parseObject(settingStr);
        if (!setting.containsKey("descExpr")){
            return "";
        }
        JSONArray descExpr = setting.getJSONArray("descExpr");
        // 获取原始表单文本
        List<ExtensionElement> formItemsExtensionElement = extensionElements.getOrDefault("formItems", null);
        if (null == formItemsExtensionElement){
            return "";
        }
        String formItemsStr = formItemsExtensionElement.get(0).getElementText();
        // 生成表单id映射map
        JSONArray formItems = JSONObject.parseArray(formItemsStr);
        Set<JSONObject> set = getAllJsonObject(formItems);
        Map<String, JSONObject> map = set.stream()
                .filter(e -> !e.isEmpty() && e.containsKey("id"))
                .collect(Collectors.toMap(e -> e.getString("id"), e -> e));
        // 渲染
        StringBuffer desc = new StringBuffer("");
        for (Object object : descExpr) {
            String key = (String) object;
            desc.append("\n");
            // 表单中的名字
            JSONObject jsonObject = map.get(key);
            String name = jsonObject.getString("name"); // 组件类型
            String title = jsonObject.getString("title");
            String value = "";
            Object orDefault = variables.getOrDefault(key, null);
            try{
                if ("DateTimeRange".equalsIgnoreCase(name)){
                    if (null == orDefault){
                        continue;
                    }
                    JSONArray o = (JSONArray) orDefault;
                    String[] objects = o.stream().map(String::valueOf).toArray(String[]::new);
                    value = String.join(" - ", objects);
                }else if ("MultipleSelect".equalsIgnoreCase(name)){
                    if (null == orDefault){
                        continue;
                    }
                    JSONArray o = (JSONArray) orDefault;
                    String[] objects = o.stream().map(String::valueOf).toArray(String[]::new);
                    value = String.join(", ", objects);
                }else{
                    value = orDefault.toString();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            desc.append(title + ": " + value);
        }
        desc.delete(0,1);
        return desc.toString();
    }

    // 遍历获取所有JSONObject
    private static Set<JSONObject> getAllJsonObject(Object object){
        HashSet<JSONObject> set = new HashSet<>();
        if(object instanceof JSONObject) {
            set.add((JSONObject) object);
            JSONObject jsonObject = (JSONObject) object;
            for (Map.Entry<String, Object> entry: jsonObject.entrySet()) {
                Object o = entry.getValue();
                Set<JSONObject> allJsonObject = getAllJsonObject(o);
                set.addAll(allJsonObject);
            }
        }
        if(object instanceof JSONArray) {
            JSONArray jsonArray = (JSONArray) object;
            for(int i = 0; i < jsonArray.size(); i ++) {
                Set<JSONObject> allJsonObject = getAllJsonObject(jsonArray.get(i));
                set.addAll(allJsonObject);
            }
        }
        return set;
    }


    public static String getTaskNodeString(Task task){
        Map<String, List<ExtensionElement>> extensionElements = task.getExtensionElements();
        List<ExtensionElement> node = extensionElements.getOrDefault("node", new ArrayList<>());
        if (node.size()>0){
            return node.get(0).getElementText();
        }else{
            return "";
        }
    }
    /**
     * 获取extensionElements扩展，没有则创建
     * @return
     */
    public static List<ExtensionElement> getOrCreateExtensionElements(BaseElement baseElement) {
        if (baseElement.getExtensionElements()==null) {
            baseElement.setExtensionElements(new HashMap<>());
        }

        Map<String, List<ExtensionElement>> extensionElementsMap = baseElement.getExtensionElements();
        if (!extensionElementsMap.containsKey("extensionElements")) {
            extensionElementsMap.put("extensionElements", new ArrayList<>());
        }
        return extensionElementsMap.get("extensionElements");
    }

    /**
     * 获取properties扩展，没有则创建
     * @return
     */
    public static List<ExtensionElement> getOrCreateExtensionProperties(BaseElement baseElement) {
        List<ExtensionElement> extensionElements = getOrCreateExtensionElements(baseElement);
        Optional<ExtensionElement> first = extensionElements.stream().filter(v -> v.getName().equals("properties")).findFirst();
        if (!first.isPresent()) {
            ExtensionElement element = new ExtensionElement();
            element.setName("properties");
            extensionElements.add(element);
            Map<String, List<ExtensionElement>> childElements = new HashMap<>();
            List<ExtensionElement> propertyElementList = new ArrayList<>();
            childElements.put("property",propertyElementList);
            element.setChildElements(childElements);
            return propertyElementList;
        }
        return first.get().getChildElements().get("property");
    }

    /**
     * 扩展->添加属性:
     * @param map
     * @return
     */
    public static void addExtensionProperty(BaseElement baseElement, Map<String, Object> map, SimplePropertyPreFilter filter) {
        List<ExtensionElement> properties = getOrCreateExtensionProperties(baseElement);
        for (String name : map.keySet()) {
            Object value = map.get(name);

            ExtensionElement childElement = new ExtensionElement();
            childElement.setName("property");
            List<ExtensionAttribute> attributeList = new ArrayList<>();
            ExtensionAttribute attributeName = new ExtensionAttribute();
            attributeName.setName("name");
            attributeName.setValue(name);
            ExtensionAttribute attributeValue = new ExtensionAttribute();
            attributeValue.setName("value");
            attributeValue.setValue(JSON.toJSONString(value, filter));
            attributeList.add(attributeName);
            attributeList.add(attributeValue);

            Map<String, List<ExtensionAttribute>> attributes = new HashMap<>();
            attributes.put("attributes", attributeList);
            childElement.setAttributes(attributes);
            properties.add(childElement);
        }
    }
    /**
     * 扩展->添加属性:
     * @param map
     * @return
     */
    public static void addExtensionProperty(BaseElement baseElement, Map<String, Object> map) {
        addExtensionProperty(baseElement, map, null);
    }

}

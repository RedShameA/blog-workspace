package com.zhy.flowable.entity.vo;

import com.zhy.flowable.constats.CommonConstants;
import com.zhy.flowable.entity.FlowCC;
import lombok.Data;
import org.flowable.engine.HistoryService;
import org.flowable.engine.ProcessEngines;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.impl.persistence.entity.HistoricProcessInstanceEntityImpl;
import org.flowable.task.api.Task;
import org.flowable.task.api.history.HistoricTaskInstance;

import java.util.Date;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author wangfeng
 * @Description Process传给前端的VO
 * @Date 2022-12-28 10:03
 */
@Data
public class ProcessVo {

    public static ConcurrentHashMap<String, Object> map = new ConcurrentHashMap<>();


    public enum Type{
        /**
         * 0:未知  1:待办任务  2:已办任务  3:已办流程  4:已发流程  5:待阅流程
         */
        UNKNOWN(0),
        TASK(1),
        ALREADY_TASK(2),
        ALREADY_PROCESS(3),
        OWN_PROCESS(4),
        CC_PROCESS(5);
        private int type;
        private Type(int type){
            this.type = type;
        }
        public int get(){
            return this.type;
        }
    }
    /**
     * 0:未知  1:待办任务  2:已办任务  3:已办流程  4:已发流程  5:待阅流程
     */
    private Integer type = Type.UNKNOWN.get();

    /**
     * 待办任务名/流程名
     */
    private String title;

    /**
     * 流程ID
     */
    private String processInstanceId;

    /**
     * 待办taskId/流程processInstanceId
     */
    private String id;

    /**
     * 摘要
     */
    private String summary;

    /**
     * 发起人（流程发起人）
     */
    private String startUser;

    /**
     * 发起时间
     */
    private Date startTime;

    /**
     * 完成时间
     */
    private Date completeTime;

    /**
     * 流程状态
     */
    private String processStatus;

    /**
     * 当前办理人
     */
    private String assignee;

    /**
     * 抄送是否已读
     */
    private Boolean CC;


    /**
     * 从历史任务转换为vo
     * @param task
     */
    public void convertFrom(HistoricTaskInstance task){
        HistoryService historyService = ProcessEngines.getDefaultProcessEngine().getHistoryService();
        String processInstanceId = task.getProcessInstanceId();
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery()
                .processInstanceId(processInstanceId).includeProcessVariables().singleResult();
        Optional<HistoricProcessInstance> optionalProcessInstance = Optional.ofNullable(historicProcessInstance);
        String startUserId = optionalProcessInstance.map(e->e.getStartUserId()).orElse(null);
        Date startTime_ = optionalProcessInstance.map(e->e.getStartTime()).orElse(null);
        Date endTime = optionalProcessInstance.map(e->e.getEndTime()).orElse(null);
        this.setType(Type.ALREADY_TASK.get());
        this.setTitle(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_TITLE));
        this.setId(task.getId());
        this.setProcessInstanceId(task.getProcessInstanceId());
        this.setSummary(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_DESC));
        this.setStartUser(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_VAR_STARTER_NICKNAME));
        this.setStartTime(startTime_);
        this.setCompleteTime(endTime);
        this.setProcessStatus(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_STATUS));
        this.setAssignee(task.getAssignee());
    }

    /**
     * 从任务转换为vo
     * @param task
     */
    public void convertFrom(Task task){
        HistoryService historyService = ProcessEngines.getDefaultProcessEngine().getHistoryService();
        String processInstanceId = task.getProcessInstanceId();
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery()
                .processInstanceId(processInstanceId).includeProcessVariables().singleResult();
        Optional<HistoricProcessInstance> optionalProcessInstance = Optional.ofNullable(historicProcessInstance);
        String startUserId = optionalProcessInstance.map(e->e.getStartUserId()).orElse(null);
        Date startTime_ = optionalProcessInstance.map(e->e.getStartTime()).orElse(null);
        Date endTime = optionalProcessInstance.map(e->e.getEndTime()).orElse(null);
        this.setType(Type.TASK.get());
        this.setTitle(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_TITLE));
        this.setId(task.getId());
        this.setProcessInstanceId(task.getProcessInstanceId());
        this.setSummary(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_DESC));
        this.setStartUser(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_VAR_STARTER_NICKNAME));
        this.setStartTime(startTime_);
        this.setCompleteTime(endTime);
        this.setProcessStatus(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_STATUS));
        this.setAssignee(task.getAssignee());
    }

    /**
     * 从FlowCC转换为vo
     * @param cc
     */
    public void convertFrom(FlowCC cc, HistoricProcessInstance historicProcessInstance){
        Optional<HistoricProcessInstance> optionalProcessInstance = Optional.ofNullable(historicProcessInstance);
        String startUserId = optionalProcessInstance.map(e->e.getStartUserId()).orElse(null);
        Date startTime_ = optionalProcessInstance.map(e->e.getStartTime()).orElse(null);
        Date endTime = optionalProcessInstance.map(e->e.getEndTime()).orElse(null);
        this.setType(Type.CC_PROCESS.get());
        this.setTitle(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_TITLE));
        this.setId(cc.getId().toString());
        this.setProcessInstanceId(((HistoricProcessInstanceEntityImpl)historicProcessInstance).getProcessInstanceId());
        this.setSummary(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_DESC));
        this.setStartUser(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_VAR_STARTER_NICKNAME));
        this.setStartTime(startTime_);
        this.setCompleteTime(endTime);
        this.setProcessStatus(this.getProcessVariable(historicProcessInstance, CommonConstants.PROCESS_STATUS));
        this.setAssignee("");
        this.setCC(cc.getReaded());
    }
    

    /**
     * 从历史流程转换为vo
     * @param process
     */
    public void convertFrom(HistoricProcessInstance process){
        Optional<HistoricProcessInstance> optionalProcessInstance = Optional.ofNullable(process);
        String startUserId = optionalProcessInstance.map(e->e.getStartUserId()).orElse(null);
        Date startTime_ = optionalProcessInstance.map(e->e.getStartTime()).orElse(null);
        Date endTime = optionalProcessInstance.map(e->e.getEndTime()).orElse(null);
        this.setType(Type.ALREADY_PROCESS.get());
        this.setTitle(this.getProcessVariable(process, CommonConstants.PROCESS_TITLE));
        this.setId(process.getId());
        this.setProcessInstanceId(((HistoricProcessInstanceEntityImpl)process).getProcessInstanceId());
        this.setSummary(this.getProcessVariable(process, CommonConstants.PROCESS_DESC));
        this.setStartUser(this.getProcessVariable(process, CommonConstants.PROCESS_VAR_STARTER_NICKNAME));
        this.setStartTime(startTime_);
        this.setCompleteTime(endTime);
        this.setProcessStatus(this.getProcessVariable(process, CommonConstants.PROCESS_STATUS));
        this.setAssignee(null);
    }

    private String getProcessVariable(HistoricProcessInstance historicProcessInstance, String name){
        Map<String, Object> processVariables = historicProcessInstance.getProcessVariables();
        Object orDefault = processVariables.getOrDefault(name, null);
        if (null == orDefault){
            return "";
        }
        return orDefault.toString();
    }
}

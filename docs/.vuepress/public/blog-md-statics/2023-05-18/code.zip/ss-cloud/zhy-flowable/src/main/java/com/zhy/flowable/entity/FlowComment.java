package com.zhy.flowable.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author syk
 * @Description 评论数据
 * @Date 13:39 2023/2/2
 */
@Data
@Builder
@TableName("flow_comment")
@AllArgsConstructor
@NoArgsConstructor
public class FlowComment {

    //id
    @TableId(type = IdType.ASSIGN_ID)
    private Integer id;

    // 抄送用户id
    private Long userId;

    // 流程id
    private String processInstanceId;

    //任务id
    private String activityId;

    // 评论类型
    private String type;

    // 发起抄送的任务id
    private String comment;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

}

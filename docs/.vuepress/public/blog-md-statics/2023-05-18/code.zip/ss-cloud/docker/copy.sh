#!/bin/sh

# 复制项目的文件到对应docker路径，便于一键生成镜像。
usage() {
	echo "Usage: sh copy.sh"
	exit 1
}


# copy sql
#echo "begin copy sql "
#cp ../sql/ry_20220814.sql ./mysql/db
#cp ../sql/ry_config_20220510.sql ./mysql/db

# copy html
# echo "begin copy html "
# cp -r ../ruoyi-ui/dist/** ./nginx/html/dist


# copy jar
echo "begin copy zhy-gateway "
cp ../zhy-gateway/target/zhy-gateway.jar ./zhy/gateway/jar
cp ../zhy-gateway/src/main/resources/bootstrap.yml ./zhy/gateway/jar

echo "begin copy zhy-auth "
cp ../zhy-auth/target/zhy-auth.jar ./zhy/auth/jar
cp ../zhy-auth/src/main/resources/bootstrap.yml ./zhy/auth/jar

echo "begin copy zhy-flowable "
cp ../zhy-flowable/target/zhy-flowable.jar ./zhy/flowable/jar
cp ../zhy-flowable/src/main/resources/bootstrap.yml ./zhy/flowable/jar

echo "begin copy zhy-visual "
cp ../zhy-visual/zhy-visual-monitor/target/zhy-visual-monitor.jar  ./zhy/visual/monitor/jar
cp ../zhy-visual/zhy-visual-monitor/src/main/resources/bootstrap.yml ./zhy/visual/monitor/jar

echo "begin copy zhy-modules-system "
cp ../zhy-modules/zhy-modules-system/target/zhy-modules-system.jar ./zhy/modules/system/jar
cp ../zhy-modules/zhy-modules-system/src/main/resources/bootstrap.yml ./zhy/modules/system/jar

echo "begin copy zhy-modules-file "
cp ../zhy-modules/zhy-modules-file/target/zhy-modules-file.jar ./zhy/modules/file/jar
cp ../zhy-modules/zhy-modules-file/src/main/resources/bootstrap.yml ./zhy/modules/file/jar

echo "begin copy zhy-modules-job "
cp ../zhy-modules/zhy-modules-job/target/zhy-modules-job.jar ./zhy/modules/job/jar
cp ../zhy-modules/zhy-modules-job/src/main/resources/bootstrap.yml ./zhy/modules/job/jar

echo "begin copy zhy-modules-gen "
cp ../zhy-modules/zhy-modules-gen/target/zhy-modules-gen.jar ./zhy/modules/gen/jar
cp ../zhy-modules/zhy-modules-gen/src/main/resources/bootstrap.yml ./zhy/modules/gen/jar

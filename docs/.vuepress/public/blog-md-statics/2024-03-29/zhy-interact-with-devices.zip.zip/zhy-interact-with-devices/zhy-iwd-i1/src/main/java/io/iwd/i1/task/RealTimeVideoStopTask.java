package io.iwd.i1.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.http.srs.template.SrsExchangeSdpTemplate;
import io.iwd.common.stdio.http.srs.template.SrsQueryStreamTemplate;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.i1.entity.RealTimeVideoStopInitParams;
import io.iwd.i1.entity.RealTimeVideoWebrtcPlayInitParams;
import io.iwd.i1.event.I1DefaultTaskProceedEvent;

import static io.iwd.i1.I1Const.TASK_PREFIX;

public class RealTimeVideoStopTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "RealTimeVideoStop", I1DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            RealTimeVideoStopInitParams input = (RealTimeVideoStopInitParams) context.getInput();
            context.putData("deviceNumber", input.getDeviceNumber());
            context.putData("channelNumber", input.getChannelNumber());
            context.putData("mediaServerIp", input.getMediaServerIp());
            context.putData("mediaServerPort", input.getMediaServerPort());
            context.putData("parentDeviceNumber", input.getParentDeviceNumber());

            context.fireNext("ISSUE_VIDEO_STOP_COMMAND");
        });

        taskFlow.addNode("ISSUE_VIDEO_STOP_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            JsonObject data = JsonObject.create()
                    .put("DeviceID", deviceNumber)
                    .put("ChannelNo", context.getData("channelNumber"))
                    .put("VideoTranfer", 0)
                    .put("VideoServerAddress", context.getData("mediaServerIp"))
                    .put("UpperHostPort", context.getData("mediaServerPort"))
                    .put("MaxPushStreamingDraution", "0")
                    .put("ParentDevID", context.getData("parentDeviceNumber"));

            String message = "WEB-1@1045@" + deviceNumber + "@FCMGroup-1@" + (System.currentTimeMillis() / 1000) + "@" + context.getTaskId();

            String script = "redis.call('SET', KEYS[1], ARGV[1]);" +
                            "redis.call('PUBLISH', 'FCMGroup-1', ARGV[2]);";
            Redis.silentMode().eval(script, 1, context.getTaskId(), data.stringify(), message);

            context.awaitNext("RECEIVED_VIDEO_STOP_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_VIDEO_STOP_RESPONSE", context -> {
            String taskId = context.getTaskId();
            String script = "local data = redis.call('GET', KEYS[1]);" +
                            "redis.call('DEL', KEYS[1]);" +
                            "return data;";
            Redis.interactiveMode().eval(script, 1, taskId);

            context.awaitNext("GOT_DATA");
        });

        taskFlow.addNode("GOT_DATA", context -> {
            Object input = context.getInput();
            if (! (input instanceof String)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "get and delete redis data failed"));
                return;
            }
            JsonObject data = JsonObject.from(input);
            if (data == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Boolean result = data.getBoolean("Result");
            if (result == null || !result) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error"));
                return;
            }

            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

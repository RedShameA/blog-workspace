package io.iwd.i1.util;

import io.iwd.common.ext.util.StringUtil;
import io.iwd.i1.I1Const;

public final class I1Validator {

    public static boolean isI1DeviceNumber(String deviceNumber) {
        if (StringUtil.isEmpty(deviceNumber)) {
            return false;
        }
        int length = deviceNumber.length();
        if (length < 1 || length > 17) {
            return false;
        }

        boolean containsNumber = false;
        for (int i = 0; i < length; i++) {
            char c = deviceNumber.charAt(i);
            if (c >= '0' && c <= '9') {
                containsNumber = true;
            } else if (c < 'A' || c > 'z') {
                return false;
            }
        }
        return containsNumber;
    }

    public static boolean isI1ChannelNumber(Integer channelNumber) {
        if (channelNumber == null) {
            return false;
        }
        return channelNumber >= I1Const.MIN_CHANNEL_NUMBER && channelNumber <= I1Const.MAX_CHANNEL_NUMBER;
    }

}

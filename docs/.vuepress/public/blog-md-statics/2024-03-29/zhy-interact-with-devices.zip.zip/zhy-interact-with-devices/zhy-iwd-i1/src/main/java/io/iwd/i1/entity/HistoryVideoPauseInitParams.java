package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

public class HistoryVideoPauseInitParams implements TaskInitParams {

    private String deviceNumber;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    @Override
    public HistoryVideoPauseInitParams populateDefault() {
        return this;
    }

    @Override
    public HistoryVideoPauseInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        return this;
    }
    
}

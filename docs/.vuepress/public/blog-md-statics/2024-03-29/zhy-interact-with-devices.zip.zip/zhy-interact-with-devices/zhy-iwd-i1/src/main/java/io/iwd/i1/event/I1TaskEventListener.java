package io.iwd.i1.event;

import io.iwd.common.event.AbstractTaskEventListener;
import io.iwd.common.event.Event;
import io.iwd.common.event.TaskProceedEvent;
import io.iwd.common.event.TaskStartEvent;
import io.iwd.common.event.srs.SrsCloseRtcEvent;
import io.iwd.common.event.srs.SrsCloseRtmpSourceEvent;
import io.iwd.i1.I1;
import io.iwd.i1.I1Const;

import java.util.LinkedList;
import java.util.List;

public class I1TaskEventListener extends AbstractTaskEventListener {

    @Override
    public void handleEvent(Event event) {
        if (event instanceof TaskProceedEvent) {
            handleTaskProceedEvent((TaskProceedEvent) event);
        } else if (event instanceof TaskStartEvent) {
            handleTaskStartEvent((TaskStartEvent) event);
        }
    }

    @Override
    public String defaultTaskPrefix() {
        return I1Const.TASK_PREFIX;
    }

    @Override
    public List<Class<? extends Event>> interests() {
        List<Class<? extends Event>> interestsList = new LinkedList<>();
        interestsList.add(I1DefaultTaskStartEvent.class);
        interestsList.add(I1DefaultTaskProceedEvent.class);
        interestsList.add(SrsCloseRtmpSourceEvent.class);
        return interestsList;
    }
}

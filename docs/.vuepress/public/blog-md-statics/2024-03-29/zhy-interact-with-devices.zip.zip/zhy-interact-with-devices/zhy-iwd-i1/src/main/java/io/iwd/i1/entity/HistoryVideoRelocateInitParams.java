package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

import java.util.Date;

public class HistoryVideoRelocateInitParams implements TaskInitParams {

    private String deviceNumber;

    private Date timePoint;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Date getTimePoint() {
        return timePoint;
    }

    public void setTimePoint(Date timePoint) {
        this.timePoint = timePoint;
    }

    @Override
    public HistoryVideoRelocateInitParams populateDefault() {
        return this;
    }

    @Override
    public HistoryVideoRelocateInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (this.timePoint == null) {
            throw new IllegalArgumentException("i1 time point error");
        }
        return this;
    }

}

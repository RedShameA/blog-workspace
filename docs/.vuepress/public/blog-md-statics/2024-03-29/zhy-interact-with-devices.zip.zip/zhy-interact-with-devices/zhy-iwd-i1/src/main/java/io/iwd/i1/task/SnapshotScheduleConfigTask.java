package io.iwd.i1.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.Validator;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.i1.entity.SnapshotScheduleConfigInitParams;
import io.iwd.i1.event.I1DefaultTaskProceedEvent;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static io.iwd.i1.I1Const.*;

public class SnapshotScheduleConfigTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "SnapshotScheduleConfig", I1DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            SnapshotScheduleConfigInitParams input = (SnapshotScheduleConfigInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            Integer channelNumber = input.getChannelNumber();
            Integer interval = input.getInterval();
            Date startTime = input.getStartTime();
            Date endTime = input.getEndTime();
            SnapshotPixelOption snapshotPixelOption = input.getSnapshotPixelOption();
            String parentDeviceNumber = input.getParentDeviceNumber();

            context.putData("deviceNumber", deviceNumber);
            context.putData("channelNumber", channelNumber);
            context.putData("interval", interval);
            context.putData("startTime", startTime);
            context.putData("endTime", endTime);
            context.putData("snapshotPixelOption", snapshotPixelOption);
            context.putData("parentDeviceNumber", parentDeviceNumber);

            context.fireNext("ISSUE_QUERY_COMMAND");
        });

        taskFlow.addNode("ISSUE_QUERY_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            Integer channelNumber = (Integer) context.getData("channelNumber");
            String parentDeviceNumber = (String) context.getData("parentDeviceNumber");

            JsonObject data = JsonObject.create()
                    .put("DeviceID", deviceNumber)
                    .put("ChannelNo", channelNumber)
                    .put("ParentDevID", parentDeviceNumber);

            String message = "WEB-1@1000@" + deviceNumber + "@FCMGroup-1@" + (System.currentTimeMillis() / 1000) + "@" + context.getTaskId();

            String script = "redis.call('SET', KEYS[1], ARGV[1]);" +
                            "redis.call('PUBLISH', 'FCMGroup-1', ARGV[2]);";
            Redis.silentMode().eval(script, 1,
                    context.getTaskId(), data.stringify(), message);

            context.awaitNext("RECEIVED_QUERY_RESPONSE", 10000);
        });

        taskFlow.addNode("RECEIVED_QUERY_RESPONSE", context -> {
            String taskId = context.getTaskId();
            String script = "local data = redis.call('GET', KEYS[1]);" +
                            "redis.call('DEL', KEYS[1]);" +
                            "return data;";
            Redis.interactiveMode().eval(script, 1, taskId);

            context.awaitNext("GOT_QUERY_DATA");
        });

        taskFlow.addNode("GOT_QUERY_DATA", context -> {
            Object input = context.getInput();
            if (! (input instanceof String)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "get and delete redis data failed"));
                return;
            }
            JsonObject data = JsonObject.from(input);
            if (data == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Boolean result = data.getBoolean("Result");
            if (result == null || !result) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error"));
                return;
            }

            String stationIp = data.getString("UpperHostIP");
            if (!Validator.isIpv4(stationIp)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_ILLEGAL_DATA | 0x0001,
                        "fcm service response data error"));
                return;
            }
            String stationPort = data.getString("UpperHostPort");
            if (!Validator.isPositiveIntegerNumber(stationPort)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_ILLEGAL_DATA | 0x0002,
                        "fcm service response data error"));
                return;
            }
            int port = Integer.parseInt(stationPort);
            if (port > 65535) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_ILLEGAL_DATA | 0x0003,
                        "fcm service response data error"));
                return;
            }

            context.putData("stationIp", stationIp);
            context.putData("stationPort", stationPort);

            context.fireNext("ISSUE_CONFIG_COMMAND");
        });

        taskFlow.addNode("ISSUE_CONFIG_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            Integer channelNumber = (Integer) context.getData("channelNumber");
            Integer interval = (Integer) context.getData("interval");
            Date startTime = (Date) context.getData("startTime");
            Date endTime = (Date) context.getData("endTime");
            SnapshotPixelOption snapshotPixelOption = (SnapshotPixelOption) context.getData("snapshotPixelOption");
            String stationIp = (String) context.getData("stationIp");
            Integer stationPort = Integer.valueOf((String) context.getData("stationPort"));
            String parentDeviceNumber = (String) context.getData("parentDeviceNumber");

            DateFormat dateFormat = new SimpleDateFormat("HH:mm");

            JsonObject data = JsonObject.create()
                    .put("DeviceID", deviceNumber)
                    .put("ChannelNo", channelNumber)
                    .put("CycleTime", String.valueOf(interval))
                    .put("StartTime", dateFormat.format(startTime))
                    .put("EndTime", dateFormat.format(endTime))
                    .put("Clarity", String.valueOf(snapshotPixelOption.value()))
                    .put("UpperHostIP", stationIp)
                    .put("UpperHostPort", stationPort)
                    .put("parentDevID", parentDeviceNumber);

            String message = "WEB-1@1002@" + deviceNumber + "@FCMGroup-1@" + (System.currentTimeMillis() / 1000) + "@" + context.getTaskId();

            String script = "redis.call('SET', KEYS[1], ARGV[1]);" +
                            "redis.call('PUBLISH', 'FCMGroup-1', ARGV[2]);";
            Redis.silentMode().eval(script, 1,
                    context.getTaskId(), data.stringify(), message);

            context.awaitNext("RECEIVED_RESPONSE", 10000);
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            String taskId = context.getTaskId();
            String script = "local data = redis.call('GET', KEYS[1]);" +
                            "redis.call('DEL', KEYS[1]);" +
                            "return data;";
            Redis.interactiveMode().eval(script, 1, taskId);

            context.awaitNext("GOT_DATA");
        });

        taskFlow.addNode("GOT_DATA", context -> {
            Object input = context.getInput();
            if (! (input instanceof String)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "get and delete redis data failed"));
                return;
            }
            JsonObject data = JsonObject.from(input);
            if (data == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Boolean result = data.getBoolean("Result");
            if (result == null || !result) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error"));
                return;
            }

            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("data", (Object) null));
        });

        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }

}

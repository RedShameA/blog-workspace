package io.iwd.i1.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SnapshotInfo {

    private final String deviceNumber;

    private final Integer channelNumber;

    private final String name;

    private final Date time;

    private final Integer size;

    public SnapshotInfo(String deviceNumber, Integer channelNumber, String name, Date time, Integer size) {
        this.deviceNumber = deviceNumber;
        this.channelNumber = channelNumber;
        this.name = name;
        this.time = time;
        this.size = size;
    }

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public Integer getChannelNumber() {
        return channelNumber;
    }

    public String getName() {
        return name;
    }

    public Date getTime() {
        return time;
    }

    public Integer getSize() {
        return size;
    }

    @Override
    public String toString() {
        String t = this.time == null ? "" : new SimpleDateFormat("HH:mm:ss").format(this.time);
        return "{\"deviceNumber\":\"" + this.deviceNumber + "\",\"channelNumber\":" + this.channelNumber + ",\"name\":\"" +
                this.name + "\",\"time\":\"" + t + "\",\"size\":" + this.size + "}";
    }
}

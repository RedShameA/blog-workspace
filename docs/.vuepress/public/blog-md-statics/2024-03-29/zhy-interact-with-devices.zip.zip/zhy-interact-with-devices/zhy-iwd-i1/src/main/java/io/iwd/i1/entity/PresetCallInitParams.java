package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

import static io.iwd.i1.I1Const.*;

public class PresetCallInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private Integer presetId;

    private String parentDeviceNumber;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Integer getPresetId() {
        return presetId;
    }

    public void setPresetId(Integer presetId) {
        this.presetId = presetId;
    }

    public String getParentDeviceNumber() {
        return parentDeviceNumber;
    }

    public void setParentDeviceNumber(String parentDeviceNumber) {
        this.parentDeviceNumber = parentDeviceNumber;
    }

    @Override
    public PresetCallInitParams populateDefault() {
        if (this.parentDeviceNumber == null) {
            this.parentDeviceNumber = "";
        }
        return this;
    }

    @Override
    public PresetCallInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (!I1Validator.isI1ChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("i1 channel number format error");
        }
        if (this.presetId < MIN_PRESET_ID_NUMBER || this.presetId > MAX_PRESET_ID_NUMBER) {
            throw new IllegalArgumentException("i1 preset id error");
        }
        if (this.parentDeviceNumber == null || (!"".equals(this.parentDeviceNumber) && !I1Validator.isI1DeviceNumber(this.parentDeviceNumber))) {
            throw new IllegalArgumentException("i1 parent device number format error");
        }
        return this;
    }
}

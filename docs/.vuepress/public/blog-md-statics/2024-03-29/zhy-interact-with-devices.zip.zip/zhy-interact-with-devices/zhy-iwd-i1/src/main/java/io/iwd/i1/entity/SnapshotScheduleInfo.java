package io.iwd.i1.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static io.iwd.i1.I1Const.*;

public class SnapshotScheduleInfo {

    private final String deviceNumber;

    private final Integer channelNumber;

    private final Integer interval;

    private final Date startTime;

    private final Date endTime;

    private final SnapshotPixelOption snapshotPixelOption;

    public SnapshotScheduleInfo(String deviceNumber,
                                Integer channelNumber,
                                Integer interval,
                                Date startTime,
                                Date endTime,
                                SnapshotPixelOption snapshotPixelOption) {
        this.deviceNumber = deviceNumber;
        this.channelNumber = channelNumber;
        this.interval = interval;
        this.startTime = startTime;
        this.endTime = endTime;
        this.snapshotPixelOption = snapshotPixelOption;
    }

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public Integer getInterval() {
        return this.interval;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public SnapshotPixelOption getSnapshotPixelOption() {
        return this.snapshotPixelOption;
    }

    @Override
    public String toString() {
        DateFormat dateFormat = new SimpleDateFormat("HH:mm");
        return "{\"deviceNumber\":\"" + this.deviceNumber + "\",\"channelNumber\":" + this.channelNumber + ",\"interval\":\"" +
                this.interval + "\",\"startTime\":\"" + dateFormat.format(this.startTime) + "\",\"endTime\":\"" + dateFormat.format(this.endTime) +
                "\",\"snapshotPixelOption\":\"" + this.snapshotPixelOption.name() + "\"}";
    }

}

package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.i1.entity.CruiseSnapshotConfigInitParams;
import io.iwd.i1.entity.CruiseSnapshotPresetInfo;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

import java.util.Collection;

/**
 * 机芯巡航拍照设置命令。
 */
public class CruiseSnapshotConfig extends AdvancedCommand<Boolean> {
    
    private CruiseSnapshotConfigInitParams initParams = new CruiseSnapshotConfigInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return CruiseSnapshotConfig命令对象。
     */
    public CruiseSnapshotConfig setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置巡航拍照id。
     * @param cruiseId 巡航拍照id。
     * @return CruiseSnapshotConfig命令对象。
     */
    public CruiseSnapshotConfig setCruiseId(Integer cruiseId) {
        this.initParams.setCruiseId(cruiseId);
        return this;
    }

    /**
     * 设置巡航拍照速率。
     * @param rate 巡航拍照速率，单位天，取值范围：1~30。
     * @return CruiseSnapshotConfig命令对象。
     */
    public CruiseSnapshotConfig setRate(Integer rate) {
        this.initParams.setRate(rate);
        return this;
    }

    /**
     * 设置巡航拍照预置位。
     * @param cruiseSnapshotPresetList 巡航拍照预置位列表。
     * @return CruiseSnapshotConfig命令对象。
     */
    public CruiseSnapshotConfig addPreset(Collection<CruiseSnapshotPresetInfo> cruiseSnapshotPresetList) {
        this.initParams.addPreset(cruiseSnapshotPresetList);
        return this;
    }

    /**
     * 设置巡航拍照预置位。
     * @param presetId 预置位id。
     * @param hour 时，取值范围：0~23。
     * @param minute 分，取值范围：0~59。
     * @return CruiseSnapshotConfig命令对象。
     */
    public CruiseSnapshotConfig addPreset(Integer presetId, Integer hour, Integer minute) {
        this.initParams.addPreset(presetId, hour, minute);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "CruiseSnapshotConfig", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

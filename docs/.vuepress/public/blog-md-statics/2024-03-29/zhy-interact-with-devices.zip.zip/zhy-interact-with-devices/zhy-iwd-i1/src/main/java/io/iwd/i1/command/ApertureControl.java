package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.i1.entity.ApertureControlInitParams;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

import static io.iwd.i1.I1Const.*;

/**
 * 光圈控制命令。
 */
public class ApertureControl extends AdvancedCommand<Boolean> {

    private ApertureControlInitParams initParams = new ApertureControlInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return ApertureControl命令对象。
     */
    public ApertureControl setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return ApertureControl命令对象。
     */
    public ApertureControl setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置光圈控制选项。
     * @param apertureControlOption 光圈控制选项。
     * @return ApertureControl命令对象。
     * @see ApertureControlOption
     */
    public ApertureControl setApertureControlOption(ApertureControlOption apertureControlOption) {
        this.initParams.setApertureControlOption(apertureControlOption);
        return this;
    }

    /**
     * 设置光圈控制速度。
     * @param speed 控制速度。
     * @return ApertureControl命令对象。
     */
    public ApertureControl setSpeed(Integer speed) {
        this.initParams.setSpeed(speed);
        return this;
    }

    /**
     * 设置光圈控制速度选项。
     * @param controlSpeedOption 控制速度选项。
     * @return ApertureControl命令对象。
     * @see ControlSpeedOption
     */
    public ApertureControl setControlSpeedOption(ControlSpeedOption controlSpeedOption) {
        this.initParams.setControlSpeedOption(controlSpeedOption);
        return this;
    }

    /**
     * 设置父设备编号。
     * @param parentDeviceNumber 父设备编号。
     * @return ApertureControl命令对象。
     */
    public ApertureControl setParentDeviceNumber(String parentDeviceNumber) {
        this.initParams.setParentDeviceNumber(parentDeviceNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "ApertureControl", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

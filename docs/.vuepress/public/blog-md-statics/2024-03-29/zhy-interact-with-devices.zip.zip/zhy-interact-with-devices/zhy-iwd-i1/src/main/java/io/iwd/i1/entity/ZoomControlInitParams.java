package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

import static io.iwd.i1.I1Const.*;

public class ZoomControlInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private ZoomControlOption zoomControlOption;

    private Integer speed;

    private String parentDeviceNumber;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public ZoomControlOption getZoomControlOption() {
        return zoomControlOption;
    }

    public void setZoomControlOption(ZoomControlOption zoomControlOption) {
        this.zoomControlOption = zoomControlOption;
    }

    public Integer getSpeed() {
        return this.speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public void setControlSpeedOption(ControlSpeedOption controlSpeedOption) {
        this.speed = controlSpeedOption.speed();
    }

    public String getParentDeviceNumber() {
        return parentDeviceNumber;
    }

    public void setParentDeviceNumber(String parentDeviceNumber) {
        this.parentDeviceNumber = parentDeviceNumber;
    }

    @Override
    public ZoomControlInitParams populateDefault() {
        if (this.zoomControlOption == null) {
            this.zoomControlOption = ZoomControlOption.STOP;
        }
        if (this.speed == null) {
            this.speed = ControlSpeedOption.AUTO.speed();
        }
        if (this.parentDeviceNumber == null) {
            this.parentDeviceNumber = "";
        }
        return this;
    }

    @Override
    public ZoomControlInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (!I1Validator.isI1ChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("i1 channel number format error");
        }
        if (this.zoomControlOption == null) {
            throw new IllegalArgumentException("i1 zoom control option error");
        }
        if (this.speed == null || this.speed < MIN_CONTROL_SPEED || this.speed > MAX_CONTROL_SPEED) {
            throw new IllegalArgumentException("i1 speed error");
        }
        if (this.parentDeviceNumber == null || (!"".equals(this.parentDeviceNumber) && !I1Validator.isI1DeviceNumber(this.parentDeviceNumber))) {
            throw new IllegalArgumentException("i1 parent device number format error");
        }
        return this;
    }
}

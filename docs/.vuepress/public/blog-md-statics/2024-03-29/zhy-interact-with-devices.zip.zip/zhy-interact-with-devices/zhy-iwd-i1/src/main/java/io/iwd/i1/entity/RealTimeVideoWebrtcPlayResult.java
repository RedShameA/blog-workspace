package io.iwd.i1.entity;

/**
 * 实时视频webrtc播放的结果。
 */
public class RealTimeVideoWebrtcPlayResult {

    /**
     * 播放是否成功。
     */
    private final boolean success;

    /**
     * webrtc answer sdp。
     */
    private final String sdp;

    /**
     * 根据某种规则生成的流id。
     */
    private final String streamId;

    /**
     * 标准构造器。
     * @param success 播放是否成功。
     * @param sdp webrtc answer sdp。
     * @param streamId 流id。
     */
    public RealTimeVideoWebrtcPlayResult(boolean success, String sdp, String streamId) {
        this.success = success;
        this.sdp = sdp;
        this.streamId = streamId;
    }

    /**
     * 返回是否播放成功。
     * @return 是否播放成功。
     */
    public boolean isSuccess() {
        return this.success;
    }

    /**
     * 返回answer sdp。
     * @return answer sdp。
     */
    public String getSdp() {
        return this.sdp;
    }

    /**
     * 返回可能存在的流id。
     * @return 流id。
     */
    public String getStreamId() {
        return streamId;
    }

    @Override
    public String toString() {
        return "{\"success\":" + this.success + ",\"sdp\":" + this.sdp + ",\"streamId\":" + this.streamId + "}";
    }

}

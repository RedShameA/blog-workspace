package io.iwd.i1.entity;

public class HistoryVideoWebrtcPlayResult {

    /**
     * 播放是否成功。
     */
    private final boolean success;

    /**
     * webrtc answer sdp。
     */
    private final String sdp;

    /**
     * 返回是否播放成功。
     * @return 是否播放成功。
     */
    public boolean isSuccess() {
        return this.success;
    }

    /**
     * 返回answer sdp。
     * @return answer sdp。
     */
    public String getSdp() {
        return this.sdp;
    }

    /**
     * 标准构造器。
     * @param success 播放是否成功。
     * @param sdp webrtc answer sdp。
     */
    public HistoryVideoWebrtcPlayResult(boolean success, String sdp) {
        this.success = success;
        this.sdp = sdp;
    }

    @Override
    public String toString() {
        return "{\"success\":" + this.success + ",\"sdp\":" + this.sdp + "}";
    }

}

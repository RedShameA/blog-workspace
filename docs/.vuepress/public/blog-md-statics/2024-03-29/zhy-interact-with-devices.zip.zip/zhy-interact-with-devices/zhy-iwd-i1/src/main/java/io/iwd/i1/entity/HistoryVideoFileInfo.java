package io.iwd.i1.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HistoryVideoFileInfo implements Comparable<HistoryVideoFileInfo> {

    private final String path;

    private final Integer duration;

    private final Date startTime;

    private final Date endTime;

    public HistoryVideoFileInfo(String path, Date startTime, Integer duration) {
        this.path = path;
        this.duration = duration;
        this.startTime = startTime;
        this.endTime = new Date(startTime.getTime() + (duration * 1000));
    }

    public String getPath() {
        return path;
    }

    public Integer getDuration() {
        return duration;
    }

    public Date getStartTime() {
        return startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return "{\"path\":\"" + this.path +
                "\",\"startTime\":\"" + dateFormat.format(this.startTime) +
                "\",\"endTime\":\"" + dateFormat.format(this.endTime) +
                "\",\"duration\":" + this.duration + "}";
    }

    @Override
    public int compareTo(HistoryVideoFileInfo o) {
        return this.startTime.compareTo(o.startTime);
    }
}

package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

import java.util.Date;

import static io.iwd.i1.I1Const.*;

public class HistoryVideoFileQueryInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private Date startTime;

    private Date endTime;

    private Integer rows;

    private Integer page;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getRows() {
        return this.rows;
    }

    public void setRows(Integer rows) {
        this.rows = rows;
    }

    public Integer getPage() {
        return this.page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    @Override
    public HistoryVideoFileQueryInitParams populateDefault() {
        if (this.rows == null) {
            this.rows = 20;
        }
        if (this.page == null) {
            this.page = 1;
        }
        return this;
    }

    @Override
    public HistoryVideoFileQueryInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (!I1Validator.isI1ChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("i1 channel number format error");
        }
        if (this.startTime == null) {
            throw new IllegalArgumentException("i1 start time format error");
        }
        if (this.endTime == null) {
            throw new IllegalArgumentException("i1 end time format error");
        }
        if (this.startTime.compareTo(this.endTime) >= 0) {
            throw new IllegalArgumentException("i1 start time is earlier than end time");
        }
        if (this.rows == null || this.rows < 1 || this.rows > 255) {
            throw new IllegalArgumentException("i1 file rows error");
        }
        if (this.page == null || this.page < 1 || this.page > 255) {
            throw new IllegalArgumentException("i1 file page error");
        }
        return this;
    }

}

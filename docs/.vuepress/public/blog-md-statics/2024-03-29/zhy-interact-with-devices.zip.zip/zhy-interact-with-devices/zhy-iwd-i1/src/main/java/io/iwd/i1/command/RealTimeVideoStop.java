package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.i1.entity.RealTimeVideoStopInitParams;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

public class RealTimeVideoStop extends AdvancedCommand<Boolean> {

    private RealTimeVideoStopInitParams initParams = new RealTimeVideoStopInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return RealTimeVideoStop命令对象。
     */
    public RealTimeVideoStop setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return RealTimeVideoStop命令对象。
     */
    public RealTimeVideoStop setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置流媒体服务器接收设备推流的ip。
     * @param mediaServerIp 流媒体服务器接收设备推流的ip。
     * @return RealTimeVideoStop命令对象。
     */
    public RealTimeVideoStop setMediaServerIp(String mediaServerIp) {
        this.initParams.setMediaServerIp(mediaServerIp);
        return this;
    }

    /**
     * 设置流媒体服务器接收设备推流的端口。
     * @param mediaServerPort 流媒体服务器接收设备推流的端口。
     * @return RealTimeVideoStop命令对象。
     */
    public RealTimeVideoStop setMediaServerPort(Integer mediaServerPort) {
        this.initParams.setMediaServerPort(mediaServerPort);
        return this;
    }

    /**
     * 设置父设备编号。
     * @param parentDeviceNumber 父设备编号。
     * @return RealTimeVideoStop命令对象。
     */
    public RealTimeVideoStop setParentDeviceNumber(String parentDeviceNumber) {
        this.initParams.setParentDeviceNumber(parentDeviceNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "RealTimeVideoStop", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

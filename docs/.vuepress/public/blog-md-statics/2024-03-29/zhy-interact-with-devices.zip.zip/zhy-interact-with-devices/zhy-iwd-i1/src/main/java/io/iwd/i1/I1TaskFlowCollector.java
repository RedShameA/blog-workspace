package io.iwd.i1;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowCollector;
import io.iwd.i1.task.*;

import java.util.LinkedList;
import java.util.List;

public class I1TaskFlowCollector implements TaskFlowCollector {

    @Override
    public List<TaskFlow> getTaskFlowList() {

        List<TaskFlow> taskFlowList = new LinkedList<>();

        //镜头控制
        taskFlowList.add(new LensControlTask().getTaskFlow());
        //变倍控制
        taskFlowList.add(new ZoomControlTask().getTaskFlow());
        //焦距控制
        taskFlowList.add(new FocusControlTask().getTaskFlow());
        //自动调焦（一键聚焦）
        taskFlowList.add(new FocusAutoControlTask().getTaskFlow());
        //光圈控制
        taskFlowList.add(new ApertureControlTask().getTaskFlow());

        //预置位调用
        taskFlowList.add(new PresetCallTask().getTaskFlow());
        //预置位重新定位
        taskFlowList.add(new PresetRelocateTask().getTaskFlow());
        //预置位删除
        taskFlowList.add(new PresetRemoveTask().getTaskFlow());
        //预置位全部删除
        taskFlowList.add(new PresetRemoveAllTask().getTaskFlow());

        //实时视频播放
        taskFlowList.add(new RealTimeVideoWebrtcPlayTask().getTaskFlow());
        //实时视频停止
        taskFlowList.add(new RealTimeVideoStopTask().getTaskFlow());
        //srs关闭实时视频
        taskFlowList.add(new SrsCloseRtmpSourceTask().getTaskFlow());

        //录像文件查询
        taskFlowList.add(new HistoryVideoFileQueryTask().getTaskFlow());
        //录像文件webrtc播放
        taskFlowList.add(new HistoryVideoWebrtcPlayTask().getTaskFlow());
        //录像回放停止
        taskFlowList.add(new HistoryVideoStopTask().getTaskFlow());
        //录像回放继续
        taskFlowList.add(new HistoryVideoContinueTask().getTaskFlow());
        //录像回放暂停
        taskFlowList.add(new HistoryVideoPauseTask().getTaskFlow());
        //录像回放速度控制
        taskFlowList.add(new HistoryVideoSpeedControlTask().getTaskFlow());
        //录像回放重新定位
        taskFlowList.add(new HistoryVideoRelocateTask().getTaskFlow());
        
        //图片抓拍
        taskFlowList.add(new SnapshotTask().getTaskFlow());
        //拍照时间表查询
        taskFlowList.add(new SnapshotScheduleQueryTask().getTaskFlow());
        //拍照时间表设置
        taskFlowList.add(new SnapshotScheduleConfigTask().getTaskFlow());

        //巡航拍照设置
        taskFlowList.add(new CruiseSnapshotConfigTask().getTaskFlow());
        //巡航拍照删除
        taskFlowList.add(new CruiseSnapshotRemoveTask().getTaskFlow());

        //雨刷点动
        taskFlowList.add(new WiperJogTask().getTaskFlow());

        return taskFlowList;
    }
}

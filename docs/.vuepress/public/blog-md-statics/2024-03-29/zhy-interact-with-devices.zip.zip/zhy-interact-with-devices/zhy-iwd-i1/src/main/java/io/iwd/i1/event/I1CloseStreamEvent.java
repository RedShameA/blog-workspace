package io.iwd.i1.event;

import io.iwd.common.event.Event;

public class I1CloseStreamEvent implements Event {

    private final String deviceNumber;

    private final Integer channelNumber;

    public I1CloseStreamEvent(String deviceNumber, Integer channelNumber) {
        this.deviceNumber = deviceNumber;
        this.channelNumber = channelNumber;
    }

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public Integer getChannelNumber() {
        return channelNumber;
    }
}

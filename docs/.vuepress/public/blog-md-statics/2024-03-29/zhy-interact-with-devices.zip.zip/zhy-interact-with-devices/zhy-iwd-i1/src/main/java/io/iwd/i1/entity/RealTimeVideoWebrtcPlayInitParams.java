package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.i1.util.I1Validator;

import static io.iwd.i1.I1Const.*;

public class RealTimeVideoWebrtcPlayInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String mediaServerIp;

    private Integer mediaServerPort;

    private Integer maxDuration;

    private VideoStreamProtocol videoStreamProtocol;

    private String parentDeviceNumber;

    private String offerSdp;

    private Boolean useExistingStream;

    private Boolean srsApiSsl;

    private String srsApiIp;

    private Integer srsApiPort;

    private String webAddress;

    private Boolean allowAutoClose;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getMediaServerIp() {
        return this.mediaServerIp;
    }

    public void setMediaServerIp(String mediaServerIp) {
        this.mediaServerIp = mediaServerIp;
    }

    public Integer getMediaServerPort() {
        return this.mediaServerPort;
    }

    public void setMediaServerPort(Integer mediaServerPort) {
        this.mediaServerPort = mediaServerPort;
    }

    public Integer getMaxDuration() {
        return this.maxDuration;
    }

    public void setMaxDuration(Integer maxDuration) {
        this.maxDuration = maxDuration;
    }

    public VideoStreamProtocol getVideoStreamProtocol() {
        return videoStreamProtocol;
    }

    public void setVideoStreamProtocol(VideoStreamProtocol videoStreamProtocol) {
        this.videoStreamProtocol = videoStreamProtocol;
    }

    public String getParentDeviceNumber() {
        return this.parentDeviceNumber;
    }

    public void setParentDeviceNumber(String parentDeviceNumber) {
        this.parentDeviceNumber = parentDeviceNumber;
    }

    public String getOfferSdp() {
        return offerSdp;
    }

    public void setOfferSdp(String offerSdp) {
        this.offerSdp = offerSdp;
    }

    public Boolean getUseExistingStream() {
        return useExistingStream;
    }

    public void setUseExistingStream(Boolean useExistingStream) {
        this.useExistingStream = useExistingStream;
    }

    public Boolean getSrsApiSsl() {
        return srsApiSsl;
    }

    public void setSrsApiSsl(Boolean srsApiSsl) {
        this.srsApiSsl = srsApiSsl;
    }

    public String getSrsApiIp() {
        return srsApiIp;
    }

    public void setSrsApiIp(String srsApiIp) {
        this.srsApiIp = srsApiIp;
    }

    public Integer getSrsApiPort() {
        return srsApiPort;
    }

    public void setSrsApiPort(Integer srsApiPort) {
        this.srsApiPort = srsApiPort;
    }

    public String getWebAddress() {
        return webAddress;
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }

    public Boolean getAllowAutoClose() {
        return allowAutoClose;
    }

    public void setAllowAutoClose(Boolean allowAutoClose) {
        this.allowAutoClose = allowAutoClose;
    }

    @Override
    public RealTimeVideoWebrtcPlayInitParams populateDefault() {
        EnvironmentHolder.get().config().getInBatch(conf -> {
            if (this.mediaServerIp == null) {
                this.mediaServerIp = (String) conf.getExtConfigInBatch("i1", "srs", "push_stream_ip");
            }
            if (this.mediaServerPort == null) {
                this.mediaServerPort = NumberUtil.toInt(conf.getExtConfigInBatch("i1", "srs", "push_stream_port"));
            }
            if (this.maxDuration == null) {
                Object config = conf.getExtConfigInBatch("i1", "default_max_push_stream_duration");
                if (config != null) {
                    this.maxDuration = NumberUtil.toInt(config);
                } else {
                    this.maxDuration = 0;
                }
            }
            if (this.srsApiSsl == null) {
                this.srsApiSsl = (Boolean) conf.getGlobalConfigInBatch("srs", "api_ssl");
            }
            if (this.srsApiIp == null) {
                this.srsApiIp = (String) conf.getGlobalConfigInBatch("srs", "api_ip");
            }
            if (this.srsApiPort == null) {
                this.srsApiPort = NumberUtil.toInt(conf.getGlobalConfigInBatch("srs", "api_port"));
            }
            if (this.webAddress == null) {
                this.webAddress = (String) conf.getGlobalConfigInBatch("srs", "web_address");
            }
            if (this.allowAutoClose == null) {
                this.allowAutoClose = (Boolean) conf.getExtConfigInBatch("i1", "auto_close_video_stream");
                if (this.allowAutoClose == null) {
                    this.allowAutoClose = true;
                }
            }
        });
        if (this.parentDeviceNumber == null) {
            this.parentDeviceNumber = "";
        }
        if (this.videoStreamProtocol == null) {
            this.videoStreamProtocol = VideoStreamProtocol.RTMP;
        }
        if (this.useExistingStream == null) {
            this.useExistingStream = Boolean.TRUE;
        }
        return this;
    }

    @Override
    public RealTimeVideoWebrtcPlayInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (!I1Validator.isI1ChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("i1 channel number format error");
        }
        if (!Validator.isIpv4(this.mediaServerIp)) {
            throw new IllegalArgumentException("i1 media server ip format error");
        }
        if (this.mediaServerPort == null || this.mediaServerPort < 1 || mediaServerPort > 65535) {
            throw new IllegalArgumentException("i1 media server port format error");
        }
        if (this.maxDuration == null || this.maxDuration < MIN_VIDEO_DURATION || this.maxDuration > MAX_VIDEO_DURATION) {
            throw new IllegalArgumentException("i1 max push stream duration error");
        }
        if (this.videoStreamProtocol == null) {
            throw new IllegalArgumentException("i1 video stream protocol error");
        }
        if (this.parentDeviceNumber == null || (!"".equals(this.parentDeviceNumber) && !I1Validator.isI1DeviceNumber(this.parentDeviceNumber))) {
            throw new IllegalArgumentException("i1 parent device number format error");
        }
        if (StringUtil.isEmpty(offerSdp)) {
            throw new IllegalArgumentException("i1 webrtc offer sdp format error");
        }
        if (this.useExistingStream == null) {
            throw new IllegalArgumentException("i1 use existing stream error");
        }
        if (this.srsApiSsl == null) {
            throw new IllegalArgumentException("i1 srs api ssl error");
        }
        if (!Validator.isIpv4(this.srsApiIp)) {
            throw new IllegalArgumentException("i1 srs api ip format error");
        }
        if (this.srsApiPort == null || this.srsApiPort < 1 || srsApiPort > 65535) {
            throw new IllegalArgumentException("i1 srs api port format error");
        }
        if (!Validator.isIpv4AndPort(this.webAddress)) {
            throw new IllegalArgumentException("i1 web address format error");
        }
        return this;
    }
}

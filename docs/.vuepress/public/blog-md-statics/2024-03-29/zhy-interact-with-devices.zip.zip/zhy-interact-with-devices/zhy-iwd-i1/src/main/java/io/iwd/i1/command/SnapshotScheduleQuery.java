package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.i1.I1Const;
import io.iwd.i1.entity.SnapshotScheduleInfo;
import io.iwd.i1.entity.SnapshotScheduleQueryInitParams;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 定时抓拍查询命令。
 */
public class SnapshotScheduleQuery extends AdvancedCommand<SnapshotScheduleInfo> {

    private SnapshotScheduleQueryInitParams initParams = new SnapshotScheduleQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return SnapshotScheduleQuery命令对象。
     */
    public SnapshotScheduleQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return SnapshotScheduleQuery命令对象。
     */
    public SnapshotScheduleQuery setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "SnapshotScheduleQuery", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public SnapshotScheduleInfo await(long time) {
        return super.await(result -> {
            if (!result.isCompleted() || !result.hasResult()) {
                return null;
            }
            JsonObject rlt = (JsonObject) result.getResult();
            JsonObject info = rlt.getJsonObject("data");
            String deviceNumber = info.getString("deviceNumber");
            Integer channelNumber = info.getInteger("channelNumber");
            Integer interval = info.getInteger("interval");
            String startTime = info.getString("startTime");
            String endTime = info.getString("endTime");
            Date st = null;
            Date et = null;
            DateFormat df = new SimpleDateFormat("HH:mm");
            try {
                st = df.parse(startTime);
                et = df.parse(endTime);
            } catch (Exception ignored) {}
            String snapshotPixelOption = info.getString("snapshotPixelOption");
            return new SnapshotScheduleInfo(deviceNumber, channelNumber, interval, st, et,
                    I1Const.SnapshotPixelOption.valueOf(snapshotPixelOption));
        }, time);
    }

}

package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.i1.entity.SnapshotScheduleConfigInitParams;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

import java.util.Date;

import static io.iwd.i1.I1Const.*;

/**
 * 定时抓拍设置命令。
 */
public class SnapshotScheduleConfig extends AdvancedCommand<Boolean> {

    private SnapshotScheduleConfigInitParams initParams = new SnapshotScheduleConfigInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return SnapshotScheduleConfig命令对象。
     */
    public SnapshotScheduleConfig setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return SnapshotScheduleConfig命令对象。
     */
    public SnapshotScheduleConfig setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置拍照间隔，单位分钟。
     * @param interval 拍照间隔，单位分钟。
     * @return SnapshotScheduleConfig命令对象。
     */
    public SnapshotScheduleConfig setInterval(Integer interval) {
        this.initParams.setInterval(interval);
        return this;
    }

    /**
     * 设置开始时间。
     * @param startTime 开始时间，只取时、分。
     * @return SnapshotScheduleConfig命令对象。
     */
    public SnapshotScheduleConfig setStartTime(Date startTime) {
        this.initParams.setStartTime(startTime);
        return this;
    }

    /**
     * 设置结束时间。
     * @param endTime 结束时间，只取时、分。
     * @return SnapshotScheduleConfig命令对象。
     */
    public SnapshotScheduleConfig setEndTime(Date endTime) {
        this.initParams.setEndTime(endTime);
        return this;
    }

    /**
     * 设置拍照分辨率。
     * @param snapshotPixelOption 拍照分辨率。
     * @return SnapshotScheduleConfig命令对象。
     */
    public SnapshotScheduleConfig setSnapshotResolutionRatio(SnapshotPixelOption snapshotPixelOption) {
        this.initParams.setSnapshotPixelOption(snapshotPixelOption);
        return this;
    }

    /**
     * 设置父设备编号。
     * @param parentDeviceNumber 父设备编号。
     * @return SnapshotScheduleConfig命令对象。
     */
    public SnapshotScheduleConfig setParentDeviceNumber(String parentDeviceNumber) {
        this.initParams.setParentDeviceNumber(parentDeviceNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "SnapshotScheduleConfig", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

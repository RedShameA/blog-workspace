package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import static io.iwd.i1.I1Const.*;

public class CruiseSnapshotConfigInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer cruiseId;

    private Integer rate;

    private final List<CruiseSnapshotPresetInfo> cruiseSnapshotPresetList = new LinkedList<>();

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getCruiseId() {
        return this.cruiseId;
    }

    public void setCruiseId(Integer cruiseId) {
        this.cruiseId = cruiseId;
    }

    public Integer getRate() {
        return this.rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public void addPreset(Integer presetId, Integer hour, Integer minute) {
        CruiseSnapshotPresetInfo cruiseSnapshotPresetInfo = new CruiseSnapshotPresetInfo(presetId, hour, minute);
        this.cruiseSnapshotPresetList.add(cruiseSnapshotPresetInfo);
    }

    public void addPreset(Collection<CruiseSnapshotPresetInfo> cruiseSnapshotPresetList) {
        this.cruiseSnapshotPresetList.addAll(cruiseSnapshotPresetList);
    }

    public List<CruiseSnapshotPresetInfo> getCruiseSnapshotPresetList() {
        return cruiseSnapshotPresetList;
    }

    @Override
    public CruiseSnapshotConfigInitParams populateDefault() {
        return this;
    }

    @Override
    public CruiseSnapshotConfigInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (this.cruiseId == null || this.cruiseId < MIN_CRUISE_ID_NUMBER || this.cruiseId > MAX_CRUISE_ID_NUMBER) {
            throw new IllegalArgumentException("i1 cruise id error");
        }
        if (this.rate == null || this.rate < 1 || this.rate > 30) {
            throw new IllegalArgumentException("i1 cruise rate error");
        }
        for (CruiseSnapshotPresetInfo presetInfo : this.cruiseSnapshotPresetList) {
            Integer presetId = presetInfo.getPresetId();
            Integer hour = presetInfo.getHour();
            Integer minute = presetInfo.getMinute();
            if (presetId == null || presetId < MIN_PRESET_ID_NUMBER || presetId > MAX_PRESET_ID_NUMBER) {
                throw new IllegalArgumentException("i1 cruise preset id error");
            }
            if (hour == null || hour < 0 || hour > 23) {
                throw new IllegalArgumentException("i1 cruise hour error");
            }
            if (minute == null || minute < 0 || minute > 59) {
                throw new IllegalArgumentException("i1 cruise minute error");
            }
        }
        return this;
    }
}

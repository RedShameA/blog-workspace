package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.i1.entity.HistoryVideoSpeedControlInitParams;

import io.iwd.i1.I1Const.*;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

public class HistoryVideoSpeedControl extends AdvancedCommand<Boolean> {
    
    private HistoryVideoSpeedControlInitParams initParams = new HistoryVideoSpeedControlInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置录像回放速度选项。
     * @param historyVideoSpeedOption 录像回放速度选项。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.initParams.setHistoryVideoSpeedOption(historyVideoSpeedOption);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoSpeedControl", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

package io.iwd.i1.event;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;
import io.iwd.i1.I1Const;

public class I1DefaultTaskStartEvent extends TaskStartEvent {

    public I1DefaultTaskStartEvent(String taskName, Object data) {
        super(taskName, data);
    }

    public I1DefaultTaskStartEvent(String taskName, Object data, TaskResult taskResult) {
        super(taskName, data, taskResult);
    }

    public I1DefaultTaskStartEvent(String taskId, String taskName, Object data, TaskResult taskResult) {
        super(taskId, taskName, data, taskResult);
    }

    public I1DefaultTaskStartEvent(String taskId, String taskName, String entranceName, Object data, TaskResult taskResult) {
        super(taskId, taskName, entranceName, data, taskResult);
    }

    @Override
    public String getTaskPrefix() {
        return I1Const.TASK_PREFIX;
    }
}

package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.i1.entity.HistoryVideoFileInfo;
import io.iwd.i1.entity.HistoryVideoFileQueryInitParams;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class HistoryVideoFileQuery extends AdvancedCommand<List<HistoryVideoFileInfo>> {

    private HistoryVideoFileQueryInitParams initParams = new HistoryVideoFileQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置查询开始时间。
     * @param startTime 查询开始时间。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setStartTime(Date startTime) {
        this.initParams.setStartTime(startTime);
        return this;
    }

    /**
     * 设置查询结束时间。
     * @param endTime 查询结束时间。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setEndTime(Date endTime) {
        this.initParams.setEndTime(endTime);
        return this;
    }

    /**
     * 设置查询的每页行数。
     * @param rows 查询的每页行数。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setRows(Integer rows) {
        this.initParams.setRows(rows);
        return this;
    }

    /**
     * 设置查询第几页。
     * @param page 查询第几页。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setPage(Integer page) {
        this.initParams.setPage(page);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoFileQuery", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public List<HistoryVideoFileInfo> await(long time) {
        return super.await(result -> {
            if (!result.isCompleted() || !result.hasResult()) {
                return Collections.emptyList();
            }
            JsonObject completedResult = (JsonObject) result.getResult();
            JsonArray data = completedResult.getJsonArray("data");
            List<HistoryVideoFileInfo> list = new ArrayList<>(data.size());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            for (int i = 0; i < data.size(); i++) {
                JsonObject file = data.getJsonObject(i);
                String filePath = file.getString("filePath");
                Integer duration = file.getInteger("duration");
                String startTimeStr = file.getString("startTime");
                Date startTime;
                try {
                    startTime = simpleDateFormat.parse(startTimeStr);
                } catch (Exception e) {
                    e.printStackTrace();
                    continue;
                }
                HistoryVideoFileInfo fileInfo = new HistoryVideoFileInfo(filePath, startTime, duration);
                list.add(fileInfo);
            }
            return list;
        }, time);
    }

}

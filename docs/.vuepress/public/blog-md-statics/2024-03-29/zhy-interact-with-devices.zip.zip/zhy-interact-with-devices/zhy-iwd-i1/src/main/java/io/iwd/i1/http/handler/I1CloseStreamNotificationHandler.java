package io.iwd.i1.http.handler;

import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.common.stdio.http.AbstractHttpRequestHandler;
import io.iwd.common.stdio.http.HttpHelper;
import io.iwd.common.stdio.http.HttpRequestHandler;
import io.iwd.i1.event.I1CloseStreamEvent;
import io.iwd.i1.util.I1Validator;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.HttpResponseStatus;

import java.util.Map;

@HttpRequestHandler(path = "/preService/i1VideoStopChannel")
public class I1CloseStreamNotificationHandler extends AbstractHttpRequestHandler<JsonObject> {

    @Override
    protected void handle0(ChannelHandlerContext waitingResponseContext,
                           String path,
                           String method,
                           Map<String, String> queryString,
                           Map<String, String> headers,
                           JsonObject body) throws Exception {
        String streamId = body.getString("streamId");
        if (StringUtil.isEmpty(streamId)) {
            HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":400,\"message\":\"no streamId\"}", null);
            return;
        }

        String[] dncn = streamId.split("_");
        if (dncn.length != 2) {
            return;
        }
        String dn = dncn[0];
        String cn = dncn[1];
        if (!I1Validator.isI1DeviceNumber(dn)) {
            return;
        }
        if (!Validator.isPositiveIntegerNumber(cn)) {
            return;
        }

        new I1CloseStreamEvent(dn, Integer.parseInt(cn)).publish();

        HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":200}", null);
    }
}

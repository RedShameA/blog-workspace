package io.iwd.i1.entity;

public class CruiseSnapshotPresetInfo {

    private final Integer presetId;

    private final Integer hour;

    private final Integer minute;

    public CruiseSnapshotPresetInfo(Integer presetId, Integer hour, Integer minute) {
        this.presetId = presetId;
        this.hour = hour;
        this.minute = minute;
    }

    public Integer getPresetId() {
        return presetId;
    }

    public Integer getHour() {
        return hour;
    }

    public Integer getMinute() {
        return minute;
    }
}

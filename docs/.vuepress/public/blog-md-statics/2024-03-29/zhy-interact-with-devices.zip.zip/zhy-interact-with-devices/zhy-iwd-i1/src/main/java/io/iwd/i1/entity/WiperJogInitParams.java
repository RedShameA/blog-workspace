package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

public class WiperJogInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String parentDeviceNumber;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getParentDeviceNumber() {
        return parentDeviceNumber;
    }

    public void setParentDeviceNumber(String parentDeviceNumber) {
        this.parentDeviceNumber = parentDeviceNumber;
    }

    @Override
    public WiperJogInitParams populateDefault() {
        if (this.parentDeviceNumber == null) {
            this.parentDeviceNumber = "";
        }
        return this;
    }

    @Override
    public WiperJogInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (!I1Validator.isI1ChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("i1 channel number format error");
        }
        if (this.parentDeviceNumber == null || (!"".equals(this.parentDeviceNumber) && !I1Validator.isI1DeviceNumber(this.parentDeviceNumber))) {
            throw new IllegalArgumentException("i1 parent device number format error");
        }
        return this;
    }

}

package io.iwd.i1;

public class I1Const {

    public static final String TASK_PREFIX = "I1";

    public static final String REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY = "i1_real_video_info";

    public static final int MIN_CONTROL_SPEED = 0;
    public static final int MAX_CONTROL_SPEED = 8;

    public static final int MIN_CHANNEL_NUMBER = 1;
    public static final int MAX_CHANNEL_NUMBER = 254;

    public static final int MIN_VIDEO_DURATION = 0;
    public static final int MAX_VIDEO_DURATION = 65535;

    public static final int MIN_PRESET_ID_NUMBER = 0;
    public static final int MAX_PRESET_ID_NUMBER = 255;

    public static final int MIN_SNAPSHOT_SCHEDULE_INTERVAL = 10;
    public static final int MAX_SNAPSHOT_SCHEDULE_INTERVAL = 1440;

    public static final int MIN_CRUISE_ID_NUMBER = 0;
    public static final int MAX_CRUISE_ID_NUMBER = 255;

    /**
     * 控制速度选项，用于替代控制速度值。
     */
    public enum ControlSpeedOption {
        /**
         * 自动。
         */
        AUTO(0),
        /**
         * 一档。
         */
        ONE(1),
        /**
         * 二档。
         */
        TWO(2),
        /**
         * 三档。
         */
        THREE(3),
        /**
         * 四档。
         */
        FOUR(4),
        /**
         * 五档。
         */
        FIVE(5),
        /**
         * 六档。
         */
        SIX(6),
        /**
         * 七档。
         */
        SEVEN(7),
        /**
         * 八档。
         */
        EIGHT(8),
        ;
        private final int speed;
        ControlSpeedOption(int speed) {
            this.speed = speed;
        }
        public int speed() {
            return this.speed;
        }
    }

    /**
     * 镜头控制选项，用于选择镜头控制的方向。
     * 有些设备可能不支持LEFT_UP RIGHT_UP LEFT_DOWN RIGHT_DOWN方向。
     */
    public enum LensControlOption {
        /**
         * 停止。
         */
        STOP(15),
        /**
         * 向上。
         */
        UP(11),
        /**
         * 向下。
         */
        DOWN(12),
        /**
         * 向左。
         */
        LEFT(13),
        /**
         * 向右。
         */
        RIGHT(14),
        /**
         * 向左上。
         */
        LEFT_UP(22),
        /**
         * 向右上。
         */
        RIGHT_UP(24),
        /**
         * 向左下。
         */
        LEFT_DOWN(23),
        /**
         * 向右下。
         */
        RIGHT_DOWN(25),
        ;
        private final int code;
        LensControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 变倍控制选项，用于选择变倍加/变倍减。
     */
    public enum ZoomControlOption {
        /**
         * 停止。
         */
        STOP(15),
        /**
         * 变倍加。
         */
        PLUS(16),
        /**
         * 变倍减。
         */
        MINUS(17),
        ;
        private final int code;
        ZoomControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 调焦控制选项，用于控制调焦远/调焦近。
     */
    public enum FocusControlOption {
        /**
         * 停止。
         */
        STOP(15),
        /**
         * 调焦近。
         */
        NEAR(18),
        /**
         * 调焦远。
         */
        FAR(19),
        ;
        private final int code;
        FocusControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 光圈控制选项，用于控制光圈开/光圈关。
     */
    public enum ApertureControlOption {
        /**
         * 停止。
         */
        STOP(15),
        /**
         * 光圈开。
         */
        OPEN(20),
        /**
         * 光圈关。
         */
        CLOSE(21),
        ;
        private final int code;
        ApertureControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 视频流协议。
     */
    public enum VideoStreamProtocol {
        RTMP(0, 0),
        ;

        private final int videoCode;
        private final int netCode;
        VideoStreamProtocol(int videoCode, int netCode) {
            this.videoCode = videoCode;
            this.netCode = netCode;
        }
        public int videoCode() {
            return this.videoCode;
        }
        public int netCode() {
            return this.netCode;
        }
    }

    /**
     * 录像回放速度选项。
     */
    public enum HistoryVideoSpeedOption {
        /**
         * 四分之一倍速。
         */
        X025(-2),
        /**
         * 二分之一倍速。
         */
        X05(-1),
        /**
         * 一倍速。
         */
        X1(0),
        /**
         * 二倍速。
         */
        X2(1),
        /**
         * 四倍速。
         */
        X4(2),
        ;
        private final int value;
        HistoryVideoSpeedOption(int value) {
            this.value = value;
        }
        public int value() {
            return this.value;
        }
    }

    /**
     * 拍照像素选项。并不是每个设备都支持这些选项，需要根据设备型号、版本等确定。
     */
    public enum SnapshotPixelOption {
        /**
         * 200万像素。
         */
        X200W(200),
        /**
         * 300万像素。
         */
        X300W(300),
        /**
         * 400万像素。
         */
        X400W(400),
        /**
         * 500万像素。
         */
        X500W(500),
        /**
         * 800万像素。
         */
        X800W(800),
        /**
         * 1200万像素。
         */
        X1200W(1200),
        /**
         * 1600万像素。
         */
        X1600W(1600),
        ;
        private final int value;
        SnapshotPixelOption(int value) {
            this.value = value;
        }
        public int value() {
            return this.value;
        }
    }

}

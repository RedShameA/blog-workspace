package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

public class SnapshotInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private Integer presetId;

    private String parentDeviceNumber;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Integer getPresetId() {
        return presetId;
    }

    public void setPresetId(Integer presetId) {
        this.presetId = presetId;
    }

    public String getParentDeviceNumber() {
        return parentDeviceNumber;
    }

    public void setParentDeviceNumber(String parentDeviceNumber) {
        this.parentDeviceNumber = parentDeviceNumber;
    }

    @Override
    public SnapshotInitParams populateDefault() {
        if (this.presetId == null) {
            this.presetId = 255; //代表摄像头当前位置
        }
        if (this.parentDeviceNumber == null) {
            this.parentDeviceNumber = "";
        }
        return this;
    }

    @Override
    public SnapshotInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (!I1Validator.isI1ChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("i1 channel number format error");
        }
        if (this.presetId == null || this.presetId < 0 || this.presetId > 255) {
            throw new IllegalArgumentException("i1 preset id error");
        }
        if (this.parentDeviceNumber == null || (!"".equals(this.parentDeviceNumber) && !I1Validator.isI1DeviceNumber(this.parentDeviceNumber))) {
            throw new IllegalArgumentException("i1 parent device number format error");
        }
        return this;
    }
}

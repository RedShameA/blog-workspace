package io.iwd.i1;

import io.iwd.i1.command.*;

public class I1 {

    /**
     * 镜头控制命令。
     */
    public static LensControl lensControl() {
        return new LensControl();
    }

    /**
     * 变倍控制命令。
     */
    public static ZoomControl zoomControl() {
        return new ZoomControl();
    }

    /**
     * 焦距控制命令。
     */
    public static FocusControl focusControl() {
        return new FocusControl();
    }

    /**
     * 自动调焦（一键聚焦）命令。
     */
    public static FocusAutoControl focusAutoControl() {
        return new FocusAutoControl();
    }

    /**
     * 光圈控制命令。
     */
    public static ApertureControl apertureControl() {
        return new ApertureControl();
    }

    /**
     * webrtc实时视频播放命令。
     */
    public static RealTimeVideoWebrtcPlay realTimeVideoWebrtcPlay() {
        return new RealTimeVideoWebrtcPlay();
    }

    /**
     * 实时视频停止命令。
     */
    public static RealTimeVideoStop realTimeVideoStop() {
        return new RealTimeVideoStop();
    }

    /**
     * 预置位调用命令。
     */
    public static PresetCall presetCall() {
        return new PresetCall();
    }

    /**
     * 预置位重新定位命令。
     */
    public static PresetRelocate presetRelocate() {
        return new PresetRelocate();
    }

    /**
     * 预置位删除命令。
     */
    public static PresetRemove presetRemove() {
        return new PresetRemove();
    }

    /**
     * 预置位全部删除命令。
     */
    public static PresetRemoveAll presetRemoveAll() {
        return new PresetRemoveAll();
    }

    /**
     * 录像文件查询命令。
     */
    public static HistoryVideoFileQuery historyVideoFileQuery() {
        return new HistoryVideoFileQuery();
    }

    /**
     * 录像文件webrtc播放命令。
     */
    public static HistoryVideoWebrtcPlay historyVideoWebrtcPlay() {
        return new HistoryVideoWebrtcPlay();
    }

    /**
     * 录像回放停止命令。
     */
    public static HistoryVideoStop historyVideoStop() {
        return new HistoryVideoStop();
    }

    /**
     * 录像回放继续命令。
     */
    public static HistoryVideoContinue historyVideoContinue() {
        return new HistoryVideoContinue();
    }

    /**
     * 录像回放暂停命令。
     */
    public static HistoryVideoPause historyVideoPause() {
        return new HistoryVideoPause();
    }

    /**
     * 录像回放速度控制命令。
     */
    public static HistoryVideoSpeedControl historyVideoSpeedControl() {
        return new HistoryVideoSpeedControl();
    }

    /**
     * 录像回放重新定位命令。
     */
    public static HistoryVideoRelocate historyVideoRelocate() {
        return new HistoryVideoRelocate();
    }

    /**
     * 图片抓拍命令。此命令抓怕的图片会直接保存在某个目录下。
     */
    public static Snapshot snapshot() {
        return new Snapshot();
    }

    /**
     * 拍照时间表查询。
     */
    public static SnapshotScheduleQuery snapshotScheduleQuery() {
        return new SnapshotScheduleQuery();
    }

    /**
     * 拍照时间表设置。
     */
    public static SnapshotScheduleConfig snapshotScheduleConfig() {
        return new SnapshotScheduleConfig();
    }

    /**
     * 巡航拍照设置。
     */
    public static CruiseSnapshotConfig cruiseSnapshotConfig() {
        return new CruiseSnapshotConfig();
    }

    /**
     * 巡航拍照删除。
     */
    public static CruiseSnapshotRemove cruiseSnapshotRemove() {
        return new CruiseSnapshotRemove();
    }

    /**
     * 雨刷点动命令。
     */
    public static WiperJog wiperJog() {
        return new WiperJog();
    }

}

package io.iwd.i1.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.i1.entity.HistoryVideoRelocateInitParams;
import io.iwd.i1.event.I1DefaultTaskProceedEvent;

import java.text.SimpleDateFormat;
import java.util.Date;

import static io.iwd.i1.I1Const.TASK_PREFIX;

public class HistoryVideoRelocateTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HistoryVideoRelocate", I1DefaultTaskProceedEvent::new);

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            HistoryVideoRelocateInitParams input = (HistoryVideoRelocateInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            Date timePoint = input.getTimePoint();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

            JsonObject data = JsonObject.create().put("method", "playback_seek");
            data.put("param", JsonObject.create().put("seekType", 1).put("timePoint", dateFormat.format(timePoint)));
            JsonObject videoJson = JsonObject.create().put("VideoJson", data.stringify());

            String message = "WEB-1@2500@" + deviceNumber + "@FCMGroup-1@" + (System.currentTimeMillis() / 1000) + "@" + context.getTaskId();

            String script = "redis.call('SET', KEYS[1], ARGV[1]);" +
                            "redis.call('PUBLISH', 'FCMGroup-1', ARGV[2]);";
            Redis.silentMode().eval(script, 1,
                    context.getTaskId(), videoJson.stringify(), message);

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            String taskId = context.getTaskId();
            String script = "local data = redis.call('GET', KEYS[1]);" +
                            "redis.call('DEL', KEYS[1]);" +
                            "return data;";
            Redis.interactiveMode().eval(script, 1, taskId);

            context.awaitNext("GOT_DATA");
        });

        taskFlow.addNode("GOT_DATA", context -> {
            Object input = context.getInput();
            if (! (input instanceof String)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "get and delete redis data failed"));
                return;
            }
            JsonObject data = JsonObject.from(input);
            if (data == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Boolean result = data.getBoolean("Result");
            if (result == null || !result) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error"));
                return;
            }

            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }

}

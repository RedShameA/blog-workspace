package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.i1.entity.CruiseSnapshotRemoveInitParams;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

/**
 * 机芯巡航拍照删除命令。
 */
public class CruiseSnapshotRemove extends AdvancedCommand<Boolean> {
    
    private CruiseSnapshotRemoveInitParams initParams = new CruiseSnapshotRemoveInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return CruiseSnapshotRemove命令对象。
     */
    public CruiseSnapshotRemove setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置巡航拍照id。
     * @param cruiseId 巡航拍照id。
     * @return CruiseSnapshotRemove命令对象。
     */
    public CruiseSnapshotRemove setCruiseId(Integer cruiseId) {
        this.initParams.setCruiseId(cruiseId);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "CruiseSnapshotRemove", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

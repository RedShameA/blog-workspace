package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.i1.entity.HistoryVideoWebrtcPlayInitParams;
import io.iwd.i1.entity.HistoryVideoWebrtcPlayResult;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

import java.util.Date;

public class HistoryVideoWebrtcPlay extends AdvancedCommand<HistoryVideoWebrtcPlayResult> {

    private HistoryVideoWebrtcPlayInitParams initParams = new HistoryVideoWebrtcPlayInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置录像文件开始时间。
     * @param startTime 录像文件开始时间。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setStartTime(Date startTime) {
        this.initParams.setStartTime(startTime);
        return this;
    }

    /**
     * 设置流媒体服务器接收设备推流的ip。
     * @param mediaServerIp 流媒体服务器接收设备推流的ip。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setMediaServerIp(String mediaServerIp) {
        this.initParams.setMediaServerIp(mediaServerIp);
        return this;
    }

    /**
     * 设置流媒体服务器接收设备推流的端口。
     * @param mediaServerPort 流媒体服务器接收设备推流的端口。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setMediaServerPort(Integer mediaServerPort) {
        this.initParams.setMediaServerPort(mediaServerPort);
        return this;
    }

    /**
     * 设置webrtc的offer sdp。
     * @param offerSdp webrtc的offer sdp。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setOfferSdp(String offerSdp) {
        this.initParams.setOfferSdp(offerSdp);
        return this;
    }

    /**
     * 设置与srs的api交互是否使用https。默认从配置文件中获取。
     * @param srsApiSsl 与srs的api交互是否使用https。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setSrsApiSsl(Boolean srsApiSsl) {
        this.initParams.setSrsApiSsl(srsApiSsl);
        return this;
    }

    /**
     * 设置srs的api交互ip。默认从配置文件中获取。
     * @param srsApiIp srs的api交互ip。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setSrsApiIp(String srsApiIp) {
        this.initParams.setSrsApiIp(srsApiIp);
        return this;
    }

    /**
     * 设置srs的api交互端口。默认从配置文件中获取。
     * @param srsApiPort srs的api交互端口。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setSrsApiPort(Integer srsApiPort) {
        this.initParams.setSrsApiPort(srsApiPort);
        return this;
    }

    /**
     * 设置web服务接收srs http请求的地址。默认从配置文件中获取。
     * @param webAddress web服务接收srs http请求的地址。
     * @return HistoryVideoWebrtcPlay命令对象。
     */
    public HistoryVideoWebrtcPlay setWebAddress(String webAddress) {
        this.initParams.setWebAddress(webAddress);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoWebrtcPlay", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public HistoryVideoWebrtcPlayResult await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                String sdp = completedResult.getString("sdp");
                return new HistoryVideoWebrtcPlayResult(true, sdp);
            }
            return new HistoryVideoWebrtcPlayResult(false, null);
        }, time);
    }

}

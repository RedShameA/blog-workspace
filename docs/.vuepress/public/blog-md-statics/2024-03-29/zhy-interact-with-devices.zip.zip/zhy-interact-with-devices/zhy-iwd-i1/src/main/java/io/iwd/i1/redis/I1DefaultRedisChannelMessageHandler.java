package io.iwd.i1.redis;

import io.iwd.common.stdio.redis.RedisChannelMessageHandler;
import io.iwd.i1.event.I1DefaultTaskProceedEvent;

public class I1DefaultRedisChannelMessageHandler extends RedisChannelMessageHandler {

    @Override
    public void handle(String channelName, String message) {
        int i = message.lastIndexOf('@');
        if (i == -1 || i == message.length() - 1) {
            return;
        }
        String taskId = message.substring(i + 1);
        new I1DefaultTaskProceedEvent(taskId, null).publish();
    }
}

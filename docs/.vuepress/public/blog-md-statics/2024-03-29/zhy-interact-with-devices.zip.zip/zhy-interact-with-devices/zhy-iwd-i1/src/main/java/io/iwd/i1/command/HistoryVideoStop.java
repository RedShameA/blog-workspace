package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.i1.entity.HistoryVideoStopInitParams;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

public class HistoryVideoStop extends AdvancedCommand<Boolean> {
    
    private HistoryVideoStopInitParams initParams = new HistoryVideoStopInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoStop命令对象。
     */
    public HistoryVideoStop setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoStop", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

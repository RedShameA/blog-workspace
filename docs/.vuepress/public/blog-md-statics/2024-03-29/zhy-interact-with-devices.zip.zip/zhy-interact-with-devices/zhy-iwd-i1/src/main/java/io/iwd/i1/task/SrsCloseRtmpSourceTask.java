package io.iwd.i1.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.i1.event.I1DefaultTaskProceedEvent;
import io.iwd.i1.util.I1Validator;

import static io.iwd.i1.I1Const.*;

public class SrsCloseRtmpSourceTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "SrsCloseRtmpSource", I1DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            String streamId = (String) context.getInput();
            String[] dncn = streamId.split("_");
            if (dncn.length != 2) {  //TODO 录像回复的流id时录像文件的开始时间
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_ILLEGAL_INIT_PARAMS | 0x0001,
                        "stream id error"));
                return;
            }
            String dn = dncn[0];
            String cn = dncn[1];
            if (!I1Validator.isI1DeviceNumber(dn)) {
                context.complete(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0001,
                        "stream id is not i1 format"));
                return;
            }
            if (!Validator.isPositiveIntegerNumber(cn)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0002,
                        "stream id is not i1 format"));
                return;
            }

            context.putData("streamId", streamId);
            context.putData("deviceNumber", dn);
            context.putData("channelNumber", Integer.parseInt(cn));

            context.fireNext("QUERY_REAL_TIME_VIDEO_INFO");
        });

        taskFlow.addNode("QUERY_REAL_TIME_VIDEO_INFO", context -> {
            String streamId = (String) context.getData("streamId");
            String script = "local info = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(info == false) then return; end;" +
                            "redis.call('HDEL', KEYS[1], KEYS[2]); return info;";
            Redis.interactiveMode().eval(script, 2, REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY, streamId);

            context.awaitNext("GOT_REAL_TIME_VIDEO_INFO");
        });

        taskFlow.addNode("GOT_REAL_TIME_VIDEO_INFO", context -> {
            String input = (String) context.getInput();
            if (StringUtil.isEmpty(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0003,
                        "can not get video info"));
                return;
            }

            String[] addressAndParentNumber = input.split("_");
            String address = addressAndParentNumber[0];
            String parentNumber;
            if (addressAndParentNumber.length == 2) {
                parentNumber = addressAndParentNumber[1];
            } else {
                parentNumber = "";
            }
            String[] ipAndPort = address.split(":");
            if (ipAndPort.length != 2) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0004,
                        "can not get video info"));
                return;
            }
            String ip = ipAndPort[0];
            if (!Validator.isIpv4(ip)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0005,
                        "video info ip error"));
                return;
            }
            String portStr = ipAndPort[1];
            if (!Validator.isPositiveIntegerNumber(portStr)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0006,
                        "video info port error"));
                return;
            }
            int port = Integer.parseInt(portStr);
            if (port > 65535) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0007,
                        "video info port error"));
                return;
            }

            context.putData("parentDeviceNumber", parentNumber);
            context.putData("mediaServerIp", ip);
            context.putData("mediaServerPort", port);

            context.fireNext("ISSUE_VIDEO_STOP_COMMAND");
        });

        taskFlow.addNode("ISSUE_VIDEO_STOP_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            JsonObject data = JsonObject.create()
                    .put("DeviceID", deviceNumber)
                    .put("ChannelNo", context.getData("channelNumber"))
                    .put("VideoTranfer", 0)
                    .put("VideoServerAddress", context.getData("mediaServerIp"))
                    .put("UpperHostPort", context.getData("mediaServerPort"))
                    .put("MaxPushStreamingDraution", "0")
                    .put("ParentDevID", context.getData("parentDeviceNumber"));

            String message = "WEB-1@1045@" + deviceNumber + "@FCMGroup-1@" + (System.currentTimeMillis() / 1000) + "@" + context.getTaskId();

            String script = "redis.call('SET', KEYS[1], ARGV[1]);" +
                            "redis.call('PUBLISH', 'FCMGroup-1', ARGV[2]);";
            Redis.silentMode().eval(script, 1, context.getTaskId(), data.stringify(), message);

            context.awaitNext("RECEIVED_VIDEO_STOP_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_VIDEO_STOP_RESPONSE", context -> {
            String taskId = context.getTaskId();
            String script = "local data = redis.call('GET', KEYS[1]);" +
                            "redis.call('DEL', KEYS[1]);" +
                            "return data;";
            Redis.interactiveMode().eval(script, 1, taskId);

            context.awaitNext("GOT_DATA");
        });

        taskFlow.addNode("GOT_DATA", context -> {
            Object input = context.getInput();
            if (! (input instanceof String)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "get and delete redis data failed"));
                return;
            }
            JsonObject data = JsonObject.from(input);
            if (data == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Boolean result = data.getBoolean("Result");
            if (result == null || !result) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error"));
                return;
            }

            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        return taskFlow;
    }

}

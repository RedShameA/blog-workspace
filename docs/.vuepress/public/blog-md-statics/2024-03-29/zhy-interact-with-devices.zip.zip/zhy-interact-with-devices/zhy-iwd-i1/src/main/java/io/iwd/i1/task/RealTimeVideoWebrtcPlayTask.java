package io.iwd.i1.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.http.srs.template.SrsExchangeSdpTemplate;
import io.iwd.common.stdio.http.srs.template.SrsQueryStreamTemplate;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.i1.entity.RealTimeVideoWebrtcPlayInitParams;
import io.iwd.i1.event.I1DefaultTaskProceedEvent;

import static io.iwd.i1.I1Const.*;

public class RealTimeVideoWebrtcPlayTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "RealTimeVideoWebrtcPlay", I1DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            RealTimeVideoWebrtcPlayInitParams input = (RealTimeVideoWebrtcPlayInitParams) context.getInput();
            context.putData("videoStreamProtocol", input.getVideoStreamProtocol());
            context.putData("deviceNumber", input.getDeviceNumber());
            context.putData("channelNumber", input.getChannelNumber());
            context.putData("mediaServerIp", input.getMediaServerIp());
            context.putData("mediaServerPort", input.getMediaServerPort());
            context.putData("maxDuration", String.valueOf(input.getMaxDuration()));
            context.putData("parentDeviceNumber", input.getParentDeviceNumber());
            context.putData("offerSdp", input.getOfferSdp());
            context.putData("srsApiSsl", input.getSrsApiSsl());
            context.putData("srsApiIp", input.getSrsApiIp());
            context.putData("srsApiPort", input.getSrsApiPort());
            context.putData("webAddress", input.getWebAddress());
            context.putData("allowAutoClose", input.getAllowAutoClose());

            Boolean useExistingStream = input.getUseExistingStream();
            if (useExistingStream) {
                context.fireNext("QUERY_STREAM");
            } else {
                context.fireNext("ISSUE_VIDEO_START_COMMAND");
            }
        });

        taskFlow.addNode("QUERY_STREAM", context -> {
            String streamId = context.getData("deviceNumber") + "_" + context.getData("channelNumber");
            context.putData("streamId", streamId);
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");

            new SrsQueryStreamTemplate(srsApiSsl, srsApiIp, srsApiPort, streamId).send();
            context.awaitNext("SRS_RESPONSE_STREAM");
        });

        taskFlow.addNode("SRS_RESPONSE_STREAM", context -> {
            Boolean input = (Boolean) context.getInput();
            if (input == null || !input) {
                context.fireNext("ISSUE_VIDEO_START_COMMAND");
            } else {
                context.fireNext("EXCHANGE_SDP");
            }
        });

        taskFlow.addNode("ISSUE_VIDEO_START_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            JsonObject data = JsonObject.create()
                    .put("DeviceID", deviceNumber)
                    .put("ChannelNo", context.getData("channelNumber"))
                    .put("VideoTranfer", 1)
                    .put("VideoServerAddress", context.getData("mediaServerIp"))
                    .put("UpperHostPort", context.getData("mediaServerPort"))
                    .put("MaxPushStreamingDraution", context.getData("maxDuration"))
                    .put("ParentDevID", context.getData("parentDeviceNumber"));

            String message = "WEB-1@1045@" + deviceNumber + "@FCMGroup-1@" + (System.currentTimeMillis() / 1000) + "@" + context.getTaskId();

            String script = "redis.call('SET', KEYS[1], ARGV[1]);" +
                            "redis.call('PUBLISH', 'FCMGroup-1', ARGV[2]);";
            Redis.silentMode().eval(script, 1, context.getTaskId(), data.stringify(), message);

            context.awaitNext("RECEIVED_VIDEO_START_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_VIDEO_START_RESPONSE", context -> {
            String taskId = context.getTaskId();
            String script = "local data = redis.call('GET', KEYS[1]);" +
                            "redis.call('DEL', KEYS[1]);" +
                            "return data;";
            Redis.interactiveMode().eval(script, 1, taskId);

            context.awaitNext("GOT_DATA");
        });

        taskFlow.addNode("GOT_DATA", context -> {
            Object input = context.getInput();
            if (! (input instanceof String)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "get and delete redis data failed"));
                return;
            }
            JsonObject data = JsonObject.from(input);
            if (data == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Boolean result = data.getBoolean("Result");
            if (result == null || !result) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error"));
                return;
            }

            Boolean allowAutoClose = (Boolean) context.getData("allowAutoClose");
            if (allowAutoClose) {
                context.fireNext("SAVE_VIDEO_INFO");
            } else {
                context.fireNext("EXCHANGE_SDP");
            }
        });

        taskFlow.addNode("SAVE_VIDEO_INFO", context -> {
            String streamId = (String) context.getData("streamId");
            String mediaServerIp = (String) context.getData("mediaServerIp");
            Integer mediaServerPort = (Integer) context.getData("mediaServerPort");
            String parentDeviceNumber = (String) context.getData("parentDeviceNumber");

            //记录播放视频时的推流ip:port, 以及可能存在的父设备编号
            Redis.silentMode().hset(REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY, streamId, mediaServerIp + ":" + mediaServerPort + "_" + parentDeviceNumber);

            context.fireNext("EXCHANGE_SDP");
        });

        taskFlow.addNode("EXCHANGE_SDP", context -> {
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            String webAddress = (String) context.getData("webAddress");
            String offerSdp = (String) context.getData("offerSdp");
            String streamPath = "/live/" + context.getData("streamId");

            new SrsExchangeSdpTemplate(srsApiSsl, srsApiIp, srsApiPort, webAddress, offerSdp, streamPath).send();
            context.awaitNext("SRS_RESPONSE_ANSWER_SDP");
        });

        taskFlow.addNode("SRS_RESPONSE_ANSWER_SDP", context -> {
            JsonObject input = (JsonObject) context.getInput();
            if (input == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0003,
                        "can not get answer sdp"));
                return;
            }
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("sdp", input.getString("sdp"))
                    .put("streamId", context.getData("streamId")));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

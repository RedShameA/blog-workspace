package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import static io.iwd.i1.I1Const.*;

public class CruiseSnapshotRemoveInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer cruiseId;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getCruiseId() {
        return this.cruiseId;
    }

    public void setCruiseId(Integer cruiseId) {
        this.cruiseId = cruiseId;
    }

    @Override
    public CruiseSnapshotRemoveInitParams populateDefault() {
        return this;
    }

    @Override
    public CruiseSnapshotRemoveInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (this.cruiseId == null || this.cruiseId < MIN_CRUISE_ID_NUMBER || this.cruiseId > MAX_CRUISE_ID_NUMBER) {
            throw new IllegalArgumentException("i1 cruise id error");
        }
        return this;
    }
}

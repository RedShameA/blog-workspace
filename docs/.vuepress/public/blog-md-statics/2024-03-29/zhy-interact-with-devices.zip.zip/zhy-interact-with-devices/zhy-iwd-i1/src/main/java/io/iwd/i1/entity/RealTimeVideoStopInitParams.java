package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.i1.util.I1Validator;

public class RealTimeVideoStopInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String mediaServerIp;

    private Integer mediaServerPort;

    private String parentDeviceNumber;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getMediaServerIp() {
        return this.mediaServerIp;
    }

    public void setMediaServerIp(String mediaServerIp) {
        this.mediaServerIp = mediaServerIp;
    }

    public Integer getMediaServerPort() {
        return this.mediaServerPort;
    }

    public void setMediaServerPort(Integer mediaServerPort) {
        this.mediaServerPort = mediaServerPort;
    }

    public String getParentDeviceNumber() {
        return this.parentDeviceNumber;
    }

    public void setParentDeviceNumber(String parentDeviceNumber) {
        this.parentDeviceNumber = parentDeviceNumber;
    }

    @Override
    public RealTimeVideoStopInitParams populateDefault() {
        EnvironmentHolder.get().config().getInBatch(conf -> {
            if (this.mediaServerIp == null) {
                this.mediaServerIp = (String) conf.getExtConfigInBatch("i1", "srs", "push_stream_ip");
            }
            if (this.mediaServerPort == null) {
                this.mediaServerPort = NumberUtil.toInt(conf.getExtConfigInBatch("i1", "srs", "push_stream_port"));
            }
        });
        if (this.parentDeviceNumber == null) {
            this.parentDeviceNumber = "";
        }
        return this;
    }

    @Override
    public RealTimeVideoStopInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        if (!I1Validator.isI1ChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("i1 channel number format error");
        }
        if (!Validator.isIpv4(this.mediaServerIp)) {
            throw new IllegalArgumentException("i1 media server ip format error");
        }
        if (this.mediaServerPort == null || this.mediaServerPort < 1 || mediaServerPort > 65535) {
            throw new IllegalArgumentException("i1 media server port format error");
        }
        if (this.parentDeviceNumber == null || (!"".equals(this.parentDeviceNumber) && !I1Validator.isI1DeviceNumber(this.parentDeviceNumber))) {
            throw new IllegalArgumentException("i1 parent device number format error");
        }
        return this;
    }
}

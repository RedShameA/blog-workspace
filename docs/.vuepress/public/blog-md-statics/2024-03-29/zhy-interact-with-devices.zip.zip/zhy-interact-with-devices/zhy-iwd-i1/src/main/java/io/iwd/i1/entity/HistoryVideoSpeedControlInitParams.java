package io.iwd.i1.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.i1.util.I1Validator;

import static io.iwd.i1.I1Const.*;

public class HistoryVideoSpeedControlInitParams implements TaskInitParams {

    private String deviceNumber;

    private HistoryVideoSpeedOption historyVideoSpeedOption;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public HistoryVideoSpeedOption getHistoryVideoSpeedOption() {
        return historyVideoSpeedOption;
    }

    public void setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.historyVideoSpeedOption = historyVideoSpeedOption;
    }

    @Override
    public HistoryVideoSpeedControlInitParams populateDefault() {
        if (this.historyVideoSpeedOption == null) {
            this.historyVideoSpeedOption = HistoryVideoSpeedOption.X1;
        }
        return this;
    }

    @Override
    public HistoryVideoSpeedControlInitParams validate() {
        if (!I1Validator.isI1DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("i1 device number format error");
        }
        return this;
    }
    
}

package io.iwd.i1.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.i1.entity.PresetRelocateInitParams;
import io.iwd.i1.event.I1DefaultTaskStartEvent;

public class PresetRelocate extends AdvancedCommand<Boolean> {
    
    private PresetRelocateInitParams initParams = new PresetRelocateInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return PresetRelocate命令对象。
     */
    public PresetRelocate setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PresetRelocate命令对象。
     */
    public PresetRelocate setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置预置位id。
     * @param presetId 预置位id。
     * @return PresetRelocate命令对象。
     */
    public PresetRelocate setPresetId(Integer presetId) {
        this.initParams.setPresetId(presetId);
        return this;
    }

    /**
     * 设置父设备编号。
     * @param parentDeviceNumber 父设备编号。
     * @return PresetRelocate命令对象。
     */
    public PresetRelocate setParentDeviceNumber(String parentDeviceNumber) {
        this.initParams.setParentDeviceNumber(parentDeviceNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PresetRelocate", null, data.populateDefault().validate(), I1DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

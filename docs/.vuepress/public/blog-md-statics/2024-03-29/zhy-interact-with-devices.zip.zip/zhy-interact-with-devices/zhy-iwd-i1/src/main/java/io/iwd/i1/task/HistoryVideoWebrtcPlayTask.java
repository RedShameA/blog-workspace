package io.iwd.i1.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.http.srs.template.SrsExchangeSdpTemplate;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.i1.entity.HistoryVideoWebrtcPlayInitParams;
import io.iwd.i1.event.I1DefaultTaskProceedEvent;

import java.text.SimpleDateFormat;

import static io.iwd.i1.I1Const.TASK_PREFIX;

public class HistoryVideoWebrtcPlayTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HistoryVideoWebrtcPlay", I1DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            HistoryVideoWebrtcPlayInitParams input = (HistoryVideoWebrtcPlayInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            context.putData("deviceNumber", deviceNumber);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            String startTime = dateFormat.format(input.getStartTime());
            context.putData("startTime", startTime);
            String rtmpUrl = "rtmp://" + input.getMediaServerIp() +":" + input.getMediaServerPort() + "/playback/" + deviceNumber + "/" + startTime;
            context.putData("rtmpUrl", rtmpUrl);
            context.putData("offerSdp", input.getOfferSdp());
            context.putData("srsApiSsl", input.getSrsApiSsl());
            context.putData("srsApiIp", input.getSrsApiIp());
            context.putData("srsApiPort", input.getSrsApiPort());
            context.putData("webAddress", input.getWebAddress());

            context.fireNext("ISSUE_COMMAND");
        });

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            JsonObject data = JsonObject.create().put("method", "playback_start");
            JsonObject param = JsonObject.create()
                    .put("playType", 1)
                    .put("playMode", 0)
                    .put("serverType", 0)
                    .put("timePoint", context.getData("startTime"))
                    .put("url", context.getData("rtmpUrl"));
            data.put("param", param);
            JsonObject videoJson = JsonObject.create().put("VideoJson", data.stringify());
            String deviceNumber = (String) context.getData("deviceNumber");

            String message = "WEB-1@2500@" + deviceNumber + "@FCMGroup-1@" + (System.currentTimeMillis() / 1000) + "@" + context.getTaskId();

            String script = "redis.call('SET', KEYS[1], ARGV[1]);" +
                            "redis.call('PUBLISH', 'FCMGroup-1', ARGV[2]);";
            Redis.silentMode().eval(script, 1,
                    context.getTaskId(), videoJson.stringify(), message);

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            String taskId = context.getTaskId();
            String script = "local data = redis.call('GET', KEYS[1]);" +
                            "redis.call('DEL', KEYS[1]);" +
                            "return data;";
            Redis.interactiveMode().eval(script, 1, taskId);

            context.awaitNext("GOT_DATA");
        });

        taskFlow.addNode("GOT_DATA", context -> {
            Object input = context.getInput();
            if (! (input instanceof String)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "get and delete redis data failed"));
                return;
            }
            JsonObject data = JsonObject.from(input);
            if (data == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Boolean result = data.getBoolean("Result");
            if (result == null || !result) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error"));
                return;
            }

            JsonObject videoJson = JsonObject.from(data.getString("VideoJson"));
            JsonObject error = videoJson.getJsonObject("error");
            Integer errorCode = error.getInteger("errorcode");
            if (errorCode == null || errorCode != 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0003,
                        "fcm service response error"));
                return;
            }

            context.fireNext("EXCHANGE_SDP");
        });

        taskFlow.addNode("EXCHANGE_SDP", context -> {
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            String webAddress = (String) context.getData("webAddress");
            String offerSdp = (String) context.getData("offerSdp");
            String streamPath = "/playback/" + context.getData("deviceNumber") + "/" + context.getData("startTime");

            new SrsExchangeSdpTemplate(srsApiSsl, srsApiIp, srsApiPort, webAddress, offerSdp, streamPath).send();
            context.awaitNext("SRS_RESPONSE_ANSWER_SDP");
        });

        taskFlow.addNode("SRS_RESPONSE_ANSWER_SDP", context -> {
            JsonObject input = (JsonObject) context.getInput();
            if (input == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0004,
                        "can not get answer sdp"));
                return;
            }
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("sdp", input.getString("sdp")));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }

}

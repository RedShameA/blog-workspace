package io.iwd.i1.event;

import io.iwd.common.event.TaskProceedEvent;

public class I1DefaultTaskProceedEvent extends TaskProceedEvent {

    public I1DefaultTaskProceedEvent(String taskId, Object data) {
        super(taskId, data);
    }

}

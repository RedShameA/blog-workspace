package io.iwd.onvif.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.onvif.entity.LensControlInitParams;
import io.iwd.onvif.event.OnvifDefaultTaskStartEvent;

import static io.iwd.onvif.OnvifConst.*;

public class LensControl extends AdvancedCommand<Boolean> {
    
    private LensControlInitParams initParams = new LensControlInitParams();

    /**
     * 设置设备ip。
     * @param deviceIp 设备ip。
     * @return LensControl命令对象。
     */
    public LensControl setDeviceIp(String deviceIp) {
        this.initParams.setDeviceIp(deviceIp);
        return this;
    }

    /**
     * 设置设备端口。
     * @param devicePort 设备端口。
     * @return LensControl命令对象。
     */
    public LensControl setDevicePort(Integer devicePort) {
        this.initParams.setDevicePort(devicePort);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return LensControl命令对象。
     */
    public LensControl setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置镜头控制选项。
     * @param lensControlOption 镜头控制选项。
     * @return LensControl命令对象。
     */
    public LensControl setLensControlOption(LensControlOption lensControlOption) {
        this.initParams.setLensControlOption(lensControlOption);
        return this;
    }

    /**
     * 设置镜头控制速度。
     * @param speed 镜头控制速度。
     * @return LensControl命令对象。
     */
    public LensControl setSpeed(Integer speed) {
        this.initParams.setSpeed(speed);
        return this;
    }

    /**
     * 设置镜头控制速度选项。
     * @param controlSpeedOption 镜头控制速度选项。
     * @return LensControl命令对象。
     */
    public LensControl setControlSpeedOption(ControlSpeedOption controlSpeedOption) {
        this.initParams.setSpeed(controlSpeedOption.speed());
        return this;
    }

    /**
     * 设置设备用户名。
     * @param username 设备用户名。
     * @return LensControl命令对象。
     */
    public LensControl setUsername(String username) {
        this.initParams.setUsername(username);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return LensControl命令对象。
     */
    public LensControl setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "LensControl", null, data.populateDefault().validate(), OnvifDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

package io.iwd.onvif.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.onvif.entity.PresetCallInitParams;
import io.iwd.onvif.event.OnvifDefaultTaskStartEvent;

public class PresetCall extends AdvancedCommand<Boolean> {

    private PresetCallInitParams initParams = new PresetCallInitParams();

    /**
     * 设置设备ip。
     * @param deviceIp 设备ip。
     * @return PresetCall命令对象。
     */
    public PresetCall setDeviceIp(String deviceIp) {
        this.initParams.setDeviceIp(deviceIp);
        return this;
    }

    /**
     * 设置设备端口。
     * @param devicePort 设备端口。
     * @return PresetCall命令对象。
     */
    public PresetCall setDevicePort(Integer devicePort) {
        this.initParams.setDevicePort(devicePort);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PresetCall命令对象。
     */
    public PresetCall setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param presetName 通道编号。
     * @return PresetCall命令对象。
     */
    public PresetCall setPresetName(String presetName) {
        this.initParams.setPresetName(presetName);
        return this;
    }

    /**
     * 设置镜头控制速度。
     * @param speed 镜头控制速度。
     * @return PresetCall命令对象。
     */
    public PresetCall setSpeed(Integer speed) {
        this.initParams.setSpeed(speed);
        return this;
    }

    /**
     * 设置设备用户名。
     * @param username 设备用户名。
     * @return PresetCall命令对象。
     */
    public PresetCall setUsername(String username) {
        this.initParams.setUsername(username);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return PresetCall命令对象。
     */
    public PresetCall setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PresetCall", null, data.populateDefault().validate(), OnvifDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

package io.iwd.onvif.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.onvif.entity.FocusControlInitParams;
import io.iwd.onvif.event.OnvifDefaultTaskStartEvent;

import static io.iwd.onvif.OnvifConst.*;

public class FocusControl extends AdvancedCommand<Boolean> {
    
    private FocusControlInitParams initParams = new FocusControlInitParams();

    /**
     * 设置设备ip。
     * @param deviceIp 设备ip。
     * @return FocusControl命令对象。
     */
    public FocusControl setDeviceIp(String deviceIp) {
        this.initParams.setDeviceIp(deviceIp);
        return this;
    }

    /**
     * 设置设备端口。
     * @param devicePort 设备端口。
     * @return FocusControl命令对象。
     */
    public FocusControl setDevicePort(Integer devicePort) {
        this.initParams.setDevicePort(devicePort);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return FocusControl命令对象。
     */
    public FocusControl setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置焦距控制选项。
     * @param focusControlOption 焦距控制选项。
     * @return FocusControl命令对象。
     */
    public FocusControl setFocusControlOption(FocusControlOption focusControlOption) {
        this.initParams.setFocusControlOption(focusControlOption);
        return this;
    }

    /**
     * 设置镜头控制速度。
     * @param speed 镜头控制速度。
     * @return FocusControl命令对象。
     */
    public FocusControl setSpeed(Integer speed) {
        this.initParams.setSpeed(speed);
        return this;
    }

    /**
     * 设置焦距控制速度选项。
     * @param controlSpeedOption 焦距控制速度选项。
     * @return FocusControl命令对象。
     */
    public FocusControl setControlSpeedOption(ControlSpeedOption controlSpeedOption) {
        this.initParams.setSpeed(controlSpeedOption.speed());
        return this;
    }

    /**
     * 设置设备用户名。
     * @param username 设备用户名。
     * @return FocusControl命令对象。
     */
    public FocusControl setUsername(String username) {
        this.initParams.setUsername(username);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return FocusControl命令对象。
     */
    public FocusControl setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "FocusControl", null, data.populateDefault().validate(), OnvifDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

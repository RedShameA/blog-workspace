package io.iwd.onvif.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.onvif.entity.PresetRemoveInitParams;
import io.iwd.onvif.event.OnvifDefaultTaskStartEvent;

public class PresetRemove extends AdvancedCommand<Boolean> {

    private PresetRemoveInitParams initParams = new PresetRemoveInitParams();

    /**
     * 设置设备ip。
     * @param deviceIp 设备ip。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setDeviceIp(String deviceIp) {
        this.initParams.setDeviceIp(deviceIp);
        return this;
    }

    /**
     * 设置设备端口。
     * @param devicePort 设备端口。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setDevicePort(Integer devicePort) {
        this.initParams.setDevicePort(devicePort);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param presetName 通道编号。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setPresetName(String presetName) {
        this.initParams.setPresetName(presetName);
        return this;
    }

    /**
     * 设置设备用户名。
     * @param username 设备用户名。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setUsername(String username) {
        this.initParams.setUsername(username);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PresetRemove", null, data.populateDefault().validate(), OnvifDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

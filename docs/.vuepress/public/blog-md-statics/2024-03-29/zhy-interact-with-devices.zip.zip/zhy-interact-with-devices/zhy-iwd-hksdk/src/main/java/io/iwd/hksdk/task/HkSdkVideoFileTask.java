package io.iwd.hksdk.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.hksdk.entity.HksdkPhotoInitParams;
import io.iwd.hksdk.entity.HksdkVideoFileInitParams;
import io.iwd.hksdk.event.HksdkDefaultTaskProceedEvent;

import static io.iwd.hksdk.HksdkConst.TASK_PREFIX;

public class HkSdkVideoFileTask implements TaskFlowInitializer {
    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HkSdkVideoFileTask", HksdkDefaultTaskProceedEvent::new);
        taskFlow.addNode("ISSUE_COMMAND", context -> {
            HksdkVideoFileInitParams input = (HksdkVideoFileInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            String channelNumber = input.getDeviceChannal();
            String sdkIp = input.getDeviceIp();
            Integer port = input.getDevicePort();
            String user = input.getDeviceUser();
            String pwd = input.getDevicePwd();
            Integer audiofiletype = input.getAudiofiletype();
            String audiofilepath = input.getAudiofilepath();
            JsonObject data = JsonObject.create()
                    .put("type", 2)
                    .put("host", sdkIp)
                    .put("port", port)
                    .put("user", user)
                    .put("pwd", pwd)
                    .put("devid", deviceNumber)
                    .put("channelid", channelNumber)
                    .put("audiofiletype", audiofiletype)
                    .put("picfilepath", audiofilepath)
                    .put("uuid", context.getTaskId());
            Redis.silentMode().rpush("dev_sdk_control", data.stringify());
            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });
        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }
}

package io.iwd.hksdk.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.hksdk.util.Gb28181Validator;

public class HksdkPhotoInitParams implements TaskInitParams {
    private String deviceNumber;

    private String sdkId;

    private String deviceChannal;

    private String sdkIp;
    private String sdkPort;
    private String sdkUser;
    private String sdkPwd;
    private String picfilepath;
    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceId) {
        this.deviceNumber = deviceId;
    }

    public String getSdkId() {
        return sdkId;
    }

    public void setSdkId(String sdkId) {
        this.sdkId = sdkId;
    }

    public String getDeviceChannal() {
        return deviceChannal;
    }

    public void setDeviceChannal(String deviceChannal) {
        this.deviceChannal = deviceChannal;
    }

    public String getSdkIp() {
        return sdkIp;
    }

    public void setSdkIp(String sdkIp) {
        this.sdkIp = sdkIp;
    }

    public String getSdkPort() {
        return sdkPort;
    }

    public void setSdkPort(String sdkPort) {
        this.sdkPort = sdkPort;
    }

    public String getSdkUser() {
        return sdkUser;
    }

    public void setSdkUser(String sdkUser) {
        this.sdkUser = sdkUser;
    }

    public String getSdkPwd() {
        return sdkPwd;
    }

    public void setSdkPwd(String sdkPwd) {
        this.sdkPwd = sdkPwd;
    }

    public String getPicfilepath() {
        return picfilepath;
    }

    public void setPicfilepath(String picfilepath) {
        this.picfilepath = picfilepath;
    }

    @Override
    public HksdkPhotoInitParams populateDefault() {
        return this ;
    }

    @Override
    public HksdkPhotoInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("HkSdk deviceNumber number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceChannal)) {
            throw new IllegalArgumentException("HkSdk deviceChannal number format error");
        }
        if (this.picfilepath == null) {
            this.picfilepath = (String) EnvironmentHolder.get().config().getExtConfig("hksdk", "sdk","sdk_picfilepath");
        }

        if (this.sdkId == null) {
            throw new IllegalArgumentException("HkSdk sdkId error");
        }
        if (this.sdkIp == null) {
            throw new IllegalArgumentException("HkSdk sdkIp error");
        }

        if (this.sdkPort == null) {
            throw new IllegalArgumentException("HkSdk sdkPort error");
        }
        if (this.sdkUser == null) {
            throw new IllegalArgumentException("HkSdk sdkUser error");
        }
        if (this.sdkPwd == null) {
            throw new IllegalArgumentException("HkSdk sdkPwd error");
        }
        return this;
    }
}

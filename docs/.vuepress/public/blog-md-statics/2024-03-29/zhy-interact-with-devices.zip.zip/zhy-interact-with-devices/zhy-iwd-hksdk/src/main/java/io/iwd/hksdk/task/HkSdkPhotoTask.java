package io.iwd.hksdk.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.hksdk.event.HksdkDefaultTaskProceedEvent;
import io.iwd.hksdk.entity.HksdkPhotoInitParams;

import static io.iwd.hksdk.HksdkConst.TASK_PREFIX;

public class HkSdkPhotoTask implements TaskFlowInitializer {
    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HkSdkPhotoTask", HksdkDefaultTaskProceedEvent::new);
        taskFlow.addNode("ISSUE_COMMAND", context -> {
            HksdkPhotoInitParams input = (HksdkPhotoInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            String channelNumber = input.getDeviceChannal();
            String sdkIp = input.getSdkIp();
            String port = input.getSdkPort();
            String user = input.getSdkUser();
            String pwd = input.getSdkPwd();
            String sdkId = input.getSdkId();
            String picfilepath = input.getPicfilepath();
            JsonObject data = JsonObject.create()
                    .put("type", 1)
                    .put("host", sdkIp)
                    .put("port", Integer.valueOf(port))
                    .put("user", user)
                    .put("pwd", pwd)
                    .put("devid", deviceNumber)
                    .put("snapid", Integer.valueOf(sdkId))
                    .put("channelid", channelNumber)
                    .put("picfilepath", picfilepath)
                    .put("uuid", context.getTaskId());
            Redis.silentMode().rpush("dev_sdk_control", data.stringify());
            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
//            context.awaitNext("RECEIVED_RESPONSE");
        });
        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }
}

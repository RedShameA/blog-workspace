package io.iwd.hksdk.event;

import io.iwd.common.event.TaskProceedEvent;

public class HksdkDefaultTaskProceedEvent extends TaskProceedEvent {

    public HksdkDefaultTaskProceedEvent(String taskId, Object data) {
        super(taskId, data);
    }

}

package io.iwd.hksdk;

public class HksdkConst {

    public static final String TASK_PREFIX = "Hksdk";
    public static final String SDK_VOICE_DEVICE_SSRC = "sip_sdk_ssrc";
    public static final String SDK_VOICE_DEVICE_DATA = "sdk_data_";
}

package io.iwd.hksdk.redis;

import io.iwd.common.stdio.redis.RedisChannelMessageHandler;

public class HksdkDefaultRedisChannelMessageHandler extends RedisChannelMessageHandler {

    @Override
    public void handle(String channelName, String message) {

    }
}

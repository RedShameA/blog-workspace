package io.iwd.hksdk.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.hksdk.util.Gb28181Validator;

public class HksdkVoicePlayInitParams implements TaskInitParams {
    private String deviceNumber;
    private String channelNumber;
    private String deviceIp;
    private Integer devicePort;
    private String deviceUser;
    private String devicePwd;

    private Integer deviceModel;//0是udp,1是tcp
    private String videoSsrc;
    private String sdp;

    private String srsApiIp;
    private Boolean srsApiSsl;
    private Integer srsApiPort;
    private String webAddress;

    private String sdkServerIp;
    private Integer sdkServerPort;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getDeviceIp() {
        return deviceIp;
    }

    public void setDeviceIp(String deviceIp) {
        this.deviceIp = deviceIp;
    }

    public Integer getDevicePort() {
        return devicePort;
    }

    public void setDevicePort(Integer devicePort) {
        this.devicePort = devicePort;
    }

    public String getDeviceUser() {
        return deviceUser;
    }

    public void setDeviceUser(String deviceUser) {
        this.deviceUser = deviceUser;
    }

    public String getDevicePwd() {
        return devicePwd;
    }

    public void setDevicePwd(String devicePwd) {
        this.devicePwd = devicePwd;
    }

    public Integer getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(Integer deviceModel) {
        this.deviceModel = deviceModel;
    }

    public String getVideoSsrc() {
        return videoSsrc;
    }

    public void setVideoSsrc(String videoSsrc) {
        this.videoSsrc = videoSsrc;
    }

    public String getSdp() {
        return sdp;
    }

    public void setSdp(String sdp) {
        this.sdp = sdp;
    }

    public String getSrsApiIp() {
        return srsApiIp;
    }

    public void setSrsApiIp(String srsApiIp) {
        this.srsApiIp = srsApiIp;
    }

    public Boolean getSrsApiSsl() {
        return srsApiSsl;
    }

    public void setSrsApiSsl(Boolean srsApiSsl) {
        this.srsApiSsl = srsApiSsl;
    }

    public Integer getSrsApiPort() {
        return srsApiPort;
    }

    public void setSrsApiPort(Integer srsApiPort) {
        this.srsApiPort = srsApiPort;
    }

    public String getWebAddress() {
        return webAddress;
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }

    public String getSdkServerIp() {
        return sdkServerIp;
    }

    public void setSdkServerIp(String sdkServerIp) {
        this.sdkServerIp = sdkServerIp;
    }

    public Integer getSdkServerPort() {
        return sdkServerPort;
    }

    public void setSdkServerPort(Integer sdkServerPort) {
        this.sdkServerPort = sdkServerPort;
    }

    @Override
    public HksdkVoicePlayInitParams populateDefault() {
        return this ;
    }

    @Override
    public HksdkVoicePlayInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("HkSdk deviceNumber number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("HkSdk channelNumber number format error");
        }
        if (this.srsApiIp == null) {

            this.srsApiIp = (String) EnvironmentHolder.get().config().getExtConfig("global", "srs", "api_ip");
        }
        if (this.srsApiSsl == null) {
            this.srsApiSsl = (Boolean) EnvironmentHolder.get().config().getExtConfig("global", "srs", "api_ssl");
        }
        if (this.srsApiPort == null) {
            this.srsApiPort = NumberUtil.toInt(EnvironmentHolder.get().config().getExtConfig("global", "srs", "api_port"));
        }
        if (this.webAddress == null) {
            this.webAddress = (String) EnvironmentHolder.get().config().getExtConfig("global", "srs", "web_address");
        }

        if (this.sdkServerIp == null) {
            this.sdkServerIp = (String) EnvironmentHolder.get().config().getExtConfig("hksdk", "sdk", "sdk_Ip");
        }
        if (this.sdkServerPort == null) {
            this.sdkServerPort = NumberUtil.toInt(EnvironmentHolder.get().config().getExtConfig("hksdk", "sdk", "sdk_port"));
        }
//        if (this.picfilepath == null) {
//            this.picfilepath = (String) EnvironmentHolder.get().config().getExtConfig("hksdk", "sdk_picfilepath");
//        }
//
//        if (this.sdkId == null) {
//            throw new IllegalArgumentException("HkSdk sdkId error");
//        }
//        if (this.sdkIp == null) {
//            throw new IllegalArgumentException("HkSdk sdkIp error");
//        }
//
//        if (this.sdkPort == null) {
//            throw new IllegalArgumentException("HkSdk sdkPort error");
//        }
//        if (this.sdkUser == null) {
//            throw new IllegalArgumentException("HkSdk sdkUser error");
//        }
//        if (this.sdkPwd == null) {
//            throw new IllegalArgumentException("HkSdk sdkPwd error");
//        }
        return this;
    }
}

package io.iwd.hksdk.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.hksdk.entity.HksdkPhotoInitParams;
import io.iwd.hksdk.entity.HksdkVoicePlayInitParams;
import io.iwd.hksdk.entity.RealTimeAudioWebrtcSendResult;
import io.iwd.hksdk.event.HksdkDefaultTaskStartEvent;

/**
 * sdk设备语音对讲
 */
public class HksdkVoicePaly extends AdvancedCommand<RealTimeAudioWebrtcSendResult> {
    private HksdkVoicePlayInitParams hksdkVoicePlayInitParams = new HksdkVoicePlayInitParams();
    /**
     * 设置设备ip。
     * @param deviceIp 设备ip.。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setDeviceIp(String deviceIp){
        this.hksdkVoicePlayInitParams.setDeviceIp(deviceIp);
        return this;
    }
    /**
     * 设置设备id。
     * @param deviceNumber 设备id。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setDeviceNumber(String deviceNumber){
        this.hksdkVoicePlayInitParams.setDeviceNumber(deviceNumber);
        return this;
    }
    /**
     * 设置通道id。
     * @param channelNumber 通道id。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setChannelNumber(String channelNumber){
        this.hksdkVoicePlayInitParams.setChannelNumber(channelNumber);
        return this;
    }
    /**
     * 设置设备端口。
     * @param devicePort 端口。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setDevicePort(Integer devicePort){
        this.hksdkVoicePlayInitParams.setDevicePort(devicePort);
        return this;
    }
    /**
     * 设置设备密码。
     * @param devicePwd 密码。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setDevicePwd(String devicePwd){
        this.hksdkVoicePlayInitParams.setDevicePwd(devicePwd);
        return this;
    }
    /**
     * 设置设备用户名。
     * @param deviceUser 用户名。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setDeviceUser(String deviceUser){
        this.hksdkVoicePlayInitParams.setDeviceUser(deviceUser);
        return this;
    }

    /**
     * 设置播放模式0是udp，1是tcp。
     * @param deviceModel 0udp,1tcp。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setDeviceModel(Integer deviceModel){
        this.hksdkVoicePlayInitParams.setDeviceModel(deviceModel);
        return this;
    }

    /**
     * 设置实时视频ssrc。
     * @param videoSsrc 实时视频ssrc。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setVideoSsrc(String videoSsrc){
        this.hksdkVoicePlayInitParams.setVideoSsrc(videoSsrc);
        return this;
    }

    /**
     * 设置sdp。
     * @param sdp sdp。
     * @return HksdkVoicePaly。
     */
    public HksdkVoicePaly setSdp(String sdp){
        this.hksdkVoicePlayInitParams.setSdp(sdp);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.hksdkVoicePlayInitParams;
        this.hksdkVoicePlayInitParams = null;
        return super.taskActive(null, "HkSdkVoicePlayTask", null, data.populateDefault().validate(), HksdkDefaultTaskStartEvent::new);
    }

    @Override
    public RealTimeAudioWebrtcSendResult await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                String sdp = completedResult.getString("sdp");
                String ssrc = completedResult.getString("ssrc");
                return new RealTimeAudioWebrtcSendResult(true, sdp, ssrc);
            }
            return new RealTimeAudioWebrtcSendResult(false, null, null);
        }, time);
    }
}

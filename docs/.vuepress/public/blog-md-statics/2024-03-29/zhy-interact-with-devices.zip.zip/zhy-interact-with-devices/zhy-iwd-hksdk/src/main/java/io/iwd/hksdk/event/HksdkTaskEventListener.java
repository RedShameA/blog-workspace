package io.iwd.hksdk.event;

import io.iwd.common.event.AbstractTaskEventListener;
import io.iwd.common.event.Event;
import io.iwd.hksdk.HksdkConst;

import java.util.LinkedList;
import java.util.List;

public class HksdkTaskEventListener extends AbstractTaskEventListener {

    @Override
    public String defaultTaskPrefix() {
        return HksdkConst.TASK_PREFIX;
    }

    @Override
    public List<Class<? extends Event>> interests() {
        List<Class<? extends Event>> interestsList = new LinkedList<>();
        interestsList.add(HksdkDefaultTaskStartEvent.class);
        interestsList.add(HksdkDefaultTaskProceedEvent.class);
        interestsList.add(SdkCloseVoiceEvent.class);
        return interestsList;
    }
}

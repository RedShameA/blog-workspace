package io.iwd.hksdk.event;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;
import io.iwd.hksdk.HksdkConst;

public class HksdkDefaultTaskStartEvent extends TaskStartEvent {

    public HksdkDefaultTaskStartEvent(String taskName, Object data) {
        super(taskName, data);
    }

    public HksdkDefaultTaskStartEvent(String taskName, Object data, TaskResult taskResult) {
        super(taskName, data, taskResult);
    }

    public HksdkDefaultTaskStartEvent(String taskId, String taskName, Object data, TaskResult taskResult) {
        super(taskId, taskName, data, taskResult);
    }

    public HksdkDefaultTaskStartEvent(String taskId, String taskName, String entranceName, Object data, TaskResult taskResult) {
        super(taskId, taskName, entranceName, data, taskResult);
    }

    @Override
    public String getTaskPrefix() {
        return HksdkConst.TASK_PREFIX;
    }

}

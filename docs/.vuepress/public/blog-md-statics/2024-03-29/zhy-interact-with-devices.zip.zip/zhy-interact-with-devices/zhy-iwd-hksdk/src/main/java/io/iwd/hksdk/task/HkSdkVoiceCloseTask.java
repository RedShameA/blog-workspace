package io.iwd.hksdk.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.hksdk.event.HksdkDefaultTaskProceedEvent;

import static io.iwd.hksdk.HksdkConst.*;

public class HkSdkVoiceCloseTask implements TaskFlowInitializer {


    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "SdkCloseVoice", HksdkDefaultTaskProceedEvent::new);
        taskFlow.addNode("PREPARE_DATA", context -> {
            String input = (String) context.getInput();
            context.putData("closeSsrc",input);
            if (input == null){
                context.fireNext("RESULT_DATE");
                return;
            }
            String redisStr=
                    "local device = redis.call('HGET',KEYS[1],KEYS[2]);"
                    +"if device then redis.call('HDEL',KEYS[1], KEYS[2]); return device;"
                    +"else  return device;end;";
            Redis.interactiveMode().eval(redisStr, 2, SDK_VOICE_DEVICE_SSRC, input);
            context.awaitNext("GOT_SSRC");
        });
        taskFlow.addNode("GOT_SSRC", context -> {
            String input = (String) context.getInput();
            if (input == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "query ssrc error"));
                return;
            }
            String redisStr = "local data =redis.call('GET',KEYS[1]);  redis.call('DEL',KEYS[1]); return data;";
            String  devicekey = SDK_VOICE_DEVICE_DATA+input;
            Redis.interactiveMode().eval(redisStr, 1, devicekey);
            context.awaitNext("REQUEST_DEVICE_RESULT");
        });
        taskFlow.addNode("REQUEST_DEVICE_RESULT", context -> {
            String deviceStr = (String) context.getInput();
            if(deviceStr == null){
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "query ssrc error"));
                return;
            }
            JsonObject input = JsonObject.from(deviceStr);
            JsonObject messageToPublish = JsonObject.create();
            // 2udp 1tcp
            Integer mode = input.getInteger("transmode");
//        String msgId= createUUID();
            messageToPublish.put("type", 3);
            messageToPublish.put("host", (String) input.get("host"));
            messageToPublish.put("port", input.getInteger("port"));
            messageToPublish.put("user", (String) input.get("user"));
            messageToPublish.put("pwd", (String) input.get("pwd"));
            messageToPublish.put("devid", input.getString("devid"));
            messageToPublish.put("channelid", (String) input.get("channelid"));
            messageToPublish.put("uuid", (String) input.get("uuid"));
            messageToPublish.put("startpush", 0);
            messageToPublish.put("transmode", mode);
            messageToPublish.put("ssrctodev",  (String) input.get("closeSsrc"));//语音ssrc
            messageToPublish.put("ssrctosrs",  "");
            Redis.silentMode().rpush("dev_sdk_control", messageToPublish.stringify());
            context.awaitNext("RESULT_SECCUSE_DATE");
        });
        taskFlow.addNode("RESULT_SECCUSE_DATE", context -> {
            context.fail(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    "get audio port error"));
            return;
        });
        taskFlow.addNode("RESULT_DATE", context -> {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_ILLEGAL_INIT_PARAMS | 0x0001,
                        "get audio port error"));
                return;
        });
        taskFlow.setDefaultEntrance("ISSUE_COMMAND");
        return taskFlow;
    }
}

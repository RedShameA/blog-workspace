package io.iwd.hksdk.event;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;
import io.iwd.common.ext.util.Generator;

/**
 * srs关闭webrtc视频的事件。
 */
public class SdkCloseVoiceEvent extends TaskStartEvent {

    public SdkCloseVoiceEvent(Object data) {
        super(null, "SdkCloseVoice", data, new TaskResult());
    }

    public String getTaskId() {
        return Generator.create32UniqueId();
    }

}

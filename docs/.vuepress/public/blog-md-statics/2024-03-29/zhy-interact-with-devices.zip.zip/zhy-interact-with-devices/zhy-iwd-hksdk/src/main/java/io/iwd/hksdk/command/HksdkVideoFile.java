package io.iwd.hksdk.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.hksdk.entity.HksdkVideoFileInitParams;
import io.iwd.hksdk.event.HksdkDefaultTaskStartEvent;

/**
 * sdk设备抓图
 */
public class HksdkVideoFile extends AdvancedCommand<Boolean> {
    private HksdkVideoFileInitParams hksdkVideoFileInitParams = new HksdkVideoFileInitParams();
    /**
     * 设置设备ip。
     * @param deviceIp 设备ip.。
     * @return HksdkPhoto。
     */
    public HksdkVideoFile setDeviceIp(String deviceIp){
        this.hksdkVideoFileInitParams.setDeviceIp(deviceIp);
        return this;
    }
    /**
     * 设置设备id。
     * @param deviceNumber 设备id。
     * @return HksdkPhoto。
     */
    public HksdkVideoFile setDeviceNumber(String deviceNumber){
        this.hksdkVideoFileInitParams.setDeviceNumber(deviceNumber);
        return this;
    }
    /**
     * 设置通道id。
     * @param deviceChannal 通道id。
     * @return HksdkPhoto。
     */
    public HksdkVideoFile setDeviceChannal(String deviceChannal){
        this.hksdkVideoFileInitParams.setDeviceChannal(deviceChannal);
        return this;
    }
    /**
     * 设置端口。
     * @param devicePort 端口。
     * @return HksdkPhoto。
     */
    public HksdkVideoFile setDevicePort(Integer devicePort){
        this.hksdkVideoFileInitParams.setDevicePort(devicePort);
        return this;
    }
    /**
     * 设置密码。
     * @param devicePwd 密码。
     * @return HksdkPhoto。
     */
    public HksdkVideoFile setDevicePwd(String devicePwd){
        this.hksdkVideoFileInitParams.setDevicePwd(devicePwd);
        return this;
    }
    /**
     * 设置用户名。
     * @param deviceUser 用户名。
     * @return HksdkPhoto。
     */
    public HksdkVideoFile setDeviceUser(String deviceUser){
        this.hksdkVideoFileInitParams.setDeviceUser(deviceUser);
        return this;
    }


    /**
     * 设置语音文件类型。
     * @param audiofiletype 语音文件类型。
     * @return HksdkPhoto。
     */
    public HksdkVideoFile setAudiofiletype(Integer audiofiletype){
        this.hksdkVideoFileInitParams.setAudiofiletype(audiofiletype);
        return this;
    }

    /**
     * 设置语音文件路径。
     * @param audiofilepath 设置语音文件路径。
     * @return HksdkPhoto。
     */
    public HksdkVideoFile setAudiofilepath(String audiofilepath){
        this.hksdkVideoFileInitParams.setAudiofilepath(audiofilepath);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.hksdkVideoFileInitParams;
        this.hksdkVideoFileInitParams = null;
        return super.taskActive(null, "HkSdkVideoFileTask", null, data.populateDefault().validate(), HksdkDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

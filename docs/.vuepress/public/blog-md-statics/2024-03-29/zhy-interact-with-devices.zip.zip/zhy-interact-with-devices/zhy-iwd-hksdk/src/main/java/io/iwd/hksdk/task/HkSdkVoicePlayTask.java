package io.iwd.hksdk.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.hksdk.entity.HksdkVoicePlayInitParams;
import io.iwd.hksdk.event.HksdkDefaultTaskProceedEvent;
import io.iwd.hksdk.http.template.SrsSdkPublishRtcStreamTemplate;

import static io.iwd.hksdk.HksdkConst.*;

public class HkSdkVoicePlayTask implements TaskFlowInitializer {


    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HkSdkVoicePlayTask", HksdkDefaultTaskProceedEvent::new);
        taskFlow.addNode("PREPARE_DATA", context -> {
            HksdkVoicePlayInitParams input = (HksdkVoicePlayInitParams) context.getInput();

            context.putData("deviceNumber", input.getDeviceNumber());
            context.putData("channelNumber", input.getChannelNumber());
            context.putData("deviceIp", input.getDeviceIp());
            context.putData("devicePort", input.getDevicePort());
            context.putData("deviceUser", input.getDeviceUser());
            context.putData("devicePwd", input.getDevicePwd());
            context.putData("deviceModel", input.getDeviceModel());
            context.putData("videoSsrc", input.getVideoSsrc());
            context.putData("sdp", input.getSdp());
            context.putData("srsApiIp", input.getSrsApiIp());

            context.putData("srsApiSsl", input.getSrsApiSsl());
            context.putData("srsApiPort", input.getSrsApiPort());
            context.putData("webAddress", input.getWebAddress());
            context.putData("sdkServerIp", input.getSdkServerIp());
            context.putData("sdkServerPort", input.getSdkServerPort());
            Redis.interactiveMode().get("dev-audio-info_"+input.getDeviceNumber() + "#" + input.getChannelNumber());
            context.awaitNext("REQUEST_HTTP_SRS");
        });
        taskFlow.addNode("REQUEST_HTTP_SRS", context -> {
//            Object input = context.getInput();
            String input = (String) context.getInput();
            if (input != null) {
                JsonObject inputStr = JsonObject.from(input);
                if(inputStr.getInteger("audiostate") == 1){
                    context.fireNext("RESULT_DATE");
                    return;
                }
            }
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            Integer deviceModel = (Integer) context.getData("deviceModel");
            String sdkServerIp = (String) context.getData("sdkServerIp");
            String sdp = (String) context.getData("sdp");
            String webAddress = (String) context.getData("webAddress");
            Integer sdkServerPort = (Integer) context.getData("sdkServerPort");
            new SrsSdkPublishRtcStreamTemplate(srsApiSsl, srsApiIp, srsApiPort, sdkServerIp, sdp , webAddress, sdkServerPort,deviceModel).send();
            context.awaitNext("REQUEST_SRS_RESULT");

        });
        taskFlow.addNode("REQUEST_SRS_RESULT", context -> {
            JsonObject input = (JsonObject) context.getInput();
            JsonObject messageToPublish = JsonObject.create();
            if(input.get("ssrc") == null){
                context.fireNext("RESULT_DATE");
                return;
            }
            // 2udp 1tcp
            int mode = (Integer) context.getData("deviceModel")==0?2:1;
            messageToPublish.put("type", 3);
            messageToPublish.put("host", (String)context.getData("deviceIp"));
            messageToPublish.put("port",  (Integer)context.getData("devicePort"));
            messageToPublish.put("user", (String)context.getData("deviceUser"));
            messageToPublish.put("pwd",(String) context.getData("devicePwd"));
            messageToPublish.put("devid", (String)context.getData("deviceNumber"));
            messageToPublish.put("channelid",(String)context.getData("channelNumber"));
            messageToPublish.put("uuid", (String)input.get("stream"));
            messageToPublish.put("startpush", 1);
            messageToPublish.put("transmode", mode);
            messageToPublish.put("ssrctosrs", (String)context.getData("videoSsrc"));//实时视频ssrc
            messageToPublish.put("ssrctodev",  input.get("ssrc").toString());
            Redis.silentMode().rpush("dev_sdk_control", messageToPublish.stringify());
            String redisStr = "redis.call('HSET', KEYS[1], ARGV[1], KEYS[2]);";
            Redis.interactiveMode().eval(redisStr, 2, SDK_VOICE_DEVICE_SSRC, (String)context.getData("deviceNumber")+ "_" +(String)context.getData("channelNumber"),  input.get("ssrc").toString());
            String  devicekey = SDK_VOICE_DEVICE_DATA+(String)context.getData("deviceNumber")+ "_" +(String)context.getData("channelNumber");
            String deviceDataStr = "redis.call('SET', KEYS[1], KEYS[2]);";
            //插入设备信息
            Redis.silentMode().eval(deviceDataStr, 2, devicekey,  messageToPublish.toString());
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("sdp", input.getString("sdp"))
                    .put("ssrc", input.get("ssrc").toString()));
        });

        taskFlow.addNode("RESULT_DATE", context -> {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0001,
                        "get audio port error"));
                return;
        });
        taskFlow.setDefaultEntrance("ISSUE_COMMAND");
        return taskFlow;
    }
}

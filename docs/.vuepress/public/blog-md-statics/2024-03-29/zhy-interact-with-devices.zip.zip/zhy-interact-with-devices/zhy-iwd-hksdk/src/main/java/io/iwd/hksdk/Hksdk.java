package io.iwd.hksdk;

import io.iwd.hksdk.command.HksdkPhoto;
import io.iwd.hksdk.command.HksdkVideoFile;
import io.iwd.hksdk.command.HksdkVoicePaly;

public class Hksdk {
    public static HksdkPhoto HkSdkPhoto(){
        return new HksdkPhoto();
    }


    public static HksdkPhoto HkSdkRadioBroadCast(){
        return new HksdkPhoto();
    }


    public static HksdkVideoFile HkSdkPullAudio(){
        return new HksdkVideoFile();
    }


    public static HksdkVoicePaly HkSdkVoicePlay(){
        return new HksdkVoicePaly();
    }
}

package io.iwd.hksdk.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.hksdk.event.HksdkDefaultTaskStartEvent;
import io.iwd.hksdk.entity.HksdkPhotoInitParams;

/**
 * sdk设备抓图
 */
public class HksdkPhoto extends AdvancedCommand<Boolean> {
    private HksdkPhotoInitParams hksdkPhotoInitParams = new HksdkPhotoInitParams();
    /**
     * 设置设备ip。
     * @param SdkIp 设备ip.。
     * @return HksdkPhoto。
     */
    public HksdkPhoto setSdkIp(String SdkIp){
        this.hksdkPhotoInitParams.setSdkIp(SdkIp);
        return this;
    }
    /**
     * 设置设备id。
     * @param deviceNumber 设备id。
     * @return HksdkPhoto。
     */
    public HksdkPhoto setDeviceNumber(String deviceNumber){
        this.hksdkPhotoInitParams.setDeviceNumber(deviceNumber);
        return this;
    }
    /**
     * 设置通道id。
     * @param deviceChannal 通道id。
     * @return HksdkPhoto。
     */
    public HksdkPhoto setDeviceChannal(String deviceChannal){
        this.hksdkPhotoInitParams.setDeviceChannal(deviceChannal);
        return this;
    }
    /**
     * 设置端口。
     * @param sdkPort 端口。
     * @return HksdkPhoto。
     */
    public HksdkPhoto setSdkPort(String sdkPort){
        this.hksdkPhotoInitParams.setSdkPort(sdkPort);
        return this;
    }
    /**
     * 设置密码。
     * @param sdkPwd 密码。
     * @return HksdkPhoto。
     */
    public HksdkPhoto setSdkPwd(String sdkPwd){
        this.hksdkPhotoInitParams.setSdkPwd(sdkPwd);
        return this;
    }
    /**
     * 设置用户名。
     * @param sdkUser 用户名。
     * @return HksdkPhoto。
     */
    public HksdkPhoto setSdkUser(String sdkUser){
        this.hksdkPhotoInitParams.setSdkUser(sdkUser);
        return this;
    }

    /**
     * 设置截图通道id。
     * @param SdkId 用户名。
     * @return HksdkPhoto。
     */
    public HksdkPhoto setSdkId(String SdkId){
        this.hksdkPhotoInitParams.setSdkId(SdkId);
        return this;
    }


    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.hksdkPhotoInitParams;
        this.hksdkPhotoInitParams = null;
        return super.taskActive(null, "HkSdkPhotoTask", null, data.populateDefault().validate(), HksdkDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

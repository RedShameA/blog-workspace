package io.iwd.hksdk.http.template;

import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.common.stdio.http.AbstractHttpTemplate;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.*;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.*;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.CharsetUtil;

import java.net.InetSocketAddress;

/**
 * 。
 */
public class SrsSdkPublishRtcStreamTemplate extends AbstractHttpTemplate {

    private final String srsApiIp;

    private final int srsApiPort;


    private final String webAddress;

    private final String sdp; //offer sdp

    private final String sdkServerIp;

    private final int sdkServerPort;

    private final int deviceModel;

    private String answerSdp;

    public SrsSdkPublishRtcStreamTemplate(boolean ssl, String ip, int port, String sdkServerIp,
                                          String sdp, String webAddress, int sdkServerPort,
                                          int deviceModel) {
        if (!Validator.isIpv4(ip)) {
            throw new IllegalArgumentException("SrsPublishRtcStream: param ip format error");
        }
        if (port < 0 || port > 65535) {
            throw new IllegalArgumentException("SrsPublishRtcStream: param port must > 0 && < 65535");
        }
        if (StringUtil.isEmpty(sdkServerIp)) {
            throw new IllegalArgumentException("SrsPublishRtcStream: param sdkServerIp can not be empty");
        }
        if (StringUtil.isEmpty(sdp)) {
            throw new IllegalArgumentException("SrsPublishRtcStream: param sdp can not be empty");
        }
        if (!Validator.isIpv4AndPort(webAddress)) {
            throw new IllegalArgumentException("SrsPublishRtcStream: param webAddress format error");
        }
//        if (StringUtil.isEmpty(sdkServerPort)) {
//            throw new IllegalArgumentException("SrsPublishRtcStream: param sdkServerPort can not be empty");
//        }
//        if (!Validator.isIpv4(deviceModel)) {
//            throw new IllegalArgumentException("SrsPublishRtcStream: param deviceModel format error");
//        }
        super.ssl = ssl;
        this.srsApiIp = ip;
        this.srsApiPort = port;
        this.sdp = sdp;
        this.webAddress = webAddress;
        this.sdkServerIp = sdkServerIp;
        this.sdkServerPort = sdkServerPort;
        this.deviceModel = deviceModel;
    }

    @Override
    protected Bootstrap getBootstrap() {
        return new Bootstrap()
                .group(getEventLoopGroup())
                .channel(getChannelType())
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        //ssl处理器
                        if (SrsSdkPublishRtcStreamTemplate.super.ssl) {
                            pipeline.addLast(SslContextBuilder.forClient().build().newHandler(ch.alloc()));
                        }
                        //连接空闲(超时)监视器
                        pipeline.addLast(new IdleStateHandler(0, 0, 10));
                        //HTTP编解码器
                        pipeline.addLast(new HttpClientCodec());
                        //HTTP报文聚合器
                        pipeline.addLast(new HttpObjectAggregator(1024 * 4));
                        //SRS请求响应处理器
                        pipeline.addLast(new SrsSdkPublishRtcStreamHandler());
                    }
                })
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                .remoteAddress(new InetSocketAddress(this.srsApiIp, this.srsApiPort));
    }

    private class SrsSdkPublishRtcStreamHandler extends SimpleChannelInboundHandler<FullHttpResponse> {

        private final String url;

        SrsSdkPublishRtcStreamHandler() {
            this.url =
                    "http" + (SrsSdkPublishRtcStreamTemplate.super.ssl ? "s" : "") + "://" +
                    SrsSdkPublishRtcStreamTemplate.this.srsApiIp + ":" + SrsSdkPublishRtcStreamTemplate.this.srsApiPort +
                    "/rtc/v1/audio_intercom_HVSDK_sdp";
        }

        //处理response
        @Override
        protected void channelRead0(ChannelHandlerContext ctx, FullHttpResponse msg) throws Exception {
            ctx.close();
            int responseCode = msg.status().code();
            String responseBody = msg.content().toString(CharsetUtil.UTF_8);
            Logger.info("[" + SrsSdkPublishRtcStreamTemplate.super.taskId + "] " + this.url + " response: " + responseCode + " " + responseBody);

            if (responseCode != HttpResponseStatus.OK.code()) {
                //发布事件
                eventConstructor.apply(SrsSdkPublishRtcStreamTemplate.super.taskId, null).publish();
                return;
            }

            JsonObject responseJson = null;
            try {
                responseJson = JsonObject.from(responseBody);
            } catch (Exception e) {
                Logger.warn("error occurred while parsing json");
            }
            if (responseJson == null) {
                //发布事件
                eventConstructor.apply(SrsSdkPublishRtcStreamTemplate.super.taskId, null).publish();
                return;
            }
            String sdp = responseJson.getString("sdp");
            Integer ssrc = responseJson.getInteger("ssrc");
            String stream = responseJson.getString("stream");
            JsonObject dateResult = JsonObject.create();
            dateResult.put("sdp",sdp);
            dateResult.put("ssrc",ssrc);
            dateResult.put("stream",stream);
            //发布事件
            eventConstructor.apply(SrsSdkPublishRtcStreamTemplate.super.taskId, dateResult).publish();
        }

        //发送request
        @Override
        public void channelActive(ChannelHandlerContext ctx) throws Exception {
            String body = JsonObject.create()
                    .put("api", this.url)
                    .put("sdp", sdp)
                    .put("webAddress", webAddress)
                    .put("sdkip", sdkServerIp)
                    .put("sdkport", sdkServerPort)
                    .put("sdkptl", deviceModel)
                    .stringify();
            ByteBuf bodyBuf = ByteBufUtil.writeUtf8(ctx.alloc(), body);
            FullHttpRequest request = new DefaultFullHttpRequest(
                    HttpVersion.HTTP_1_1,
                    HttpMethod.POST,
                    this.url,
                    bodyBuf);
            request.headers().set(HttpHeaderNames.CONTENT_TYPE, APPLICATION_JSON);
            request.headers().set(HttpHeaderNames.CONTENT_LENGTH, bodyBuf.readableBytes());

            Logger.info("[" + SrsSdkPublishRtcStreamTemplate.super.taskId + "] POST " + this.url + " request: " + body);
            ctx.writeAndFlush(request);
        }

        //处理连接空闲
        @Override
        public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
            if (evt instanceof IdleStateEvent) {
                ctx.close();
                Logger.warn("SrsQueryStreamHandler IdleStateEvent Triggered, connection close...");
            }
        }

    }

}

package io.iwd.hksdk;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowCollector;
import io.iwd.hksdk.command.HksdkPhoto;
import io.iwd.hksdk.task.HkSdkPhotoTask;
import io.iwd.hksdk.task.HkSdkVideoFileTask;
import io.iwd.hksdk.task.HkSdkVoiceCloseTask;
import io.iwd.hksdk.task.HkSdkVoicePlayTask;

import java.util.LinkedList;
import java.util.List;

public class HksdkTaskFlowCollector implements TaskFlowCollector {

    @Override
    public List<TaskFlow> getTaskFlowList() {

        List<TaskFlow> taskFlowList = new LinkedList<>();
        //sdk抓图
        taskFlowList.add(new HkSdkPhotoTask().getTaskFlow());
        //sdk语音文件播放
        taskFlowList.add(new HkSdkVideoFileTask().getTaskFlow());

        //sdk语音d对讲
        taskFlowList.add(new HkSdkVoicePlayTask().getTaskFlow());

        //sdk语音对讲关闭
        taskFlowList.add(new HkSdkVoiceCloseTask().getTaskFlow());
        return taskFlowList;
    }
}

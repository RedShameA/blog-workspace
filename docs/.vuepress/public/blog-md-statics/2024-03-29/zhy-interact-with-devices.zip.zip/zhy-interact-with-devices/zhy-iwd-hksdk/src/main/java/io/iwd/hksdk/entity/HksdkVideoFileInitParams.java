package io.iwd.hksdk.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.hksdk.util.Gb28181Validator;

public class HksdkVideoFileInitParams implements TaskInitParams {
    private String deviceNumber;
    private String deviceChannal;
    private String deviceIp;
    private Integer devicePort;
    private String deviceUser;
    private String devicePwd;
    private Integer audiofiletype;
    private String audiofilepath;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getDeviceChannal() {
        return deviceChannal;
    }

    public void setDeviceChannal(String deviceChannal) {
        this.deviceChannal = deviceChannal;
    }

    public String getDeviceIp() {
        return deviceIp;
    }

    public void setDeviceIp(String deviceIp) {
        this.deviceIp = deviceIp;
    }

    public Integer getDevicePort() {
        return devicePort;
    }

    public void setDevicePort(Integer devicePort) {
        this.devicePort = devicePort;
    }

    public String getDeviceUser() {
        return deviceUser;
    }

    public void setDeviceUser(String deviceUser) {
        this.deviceUser = deviceUser;
    }

    public String getDevicePwd() {
        return devicePwd;
    }

    public void setDevicePwd(String devicePwd) {
        this.devicePwd = devicePwd;
    }

    public Integer getAudiofiletype() {
        return audiofiletype;
    }

    public void setAudiofiletype(Integer audiofiletype) {
        this.audiofiletype = audiofiletype;
    }

    public String getAudiofilepath() {
        return audiofilepath;
    }

    public void setAudiofilepath(String audiofilepath) {
        this.audiofilepath = audiofilepath;
    }

    @Override
    public HksdkVideoFileInitParams populateDefault() {
        return this ;
    }

    @Override
    public HksdkVideoFileInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("HkSdk deviceNumber number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceChannal)) {
            throw new IllegalArgumentException("HkSdk deviceChannal number format error");
        }
        if (this.audiofilepath == null) {
            this.audiofilepath = (String) EnvironmentHolder.get().config().getExtConfig("hksdk",  "sdk", "sdk_AudioPath");
        }
        if (this.audiofiletype == null) {
            throw new IllegalArgumentException("HkSdk audiofiletype error");
        }
        if (this.deviceIp == null) {
            throw new IllegalArgumentException("HkSdk sdkIp error");
        }

        if (this.devicePort == null) {
            throw new IllegalArgumentException("HkSdk sdkPort error");
        }
        if (this.deviceUser == null) {
            throw new IllegalArgumentException("HkSdk sdkUser error");
        }
        if (this.devicePwd == null) {
            throw new IllegalArgumentException("HkSdk sdkPwd error");
        }
        return this;
    }
}

package io.iwd.csg;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowCollector;
import io.iwd.csg.command.HistoryVideoFileQuery;
import io.iwd.csg.command.HistoryVideoStop;
import io.iwd.csg.task.*;

import java.util.LinkedList;
import java.util.List;

/**
 * 南网协议，任务流程收集器。
 */
public class CsgTaskFlowCollector implements TaskFlowCollector {

    @Override
    public List<TaskFlow> getTaskFlowList() {

        List<TaskFlow> taskFlowList = new LinkedList<>();

        //webrtc实时视频播放
        taskFlowList.add(new RealTimeVideoWebrtcPlayTask().getTaskFlow());

        //srs关闭webrtc视频
        taskFlowList.add(new SrsCloseRtcTask().getTaskFlow());

        //镜头控制
        taskFlowList.add(new LensControlTask().getTaskFlow());
        //变倍控制
        taskFlowList.add(new ZoomControlTask().getTaskFlow());
        //焦距控制
        taskFlowList.add(new FocusControlTask().getTaskFlow());
        //光圈控制
        taskFlowList.add(new ApertureControlTask().getTaskFlow());
        //辅助开关控制
        taskFlowList.add(new AuxiliarySwitchControlTask().getTaskFlow());

        //3d控球
        taskFlowList.add(new ThreeDimensionalControlTask().getTaskFlow());

        //预置位重新定位
        taskFlowList.add(new PresetRelocateTask().getTaskFlow());
        //预置位调用
        taskFlowList.add(new PresetCallTask().getTaskFlow());
        //预置位删除
        taskFlowList.add(new PresetRemoveTask().getTaskFlow());

        //巡航线设置
        taskFlowList.add(new CruiseConfigTask().getTaskFlow());
        //巡航线删除
        taskFlowList.add(new CruiseRemoveTask().getTaskFlow());
        //巡航线启动
        taskFlowList.add(new CruiseStartTask().getTaskFlow());
        //巡航线停止
        taskFlowList.add(new CruiseStopTask().getTaskFlow());

        //巡检点追加
        taskFlowList.add(new PatrolInspectionPointAppendTask().getTaskFlow());
        //巡检点删除
        taskFlowList.add(new PatrolInspectionPointRemoveTask().getTaskFlow());
        //巡检点修改
        taskFlowList.add(new PatrolInspectionPointModifyTask().getTaskFlow());
        //巡检线删除
        taskFlowList.add(new PatrolInspectionRemoveTask().getTaskFlow());
        //巡检点数量查询
        taskFlowList.add(new PatrolInspectionPointCountQueryTask().getTaskFlow());
        //巡检线开始
        taskFlowList.add(new PatrolInspectionStartTask().getTaskFlow());
        //巡检线停止
        taskFlowList.add(new PatrolInspectionStopTask().getTaskFlow());

        //录像文件数量查询
        taskFlowList.add(new HistoryVideoFileCountQueryTask().getTaskFlow());
        //录像文件查询
        taskFlowList.add(new HistoryVideoFileQueryTask().getTaskFlow());
        //录像文件webrtc播放
        taskFlowList.add(new HistoryVideoWebrtcPlayTask().getTaskFlow());
        //录像文件暂停
        taskFlowList.add(new HistoryVideoPauseTask().getTaskFlow());
        //录像文件继续
        taskFlowList.add(new HistoryVideoContinueTask().getTaskFlow());
        //录像文件速度控制
        taskFlowList.add(new HistoryVideoSpeedControlTask().getTaskFlow());
        //录像文件重新定位
        taskFlowList.add(new HistoryVideoRelocateTask().getTaskFlow());
        //录像文件停止播放
        taskFlowList.add(new HistoryVideoStopTask().getTaskFlow());

        //密码修改
        taskFlowList.add(new PasswordModifyTask().getTaskFlow());
        //设备重启
        taskFlowList.add(new DeviceRebootTask().getTaskFlow());
        //设置osd参数
        taskFlowList.add(new OsdConfigTask().getTaskFlow());
        //查询osd参数
        taskFlowList.add(new OsdQueryTask().getTaskFlow());
        //设置主站信息
        taskFlowList.add(new StationConfigTask().getTaskFlow());
        //查询主站信息
        taskFlowList.add(new StationQueryTask().getTaskFlow());

        return taskFlowList;
    }
}

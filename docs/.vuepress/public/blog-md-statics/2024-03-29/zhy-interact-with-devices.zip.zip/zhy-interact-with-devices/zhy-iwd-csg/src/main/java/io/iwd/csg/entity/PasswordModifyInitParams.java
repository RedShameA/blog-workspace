package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

public class PasswordModifyInitParams implements TaskInitParams {

    private String deviceNumber;

    private String oldPassword;

    private String newPassword;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getOldPassword() {
        return this.oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getNewPassword() {
        return this.newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    @Override
    public PasswordModifyInitParams populateDefault() {
        if (this.oldPassword == null) {
            this.oldPassword = "";
        }
        return this;
    }

    @Override
    public PasswordModifyInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgPassword(this.oldPassword)) {
            throw new IllegalArgumentException("csg old password format error");
        }
        if (!CsgValidator.isCsgPassword(this.newPassword)) {
            throw new IllegalArgumentException("csg new password format error");
        }
        return this;
    }

}

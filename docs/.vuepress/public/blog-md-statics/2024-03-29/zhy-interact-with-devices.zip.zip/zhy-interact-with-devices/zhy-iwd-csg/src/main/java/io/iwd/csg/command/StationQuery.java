package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.csg.entity.StationQueryResult;
import io.iwd.csg.entity.StationQueryInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 主站信息查询命令。
 */
public class StationQuery extends AdvancedCommand<StationQueryResult> {
    
    private StationQueryInitParams initParams = new StationQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return StationQuery命令对象。
     */
    public StationQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "StationQuery", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public StationQueryResult await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                String ip = completedResult.getString("ip");
                Integer port = completedResult.getInteger("port");
                String cardNumber = completedResult.getString("cardNumber");
                return new StationQueryResult(true, ip, port, cardNumber);
            }
            return new StationQueryResult(false, null, null, null);
        }, time);
    }
    
}

package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.HistoryVideoSpeedControlInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import static io.iwd.csg.CsgConst.HistoryVideoSpeedOption;

/**
 * 录像回放速度控制命令。
 */
public class HistoryVideoSpeedControl extends AdvancedCommand<Boolean> {

    private HistoryVideoSpeedControlInitParams initParams = new HistoryVideoSpeedControlInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置录像回放速度选项。
     * @param historyVideoSpeedOption 录像回放速度选项。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.initParams.setHistoryVideoSpeedOption(historyVideoSpeedOption);
        return this;
    }

    /**
     * 设置ssrc。
     * @param ssrc ssrc。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setSsrc(Long ssrc) {
        this.initParams.setSsrc(ssrc);
        return this;
    }
    
    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoSpeedControl", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

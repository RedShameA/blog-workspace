package io.iwd.csg.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.csg.entity.CruiseConfigInitParams;
import io.iwd.csg.entity.CruisePresetInfo;
import io.iwd.csg.event.CsgDefaultTaskProceedEvent;

import java.util.List;

import static io.iwd.csg.CsgConst.*;

public class CruiseConfigTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "CruiseConfig", CsgDefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            CruiseConfigInitParams input = (CruiseConfigInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            Integer channelNumber = input.getChannelNumber();
            String password = input.getPassword();
            Integer cruiseId = input.getCruiseId();
            List<CruisePresetInfo> cruisePresetList = input.getCruisePresetList();

            context.putData("deviceNumber", deviceNumber);
            context.putData("channelNumber", channelNumber);
            context.putData("password", password);
            context.putData("cruiseId", cruiseId);
            context.putData("cruisePresetList", cruisePresetList);

            context.fireNext("ISSUE_REMOVE_COMMAND");
        });

        taskFlow.addNode("ISSUE_REMOVE_COMMAND", context -> {
            JsonObject data = JsonObject.create()
                    .put("DeviceID", context.getData("deviceNumber"))
                    .put("ChannelNo", context.getData("channelNumber"))
                    .put("Password", context.getData("password"))
                    .put("msgid", context.getTaskId())
                    .put("FunCode", 178)
                    .put("CruiseList", JsonArray.create())
                    .put("CruiseGroupNo", context.getData("cruiseId"));

            Redis.silentMode().publish("WEB_FCM_SPG_MSG", data.stringify());

            context.awaitNext("RECEIVED_REMOVE_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_REMOVE_RESPONSE", context -> {
            JsonObject data = (JsonObject) context.getInput();
            Integer code = data.getInteger("ResultCode");
            if (code != 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error: " + code));
                return;
            }

            context.fireNext("ISSUE_ADD_COMMAND");
        });

        taskFlow.addNode("ISSUE_ADD_COMMAND", context -> {
            JsonArray presetList = JsonArray.create();
            @SuppressWarnings("unchecked")
            List<CruisePresetInfo> cruisePresetInfoList = (List<CruisePresetInfo>) context.getData("cruisePresetList");
            for (CruisePresetInfo cruisePresetInfo : cruisePresetInfoList) {
                Integer presetId = cruisePresetInfo.getPresetId();
                Integer speed = cruisePresetInfo.getSpeed();
                Integer interval = cruisePresetInfo.getInterval();
                JsonObject preset = JsonObject.create()
                        .put("CruisePointNo", 0)
                        .put("CruisePresetPointNo", presetId)
                        .put("CruiseStayDuration", interval)
                        .put("CruiseVelocity", speed);
                presetList.add(preset);
            }

            JsonObject data = JsonObject.create()
                    .put("DeviceID", context.getData("deviceNumber"))
                    .put("ChannelNo", context.getData("channelNumber"))
                    .put("Password", context.getData("password"))
                    .put("msgid", context.getTaskId())
                    .put("FunCode", 178)
                    .put("CruiseList", presetList)
                    .put("CruiseGroupNo", context.getData("cruiseId"));

            Redis.silentMode().publish("WEB_FCM_SPG_MSG", data.stringify());

            context.awaitNext("RECEIVED_ADD_RESPONSE", 3000L * cruisePresetInfoList.size());
        });

        taskFlow.addNode("RECEIVED_ADD_RESPONSE", context -> {
            JsonObject data = (JsonObject) context.getInput();
            Integer code = data.getInteger("ResultCode");
            if (code != 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error: " + code));
                return;
            }
            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

package io.iwd.csg.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.csg.entity.HistoryVideoFileCountQueryInitParams;
import io.iwd.csg.event.CsgDefaultTaskProceedEvent;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static io.iwd.csg.CsgConst.*;

public class HistoryVideoFileCountQueryTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HistoryVideoFileCountQuery", CsgDefaultTaskProceedEvent::new);

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            HistoryVideoFileCountQueryInitParams input = (HistoryVideoFileCountQueryInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            Integer channelNumber = input.getChannelNumber();
            Date startTime = input.getStartTime();
            Date endTime = input.getEndTime();
            HistoryVideoFileType[] historyVideoFileTypes = input.getHistoryVideoFileTypes();
            int typeCode = HistoryVideoFileType.codeOf(historyVideoFileTypes);
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String st = dateFormat.format(startTime);
            String et = dateFormat.format(endTime);

            JsonObject data = JsonObject.create()
                    .put("DeviceID", deviceNumber)
                    .put("ChannelNo", channelNumber)
                    .put("msgid", context.getTaskId())
                    .put("FunCode", 152)
                    .put("VideoStartTime", st)
                    .put("VideoEndTime", et)
                    .put("VideoType", typeCode);

            Redis.silentMode().publish("WEB_FCM_SPG_MSG", data.stringify());

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonObject data = (JsonObject) context.getInput();
            Integer code = data.getInteger("ResultCode");
            if (code != 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error: " + code));
                return;
            }
            Integer count = data.getInteger("VideoFileNumber");
            if (count == null || count < 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response error: " + code + ", wrong file count:" + count));
                return;
            }
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("count", count));
        });

        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }
}

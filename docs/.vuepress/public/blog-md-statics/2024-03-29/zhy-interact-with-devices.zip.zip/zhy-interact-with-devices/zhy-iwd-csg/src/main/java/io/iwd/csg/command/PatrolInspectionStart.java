package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.PatrolInspectionStartInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 巡检线开始命令。
 */
public class PatrolInspectionStart extends AdvancedCommand<Boolean> {
    
    private PatrolInspectionStartInitParams initParams = new PatrolInspectionStartInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return PatrolInspectionStart命令对象。
     */
    public PatrolInspectionStart setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PatrolInspectionStart命令对象。
     */
    public PatrolInspectionStart setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return PatrolInspectionStart命令对象。
     */
    public PatrolInspectionStart setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置巡检线id。
     * @param patrolInspectionId 巡检线id。
     * @return PatrolInspectionStart命令对象。
     */
    public PatrolInspectionStart setPatrolInspectionId(Integer patrolInspectionId) {
        this.initParams.setPatrolInspectionId(patrolInspectionId);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PatrolInspectionStart", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

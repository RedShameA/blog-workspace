package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.*;

public class FocusControlInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String password;

    private FocusControlOption focusControlOption;

    private Integer speed;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public FocusControlOption getFocusControlOption() {
        return this.focusControlOption;
    }

    public void setFocusControlOption(FocusControlOption lensControlOption) {
        this.focusControlOption = lensControlOption;
    }

    public Integer getSpeed() {
        return this.speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public void setControlSpeedOption(ControlSpeedOption controlSpeedOption) {
        this.speed = controlSpeedOption.speed();
    }

    @Override
    public FocusControlInitParams populateDefault() {
        if (this.focusControlOption == null) {
            this.focusControlOption = FocusControlOption.STOP;
        }
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        if (this.speed == null) {
            this.speed = ControlSpeedOption.ONE.speed();
        }
        return this;
    }

    @Override
    public FocusControlInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (this.focusControlOption == null) {
            throw new IllegalArgumentException("csg lens control option error");
        }
        if (this.speed == null || this.speed < MIN_CONTROL_SPEED || this.speed > MAX_CONTROL_SPEED) {
            throw new IllegalArgumentException("csg speed error");
        }
        return this;
    }

}

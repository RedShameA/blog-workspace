package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.AuxiliarySwitchControlInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import static io.iwd.csg.CsgConst.*;

/**
 * 辅助开关控制命令。
 */
public class AuxiliarySwitchControl extends AdvancedCommand<Boolean> {
    
    private AuxiliarySwitchControlInitParams initParams = new AuxiliarySwitchControlInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return AuxiliarySwitchControl命令对象。
     */
    public AuxiliarySwitchControl setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return AuxiliarySwitchControl命令对象。
     */
    public AuxiliarySwitchControl setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return AuxiliarySwitchControl命令对象。
     */
    public AuxiliarySwitchControl setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置设备密码。
     * @param auxiliarySwitchControlOption 辅助开关控制选项。
     * @return AuxiliarySwitchControl命令对象。
     */
    public AuxiliarySwitchControl setAuxiliarySwitchControlOption(AuxiliarySwitchControlOption auxiliarySwitchControlOption) {
        this.initParams.setAuxiliarySwitchControlOption(auxiliarySwitchControlOption);
        return this;
    }

    /**
     * 设置设备密码。
     * @param switchNumber 辅助开关号。
     * @return AuxiliarySwitchControl命令对象。
     */
    public AuxiliarySwitchControl setSwitchNumber(Integer switchNumber) {
        this.initParams.setSwitchNumber(switchNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "AuxiliarySwitchControl", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

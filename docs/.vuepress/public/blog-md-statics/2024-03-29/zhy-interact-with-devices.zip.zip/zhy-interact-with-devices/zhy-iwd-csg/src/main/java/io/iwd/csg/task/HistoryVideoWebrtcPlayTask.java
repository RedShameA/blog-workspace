package io.iwd.csg.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.http.srs.template.SrsExchangeSdpTemplate;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.csg.entity.HistoryVideoWebrtcPlayInitParams;
import io.iwd.csg.event.CsgDefaultTaskProceedEvent;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static io.iwd.csg.CsgConst.*;

public class HistoryVideoWebrtcPlayTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HistoryVideoWebrtcPlay", CsgDefaultTaskProceedEvent::new);

        //准备数据
        taskFlow.addNode("PREPARE_DATA", context -> {
            HistoryVideoWebrtcPlayInitParams input = (HistoryVideoWebrtcPlayInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            Integer channelNumber = input.getChannelNumber();
            Date startTime = input.getStartTime();
            Date endTime = input.getEndTime();
            Integer videoStreamProtocol = input.getVideoStreamProtocol().code();
            String mediaServerIp = input.getMediaServerIp();
            Integer mediaServerPort = input.getMediaServerPort();
            Boolean srsApiSsl = input.getSrsApiSsl();
            String srsApiIp = input.getSrsApiIp();
            Integer srsApiPort = input.getSrsApiPort();
            String webAddress = input.getWebAddress();
            String offerSdp = input.getOfferSdp();

            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String st = dateFormat.format(startTime);
            String et = dateFormat.format(endTime);

            context.putData("deviceNumber", deviceNumber);
            context.putData("channelNumber", channelNumber);
            context.putData("startTime", st);
            context.putData("endTime", et);
            context.putData("videoStreamProtocol", videoStreamProtocol);
            context.putData("mediaServerIp", mediaServerIp);
            context.putData("mediaServerPort", mediaServerPort);
            context.putData("srsApiSsl", srsApiSsl);
            context.putData("srsApiIp", srsApiIp);
            context.putData("srsApiPort", srsApiPort);
            context.putData("webAddress", webAddress);
            context.putData("offerSdp", offerSdp);

            context.fireNext("ISSUE_COMMAND");
        });

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("DeviceID", context.getData("deviceNumber"))
                    .put("ChannelNo", context.getData("channelNumber"))
                    .put("NetType", context.getData("videoStreamProtocol"))
                    .put("VideoStartTime", context.getData("startTime"))
                    .put("VideoEndTime", context.getData("endTime"))
                    .put("FunCode", 154)
                    .put("StreamIP", context.getData("mediaServerIp"))
                    .put("StreamPort", context.getData("mediaServerPort"))
                    .put("rtc", 1);

            Redis.silentMode().publish("WEB_FCM_SPG_MSG", data.stringify());

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer resultCode = input.getInteger("ResultCode");
            if (resultCode != 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Long ssrcValue = input.getLong("SSRC");
            if (ssrcValue == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response no ssrc"));
                return;
            }

            context.putData("ssrc", ssrcValue);

            context.fireNext("SAVE_HISTORY_VIDEO_INFO");
        });

        taskFlow.addNode("SAVE_HISTORY_VIDEO_INFO", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            Integer channelNumber = (Integer) context.getData("channelNumber");
            Integer videoStreamProtocol = (Integer) context.getData("videoStreamProtocol");
            String ssrc = context.getData("ssrc").toString();

            String script = "local dncnList = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(dncnList == false or dncnList == '') " +
                            "then redis.call('HSET', KEYS[1], KEYS[2], ARGV[1]); " +
                            "else redis.call('HSET', KEYS[1], KEYS[2], dncnList..','..ARGV[1]);" +
                            "end;" +
                            "redis.call('HSET', KEYS[1], KEYS[3], ARGV[2]);" +
                            "return 2;";

            Redis.interactiveMode().eval(script, 3,
                    REDIS_HISTORY_VIDEO_INFO_MAP_KEY, ssrc, "ts:" + ssrc,
                    deviceNumber + "_" + channelNumber + "_" + videoStreamProtocol, String.valueOf(System.currentTimeMillis()));

            context.awaitNext("SAVE_HISTORY_VIDEO_INFO_COMPLETED");
        });

        taskFlow.addNode("SAVE_HISTORY_VIDEO_INFO_COMPLETED", context -> {
            if (! (context.getInput() instanceof Number)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "redis error"));
                return;
            }

            context.fireNext("EXCHANGE_SDP");
        });

        taskFlow.addNode("EXCHANGE_SDP", context -> {
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            String webAddress = (String) context.getData("webAddress");
            String offerSdp = (String) context.getData("offerSdp");
            String streamPath = "/live/chid" + context.getData("ssrc");

            new SrsExchangeSdpTemplate(srsApiSsl, srsApiIp, srsApiPort, webAddress, offerSdp, streamPath).send();
            context.awaitNext("SRS_RESPONSE_ANSWER_SDP");
        });

        taskFlow.addNode("SRS_RESPONSE_ANSWER_SDP", context -> {
            JsonObject input = (JsonObject) context.getInput();
            if (input == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0003,
                        "can not get answer sdp"));
                return;
            }
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("sdp", input.getString("sdp"))
                    .put("ssrc", context.getData("ssrc")));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

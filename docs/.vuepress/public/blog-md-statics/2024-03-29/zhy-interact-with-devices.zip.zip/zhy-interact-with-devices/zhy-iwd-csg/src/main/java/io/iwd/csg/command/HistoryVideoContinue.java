package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.HistoryVideoContinueInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import static io.iwd.csg.CsgConst.*;

/**
 * 录像回放继续命令。
 */
public class HistoryVideoContinue extends AdvancedCommand<Boolean> {

    private HistoryVideoContinueInitParams initParams = new HistoryVideoContinueInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoPause命令对象。
     */
    public HistoryVideoContinue setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoPause命令对象。
     */
    public HistoryVideoContinue setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置录像回放速度选项。
     * @param historyVideoSpeedOption 录像回放速度选项。
     * @return HistoryVideoPause命令对象。
     */
    public HistoryVideoContinue setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.initParams.setHistoryVideoSpeedOption(historyVideoSpeedOption);
        return this;
    }

    /**
     * 设置ssrc。
     * @param ssrc ssrc。
     * @return HistoryVideoPause命令对象。
     */
    public HistoryVideoContinue setSsrc(Long ssrc) {
        this.initParams.setSsrc(ssrc);
        return this;
    }
    
    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoContinue", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

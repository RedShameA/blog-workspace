package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.CruiseRemoveInitParams;
import io.iwd.csg.entity.CruisePresetInfo;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import java.util.Collection;

import static io.iwd.csg.CsgConst.CruiseSpeedOption;

/**
 * 巡航线删除命令。
 */
public class CruiseRemove extends AdvancedCommand<Boolean> {
    
    private CruiseRemoveInitParams initParams = new CruiseRemoveInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return CruiseRemove命令对象。
     */
    public CruiseRemove setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return CruiseRemove命令对象。
     */
    public CruiseRemove setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return CruiseRemove命令对象。
     */
    public CruiseRemove setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置巡航线id。
     * @param cruiseId 巡航线id。
     * @return CruiseRemove命令对象。
     */
    public CruiseRemove setCruiseId(Integer cruiseId) {
        this.initParams.setCruiseId(cruiseId);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "CruiseRemove", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.csg.entity.HistoryVideoStopInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 录像文件停止播放命令。
 */
public class HistoryVideoStop extends AdvancedCommand<Boolean> {
    
    private HistoryVideoStopInitParams initParams = new HistoryVideoStopInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoStop命令对象。
     */
    public HistoryVideoStop setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoStop命令对象。
     */
    public HistoryVideoStop setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置ssrc。
     * @param ssrc ssrc。
     * @return HistoryVideoStop命令对象。
     */
    public HistoryVideoStop setSsrc(String ssrc) {
        this.initParams.setSsrc(ssrc);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoStop", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject rlt = (JsonObject) result.getResult();
                Integer code = rlt.getInteger("code");
                return Code.isCompleted(code);
            }
            return false;
        }, time);
    }
    
}

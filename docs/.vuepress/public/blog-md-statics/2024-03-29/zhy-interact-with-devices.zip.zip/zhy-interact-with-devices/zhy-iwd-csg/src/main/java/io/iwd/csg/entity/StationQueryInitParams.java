package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

public class StationQueryInitParams implements TaskInitParams {

    private String deviceNumber;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    @Override
    public StationQueryInitParams populateDefault() {
        return this;
    }

    @Override
    public StationQueryInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        return this;
    }
}

package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.PatrolInspectionPointModifyInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 巡检点修改命令。
 */
public class PatrolInspectionPointModify extends AdvancedCommand<Boolean> {
    
    private PatrolInspectionPointModifyInitParams initParams = new PatrolInspectionPointModifyInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return PatrolInspectionPointModify命令对象。
     */
    public PatrolInspectionPointModify setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PatrolInspectionPointModify命令对象。
     */
    public PatrolInspectionPointModify setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return PatrolInspectionPointModify命令对象。
     */
    public PatrolInspectionPointModify setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置巡检线id。
     * @param patrolInspectionId 巡检线id。
     * @return PatrolInspectionPointModify命令对象。
     */
    public PatrolInspectionPointModify setPatrolInspectionId(Integer patrolInspectionId) {
        this.initParams.setPatrolInspectionId(patrolInspectionId);
        return this;
    }

    /**
     * 设置巡检点id。
     * @param patrolInspectionPointId 巡检点id。
     * @return PatrolInspectionPointModify命令对象。
     */
    public PatrolInspectionPointModify setPatrolInspectionPointId(Integer patrolInspectionPointId) {
        this.initParams.setPatrolInspectionPointId(patrolInspectionPointId);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PatrolInspectionPointModify", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.*;

public class OsdConfigInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String password;

    private Boolean timeVisible;

    private Boolean textVisible;

    private String textContent;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getTimeVisible() {
        return this.timeVisible;
    }

    public void setTimeVisible(Boolean timeVisible) {
        this.timeVisible = timeVisible;
    }

    public Boolean getTextVisible() {
        return this.textVisible;
    }

    public void setTextVisible(Boolean textVisible) {
        this.textVisible = textVisible;
    }

    public String getTextContent() {
        return this.textContent;
    }

    public void setTextContent(String textContent) {
        this.textContent = textContent;
    }

    @Override
    public OsdConfigInitParams populateDefault() {
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        if (this.timeVisible == null) {
            this.timeVisible = Boolean.TRUE;
        }
        if (this.textVisible == null) {
            this.textVisible = Boolean.TRUE;
        }
        return this;
    }

    @Override
    public OsdConfigInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (this.timeVisible == null) {
            throw new IllegalArgumentException("csg osd time visible error");
        }
        if (this.textVisible == null) {
            throw new IllegalArgumentException("csg osd text visible error");
        }
        if (this.textContent == null || this.textContent.length() > (65535 - 7)) { //报文最大字节数 不代表设备一定支持
            throw new IllegalArgumentException("csg osd text content error");
        }
        return this;
    }
    
}

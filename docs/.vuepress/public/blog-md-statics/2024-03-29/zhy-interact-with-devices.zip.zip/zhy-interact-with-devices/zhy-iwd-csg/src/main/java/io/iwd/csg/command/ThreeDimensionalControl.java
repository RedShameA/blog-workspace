package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.ThreeDimensionalControlInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

public class ThreeDimensionalControl extends AdvancedCommand<Boolean> {

    private ThreeDimensionalControlInitParams initParams = new ThreeDimensionalControlInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return ThreeDimensionalControl命令对象。
     */
    public ThreeDimensionalControl setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return ThreeDimensionalControl命令对象。
     */
    public ThreeDimensionalControl setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return ThreeDimensionalControl命令对象。
     */
    public ThreeDimensionalControl setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置起始点x坐标。
     * @param startPointXCoordinate 起始点x坐标。
     * @return ThreeDimensionalControl命令对象。
     */
    public ThreeDimensionalControl setStartPointXCoordinate(Integer startPointXCoordinate) {
        this.initParams.setStartPointXCoordinate(startPointXCoordinate);
        return this;
    }

    /**
     * 设置起始点y坐标。
     * @param startPointYCoordinate 起始点y坐标。
     * @return ThreeDimensionalControl命令对象。
     */
    public ThreeDimensionalControl setStartPointYCoordinate(Integer startPointYCoordinate) {
        this.initParams.setStartPointYCoordinate(startPointYCoordinate);
        return this;
    }

    /**
     * 设置结束点x坐标。
     * @param endPointXCoordinate 结束点x坐标。
     * @return ThreeDimensionalControl命令对象。
     */
    public ThreeDimensionalControl setEndPointXCoordinate(Integer endPointXCoordinate) {
        this.initParams.setEndPointXCoordinate(endPointXCoordinate);
        return this;
    }

    /**
     * 设置结束点x坐标。
     * @param endPointYCoordinate 结束点x坐标。
     * @return ThreeDimensionalControl命令对象。
     */
    public ThreeDimensionalControl setEndPointYCoordinate(Integer endPointYCoordinate) {
        this.initParams.setEndPointYCoordinate(endPointYCoordinate);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "ThreeDimensionalControl", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

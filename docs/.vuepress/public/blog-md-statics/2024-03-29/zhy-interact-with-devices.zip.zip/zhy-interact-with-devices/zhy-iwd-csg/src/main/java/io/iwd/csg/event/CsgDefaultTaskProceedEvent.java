package io.iwd.csg.event;

import io.iwd.common.event.TaskProceedEvent;

public class CsgDefaultTaskProceedEvent extends TaskProceedEvent {

    public CsgDefaultTaskProceedEvent(String taskId, Object data) {
        super(taskId, data);
    }

}

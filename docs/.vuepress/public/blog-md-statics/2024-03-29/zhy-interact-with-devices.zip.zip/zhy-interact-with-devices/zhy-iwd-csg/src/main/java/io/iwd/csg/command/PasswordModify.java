package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.PasswordModifyInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 密码修改命令。
 */
public class PasswordModify extends AdvancedCommand<Boolean> {
    
    private PasswordModifyInitParams initParams = new PasswordModifyInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return PasswordModify命令对象。
     */
    public PasswordModify setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置原设备密码。
     * @param oldPassword 原设备密码。
     * @return PasswordModify命令对象。
     */
    public PasswordModify setOldPassword(String oldPassword) {
        this.initParams.setOldPassword(oldPassword);
        return this;
    }

    /**
     * 设置新设备密码。
     * @param newPassword 设备密码。
     * @return PasswordModify命令对象。
     */
    public PasswordModify setNewPassword(String newPassword) {
        this.initParams.setNewPassword(newPassword);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PasswordModify", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
    
}

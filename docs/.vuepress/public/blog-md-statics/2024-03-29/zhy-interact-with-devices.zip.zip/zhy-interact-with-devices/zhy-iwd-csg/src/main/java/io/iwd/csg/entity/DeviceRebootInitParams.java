package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.*;

public class DeviceRebootInitParams implements TaskInitParams {

    private String deviceNumber;

    private String password;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public DeviceRebootInitParams populateDefault() {
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        return this;
    }

    @Override
    public DeviceRebootInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        return this;
    }
}

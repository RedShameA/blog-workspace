package io.iwd.csg.util;

import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;

public class CsgValidator {

    public static boolean isCsgDeviceNumber(String deviceNumber) {
        if (StringUtil.isEmpty(deviceNumber)) {
            return false;
        }
        int length = deviceNumber.length();
        if (length == 0 || length > 6) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            char c = deviceNumber.charAt(i);
            if ((c < '0' || c > '9') && (c < 'A' || c > 'z')) {
                return false;
            }
        }
        return true;
    }

    public static boolean isCsgChannelNumber(String channelNumber) {
        if (!Validator.isPositiveIntegerNumber(channelNumber)) {
            return false;
        }
        int cn = Integer.parseInt(channelNumber);
        return cn >= 1 && cn <= 255;
    }

    public static boolean isCsgChannelNumber(Integer channelNumber) {
        return channelNumber >= 1 && channelNumber <= 255;
    }

    public static boolean isCsgPassword(String password) {
        if (password == null) {
            return false;
        }
        int length = password.length();
        if (length != 4) {
            return false;
        }
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'z')) {
                continue;
            }
            return false;
        }
        return true;
    }

}

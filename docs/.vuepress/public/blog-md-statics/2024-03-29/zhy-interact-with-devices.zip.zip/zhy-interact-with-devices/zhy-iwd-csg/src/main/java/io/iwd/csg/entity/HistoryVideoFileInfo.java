package io.iwd.csg.entity;

import io.iwd.csg.CsgConst;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HistoryVideoFileInfo implements Comparable<HistoryVideoFileInfo> {

    private final Date startTime;

    private final Date endTime;

    private final Integer size;

    private final CsgConst.HistoryVideoFileType historyVideoFileType;

    public HistoryVideoFileInfo(Date startTime, Date endTime, Integer size, CsgConst.HistoryVideoFileType historyVideoFileType) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.size = size;
        this.historyVideoFileType = historyVideoFileType;
    }

    public Date getStartTime() {
        return startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public Integer getSize() {
        return size;
    }

    public CsgConst.HistoryVideoFileType getHistoryVideoFileType() {
        return historyVideoFileType;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return "{\"startTime\":\"" + dateFormat.format(this.startTime) +
                "\",\"endTime\":\"" + dateFormat.format(this.endTime) +
                "\",\"size\":" + this.size +
                ",\"historyVideoFileType\":\"" + this.historyVideoFileType.name() + "(" + this.historyVideoFileType.code() + ")\"}";
    }

    @Override
    public int compareTo(HistoryVideoFileInfo o) {
        return this.startTime.compareTo(o.startTime);
    }
}

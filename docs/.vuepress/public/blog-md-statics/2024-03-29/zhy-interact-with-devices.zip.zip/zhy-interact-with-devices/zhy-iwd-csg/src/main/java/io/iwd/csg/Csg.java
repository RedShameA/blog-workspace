package io.iwd.csg;

import io.iwd.csg.command.*;

public final class Csg {

    /**
     * webrtc实时视频播放命令。
     */
    public static RealTimeVideoWebrtcPlay realTimeVideoWebrtcPlay() {
        return new RealTimeVideoWebrtcPlay();
    }

    /**
     * 镜头控制命令。
     */
    public static LensControl lensControl() {
        return new LensControl();
    }

    /**
     * 变倍控制命令。
     */
    public static ZoomControl zoomControl() {
        return new ZoomControl();
    }

    /**
     * 光圈控制命令。
     */
    public static ApertureControl apertureControl() {
        return new ApertureControl();
    }

    /**
     * 调焦控制命令。
     */
    public static FocusControl focusControl() {
        return new FocusControl();
    }

    /**
     * 辅助开关控制命令。
     */
    public static AuxiliarySwitchControl auxiliarySwitchControl() {
        return new AuxiliarySwitchControl();
    }

    /**
     * 3d控球命令。
     */
    public static ThreeDimensionalControl threeDimensionalControl() {
        return new ThreeDimensionalControl();
    }

    /**
     * 预置位重新定位命令。
     */
    public static PresetRelocate presetRelocate() {
        return new PresetRelocate();
    }

    /**
     * 预置位调用命令。
     */
    public static PresetCall presetCall() {
        return new PresetCall();
    }

    /**
     * 预置位删除命令。
     */
    public static PresetRemove presetRemove() {
        return new PresetRemove();
    }

    /**
     * 巡航线设置命令。
     */
    public static CruiseConfig cruiseConfig() {
        return new CruiseConfig();
    }

    /**
     * 巡航线删除命令。
     */
    public static CruiseRemove cruiseRemove() {
        return new CruiseRemove();
    }

    /**
     * 巡航线调用命令。
     */
    public static CruiseStart cruiseStart() {
        return new CruiseStart();
    }

    /**
     * 巡航线停止命令。
     */
    public static CruiseStop cruiseStop() {
        return new CruiseStop();
    }

    /**
     * 巡检点追加命令。
     */
    public static PatrolInspectionPointAppend patrolInspectionPointAppend() {
        return new PatrolInspectionPointAppend();
    }

    /**
     * 巡检点删除命令。
     */
    public static PatrolInspectionPointRemove patrolInspectionPointRemove() {
        return new PatrolInspectionPointRemove();
    }

    /**
     * 巡检点修改命令。
     */
    public static PatrolInspectionPointModify patrolInspectionPointModify() {
        return new PatrolInspectionPointModify();
    }

    /**
     * 巡检线删除命令。
     */
    public static PatrolInspectionRemove patrolInspectionRemove() {
        return new PatrolInspectionRemove();
    }

    /**
     * 巡检点数量查询命令。
     */
    public static PatrolInspectionPointCountQuery patrolInspectionPointCountQuery() {
        return new PatrolInspectionPointCountQuery();
    }

    /**
     * 巡检线开始命令。
     */
    public static PatrolInspectionStart patrolInspectionStart() {
        return new PatrolInspectionStart();
    }

    /**
     * 巡检线停止命令。
     */
    public static PatrolInspectionStop patrolInspectionStop() {
        return new PatrolInspectionStop();
    }

    /**
     * 录像文件数量查询命令。
     */
    public static HistoryVideoFileCountQuery historyVideoFileCountQuery() {
        return new HistoryVideoFileCountQuery();
    }

    /**
     * 录像文件查询命令。
     */
    public static HistoryVideoFileQuery historyVideoFileQuery() {
        return new HistoryVideoFileQuery();
    }

    /**
     * webrtc录像文件播放命令。
     */
    public static HistoryVideoWebrtcPlay historyVideoWebrtcPlay() {
        return new HistoryVideoWebrtcPlay();
    }

    /**
     * 录像文件暂停命令。
     */
    public static HistoryVideoPause historyVideoPause() {
        return new HistoryVideoPause();
    }

    /**
     * 录像文件继续命令。
     */
    public static HistoryVideoContinue historyVideoContinue() {
        return new HistoryVideoContinue();
    }

    /**
     * 录像文件速度控制命令。
     */
    public static HistoryVideoSpeedControl historyVideoSpeedControl() {
        return new HistoryVideoSpeedControl();
    }

    /**
     * 录像文件重新定位命令。
     */
    public static HistoryVideoRelocate historyVideoRelocate() {
        return new HistoryVideoRelocate();
    }

    /**
     * 录像文件停止播放命令。
     */
    public static HistoryVideoStop historyVideoStop() {
        return new HistoryVideoStop();
    }

    /**
     * 密码修改命令。
     */
    public static PasswordModify passwordModify() {
        return new PasswordModify();
    }

    /**
     * 设备重启命令。
     */
    public static DeviceReboot deviceReboot() {
        return new DeviceReboot();
    }

    /**
     * osd参数设置命令。
     */
    public static OsdConfig osdConfig() {
        return new OsdConfig();
    }

    /**
     * osd参数查询命令。
     */
    public static OsdQuery osdQuery() {
        return new OsdQuery();
    }

    /**
     * 主站信息设置命令。
     */
    public static StationConfig stationConfig() {
        return new StationConfig();
    }

    /**
     * 主站信息查询命令。
     */
    public static StationQuery stationQuery() {
        return new StationQuery();
    }

}

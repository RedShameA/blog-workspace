package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.CruiseConfigInitParams;
import io.iwd.csg.entity.CruisePresetInfo;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import java.util.Collection;

import static io.iwd.csg.CsgConst.*;

/**
 * 巡航线设置命令。
 */
public class CruiseConfig extends AdvancedCommand<Boolean> {
    
    private CruiseConfigInitParams initParams = new CruiseConfigInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return CruiseConfig命令对象。
     */
    public CruiseConfig setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return CruiseConfig命令对象。
     */
    public CruiseConfig setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return CruiseConfig命令对象。
     */
    public CruiseConfig setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置巡航线id。
     * @param cruiseId 巡航线id。
     * @return CruiseConfig命令对象。
     */
    public CruiseConfig setCruiseId(Integer cruiseId) {
        this.initParams.setCruiseId(cruiseId);
        return this;
    }

    /**
     * 添加巡航线预置位。
     * @param presetId 预置位id。
     * @param speed 镜头转向预置位的速度。
     * @param interval 在预置位的停留时间。
     * @return CruiseConfig命令对象。
     */
    public CruiseConfig addPreset(Integer presetId, Integer speed, Integer interval) {
        this.initParams.addPreset(presetId, speed, interval);
        return this;
    }

    /**
     * 添加巡航线预置位。
     * @param presetId 预置位id。
     * @param cruiseSpeedOption 镜头转向预置位的速度选项。
     * @param interval 在预置位的停留时间。
     * @return CruiseConfig命令对象。
     */
    public CruiseConfig addPreset(Integer presetId, CruiseSpeedOption cruiseSpeedOption, Integer interval) {
        this.initParams.addPreset(presetId, cruiseSpeedOption, interval);
        return this;
    }

    /**
     * 添加巡航线预置位。
     * @param presetList 巡航线预置位信息列表。
     * @return CruiseConfig命令对象。
     */
    public CruiseConfig addPreset(Collection<CruisePresetInfo> presetList) {
        this.initParams.addPreset(presetList);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "CruiseConfig", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

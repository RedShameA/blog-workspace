package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import io.iwd.csg.CsgConst.HistoryVideoSpeedOption;

public class HistoryVideoContinueInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private HistoryVideoSpeedOption historyVideoSpeedOption;

    private Long ssrc;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public HistoryVideoSpeedOption getHistoryVideoSpeedOption() {
        return this.historyVideoSpeedOption;
    }

    public void setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.historyVideoSpeedOption = historyVideoSpeedOption;
    }

    public Long getSsrc() {
        return this.ssrc;
    }

    public void setSsrc(Long ssrc) {
        this.ssrc = ssrc;
    }

    @Override
    public HistoryVideoContinueInitParams populateDefault() {
        if (this.historyVideoSpeedOption == null) {
            this.historyVideoSpeedOption = HistoryVideoSpeedOption.X1;
        }
        return this;
    }

    @Override
    public HistoryVideoContinueInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (this.historyVideoSpeedOption == null) {
            throw new IllegalArgumentException("csg history video speed option error");
        }
        if (this.ssrc == null || this.ssrc > 0xFFFFFFFFL) {
            throw new IllegalArgumentException("csg ssrc error");
        }
        return this;
    }
}

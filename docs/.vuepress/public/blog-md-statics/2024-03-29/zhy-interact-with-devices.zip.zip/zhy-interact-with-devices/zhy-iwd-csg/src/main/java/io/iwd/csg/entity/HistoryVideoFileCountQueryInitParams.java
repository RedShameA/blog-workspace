package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import java.util.Date;

import static io.iwd.csg.CsgConst.*;

public class HistoryVideoFileCountQueryInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private Date startTime;

    private Date endTime;

    private HistoryVideoFileType[] historyVideoFileTypes;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public HistoryVideoFileType[] getHistoryVideoFileTypes() {
        return this.historyVideoFileTypes;
    }

    public void setHistoryVideoFileTypes(HistoryVideoFileType... historyVideoFileType) {
        this.historyVideoFileTypes = historyVideoFileType;
    }

    @Override
    public HistoryVideoFileCountQueryInitParams populateDefault() {
        if (this.historyVideoFileTypes == null) {
            this.historyVideoFileTypes = new HistoryVideoFileType[] {HistoryVideoFileType.ALL};
        }
        return this;
    }

    @Override
    public HistoryVideoFileCountQueryInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (this.startTime == null) {
            throw new IllegalArgumentException("csg start time format error");
        }
        if (this.endTime == null) {
            throw new IllegalArgumentException("csg end time format error");
        }
        if (this.startTime.compareTo(this.endTime) >= 0) {
            throw new IllegalArgumentException("csg start time is earlier than end time");
        }
        if (this.historyVideoFileTypes == null || this.historyVideoFileTypes.length == 0) {
            throw new IllegalArgumentException("csg history video file type error");
        }
        return this;
    }

}

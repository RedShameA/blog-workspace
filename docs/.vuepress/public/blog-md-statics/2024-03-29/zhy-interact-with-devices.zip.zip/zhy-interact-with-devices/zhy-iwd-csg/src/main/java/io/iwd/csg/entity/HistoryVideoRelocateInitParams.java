package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.util.Validator;
import io.iwd.csg.CsgConst.HistoryVideoSpeedOption;
import io.iwd.csg.util.CsgValidator;

public class HistoryVideoRelocateInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private HistoryVideoSpeedOption historyVideoSpeedOption;

    private Integer offset;

    private Long ssrc;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public HistoryVideoSpeedOption getHistoryVideoSpeedOption() {
        return this.historyVideoSpeedOption;
    }

    public void setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.historyVideoSpeedOption = historyVideoSpeedOption;
    }

    public Integer getOffset() {
        return this.offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Long getSsrc() {
        return this.ssrc;
    }

    public void setSsrc(Long ssrc) {
        this.ssrc = ssrc;
    }

    @Override
    public HistoryVideoRelocateInitParams populateDefault() {
        if (this.historyVideoSpeedOption == null) {
            this.historyVideoSpeedOption = HistoryVideoSpeedOption.X1;
        }
        if (this.offset == null) {
            this.offset = 0;
        }
        return this;
    }

    @Override
    public HistoryVideoRelocateInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (this.historyVideoSpeedOption == null) {
            throw new IllegalArgumentException("csg history video speed option error");
        }
        if (this.offset == null || this.offset < 0 || this.offset > 65535) {
            throw new IllegalArgumentException("csg history video offset error");
        }
        if (this.ssrc == null || this.ssrc > 0xFFFFFFFFL) {
            throw new IllegalArgumentException("csg ssrc error");
        }
        return this;
    }
}

package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import java.util.Date;

import static io.iwd.csg.CsgConst.*;

public class HistoryVideoFileQueryInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private Date startTime;

    private Date endTime;
    
    private HistoryVideoFileType[] historyVideoFileTypes;

    private Integer fileTotalCount;

    private Integer startIndex;

    private Integer endIndex;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public HistoryVideoFileType[] getHistoryVideoFileTypes() {
        return this.historyVideoFileTypes;
    }

    public void setHistoryVideoFileTypes(HistoryVideoFileType... historyVideoFileType) {
        this.historyVideoFileTypes = historyVideoFileType;
    }

    public Integer getFileTotalCount() {
        return this.fileTotalCount;
    }

    public void setFileTotalCount(Integer fileTotalCount) {
        this.fileTotalCount = fileTotalCount;
    }

    public Integer getStartIndex() {
        return this.startIndex;
    }

    public void setStartIndex(Integer startIndex) {
        this.startIndex = startIndex;
    }

    public Integer getEndIndex() {
        return this.endIndex;
    }

    public void setEndIndex(Integer endIndex) {
        this.endIndex = endIndex;
    }

    @Override
    public HistoryVideoFileQueryInitParams populateDefault() {
        if (this.historyVideoFileTypes == null) {
            this.historyVideoFileTypes = new HistoryVideoFileType[] {HistoryVideoFileType.ALL};
        }
        return this;
    }

    @Override
    public HistoryVideoFileQueryInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (this.startTime == null) {
            throw new IllegalArgumentException("csg start time format error");
        }
        if (this.endTime == null) {
            throw new IllegalArgumentException("csg end time format error");
        }
        if (this.startTime.compareTo(this.endTime) >= 0) {
            throw new IllegalArgumentException("csg start time is earlier than end time");
        }
        if (this.historyVideoFileTypes == null || this.historyVideoFileTypes.length == 0) {
            throw new IllegalArgumentException("csg history video file type error");
        }
        if (this.fileTotalCount == null || this.fileTotalCount < 0 || this.fileTotalCount > 65535) {
            throw new IllegalArgumentException("csg file total count error");
        }
        if (this.startIndex == null || this.startIndex > this.fileTotalCount || this.startIndex > MAX_HISTORY_FILE_QUERY_COUNT) {
            throw new IllegalArgumentException("csg start index error");
        }
        if (this.endIndex == null || this.endIndex > this.fileTotalCount || this.endIndex > MAX_HISTORY_FILE_QUERY_COUNT) {
            throw new IllegalArgumentException("csg end index error");
        }
        if (this.startIndex.compareTo(this.endIndex) >= 0) {
            throw new IllegalArgumentException("csg start index is bigger than end index");
        }
        return this;
    }
    
}

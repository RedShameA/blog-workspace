package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.HistoryVideoPauseInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 录像回放暂停命令。
 */
public class HistoryVideoPause extends AdvancedCommand<Boolean> {

    private HistoryVideoPauseInitParams initParams = new HistoryVideoPauseInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoPause命令对象。
     */
    public HistoryVideoPause setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoPause命令对象。
     */
    public HistoryVideoPause setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置ssrc。
     * @param ssrc ssrc。
     * @return HistoryVideoPause命令对象。
     */
    public HistoryVideoPause setSsrc(Long ssrc) {
        this.initParams.setSsrc(ssrc);
        return this;
    }
    
    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoPause", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import static io.iwd.csg.CsgConst.*;

public class CruiseConfigInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String password;

    private Integer cruiseId;

    private List<CruisePresetInfo> cruisePresetList = new LinkedList<>();

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getCruiseId() {
        return this.cruiseId;
    }

    public void setCruiseId(Integer cruiseId) {
        this.cruiseId = cruiseId;
    }

    public List<CruisePresetInfo> getCruisePresetList() {
        return this.cruisePresetList;
    }

    public void addPreset(Integer presetId, Integer speed, Integer interval) {
        CruisePresetInfo cruisePresetInfo = new CruisePresetInfo(presetId, interval, speed);
        this.cruisePresetList.add(cruisePresetInfo);
    }

    public void addPreset(Integer presetId, CruiseSpeedOption cruiseSpeedOption, Integer interval) {
        CruisePresetInfo cruisePresetInfo = new CruisePresetInfo(presetId, cruiseSpeedOption, interval);
        this.cruisePresetList.add(cruisePresetInfo);
    }

    public void addPreset(Collection<CruisePresetInfo> presetList) {
        this.cruisePresetList.addAll(presetList);
    }

    @Override
    public CruiseConfigInitParams populateDefault() {
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        return this;
    }

    @Override
    public CruiseConfigInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (this.cruiseId == null || this.cruiseId < MIN_CRUISE_ID_NUMBER || this.cruiseId > MAX_CRUISE_ID_NUMBER) {
            throw new IllegalArgumentException("csg cruise id format error");
        }
        if (this.cruisePresetList.size() > 32) {
            throw new IllegalArgumentException("csg cruise preset list size error");
        }
        for (CruisePresetInfo presetInfo : this.cruisePresetList) {
            Integer presetId = presetInfo.getPresetId();
            Integer speed = presetInfo.getSpeed();
            Integer interval = presetInfo.getInterval();
            if (presetId == null || presetId < MIN_PRESET_ID_NUMBER || presetId > MAX_PRESET_ID_NUMBER) {
                throw new IllegalArgumentException("csg cruise preset id error");
            }
            if (speed == null || speed < MIN_CRUISE_SPEED || speed > MAX_CRUISE_SPEED) {
                throw new IllegalArgumentException("csg cruise speed error");
            }
            if (interval == null || interval < MIN_CRUISE_PRESET_INTERVAL || interval > MAX_CRUISE_PRESET_INTERVAL) {
                throw new IllegalArgumentException("csg cruise preset interval error");
            }
        }
        return this;
    }
    
}

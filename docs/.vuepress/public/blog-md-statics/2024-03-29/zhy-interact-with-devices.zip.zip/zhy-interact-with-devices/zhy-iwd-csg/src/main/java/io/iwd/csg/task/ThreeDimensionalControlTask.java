package io.iwd.csg.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.csg.entity.ThreeDimensionalControlInitParams;
import io.iwd.csg.event.CsgDefaultTaskProceedEvent;

import static io.iwd.csg.CsgConst.TASK_PREFIX;

public class ThreeDimensionalControlTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "ThreeDimensionalControl", CsgDefaultTaskProceedEvent::new);

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            ThreeDimensionalControlInitParams input = (ThreeDimensionalControlInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            Integer channelNumber = input.getChannelNumber();
            String password = input.getPassword();
            Integer startPointXCoordinate = input.getStartPointXCoordinate();
            Integer startPointYCoordinate = input.getStartPointYCoordinate();
            Integer endPointXCoordinate = input.getEndPointXCoordinate();
            Integer endPointYCoordinate = input.getEndPointYCoordinate();

            JsonObject data = JsonObject.create()
                    .put("DeviceID", deviceNumber)
                    .put("ChannelNo", channelNumber)
                    .put("Password", password)
                    .put("msgid", context.getTaskId())
                    .put("FunCode", 0xB1)
                    .put("StartX", startPointXCoordinate)
                    .put("StartY", startPointYCoordinate)
                    .put("EndX", endPointXCoordinate)
                    .put("EndY", endPointYCoordinate);

            Redis.silentMode().publish("WEB_FCM_SPG_MSG", data.stringify());

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonObject data = (JsonObject) context.getInput();
            Integer code = data.getInteger("ResultCode");
            if (code != 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error: " + code));
                return;
            }
            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }

}

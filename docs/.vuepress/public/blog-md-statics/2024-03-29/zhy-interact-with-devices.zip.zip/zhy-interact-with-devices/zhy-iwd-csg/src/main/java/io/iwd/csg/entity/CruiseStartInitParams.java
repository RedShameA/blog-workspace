package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.CsgConst;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.*;

public class CruiseStartInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String password;

    private Integer cruiseId;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getCruiseId() {
        return this.cruiseId;
    }

    public void setCruiseId(Integer cruiseId) {
        this.cruiseId = cruiseId;
    }

    @Override
    public CruiseStartInitParams populateDefault() {
        if (this.password == null) {
            this.password = CsgConst.INITIAL_PASSWORD;
        }
        return this;
    }

    @Override
    public CruiseStartInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (this.cruiseId == null || this.cruiseId < MIN_CRUISE_ID_NUMBER || this.cruiseId > MAX_CRUISE_ID_NUMBER) {
            throw new IllegalArgumentException("csg cruise id format error");
        }
        return this;
    }
}

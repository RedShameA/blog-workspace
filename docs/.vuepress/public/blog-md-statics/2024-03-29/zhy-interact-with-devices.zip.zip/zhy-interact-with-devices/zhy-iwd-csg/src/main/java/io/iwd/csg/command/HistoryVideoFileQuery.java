package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.csg.entity.HistoryVideoFileInfo;
import io.iwd.csg.entity.HistoryVideoFileQueryInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static io.iwd.csg.CsgConst.HistoryVideoFileType;

/**
 * 录像文件查询命令。
 */
public class HistoryVideoFileQuery extends AdvancedCommand<List<HistoryVideoFileInfo>> {
    
    private HistoryVideoFileQueryInitParams initParams = new HistoryVideoFileQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置查询开始时间。
     * @param startTime 查询开始时间。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setStartTime(Date startTime) {
        this.initParams.setStartTime(startTime);
        return this;
    }

    /**
     * 设置查询结束时间。
     * @param endTime 查询结束时间。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setEndTime(Date endTime) {
        this.initParams.setEndTime(endTime);
        return this;
    }

    /**
     * 设置查询录像类型。
     * @param historyVideoFileType 查询录像类型。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setHistoryVideoFileTypes(HistoryVideoFileType... historyVideoFileType) {
        this.initParams.setHistoryVideoFileTypes(historyVideoFileType);
        return this;
    }

    /**
     * 设置文件总数，这个参数一般通过{@link io.iwd.csg.command.HistoryVideoFileCountQuery}命令获取。
     * @param fileTotalCount 文件总数。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setFileTotalCount(Integer fileTotalCount) {
        this.initParams.setFileTotalCount(fileTotalCount);
        return this;
    }

    /**
     * 设置查询开始索引。最大不超过48。
     * @param startIndex 查询开始索引。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setStartIndex(Integer startIndex) {
        this.initParams.setStartIndex(startIndex);
        return this;
    }

    /**
     * 设置查询结束索引。最大不超过48。
     * @param endIndex 查询结束索引。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setEndIndex(Integer endIndex) {
        this.initParams.setEndIndex(endIndex);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoFileQuery", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public List<HistoryVideoFileInfo> await(long time) {
        return super.await(result -> {
            if (!result.isCompleted() || !result.hasResult()) {
                return Collections.emptyList();
            }
            JsonObject completedResult = (JsonObject) result.getResult();
            JsonArray data = completedResult.getJsonArray("data");
            List<HistoryVideoFileInfo> list = new ArrayList<>(data.size());
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 0; i < data.size(); i++) {
                JsonObject fileInfo = data.getJsonObject(i);
                String st = fileInfo.getString("startTime");
                String et = fileInfo.getString("endTime");
                Integer size = fileInfo.getInteger("size");
                Integer typeCode = fileInfo.getInteger("typeCode");
                Date startTime, endTime;
                try {
                    startTime = dateFormat.parse(st);
                    endTime = dateFormat.parse(et);
                } catch (ParseException ex) {
                    startTime = null;
                    endTime = null;
                }
                HistoryVideoFileInfo historyVideoFileInfo =
                        new HistoryVideoFileInfo(startTime, endTime, size, HistoryVideoFileType.nameOf(typeCode));
                list.add(historyVideoFileInfo);
            }
            return list;
        }, time);
    }
    
}

package io.iwd.csg.event;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;

public class CsgDefaultTaskStartEvent extends TaskStartEvent {

    public CsgDefaultTaskStartEvent(String taskName, Object data, TaskResult taskResult) {
        super(taskName, data, taskResult);
    }

    public CsgDefaultTaskStartEvent(String taskId, String taskName, Object data, TaskResult taskResult) {
        super(taskId, taskName, data, taskResult);
    }

    public CsgDefaultTaskStartEvent(String taskId, String taskName, String entranceName, Object data, TaskResult taskResult) {
        super(taskId, taskName, entranceName, data, taskResult);
    }

    @Override
    public String getTaskPrefix() {
        return "Csg";
    }
}

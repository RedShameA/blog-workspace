package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.INITIAL_PASSWORD;

public class StationConfigInitParams implements TaskInitParams {

    private String deviceNumber;

    private String password;

    private String ip;

    private Integer port;

    private String cardNumber;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIp() {
        return this.ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public Integer getPort() {
        return this.port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public String getCardNumber() {
        return this.cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    @Override
    public StationConfigInitParams populateDefault() {
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        return this;
    }

    @Override
    public StationConfigInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (!Validator.isIpv4(this.ip)) {
            throw new IllegalArgumentException("csg station ip format error");
        }
        if (this.port == null || this.port < 0 || this.port > 65535) {
            throw new IllegalArgumentException("csg station port format error");
        }
        if (this.cardNumber.length() != 11 || !Validator.isPositiveIntegerNumber(this.cardNumber)) {
            throw new IllegalArgumentException("csg station card number format error");
        }
        return this;
    }
}

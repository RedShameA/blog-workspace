package io.iwd.csg.entity;

/**
 * 历史视频webrtc播放的结果。
 */
public class HistoryVideoWebrtcPlayResult {

    /**
     * 播放是否成功。
     */
    private final boolean success;

    /**
     * webrtc answer sdp。
     */
    private final String sdp;

    /**
     * 信令服务生成的ssrc。
     */
    private final Long ssrc;

    /**
     * 标准构造器。
     * @param success 播放是否成功。
     * @param sdp webrtc的answer sdp。
     * @param ssrc ssrc。
     */
    public HistoryVideoWebrtcPlayResult(boolean success, String sdp, Long ssrc) {
        this.success = success;
        this.sdp = sdp;
        this.ssrc = ssrc;
    }

    /**
     * 返回是否播放成功。
     * @return 是否播放成功。
     */
    public boolean isSuccess() {
        return this.success;
    }

    /**
     * 返回answer sdp。
     * @return answer sdp。
     */
    public String getSdp() {
        return this.sdp;
    }

    /**
     * 返回ssrc。
     * @return ssrc。
     */
    public Long getSsrc() {
        return this.ssrc;
    }

    @Override
    public String toString() {
        return "{\"success\":" + this.success + ",\"sdp\":" + this.sdp + ",\"ssrc\":" + this.ssrc + "}";
    }

}

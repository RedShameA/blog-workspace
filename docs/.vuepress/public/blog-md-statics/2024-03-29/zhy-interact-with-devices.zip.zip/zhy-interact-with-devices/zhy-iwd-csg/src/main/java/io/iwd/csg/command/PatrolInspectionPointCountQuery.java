package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.csg.entity.PatrolInspectionPointCountQueryInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static io.iwd.csg.CsgConst.MAX_PATROL_INSPECTION_ID_NUMBER;

public class PatrolInspectionPointCountQuery extends AdvancedCommand<List<Integer>> {

    private PatrolInspectionPointCountQueryInitParams initParams = new PatrolInspectionPointCountQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return PatrolInspectionPointCountQuery命令对象。
     */
    public PatrolInspectionPointCountQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PatrolInspectionPointCountQuery命令对象。
     */
    public PatrolInspectionPointCountQuery setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PatrolInspectionPointCountQuery", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public List<Integer> await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                JsonArray countArray = completedResult.getJsonArray("countArray");
                List<Integer> countList = new ArrayList<>(MAX_PATROL_INSPECTION_ID_NUMBER);
                for (int i = 0; i < MAX_PATROL_INSPECTION_ID_NUMBER; i++) {
                    countList.add(countArray.getInteger(i));
                }
                return countList;
            }
            return Collections.emptyList();
        }, time);
    }

}

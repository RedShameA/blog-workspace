package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.OsdConfigInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 镜头控制命令。
 */
public class OsdConfig extends AdvancedCommand<Boolean> {

    private OsdConfigInitParams initParams = new OsdConfigInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return OsdConfig命令对象。
     */
    public OsdConfig setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return OsdConfig命令对象。
     */
    public OsdConfig setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return OsdConfig命令对象。
     */
    public OsdConfig setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置是否显示时间。
     * @param timeVisible 是否显示时间。
     * @return OsdConfig命令对象。
     */
    public OsdConfig setTimeVisible(Boolean timeVisible) {
        this.initParams.setTimeVisible(timeVisible);
        return this;
    }

    /**
     * 设置是否显示文本。
     * @param textVisible 是否显示文本。
     * @return OsdConfig命令对象。
     */
    public OsdConfig setTextVisible(Boolean textVisible) {
        this.initParams.setTextVisible(textVisible);
        return this;
    }

    /**
     * 设置文本内容。
     * @param textContent 文本内容。
     * @return OsdConfig命令对象。
     */
    public OsdConfig setTextContent(String textContent) {
        this.initParams.setTextContent(textContent);
        return this;
    }


    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "OsdConfig", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

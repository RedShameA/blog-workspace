package io.iwd.csg.entity;

import io.iwd.common.ext.util.StringUtil;

public class OsdQueryResult {

    private final Boolean success;

    private final Boolean timeVisible;

    private final Boolean textVisible;

    private final String textContent;

    public OsdQueryResult(Boolean success, Boolean timeVisible, Boolean textVisible, String textContent) {
        this.success = success;
        this.timeVisible = timeVisible;
        this.textVisible = textVisible;
        this.textContent = textContent;
    }

    public Boolean getSuccess() {
        return success;
    }

    public Boolean getTimeVisible() {
        return timeVisible;
    }

    public Boolean getTextVisible() {
        return textVisible;
    }

    public String getTextContent() {
        return textContent;
    }

    @Override
    public String toString() {
        return "{\"success\":" + this.success + ",\"timeVisible\":" + this.timeVisible + ",\"textVisible\":" + this.textVisible + ",\"textContent\":\"" + StringUtil.escapeDoubleQuotes(this.textContent, 1) + "\"}";
    }
}

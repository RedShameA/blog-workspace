package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.util.Validator;
import io.iwd.csg.util.CsgValidator;

public class HistoryVideoPauseInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private Long ssrc;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Long getSsrc() {
        return this.ssrc;
    }

    public void setSsrc(Long ssrc) {
        this.ssrc = ssrc;
    }

    @Override
    public HistoryVideoPauseInitParams populateDefault() {
        return this;
    }

    @Override
    public HistoryVideoPauseInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (this.ssrc == null || this.ssrc > 0xFFFFFFFFL) {
            throw new IllegalArgumentException("csg ssrc error");
        }
        return this;
    }
}

package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.*;

public class AuxiliarySwitchControlInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String password;

    private AuxiliarySwitchControlOption auxiliarySwitchControlOption;

    private Integer switchNumber;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public AuxiliarySwitchControlOption getAuxiliarySwitchControlOption() {
        return auxiliarySwitchControlOption;
    }

    public void setAuxiliarySwitchControlOption(AuxiliarySwitchControlOption auxiliarySwitchControlOption) {
        this.auxiliarySwitchControlOption = auxiliarySwitchControlOption;
    }

    public Integer getSwitchNumber() {
        return switchNumber;
    }

    public void setSwitchNumber(Integer switchNumber) {
        this.switchNumber = switchNumber;
    }

    @Override
    public AuxiliarySwitchControlInitParams populateDefault() {
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        return this;
    }

    @Override
    public AuxiliarySwitchControlInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (this.auxiliarySwitchControlOption == null) {
            throw new IllegalArgumentException("csg auxiliary switch control option error");
        }
        if (this.switchNumber == null || this.switchNumber < MIN_AUXILIARY_SWITCH_NUMBER || this.switchNumber > MAX_AUXILIARY_SWITCH_NUMBER) {
            throw new IllegalArgumentException("csg switch number error");
        }
        return this;
    }
    
}

package io.iwd.csg.entity;

public class StationQueryResult {

    private final boolean success;

    private final String ip;

    private final Integer port;

    private final String cardNumber;

    public StationQueryResult(boolean success, String ip, Integer port, String cardNumber) {
        this.success = success;
        this.ip = ip;
        this.port = port;
        this.cardNumber = cardNumber;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getIp() {
        return ip;
    }

    public Integer getPort() {
        return port;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    @Override
    public String toString() {
        return "{\"success\":" + this.success + ",\"ip\":\"" + this.ip + "\",\"port\":" + this.port + ",\"cardNumber\":\"" + this.cardNumber + "\"}";
    }
}

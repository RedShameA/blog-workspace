package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.INITIAL_PASSWORD;

public class ThreeDimensionalControlInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String password;

    private Integer startPointXCoordinate;

    private Integer startPointYCoordinate;

    private Integer endPointXCoordinate;

    private Integer endPointYCoordinate;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getStartPointXCoordinate() {
        return startPointXCoordinate;
    }

    public void setStartPointXCoordinate(Integer startPointXCoordinate) {
        this.startPointXCoordinate = startPointXCoordinate;
    }

    public Integer getStartPointYCoordinate() {
        return startPointYCoordinate;
    }

    public void setStartPointYCoordinate(Integer startPointYCoordinate) {
        this.startPointYCoordinate = startPointYCoordinate;
    }

    public Integer getEndPointXCoordinate() {
        return endPointXCoordinate;
    }

    public void setEndPointXCoordinate(Integer endPointXCoordinate) {
        this.endPointXCoordinate = endPointXCoordinate;
    }

    public Integer getEndPointYCoordinate() {
        return endPointYCoordinate;
    }

    public void setEndPointYCoordinate(Integer endPointYCoordinate) {
        this.endPointYCoordinate = endPointYCoordinate;
    }

    @Override
    public ThreeDimensionalControlInitParams populateDefault() {
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        return this;
    }

    @Override
    public ThreeDimensionalControlInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (this.startPointXCoordinate == null || this.startPointXCoordinate < 0 || this.startPointXCoordinate > 255) {
            throw new IllegalArgumentException("csg 3d control start point x coordinate error");
        }
        if (this.startPointYCoordinate == null || this.startPointYCoordinate < 0 || this.startPointYCoordinate > 255) {
            throw new IllegalArgumentException("csg 3d control start point y coordinate error");
        }
        if (this.endPointXCoordinate == null || this.endPointXCoordinate < 0 || this.endPointXCoordinate > 255) {
            throw new IllegalArgumentException("csg 3d control end point x coordinate error");
        }
        if (this.endPointYCoordinate == null || this.endPointYCoordinate < 0 || this.endPointYCoordinate > 255) {
            throw new IllegalArgumentException("csg 3d control end point y coordinate error");
        }
        return this;
    }
}

package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.HistoryVideoRelocateInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import static io.iwd.csg.CsgConst.HistoryVideoSpeedOption;

/**
 * 录像回放重新定位命令。
 */
public class HistoryVideoRelocate extends AdvancedCommand<Boolean> {

    private HistoryVideoRelocateInitParams initParams = new HistoryVideoRelocateInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoRelocate命令对象。
     */
    public HistoryVideoRelocate setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoRelocate命令对象。
     */
    public HistoryVideoRelocate setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置录像回放速度选项。
     * @param historyVideoSpeedOption 录像回放速度选项。
     * @return HistoryVideoRelocate命令对象。
     */
    public HistoryVideoRelocate setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.initParams.setHistoryVideoSpeedOption(historyVideoSpeedOption);
        return this;
    }

    /**
     * 设置录像回放距文件开始播放的偏移值，单位秒，最大65535。
     * @param offset 录像回放距文件开始播放的偏移值。
     * @return HistoryVideoRelocate命令对象。
     */
    public HistoryVideoRelocate setOffset(Integer offset) {
        this.initParams.setOffset(offset);
        return this;
    }

    /**
     * 设置ssrc。
     * @param ssrc ssrc。
     * @return HistoryVideoRelocate命令对象。
     */
    public HistoryVideoRelocate setSsrc(Long ssrc) {
        this.initParams.setSsrc(ssrc);
        return this;
    }
    
    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoRelocate", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

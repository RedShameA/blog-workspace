package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.csg.entity.OsdQueryInitParams;
import io.iwd.csg.entity.OsdQueryResult;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

public class OsdQuery extends AdvancedCommand<OsdQueryResult> {
    
    private OsdQueryInitParams initParams = new OsdQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return OsdQuery命令对象。
     */
    public OsdQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return OsdQuery命令对象。
     */
    public OsdQuery setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "OsdQuery", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public OsdQueryResult await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                Boolean timeVisible = completedResult.getBoolean("timeVisible");
                Boolean textVisible = completedResult.getBoolean("textVisible");
                String textContent = completedResult.getString("textContent");
                return new OsdQueryResult(true, timeVisible, textVisible, textContent);
            }
            return new OsdQueryResult(false, null, null, null);
        }, time);
    }
    
}

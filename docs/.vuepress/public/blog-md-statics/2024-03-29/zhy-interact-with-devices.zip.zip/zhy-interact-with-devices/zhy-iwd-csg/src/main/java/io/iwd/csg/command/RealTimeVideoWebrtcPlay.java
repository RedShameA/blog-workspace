package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.csg.entity.RealTimeVideoWebrtcPlayInitParams;
import io.iwd.csg.entity.RealTimeVideoWebrtcPlayResult;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import static io.iwd.csg.CsgConst.*;

public class RealTimeVideoWebrtcPlay extends AdvancedCommand<RealTimeVideoWebrtcPlayResult> {

    private RealTimeVideoWebrtcPlayInitParams initParams = new RealTimeVideoWebrtcPlayInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置推流协议。
     * @param videoStreamProtocol 推流协议。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setStreamProtocol(VideoStreamProtocol videoStreamProtocol) {
        this.initParams.setVideoStreamProtocol(videoStreamProtocol);
        return this;
    }

    /**
     * 设置码流类型。
     * @param streamType 码流类型。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setStreamType(StreamType streamType) {
        this.initParams.setStreamType(streamType);
        return this;
    }

    /**
     * 设置流媒体服务器接收设备推流的ip。
     * @param mediaServerIp 流媒体服务器接收设备推流的ip。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setMediaServerIp(String mediaServerIp) {
        this.initParams.setMediaServerIp(mediaServerIp);
        return this;
    }

    /**
     * 设置流媒体服务器接收设备推流的端口。
     * @param mediaServerPort 流媒体服务器接收设备推流的端口。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setMediaServerPort(Integer mediaServerPort) {
        this.initParams.setMediaServerPort(mediaServerPort);
        return this;
    }

    /**
     * 设置webrtc的offer sdp。
     * @param offerSdp webrtc的offer sdp。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setOfferSdp(String offerSdp) {
        this.initParams.setOfferSdp(offerSdp);
        return this;
    }

    /**
     * 设置是否使用已存在的流。默认为{@code true}。
     * @param useExistingStream 是否使用已存在的流。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setUseExistingStream(Boolean useExistingStream) {
        this.initParams.setUseExistingStream(useExistingStream);
        return this;
    }

    /**
     * 设置与srs的api交互是否使用https。默认从配置文件中获取。
     * @param srsApiSsl 与srs的api交互是否使用https。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setSrsApiSsl(Boolean srsApiSsl) {
        this.initParams.setSrsApiSsl(srsApiSsl);
        return this;
    }

    /**
     * 设置srs的api交互ip。默认从配置文件中获取。
     * @param srsApiIp srs的api交互ip。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setSrsApiIp(String srsApiIp) {
        this.initParams.setSrsApiIp(srsApiIp);
        return this;
    }

    /**
     * 设置srs的api交互端口。默认从配置文件中获取。
     * @param srsApiPort srs的api交互端口。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setSrsApiPort(Integer srsApiPort) {
        this.initParams.setSrsApiPort(srsApiPort);
        return this;
    }

    /**
     * 设置web服务接收srs http请求的地址。默认从配置文件中获取。
     * @param webAddress web服务接收srs http请求的地址。
     * @return RealTimeVideoWebrtcPlay命令对象。
     */
    public RealTimeVideoWebrtcPlay setWebAddress(String webAddress) {
        this.initParams.setWebAddress(webAddress);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "RealTimeVideoWebrtcPlay", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public RealTimeVideoWebrtcPlayResult await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                String sdp = completedResult.getString("sdp");
                Long ssrc = completedResult.getLong("ssrc");
                return new RealTimeVideoWebrtcPlayResult(true, sdp, ssrc);
            }
            return new RealTimeVideoWebrtcPlayResult(false, null, null);
        }, time);
    }

}

package io.iwd.csg.event;

import io.iwd.common.event.*;
import io.iwd.common.event.srs.SrsCloseRtcEvent;
import io.iwd.common.event.srs.SrsRtspReadyEvent;

import java.util.LinkedList;
import java.util.List;

import static io.iwd.csg.CsgConst.TASK_PREFIX;

public class CsgTaskEventListener extends AbstractTaskEventListener {

    @Override
    public String defaultTaskPrefix() {
        return TASK_PREFIX;
    }

    @Override
    public List<Class<? extends Event>> interests() {
        List<Class<? extends Event>> interestsList = new LinkedList<>();
        interestsList.add(CsgDefaultTaskStartEvent.class);
        interestsList.add(CsgDefaultTaskProceedEvent.class);
        interestsList.add(SrsCloseRtcEvent.class);
        return interestsList;
    }

}

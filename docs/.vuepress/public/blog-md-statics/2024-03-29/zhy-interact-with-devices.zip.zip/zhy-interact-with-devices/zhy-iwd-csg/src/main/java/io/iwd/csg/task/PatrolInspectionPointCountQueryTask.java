package io.iwd.csg.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.csg.entity.PatrolInspectionPointCountQueryInitParams;
import io.iwd.csg.event.CsgDefaultTaskProceedEvent;

import static io.iwd.csg.CsgConst.*;

public class PatrolInspectionPointCountQueryTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "PatrolInspectionPointCountQuery", CsgDefaultTaskProceedEvent::new);

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            PatrolInspectionPointCountQueryInitParams input = (PatrolInspectionPointCountQueryInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            Integer channelNumber = input.getChannelNumber();

            JsonObject data = JsonObject.create()
                    .put("DeviceID", deviceNumber)
                    .put("ChannelNo", channelNumber)
                    .put("msgid", context.getTaskId())
                    .put("FunCode", 0xB6);

            Redis.silentMode().publish("WEB_FCM_SPG_MSG", data.stringify());

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonObject data = (JsonObject) context.getInput();
            Integer code = data.getInteger("ResultCode");
            if (code != 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error: " + code));
                return;
            }

            JsonArray countArray = JsonArray.create();
            for (int i = 0; i < MAX_PATROL_INSPECTION_ID_NUMBER; i++) {
                countArray.add(0);
            }

            JsonArray list = data.getJsonArray("PatrolParamList");
            for (int i = 0; i < list.size(); i++) {
                JsonObject patrolInspection = list.getJsonObject(i);
                Integer patrolInspectionId = patrolInspection.getInteger("PatrolGroupNo");
                Integer pointCount = patrolInspection.getInteger("PatrolPointNumber");
                countArray.set(patrolInspectionId - 1, pointCount);
            }

            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("countArray", countArray));
        });

        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }
}

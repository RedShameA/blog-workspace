package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.*;

public class PatrolInspectionPointAppendInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String password;

    private Integer patrolInspectionId;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getPatrolInspectionId() {
        return this.patrolInspectionId;
    }

    public void setPatrolInspectionId(Integer patrolInspectionId) {
        this.patrolInspectionId = patrolInspectionId;
    }

    @Override
    public PatrolInspectionPointAppendInitParams populateDefault() {
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        return this;
    }

    @Override
    public PatrolInspectionPointAppendInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (this.patrolInspectionId == null || this.patrolInspectionId < MIX_PATROL_INSPECTION_ID_NUMBER || this.patrolInspectionId > MAX_PATROL_INSPECTION_ID_NUMBER) {
            throw new IllegalArgumentException("csg patrol inspection id error");
        }
        return this;
    }
}

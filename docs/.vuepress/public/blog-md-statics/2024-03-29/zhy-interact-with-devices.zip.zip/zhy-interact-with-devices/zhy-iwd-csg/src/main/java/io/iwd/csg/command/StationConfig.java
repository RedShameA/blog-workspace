package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.StationConfigInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 主站信息配置命令，配置后设备会连接新的主站。
 */
public class StationConfig extends AdvancedCommand<Boolean> {
    
    private StationConfigInitParams initParams = new StationConfigInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return StationConfig命令对象。
     */
    public StationConfig setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return StationConfig命令对象。
     */
    public StationConfig setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置主站ip。
     * @param ip 主站ip。
     * @return StationConfig命令对象。
     */
    public StationConfig setIp(String ip) {
        this.initParams.setIp(ip);
        return this;
    }

    /**
     * 设置主站端口。
     * @param port 主站端口。
     * @return StationConfig命令对象。
     */
    public StationConfig setPort(Integer port) {
        this.initParams.setPort(port);
        return this;
    }

    /**
     * 设置主站卡号。
     * @param cardNumber 主站卡号。
     * @return StationConfig命令对象。
     */
    public StationConfig setCardNumber(String cardNumber) {
        this.initParams.setCardNumber(cardNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "StationConfig", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }


}

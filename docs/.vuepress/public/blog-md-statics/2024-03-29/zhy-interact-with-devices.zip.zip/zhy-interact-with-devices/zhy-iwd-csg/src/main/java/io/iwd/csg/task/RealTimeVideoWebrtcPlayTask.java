package io.iwd.csg.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.http.srs.template.SrsExchangeSdpTemplate;
import io.iwd.common.stdio.http.srs.template.SrsQueryStreamTemplate;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.csg.entity.RealTimeVideoWebrtcPlayInitParams;
import io.iwd.csg.event.CsgDefaultTaskProceedEvent;

import static io.iwd.csg.CsgConst.*;

public class RealTimeVideoWebrtcPlayTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "RealTimeVideoWebrtcPlay", CsgDefaultTaskProceedEvent::new);

        //准备数据
        taskFlow.addNode("PREPARE_DATA", context -> {
            RealTimeVideoWebrtcPlayInitParams input = (RealTimeVideoWebrtcPlayInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            Integer channelNumber = input.getChannelNumber();
            Integer streamType = input.getStreamType().code();
            Integer streamProtocol = input.getVideoStreamProtocol().code();
            String mediaServerIp = input.getMediaServerIp();
            Integer mediaServerPort = input.getMediaServerPort();
            Boolean srsApiSsl = input.getSrsApiSsl();
            String srsApiIp = input.getSrsApiIp();
            Integer srsApiPort = input.getSrsApiPort();
            String webAddress = input.getWebAddress();
            String offerSdp = input.getOfferSdp();
            Boolean useExistingStream = input.getUseExistingStream();

            context.putData("deviceNumber", deviceNumber);
            context.putData("channelNumber", channelNumber);
            context.putData("streamType", streamType);
            context.putData("protocol", streamProtocol);
            context.putData("mediaServerIp", mediaServerIp);
            context.putData("mediaServerPort", mediaServerPort);
            context.putData("srsApiSsl", srsApiSsl);
            context.putData("srsApiIp", srsApiIp);
            context.putData("srsApiPort", srsApiPort);
            context.putData("webAddress", webAddress);
            context.putData("sdp", offerSdp);

            if (useExistingStream) {
                context.fireNext("QUERY_SSRC");
            } else {
                context.fireNext("ISSUE_REAL_TIME_VIDEO_START_COMMAND");
            }
        });

        //从redis中查找ssrc
        taskFlow.addNode("QUERY_SSRC", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            Integer channelNumber = (Integer) context.getData("channelNumber");
            String ssrcFieldKey = deviceNumber + "_" + channelNumber;

            Redis.interactiveMode().hget(REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY, ssrcFieldKey);
            context.awaitNext("GOT_SSRC");
        });

        //查到redis中是否有ssrc
        taskFlow.addNode("GOT_SSRC", context -> {
            String ssrc = (String) context.getInput();
            context.putData("previousSsrc", ssrc);
            if (StringUtil.isEmpty(ssrc)) {
                //没有记录，认定为没有流
                //下发播放指令
                context.fireNext("ISSUE_VIDEO_START_COMMAND");
            } else {
                //询问SRS是否有流
                context.fireNext("QUERY_STREAM");
            }
        });

        //向SRS查询是否有流
        taskFlow.addNode("QUERY_STREAM", context -> {
            String ssrc = (String) context.getData("previousSsrc");
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");

            new SrsQueryStreamTemplate(srsApiSsl, srsApiIp, srsApiPort, ssrc).send();

            context.awaitNext("SRS_RESPONSE_STREAM");
        });

        //SRS回复是否有流
        taskFlow.addNode("SRS_RESPONSE_STREAM", context -> {
            Boolean input = (Boolean) context.getInput();
            if (input == null || !input) {
                context.fireNext("ISSUE_VIDEO_START_COMMAND");
            } else {
                context.fireNext("EXCHANGE_SDP");
            }
        });

        //向FCM下发实时视频播放指令
        taskFlow.addNode("ISSUE_VIDEO_START_COMMAND", context -> {
            JsonObject message = JsonObject.create()
                    .put("DeviceID", context.getData("deviceNumber"))
                    .put("ChannelNo", context.getData("channelNumber"))
                    .put("BitStreamType", context.getData("streamType"))
                    .put("NetType", context.getData("protocol"))
                    .put("StreamIP", context.getData("mediaServerIp"))
                    .put("StreamPort", context.getData("mediaServerPort"))
                    .put("msgid", context.getTaskId())
                    .put("FunCode", 0x89)
                    .put("rtc", 1);

            Redis.silentMode().publish("WEB_FCM_SPG_MSG", message.stringify());

            context.awaitNext("RECEIVED_VIDEO_START_RESPONSE", 10000);
        });

        //收到FCM回复实时视频播放结果
        taskFlow.addNode("RECEIVED_VIDEO_START_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer resultCode = input.getInteger("ResultCode");
            if (resultCode == null || resultCode != 0) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "fcm service response error"));
                return;
            }
            Long ssrc = input.getLong("SSRC");
            if (ssrc == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "fcm service response no ssrc"));
                return;
            }
            context.putData("ssrc", ssrc);

            context.fireNext("SAVE_SSRC");
        });

        //保存新的ssrc
        taskFlow.addNode("SAVE_SSRC", context -> {
            String previousSsrc = (String) context.getData("previousSsrc");
            if (previousSsrc == null) {
                previousSsrc = "";
            }
            String ssrc = context.getData("ssrc").toString();
            String deviceNumber = (String) context.getData("deviceNumber");
            Integer channelNumber = (Integer) context.getData("channelNumber");
            Integer streamType = (Integer) context.getData("streamType");
            String fieldKey = deviceNumber + "_" + channelNumber;

            String script = "local currentSsrc = redis.call('HGET',KEYS[1],KEYS[2]);" +
                            "if(currentSsrc == false or currentSsrc == ARGV[1]) then " +
                            "redis.call('HSET',KEYS[1],KEYS[2],ARGV[2]);" + //保存ssrc
                            "redis.call('HSET',KEYS[1],ARGV[2],ARGV[3]); " + //保存ssrc=>dn_cn_st
                            "return 2;" +
                            "else return 0;end";

            Redis.interactiveMode().eval(script, 2, REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY, fieldKey, previousSsrc, ssrc, fieldKey + "_" + streamType);

            context.awaitNext("SAVE_SSRC_COMPLETED");
        });

        //保存ssrc完成
        taskFlow.addNode("SAVE_SSRC_COMPLETED", context -> {
            Object input = context.getInput();
            if (! (input instanceof Number)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "redis error"));
                return;
            }
            if (((Number) input).intValue() != 2) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0002,
                        "redis error"));
                return;
            }

            context.fireNext("SEND_OFFER");
        });

        //向SRS发送offer
        taskFlow.addNode("SEND_OFFER", context -> {
            String ssrc = context.getData("ssrc").toString();
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            String webAddress = (String) context.getData("webAddress");
            String sdp = (String) context.getData("sdp");

            new SrsExchangeSdpTemplate(srsApiSsl, srsApiIp, srsApiPort, webAddress, sdp, "/live/chid" + ssrc).send();

            context.awaitNext("RECEIVED_ANSWER");
        });

        //收到SRS的answer
        taskFlow.addNode("RECEIVED_ANSWER", context -> {
            Object input = context.getInput();
            if (input == null) {
                //响应出现异常情况
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0003,
                        "received unexpected srs response"));
                return;
            }

            JsonObject response = (JsonObject) input;
            String sdp = response.getString("sdp");
            String sessionId = response.getString("sessionId");

            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("sdp", sdp)
                    .put("sessionId", sessionId)
                    .put("ssrc", context.getData("ssrc")));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

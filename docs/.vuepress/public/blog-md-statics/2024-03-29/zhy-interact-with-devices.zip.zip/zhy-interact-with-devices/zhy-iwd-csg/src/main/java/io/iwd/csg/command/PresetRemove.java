package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.csg.entity.PresetRemoveInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

/**
 * 预置位删除命令。
 */
public class PresetRemove extends AdvancedCommand<Boolean> {

    private PresetRemoveInitParams initParams = new PresetRemoveInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置设备密码。
     * @param password 设备密码。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }
    
    /**
     * 设置预置位id。
     * @param presetId 预置位id。
     * @return PresetRemove命令对象。
     */
    public PresetRemove setPresetId(Integer presetId) {
        this.initParams.setPresetId(presetId);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PresetRemove", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

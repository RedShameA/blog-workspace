package io.iwd.csg;

import java.util.HashMap;
import java.util.Map;

public class CsgConst {

    public static final String TASK_PREFIX = "Csg";

    public static final String REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY = "csg_real_video_info";
    public static final String REDIS_HISTORY_VIDEO_INFO_MAP_KEY = "csg_history_video_info";

    public static final String INITIAL_PASSWORD = "1234";

    public static final int MIN_CONTROL_SPEED = 1;
    public static final int MAX_CONTROL_SPEED = 100;

    public static final int MIN_CRUISE_SPEED = 1;
    public static final int MAX_CRUISE_SPEED = 100;

    public static final int MIN_PRESET_ID_NUMBER = 1;
    public static final int MAX_PRESET_ID_NUMBER = 254;

    public static final int MIN_CRUISE_ID_NUMBER = 1;
    public static final int MAX_CRUISE_ID_NUMBER = 16;

    public static final int MIN_CRUISE_POINT_ID_NUMBER = 1;
    public static final int MAX_CRUISE_POINT_ID_NUMBER = 32;

    public static final int MIN_CRUISE_PRESET_INTERVAL = 3;
    public static final int MAX_CRUISE_PRESET_INTERVAL = 255;

    public static final int MIX_PATROL_INSPECTION_ID_NUMBER = 1;
    public static final int MAX_PATROL_INSPECTION_ID_NUMBER = 4;

    public static final int MIX_PATROL_INSPECTION_POINT_ID_NUMBER = 1;
    public static final int MAX_PATROL_INSPECTION_POINT_ID_NUMBER = 64;

    public static final int MIN_AUXILIARY_SWITCH_NUMBER = 0;
    public static final int MAX_AUXILIARY_SWITCH_NUMBER = 255;

    public static final int MAX_HISTORY_FILE_QUERY_COUNT = 48;

    /**
     * 控制速度选项，用于替代控制速度值。
     */
    public enum ControlSpeedOption {
        /**
         * 一档。
         */
        ONE(10),
        /**
         * 二档。
         */
        TWO(20),
        /**
         * 三档。
         */
        THREE(30),
        /**
         * 四档。
         */
        FOUR(40),
        /**
         * 五档。
         */
        FIVE(50),
        /**
         * 六档。
         */
        SIX(60),
        /**
         * 七档。
         */
        SEVEN(70),
        /**
         * 八档。
         */
        EIGHT(80),
        /**
         * 九档。
         */
        NINE(90),
        /**
         * 十档。
         */
        TEN(100),
        ;
        private final int speed;
        ControlSpeedOption(int speed) {
            this.speed = speed;
        }
        public int speed() {
            return this.speed;
        }
    }

    /**
     * 镜头控制选项，用于选择镜头控制的方向。
     * 有些设备可能不支持LEFT_UP RIGHT_UP LEFT_DOWN RIGHT_DOWN方向。
     */
    public enum LensControlOption {
        /**
         * 停止。
         */
        STOP(48),
        /**
         * 向上。
         */
        UP(49),
        /**
         * 向下。
         */
        DOWN(50),
        /**
         * 向左。
         */
        LEFT(51),
        /**
         * 向右。
         */
        RIGHT(52),
        /**
         * 向左上。
         */
        LEFT_UP(53),
        /**
         * 向右上。
         */
        RIGHT_UP(54),
        /**
         * 向左下。
         */
        LEFT_DOWN(55),
        /**
         * 向右下。
         */
        RIGHT_DOWN(56),
        ;
        private final int code;
        LensControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 变倍控制选项，用于选择变倍加/变倍减。
     */
    public enum ZoomControlOption {
        /**
         * 停止。
         */
        STOP(48),
        /**
         * 变倍加。
         */
        PLUS(57),
        /**
         * 变倍减。
         */
        MINUS(58),
        ;
        private final int code;
        ZoomControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 调焦控制选项，用于控制调焦远/调焦近。
     */
    public enum FocusControlOption {
        /**
         * 停止。
         */
        STOP(48),
        /**
         * 调焦近。
         */
        NEAR(62),
        /**
         * 调焦远。
         */
        FAR(61),
        ;
        private final int code;
        FocusControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 光圈控制选项，用于控制光圈开/光圈关。
     */
    public enum ApertureControlOption {
        /**
         * 停止。
         */
        STOP(48),
        /**
         * 光圈开。
         */
        OPEN(59),
        /**
         * 光圈关。
         */
        CLOSE(60),
        ;
        private final int code;
        ApertureControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 视频流协议。
     */
    public enum VideoStreamProtocol {
        /**
         * UDP协议。
         */
        UDP(0),
        /**
         * TCP协议。
         */
        TCP(1),
        ;
        private final int code;
        VideoStreamProtocol(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 码流类型。
     */
    public enum StreamType {
        /**
         * 主码流。
         */
        MAIN(0),
        /**
         * 从码流。
         */
        SUB(1),
        /**
         * 第三流。
         */
        THIRD(2),
        ;
        private final int code;
        StreamType(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 录像回放速度选项。
     */
    public enum HistoryVideoSpeedOption {
        /**
         * 八分之一倍速。
         */
        X0125("0.125"),
        /**
         * 四分之一倍速。
         */
        X025("0.25"),
        /**
         * 二分之一倍速。
         */
        X05("0.5"),
        /**
         * 一倍速。
         */
        X1("1.0"),
        /**
         * 二倍速。
         */
        X2("2.0"),
        /**
         * 四倍速。
         */
        X4("4.0"),
        /**
         * 八倍速。
         */
        X8("8.0"),
        /**
         * 十六倍速。
         */
        X16("16.0"),
        ;
        private final String value;
        HistoryVideoSpeedOption(String value) {
            this.value = value;
        }
        public String value() {
            return this.value;
        }
    }

    /**
     * 录像文件类型。
     */
    public enum HistoryVideoFileType {
        /**
         * 所有。
         */
        ALL(0XFFFFFFFF),
        /**
         * 异物入侵告警。
         */
        FOREIGN_INTRUSION_ALARM(0x00000001),
        /**
         * 移动侦测告警。
         */
        MOBILE_DETECTION_ALARM(0x00000002),
        /**
         * 视频遮挡告警。
         */
        VIDEO_OCCLUSION_ALARM(0x00000004),
        /**
         * 人员告警。
         */
        PERSONNEL_ALARM(0x00000008),
        /**
         * 施工机械告警。
         */
        CONSTRUCTION_MACHINERY_ALARM(0x00000010),
        /**
         * 综合防盗告警。
         */
        COMPREHENSIVE_ANTI_THEFT_ALARM(0x00000020),
        /**
         * 本体告警。
         */
        SELF_ALARM(0x00000040),
        /**
         * 交通事件告警。
         */
        TRAFFIC_EVENT_ALARM(0x00000080),
        /**
         * 定时。
         */
        TIMING(0x00000100),
        /**
         * 大风舞动告警。
         */
        WIND_DANCING_ALARM(0x00000200),
        /**
         * 杆塔倾斜报警。
         */
        TOWER_TILT_ALARM(0x00000400),
        /**
         * 树木/吊车/超高报警。
         */
        SUPERELEVATION_ALARM(0x00000800),
        /**
         * 塔基防范报警。
         */
        TOWER_PREVENTION_ALARM(0x00001000),
        /**
         * 人员检测报警。
         */
        PERSONNEL_DETECTION_ALARM(0x00002000),
        /**
         * 烟火检测报警。
         */
        PYROTECHNIC_DETECTION_ALARM(0x00004000)
        ;

        private static final Map<Integer, HistoryVideoFileType> TYPE_MAP;

        static {
            TYPE_MAP = new HashMap<>(64, 0.5f);
            TYPE_MAP.put(0XFFFFFFFF, ALL);
            TYPE_MAP.put(0x00000001, FOREIGN_INTRUSION_ALARM);
            TYPE_MAP.put(0x00000002, MOBILE_DETECTION_ALARM);
            TYPE_MAP.put(0x00000004, VIDEO_OCCLUSION_ALARM);
            TYPE_MAP.put(0x00000008, PERSONNEL_ALARM);
            TYPE_MAP.put(0x00000010, CONSTRUCTION_MACHINERY_ALARM);
            TYPE_MAP.put(0x00000020, COMPREHENSIVE_ANTI_THEFT_ALARM);
            TYPE_MAP.put(0x00000040, SELF_ALARM);
            TYPE_MAP.put(0x00000080, TRAFFIC_EVENT_ALARM);
            TYPE_MAP.put(0x00000100, TIMING);
            TYPE_MAP.put(0x00000200, WIND_DANCING_ALARM);
            TYPE_MAP.put(0x00000400, TOWER_TILT_ALARM);
            TYPE_MAP.put(0x00000800, SUPERELEVATION_ALARM);
            TYPE_MAP.put(0x00001000, TOWER_PREVENTION_ALARM);
            TYPE_MAP.put(0x00002000, PERSONNEL_DETECTION_ALARM);
            TYPE_MAP.put(0x00004000, PYROTECHNIC_DETECTION_ALARM);
        }

        private final int code;
        HistoryVideoFileType(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }

        public static int codeOf(HistoryVideoFileType... type) {
            if (type == null) {
                return ALL.code();
            }
            int code = 0;
            for (HistoryVideoFileType historyVideoFileType : type) {
                code |= historyVideoFileType.code();
            }
            return code;
        }

        public static HistoryVideoFileType nameOf(int code) {
            return TYPE_MAP.get(code);
        }
    }

    /**
     * 巡航速度选项，用于替代巡航速度值。
     */
    public enum CruiseSpeedOption {
        /**
         * 一档。
         */
        ONE(10),
        /**
         * 二档。
         */
        TWO(20),
        /**
         * 三档。
         */
        THREE(30),
        /**
         * 四档。
         */
        FOUR(40),
        /**
         * 五档。
         */
        FIVE(50),
        /**
         * 六档。
         */
        SIX(60),
        /**
         * 七档。
         */
        SEVEN(70),
        /**
         * 八档。
         */
        EIGHT(80),
        /**
         * 九档。
         */
        NINE(90),
        /**
         * 十档。
         */
        TEN(100),
        ;
        private final int speed;
        CruiseSpeedOption(int speed) {
            this.speed = speed;
        }
        public int speed() {
            return this.speed;
        }
    }

    /**
     * 辅助开关控制选项项。
     */
    public enum AuxiliarySwitchControlOption {
        /**
         * 打开。
         */
        TURN_ON(17),
        /**
         * 关闭。
         */
        TURN_OFF(18),
        ;

        private final int code;
        AuxiliarySwitchControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

}

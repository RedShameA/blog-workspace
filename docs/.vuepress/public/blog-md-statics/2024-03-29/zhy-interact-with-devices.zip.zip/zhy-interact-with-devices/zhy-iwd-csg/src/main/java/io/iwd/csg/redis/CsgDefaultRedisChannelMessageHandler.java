package io.iwd.csg.redis;

import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.event.TaskProceedEvent;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.stdio.redis.RedisChannelMessageHandler;
import io.iwd.csg.event.CsgDefaultTaskProceedEvent;

public class CsgDefaultRedisChannelMessageHandler extends RedisChannelMessageHandler {

    @Override
    public void handle(String channelName, String message) {
        JsonObject fcmData = JsonObject.from(message);
        if (fcmData == null) {
            return;
        }
        String messageId = fcmData.getString("msgid");
        if (messageId == null) {
            return;
        }
        new CsgDefaultTaskProceedEvent(messageId, fcmData).publish();
    }
}

package io.iwd.csg.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.csg.entity.HistoryVideoFileCountQueryInitParams;
import io.iwd.csg.event.CsgDefaultTaskStartEvent;

import java.util.Date;

import static io.iwd.csg.CsgConst.*;

/**
 * 录像文件数量查询命令。
 */
public class HistoryVideoFileCountQuery extends AdvancedCommand<Integer> {
    
    private HistoryVideoFileCountQueryInitParams initParams = new HistoryVideoFileCountQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoFileCountQuery命令对象。
     */
    public HistoryVideoFileCountQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoFileCountQuery命令对象。
     */
    public HistoryVideoFileCountQuery setChannelNumber(Integer channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置查询开始时间。
     * @param startTime 查询开始时间。
     * @return HistoryVideoFileCountQuery命令对象。
     */
    public HistoryVideoFileCountQuery setStartTime(Date startTime) {
        this.initParams.setStartTime(startTime);
        return this;
    }

    /**
     * 设置查询结束时间。
     * @param endTime 查询结束时间。
     * @return HistoryVideoFileCountQuery命令对象。
     */
    public HistoryVideoFileCountQuery setEndTime(Date endTime) {
        this.initParams.setEndTime(endTime);
        return this;
    }

    /**
     * 设置查询录像类型。
     * @param historyVideoFileType 查询录像类型。
     * @return HistoryVideoFileCountQuery命令对象。
     */
    public HistoryVideoFileCountQuery setHistoryVideoFileTypes(HistoryVideoFileType... historyVideoFileType) {
        this.initParams.setHistoryVideoFileTypes(historyVideoFileType);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoFileCountQuery", null, data.populateDefault().validate(), CsgDefaultTaskStartEvent::new);
    }

    @Override
    public Integer await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                return completedResult.getInteger("count");
            }
            return null;
        }, time);
    }
    
}

package io.iwd.csg.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.csg.util.CsgValidator;

import static io.iwd.csg.CsgConst.*;

public class PresetCallInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer channelNumber;

    private String password;

    private Integer presetId;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getPresetId() {
        return presetId;
    }

    public void setPresetId(Integer presetId) {
        this.presetId = presetId;
    }

    @Override
    public PresetCallInitParams populateDefault() {
        if (this.password == null) {
            this.password = INITIAL_PASSWORD;
        }
        return this;
    }

    @Override
    public PresetCallInitParams validate() {
        if (!CsgValidator.isCsgDeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("csg device number format error");
        }
        if (!CsgValidator.isCsgChannelNumber(this.channelNumber)) {
            throw new IllegalArgumentException("csg channel number format error");
        }
        if (!CsgValidator.isCsgPassword(this.password)) {
            throw new IllegalArgumentException("csg password format error");
        }
        if (this.presetId == null || this.presetId < MIN_PRESET_ID_NUMBER || this.presetId > MAX_PRESET_ID_NUMBER) {
            throw new IllegalArgumentException("csg preset id error");
        }
        return this;
    }
}

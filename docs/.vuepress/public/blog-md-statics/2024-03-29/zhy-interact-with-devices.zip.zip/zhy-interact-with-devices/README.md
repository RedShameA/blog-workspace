# zhy-interact-with-devices

## 介绍
设备交互API是在输电主站视频子系统研发完成，设备与主站交互相模式相对成熟的基础上，封装已有的设备功能，方便业务研发人员调用的工具库。


## 软件架构
设备交互API采用了公共核心包+扩展包的代码组织模式，使用这种模块化的模式是为了减少研发人员不必要的依赖引入。


## 引入方式

1.  拉取最新代码或指定发行版本代码
2.  在zhy-interact-with-devices下执行maven install，将所有包安装到本地仓库
3.  在项目中引入zhy-iwd-common（SpringBoot项目可以引入starter）
4.  根据需要引入扩展包

## 使用说明

设备交互API面向两种用户：
1. 已封装命令的直接使用者
2. 开发自定义命令或包的扩展者

为了满足以上两种用户，设备交互API提供了丰富的常用命令，同时也提供了用于扩展开发的诸多类、接口和配置。

####  配置文件

在每个包下都存在一个含有此包全部配置项的conf文件，文件内容格式为json。

当设备交互API初始化时，首先会加载iwd-global.conf文件，之后会根据“ext_packages”配置加载其他的配置文件。

在加载配置文件时，首先会获取和解析类路径下配置文件的全部内容，之后再获取和解析程序当前运行路径下的配置文件的全部内容，相同的配置项后者会覆盖前者。

基于上述特性，用户可以在程序运行路径下创建对应的配置文件并按需覆盖配置项。

强烈不建议用户在自己的项目类路径中创建配置文件，否则在获取配置文件时，获取到的文件就会是用户自己创建的文件，这样可能导致某些配置项遗漏。

####  命令的直接使用

对于abc包的命令，一般位于Abc类中。

几乎每个命令都继承了AdvancedCommand抽象类，并存在若干个set方法，这些set方法用于设置此命令需要的参数。

几乎每个命令中都存在一个InitParams对象，它是命令需要的全部参数的容器。
InitParams对象中的populateDefault方法用于设置参数默认值，validate方法用校验参数格式，用户可以通过查看这两个方法的内容确定必填参数和参数格式。

每个继承了AdvancedCommand抽象类的命令都有5个触发命令的方法：
1. ignore() 执行命令并忽略命令结果
2. await() 执行命令并使当前线程等待直至命令产生结果
3. await(long) 执行命令并使当前线程等待直至命令产生结果或到达超时时间
4. listen(TaskResult.Listener) 执行命令并指定命令产生结果后的动作
5. result() 执行命令并获取命令结果容器

####  扩展自定义命令

要扩展自定义命令，必须了解执行引擎的机制和common中的大多数组件。在了解清楚后，可以按照一般通用的方式进行扩展：
1. 确定命令需要的参数，创建对应的InitParams实现类。
2. 确定命令的执行流程，创建对应的TaskFlowInitializer实现类，并编写每个任务节点。
3. 在某个TaskFlowCollector中添加对应的命令任务，并在某个扩展配置文件中配置对应的“task_flow_collector”配置项。
4. 创建对应的命令类，并在某个命令集类中增加对应的静态方法。

对于需要发送http请求或接收http请求的命令，可以参考io.iwd.common.stdio.http包。

对于需要使用redis的命令，可以参考io.iwd.common.stdio.redis包。

对于需要其他网络交互的命令，可以基于netty开发对应组件。

## 技术细节

设备交互API的核心引擎采用EventLoop模式，具体实现在TaskReactor中。
TaskReactor是一个可以自动获取事件并处理事件的线程，当没有事件时，它会进入休眠状态，当有事件输入时，它又会被唤醒。

设备交互API内部组件通信采用事件发布订阅模式。
所有的事件都是io.iwd.common.event.Event接口的实现类，所有的事件监听器都是io.iwd.common.event.EventListener的实现类。
几乎每个事件监听器都需要配置在“event_listener”配置项中。

设备交互API的功能，需要以TaskFlow(任务流程)和Task(任务节点)为基础进行代码组织。
将TaskFlow添加到TaskFlowCollector中，并在配置文件中指明TaskFlowCollector的全类名，
这样当运行环境刷新(一般是程序启动)时，Environment就会自动将TaskFlow放入注册中心。
```java
public class SomeTaskFlowCollector implements TaskFlowCollector {
    public List<TaskFlow> getTaskFlowList() {
        List<TaskFlow> taskFlowList = new LinkedList<>();
        taskFlowList.add(new SomeTask().getTaskFlow());
        return taskFlowList;
    }
}
```

在开发Task(任务节点)时，会频繁用到TaskContextFacade。
```java
public class SomeTask implements TaskFlowInitializer {
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "SomeTaskName", SomeTaskProceedEvent::new);
        taskFlow.addNode("ACTION_1", context -> {
            context.putData("key", "value"); //将数据存放到上下文中，存放的数据可以在任意节点中获取到
            //do something...
            context.awaitNext("ACTION_2"); //等待一个事件来触发指定的下一个任务节点执行
        });
        taskFlow.addNode("ACTION_2", context -> {
            Object input = context.getInput(); //获取此任务节点的输入数据，输入数据在跳转节点后不会保留
            String value = (String) context.getData("key"); //获取ACTION_1中存放的数据
            //do something...
            context.complete(); //将任务流程设置为完成状态
        });
    }
}
```
如上所示，使用context可以控制整个任务的流程，此外TaskContextFacade还有许多其他功能。

当需要使用某个TaskFlow时，可以发布一个TaskStartEvent，如果此时存在一个对应的事件监听器，那么监听器会触发任务的执行。
几乎所有封装的命令都是这样开始执行的。
```java
public class SomeCommand extends AdvancedCommand<Object> {
    protected TaskResult taskStart() {
        return super.taskActive(null, "SomeTaskName", null, data, SomeTaskStartEvent::new);
    }
}
```
package io.iwd.example;

import io.iwd.common.environment.Environment;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) throws Exception {

        Environment environment = new Environment();
        environment.refresh();

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("waiting command...");
            String input = scanner.nextLine();
            if ("exit".equals(input)) {
                break;
            }
            String[] params = input.split(" ");
            String cls = params[0];
            Class<?> clazz = null;
            try {
                clazz = Class.forName("io.iwd.example." + cls);
            } catch (Exception e) {
                System.out.println("on such class");
            }
            if (clazz == null) {
                continue;
            }
            Method main = clazz.getMethod("main", String[].class);
            try {
                if (params.length > 1) {
                    main.invoke(null, (Object) Arrays.copyOfRange(params, 1, params.length));
                } else {
                    main.invoke(null, (Object) null);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

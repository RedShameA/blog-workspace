package io.iwd.example.hksdk;

import io.iwd.hksdk.Hksdk;

public class HksdkVideoFile {

    public static void main(String[] args) {
        boolean result = Hksdk.HkSdkPullAudio()
                .setDeviceNumber("34020000001110000001")
                .setDeviceChannal("34020000001320000001")
                .setDeviceIp("172.16.80.43")
                .setDevicePort(8000)
                .setDeviceUser("zhy12345")
                .setDevicePwd("admin")
                .setAudiofiletype(1)
                .await(5000);
        if (result) {
            System.out.println("register success");
        }
    }
}

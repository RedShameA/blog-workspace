package io.iwd.example.common;

import io.iwd.common.Common;
import io.iwd.common.entity.ServiceVersionInfo;

import java.util.List;

public class ServicesVersionQuery {

    public static void main(String[] args) {
        io.iwd.common.command.ServicesVersionQuery servicesVersionQuery = Common.servicesVersionQuery();
        Integer count = Integer.parseInt(args[0]);
        List<ServiceVersionInfo> serviceVersionList = servicesVersionQuery.setExpectedServiceCount(count).await(5000);
        StringBuilder builder = new StringBuilder();
        builder.append('[');
        for (ServiceVersionInfo info : serviceVersionList) {
            builder.append(info.toString()).append(',');
        }
        if (!serviceVersionList.isEmpty()) {
            builder.deleteCharAt(builder.length() - 1);
        }
        builder.append(']');
        System.out.println(builder.toString());
    }

}

package io.iwd.example.hksdk;

import io.iwd.hksdk.Hksdk;

public class HksdkVoicePlay {

    public static void main(String[] args) {
//        boolean result = Hksdk.HkSdkVoicePlay()
//                .setDeviceNumber("34020000001110000001")
//                .setChannelNumber("34020000001320000001")
//                .setDeviceIp("172.16.80.40")
//                .setDevicePort(8000)
//                .setDevicePwd("zhy12345")
//                .setDeviceUser("admin")
//                .setDeviceModel(1)
//                .setSdp("v=0\n" +
//                        "o=- 6415196471449871875 2 IN IP4 127.0.0.1\n" +
//                        "s=-\n" +
//                        "t=0 0\n" +
//                        "a=group:BUNDLE 0\n" +
//                        "a=extmap-allow-mixed\n" +
//                        "a=msid-semantic: WMS\n" +
//                        "m=audio 9 UDP/TLS/RTP/SAVPF 111 63 103 104 9 0 8 106 105 13 110 112 113 126\n" +
//                        "c=IN IP4 0.0.0.0\n" +
//                        "a=rtcp:9 IN IP4 0.0.0.0\n" +
//                        "a=ice-ufrag:Fbc1\n" +
//                        "a=ice-pwd:1WgBsyUcdjtxRjBFhhgQ0fmv\n" +
//                        "a=ice-options:trickle\n" +
//                        "a=fingerprint:sha-256 F7:2C:4C:04:17:82:10:A1:5F:05:8B:58:CC:14:A4:56:EC:15:E2:66:04:5A:C1:AC:80:A5:EE:12:9E:AF:40:82\n" +
//                        "a=setup:actpass\n" +
//                        "a=mid:0\n" +
//                        "a=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level\n" +
//                        "a=extmap:2 http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time\n" +
//                        "a=extmap:3 http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01\n" +
//                        "a=extmap:4 urn:ietf:params:rtp-hdrext:sdes:mid\n" +
//                        "a=sendonly\n" +
//                        "a=msid:- cf0d5927-d578-40cd-922b-7a06650e3bc4\n" +
//                        "a=rtcp-mux\n" +
//                        "a=rtpmap:111 opus/48000/2\n" +
//                        "a=rtcp-fb:111 transport-cc\n" +
//                        "a=fmtp:111 minptime=10;useinbandfec=1\n" +
//                        "a=rtpmap:63 red/48000/2\n" +
//                        "a=fmtp:63 111/111\n" +
//                        "a=rtpmap:103 ISAC/16000\n" +
//                        "a=rtpmap:104 ISAC/32000\n" +
//                        "a=rtpmap:9 G722/8000\n" +
//                        "a=rtpmap:0 PCMU/8000\n" +
//                        "a=rtpmap:8 PCMA/8000\n" +
//                        "a=rtpmap:106 CN/32000\n" +
//                        "a=rtpmap:105 CN/16000\n" +
//                        "a=rtpmap:13 CN/8000\n" +
//                        "a=rtpmap:110 telephone-event/48000\n" +
//                        "a=rtpmap:112 telephone-event/32000\n" +
//                        "a=rtpmap:113 telephone-event/16000\n" +
//                        "a=rtpmap:126 telephone-event/8000\n" +
//                        "a=ssrc:3565359586 cname:sumrzxNcA2SEpByF\n" +
//                        "a=ssrc:3565359586 msid:- cf0d5927-d578-40cd-922b-7a06650e3bc4\n")
//                .setVideoSsrc("Sew4ew")
//                .await(5000);
//        if (result) {
//            System.out.println("register success");
//        }
    }
}

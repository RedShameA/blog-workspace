package io.iwd.example.gb28181;

import io.iwd.gb28181.Gb28181;

public class RegisterDevice {

    public static void main(String[] args) {
        Boolean result = Gb28181.deviceRegister()
                .setDeviceNumber(args[0])
                .setHeartbeatInterval(Integer.parseInt(args[1]))
                .setMaxHeartbeatLost(Integer.parseInt(args[2]))
                .setPassword(args[3])
                .setServerId(args[4])
                .setServerIp(args[5])
                .setServerPort(Integer.parseInt(args[6]))
                .await();
        if (result) {
            System.out.println("register success");
        }
    }
}

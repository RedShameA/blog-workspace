package io.iwd.example.hksdk;

import io.iwd.hksdk.Hksdk;

public class HksdkPhoto {

    public static void main(String[] args) {
//        boolean result = Hksdk.HkSdkPhoto()
//                .setDeviceNumber("34020000001110000001")
//                .setDeviceChannal("34020000001320000001")
//                .setSdkId("1")
//                .setSdkIp("172.16.80.43")
//                .setSdkPort("8000")
//                .setSdkPwd("zhy12345")
//                .setSdkUser("admin")
//                .await(5000);
//        if (result) {
//            System.out.println("register success");
//        }
    }
}

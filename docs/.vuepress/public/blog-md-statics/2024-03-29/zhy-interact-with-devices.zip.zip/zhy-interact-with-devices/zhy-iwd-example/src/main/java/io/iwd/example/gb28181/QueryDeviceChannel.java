package io.iwd.example.gb28181;

import io.iwd.gb28181.Gb28181;
import io.iwd.gb28181.entity.DeviceChannelQueryResult;

public class QueryDeviceChannel {

    public static void main(String[] args) {
        DeviceChannelQueryResult result = Gb28181.deviceChannelQuery()
                .setDeviceNumber(args[0])
                .setUseCache(Boolean.parseBoolean(args[1]))
                .await();
        System.out.println(result.toString());
    }
}

package io.iwd.example.common;

import io.iwd.common.Common;

public class SrsAllStreamInfoQuery {

    public static void main(String[] args) {
        io.iwd.common.command.SrsAllStreamInfoQuery srsAllStreamInfoQuery = Common.srsAllStreamInfoQuery();
        String info = srsAllStreamInfoQuery.await(5000);
        System.out.println(info);
    }

}

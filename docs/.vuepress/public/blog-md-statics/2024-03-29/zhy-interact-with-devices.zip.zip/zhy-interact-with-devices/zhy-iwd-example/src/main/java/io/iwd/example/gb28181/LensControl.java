package io.iwd.example.gb28181;

import io.iwd.gb28181.Gb28181;
import io.iwd.gb28181.Gb28181Const;

public class LensControl {

    public static void main(String[] args) {
        io.iwd.gb28181.command.LensControl lensControl = Gb28181.lensControl()
                .setDeviceNumber(args[0])
                .setChannelNumber(args[1]);
        if (args.length >= 3) {
            lensControl.setLensControlOption(Gb28181Const.LensControlOption.valueOf(args[2]));
        }
        if (args.length >= 4) {
            lensControl.setControlSpeedOption(Gb28181Const.ControlSpeedOption.valueOf(args[3]));
        }
        Boolean result = lensControl.await(100L);
        if (result) {
            System.out.println("control success");
        }
    }

}

package io.iwd.example.common;

import io.iwd.common.Common;

public class SrsVersionQuery {

    public static void main(String[] args) {
        io.iwd.common.command.SrsVersionQuery srsVersionQuery = Common.srsVersionQuery();
        String version = srsVersionQuery.await(5000);
        System.out.println(version);
    }

}

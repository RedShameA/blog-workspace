package io.iwd.common.engine;

import io.iwd.common.environment.ManagerLifecycle;

/**
 * 任务执行器的管理器。
 */
public class TaskReactorManager implements ManagerLifecycle {

    /**
     * 执行线程数。
     */
    private final int reactorCount;

    /**
     * 所有执行线程。
     */
    private final TaskReactor[] reactors;

    /**
     * 标准构造器
     * @param reactorCount 执行线程数。
     */
    public TaskReactorManager(int reactorCount) {
        this.reactorCount = reactorCount;
        this.reactors = new TaskReactor[this.reactorCount];
    }

    /**
     * 为任务选择一个执行线程。
     * @param taskId 任务id。
     * @return 执行器。
     */
    public TaskReactor chooseReactor(String taskId) {
        int index = Math.abs(taskId.hashCode() % this.reactorCount);
        return this.reactors[index];
    }

    @Override
    public void active() {
        for (int i = 0; i < this.reactorCount; i++) {
            this.reactors[i] = new TaskReactor("reactor-" + i);
            this.reactors[i].start();
        }
    }

    @Override
    public void destroy() {
        for (TaskReactor taskReactor : this.reactors) {
            taskReactor.close();
        }
    }
}

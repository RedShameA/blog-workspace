package io.iwd.common.stdio.redis;

public interface Redis {

    /**
     * 使用静默模式，不接收redis的响应。
     * @return 静默模式redis。
     */
    static Redis silentMode() {
        return RedisHolder.SILENT_MODE;
    }

    /**
     * 使用交互模式，接收redis的响应。
     * @return 交互模式redis。
     */
    static Redis interactiveMode() {
        return RedisHolder.INTERACTIVE_MODE;
    }

    static boolean isException(Object input) {
        return input instanceof RedisException;
    }

    RedisCommandWrapper command(RedisCommand redisCommand, String... params);

    void publish(String channelName, String message);

    void eval(String script, int keysNum, String... params);

    void get(String key);

    void set(String key, String value);

    void del(String key);

    void hget(String key, String field);

    void hset(String key, String field, String value);

    void hdel(String key, String field);

    void hgetall(String key);

    void rpush(String key, String... values);

}

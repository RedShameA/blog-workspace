package io.iwd.common.event.srs;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;
import io.iwd.common.ext.util.Generator;

/**
 * srs关闭rtmp视频源的事件。
 */
public class SrsCloseRtmpSourceEvent extends TaskStartEvent {

    public SrsCloseRtmpSourceEvent(Object data) {
        super(null, "SrsCloseRtmpSource", data, new TaskResult());
    }

    public String getTaskId() {
        return Generator.create32UniqueId();
    }
}

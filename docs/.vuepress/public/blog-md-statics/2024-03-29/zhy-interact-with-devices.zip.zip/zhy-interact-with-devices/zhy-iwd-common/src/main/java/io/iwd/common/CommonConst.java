package io.iwd.common;

public class CommonConst {

    public static final String TASK_PREFIX = "common";

    public static final String ORIGINAL_PICTURE_INFO_LIST = "IPM_ORIGINAL_MSG";

    public static final String ALARM_PICTURE_INFO_LIST = "IPM_ALARM_MSG";

}

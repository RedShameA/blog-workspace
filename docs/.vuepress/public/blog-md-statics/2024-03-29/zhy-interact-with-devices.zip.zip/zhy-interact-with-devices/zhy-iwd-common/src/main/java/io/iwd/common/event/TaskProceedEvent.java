package io.iwd.common.event;

/**
 * 任务继续事件抽象基类。
 */
public abstract class TaskProceedEvent implements Event {

    /**
     * 任务id。
     */
    private final String taskId;

    /**
     * 需要输入的数据。
     */
    private final Object data;

    /**
     * 标准构造器。
     * @param taskId 任务id。
     * @param data 需要输入的数据。
     */
    public TaskProceedEvent(String taskId, Object data) {
        this.taskId = taskId;
        this.data = data;
    }

    /**
     * 获取任务id。
     * @return 任务id。
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * 获取输入的数据。
     * @return 输入的数据。
     */
    public Object getData() {
        return data;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() +
                "[taskId:\"" + this.taskId + "]";
    }
}

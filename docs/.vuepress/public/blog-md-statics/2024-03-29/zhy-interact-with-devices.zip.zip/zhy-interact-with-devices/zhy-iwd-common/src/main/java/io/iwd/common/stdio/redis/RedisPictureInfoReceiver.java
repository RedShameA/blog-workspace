package io.iwd.common.stdio.redis;

import io.iwd.common.entity.AlarmPictureInfo;
import io.iwd.common.entity.OriginalPictureInfo;
import io.iwd.common.environment.*;
import io.iwd.common.event.CommonDefaultTaskProceedEvent;
import io.iwd.common.event.ipm.AlarmPictureReceivedEvent;
import io.iwd.common.event.ipm.OriginalPictureReceivedEvent;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.misc.NettyComponentThreadFactory;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.StringUtil;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.*;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.redis.*;
import io.netty.util.CharsetUtil;
import io.netty.util.ReferenceCountUtil;
import io.netty.util.concurrent.ScheduledFuture;

import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import static io.iwd.common.CommonConst.ALARM_PICTURE_INFO_LIST;
import static io.iwd.common.CommonConst.ORIGINAL_PICTURE_INFO_LIST;

/**
 * redis图片信息接收器，用于获取ipm入队的图片信息。
 * 与redis建立一个连接，用BLPOP命令不断读取数据。
 */
public class RedisPictureInfoReceiver implements ManagerLifecycle, RedisClient {

    protected static final String[] ALL_PICTURE_KEYS = new String[] {ORIGINAL_PICTURE_INFO_LIST, ALARM_PICTURE_INFO_LIST};

    protected static final String[] ORIGINAL_PICTURE_KEYS = new String[] {ORIGINAL_PICTURE_INFO_LIST};

    protected static final String[] ALARM_PICTURE_KEYS = new String[] {ALARM_PICTURE_INFO_LIST};

    protected final String ip;

    protected final int port;

    protected final String password;

    protected final boolean autoReconnect;

    protected final int popTimeout;

    protected final boolean auto;

    protected final AtomicBoolean closed;

    protected final ReadWriteLock lock;

    protected EventLoopGroup eventLoopGroup;

    protected Channel channel;

    public RedisPictureInfoReceiver(String ip, int port, String password, boolean autoReconnect, int popTimeout, boolean auto) {
        this.ip = ip;
        this.port = port;
        this.password = password;
        this.autoReconnect = autoReconnect;
        this.popTimeout = popTimeout;
        this.auto = auto;
        this.closed = new AtomicBoolean(false);
        this.lock = new ReentrantReadWriteLock();
    }

    @Override
    public void active() {
        if (this.eventLoopGroup != null || this.closed.get()) {
            return;
        }

        this.eventLoopGroup = EnvironmentHolder.get().isEpollAvailable() ?
                new EpollEventLoopGroup(1, new NettyComponentThreadFactory(getClass())) :
                new NioEventLoopGroup(1, new NettyComponentThreadFactory(getClass()));

        connectAndInit();
    }

    @Override
    public void destroy() {
        if (!this.closed.compareAndSet(false, true)) {
            return;
        }

        disconnect();

        if (this.eventLoopGroup != null) {
            this.eventLoopGroup.shutdownGracefully().awaitUninterruptibly();
            this.eventLoopGroup = null;
        }
    }

    @Override
    public void connectAndInit() {
        Lock lock = this.lock.writeLock();
        lock.lock();
        try {

            do {
                if (this.closed.get() || this.channel != null) {
                    return;
                }

                final RedisClient redisClient = this;
                final String password = this.password;
                final boolean auto = this.auto;
                //需要等pipeline初始化完才能使用
                final CountDownLatch countDownLatch = new CountDownLatch(1);
                final int popTimeout = this.popTimeout;

                boolean shouldReconnect = this.autoReconnect && !this.closed.get();

                Bootstrap bootstrap = new Bootstrap();
                bootstrap.group(this.eventLoopGroup);
                bootstrap.channel(EnvironmentHolder.get().isEpollAvailable() ?
                        EpollSocketChannel.class :
                        NioSocketChannel.class);
                bootstrap.handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        pipeline.addLast(new RedisEncoder());
                        pipeline.addLast(new RedisDecoder());
                        pipeline.addLast(new RedisBulkStringAggregator());
                        pipeline.addLast(new RedisArrayAggregator());
                        pipeline.addLast(new RedisPictureInfoReceiver.RedisChannelInitializer(redisClient, password, countDownLatch, popTimeout, auto));
                    }
                });

                bootstrap
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                        .option(ChannelOption.SO_KEEPALIVE, true)
                        .option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
                        .remoteAddress(new InetSocketAddress(ip, port));

                Logger.info(getClass().getSimpleName() + " connecting Redis");
                ChannelFuture channelFuture = bootstrap
                        .connect()
                        .awaitUninterruptibly();

                Channel channel = channelFuture.channel();

                if (!channelFuture.isSuccess()) {
                    if (channel != null) {
                        channel.close().awaitUninterruptibly();
                    }
                    this.channel = null;
                    Logger.error("RedisPictureInfoReceiver failed to connect Redis " + ip + ":" + port + (shouldReconnect ? ", reconnecting" : ""));
                    if (shouldReconnect) {
                        continue;
                    }
                    return;
                }

                boolean initSuccess;
                try {
                    initSuccess = countDownLatch.await(10, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    initSuccess = false;
                }
                if (!initSuccess) {
                    if (channel != null) {
                        channel.close().awaitUninterruptibly();
                    }
                    this.channel = null;
                    Logger.error("RedisPictureInfoReceiver failed to initialize" + (shouldReconnect ? ", reconnecting" : ""));
                    if (shouldReconnect) {
                        continue;
                    }
                    return;

                }
                this.channel = channel;
                Logger.info("RedisPictureInfoReceiver connected Redis " + ip + ":" + port);
                break;

            } while (true);

        } finally {
            lock.unlock();
        }
    }

    @Override
    public void disconnect() {
        Lock lock = this.lock.writeLock();
        lock.lock();
        try {
            if (this.channel != null) {
                this.channel.close().awaitUninterruptibly();
                this.channel = null;
            }
            Logger.info("RedisPictureInfoReceiver disconnected Redis " + ip + ":" + port);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void reconnectAndInit() {
        Lock lock = this.lock.writeLock();
        lock.lock();
        try {
            disconnect();
            connectAndInit();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean isAutoReconnect() {
        return this.autoReconnect;
    }

    @Override
    public boolean isClosed() {
        return this.closed.get();
    }

    protected void executeBlpop(String taskId, String[] keys) {
        if (this.auto) {
            Logger.warn("can not get picture info manually, receiver is in auto mode");
            return;
        }
        Lock lock = this.lock.readLock();
        if (!lock.tryLock()) {
            Logger.warn("blpop command execute failed, can not get lock" );
            return;
        }
        try {
            if (this.channel != null) {
                this.channel.writeAndFlush(new BlpopCommandWrapper(taskId, keys));
            }
        } finally {
            lock.unlock();
        }
    }

    protected static String responseToString(Object response) {
        if (response instanceof List) {
            List<?> list = (List<?>) response;
            if (list.size() == 0) {
                return "(empty list or set)";
            }
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < list.size(); i++) {
                builder.append(i + 1).append(')');
                builder.append(list.get(i));
                builder.append(' ');
            }
            return builder.toString();
        }
        return String.valueOf(response);
    }

    static class RedisChannelInitializer extends RedisConnectHandler {

        private final CountDownLatch countDownLatch;

        private final int popTimeout;

        private final boolean auto;

        public RedisChannelInitializer(RedisClient redisClient, String password, CountDownLatch countDownLatch, int popTimeout, boolean auto) {
            super(redisClient, password);
            this.countDownLatch = countDownLatch;
            this.popTimeout = popTimeout;
            this.auto = auto;
        }

        @Override
        protected void channelActiveInternal(ChannelHandlerContext ctx) throws Exception {

            //移除RedisChannelInitializer
            ctx.channel().pipeline().removeLast();

            //添加RedisChannelHandler
            if (this.auto) {
                ctx.channel().pipeline().addLast(new AutoModeHandler(super.redisClient, this.popTimeout));
            } else {
                ctx.channel().pipeline().addLast(new ManualModeHandler(super.redisClient, this.popTimeout));
            }

            this.countDownLatch.countDown();
        }
    }

    static abstract class RedisChannelHandler extends ChannelDuplexHandler {

        /**
         * 此handler关联的redis客户端。
         */
        protected final RedisClient redisClient;

        protected final int popTimeout;

        /**
         * 此handler的ctx，供writeRedisMessage()发送命令使用。
         */
        protected ChannelHandlerContext channelHandlerContext;

        protected ScheduledFuture<?> monitor;

        public RedisChannelHandler(RedisClient redisClient, int popTimeout) {
            this.redisClient = redisClient;
            this.popTimeout = popTimeout;
        }

        protected abstract String lastBlpopKeys();

        protected abstract void handleResult(List<String> result);

        @Override
        public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
            this.channelHandlerContext = ctx;
        }

        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
            if (! (msg instanceof RedisMessage)) {
                return;
            }
            String lastBlpopKeys = lastBlpopKeys();
            if (lastBlpopKeys == null) {
                Logger.error("received response, but no last blpop keys");
                return;
            }
            //收到redis响应
            try {
                parsePictureInfo: {
                    RedisMessage redisMessage = (RedisMessage) msg;
                    if (redisMessage instanceof ErrorRedisMessage) {
                        Logger.info("BLPOP " + lastBlpopKeys() + " " + this.popTimeout + " >>> " + ((ErrorRedisMessage) redisMessage).content());
                        break parsePictureInfo;
                    }
                    if (! (redisMessage instanceof ArrayRedisMessage)) {
                        Logger.warn("received unexpected message");
                        break parsePictureInfo;
                    }

                    ArrayRedisMessage arrayRedisMessage = (ArrayRedisMessage) msg;
                    if (arrayRedisMessage.isNull()) {
                        Logger.info("BLPOP " + lastBlpopKeys() + " " + this.popTimeout + " >>> null");
                        break parsePictureInfo;
                    }
                    List<RedisMessage> children = arrayRedisMessage.children();
                    List<String> result = new LinkedList<>();
                    for (RedisMessage rm : children) {
                        if (rm instanceof FullBulkStringRedisMessage) {
                            FullBulkStringRedisMessage fullBulkStringRedisMessage = (FullBulkStringRedisMessage) rm;
                            String m = fullBulkStringRedisMessage.isNull() ? null : fullBulkStringRedisMessage.content().toString(CharsetUtil.UTF_8);
                            result.add(m);
                        }
                    }
                    Logger.info("BLPOP " + lastBlpopKeys() + " " + this.popTimeout + " >>> " + responseToString(result));

                    handleResult(result);
                }
            } finally {
                ReferenceCountUtil.release(msg);
            }
        }

        @Override
        public void channelInactive(ChannelHandlerContext ctx) throws Exception {
            if (this.monitor != null) {
                this.monitor.cancel(false);
            }
            boolean shouldReconnect = this.redisClient.isAutoReconnect() && !this.redisClient.isClosed();
            Logger.warn("redis connection (RedisPictureInfoReceiver) closed" + (shouldReconnect ? ", reconnecting" : ""));
            if (!shouldReconnect) {
                return;
            }
            new Thread(this.redisClient::reconnectAndInit).start();
        }

        protected void blpop(ChannelHandlerContext ctx, String... keys) {
            if (keys == null || keys.length == 0) {
                Logger.warn("can not execute blpop without key");
                return;
            }
            List<RedisMessage> messages = new ArrayList<>(keys.length + 1);
            messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(ctx.alloc(), "BLPOP"))); //blpop
            for (String k : keys) {
                messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(ctx.alloc(), k)));
            }
            messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(ctx.alloc(), String.valueOf(this.popTimeout)))); //超时时间
            RedisMessage redisMessage = new ArrayRedisMessage(messages);
            ctx.writeAndFlush(redisMessage);
        }
    }

    static class AutoModeHandler extends RedisChannelHandler {

        private static final String BLPOP_KEYS = ALARM_PICTURE_INFO_LIST + " " + ORIGINAL_PICTURE_INFO_LIST;

        private int inactiveTimes;

        AutoModeHandler(RedisClient redisClient, int popTimeout) {
            super(redisClient, popTimeout);
            this.inactiveTimes = 0;
        }

        @Override
        protected String lastBlpopKeys() {
            return BLPOP_KEYS;
        }

        @Override
        protected void handleResult(List<String> result) {
            String firstElement = result.get(0);
            if (firstElement != null) { //不是超时响应
                String infoStr = result.get(1);
                JsonObject pictureInfo = JsonObject.from(infoStr);
                switch (firstElement) {
                    case ORIGINAL_PICTURE_INFO_LIST:
                        //解析
                        OriginalPictureInfo originalPictureInfo = new OriginalPictureInfo(pictureInfo);
                        //发布事件
                        new OriginalPictureReceivedEvent(originalPictureInfo).publish();
                        break;
                    case ALARM_PICTURE_INFO_LIST:
                        //解析
                        AlarmPictureInfo alarmPictureInfo = new AlarmPictureInfo(pictureInfo);
                        //发布事件
                        new AlarmPictureReceivedEvent(alarmPictureInfo).publish();
                        break;
                }
            }
        }

        @Override
        public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
            super.handlerAdded(ctx);
            super.monitor = ctx.channel().eventLoop().scheduleWithFixedDelay(() -> {
                if (this.inactiveTimes >= 1) {
                    //最多两次检测到不活跃，断开连接
                    this.channelHandlerContext.channel().close();
                }
            }, super.popTimeout, super.popTimeout, TimeUnit.SECONDS); //redis可能因为执行了耗时操作而长时间不响应 需要观察

            //开始执行blpop
            super.blpop(ctx, ALL_PICTURE_KEYS);
        }

        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
            super.channelRead(ctx, msg);
            //清空inactiveTimes
            this.inactiveTimes = 0;
            //继续blpop
            super.blpop(ctx, ALL_PICTURE_KEYS);
        }

    }

    static class ManualModeHandler extends RedisChannelHandler {

        private final Deque<BlpopCommandWrapper> deque;

        private BlpopCommandWrapper commandPointer;

        public ManualModeHandler(RedisClient redisClient, int popTimeout) {
            super(redisClient, popTimeout);
            this.deque = new LinkedList<>();
        }

        @Override
        protected String lastBlpopKeys() {
            BlpopCommandWrapper blpopCommandWrapper = this.deque.peekFirst();
            if (blpopCommandWrapper == null) {
                return null;
            }
            String[] keys = blpopCommandWrapper.getKeys();
            if (keys == null || keys.length == 0) {
                return null;
            }
            StringBuilder keysBuilder = new StringBuilder();
            for (String k : keys) {
                keysBuilder.append(k).append(' ');
            }
            keysBuilder.deleteCharAt(keysBuilder.length() - 1);
            return keysBuilder.toString();
        }

        @Override
        protected void handleResult(List<String> result) {
            BlpopCommandWrapper blpopCommandWrapper = this.deque.pollFirst();
            if (blpopCommandWrapper == null) {
                Logger.error("can not poll BlpopCommandWrapper, this should not happen");
                return;
            }
            String taskId = blpopCommandWrapper.getTaskId();

            String firstElement = result.get(0);
            if (firstElement != null) { //不是超时响应
                String infoStr = result.get(1);
                JsonObject pictureInfo = JsonObject.from(infoStr);
                new CommonDefaultTaskProceedEvent(taskId, pictureInfo).publish();
            }
        }

        @Override
        public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
            super.handlerAdded(ctx);
            this.monitor = ctx.channel().eventLoop().scheduleWithFixedDelay(() -> {
                BlpopCommandWrapper theEarliest = this.deque.peekFirst();
                if (this.commandPointer == null || this.commandPointer != theEarliest) { //这里不能用equals()
                    this.commandPointer = theEarliest;
                    return;
                }
                //最早的命令未收到回复，断开
                this.channelHandlerContext.channel().close();
            }, super.popTimeout + 30, super.popTimeout + 30, TimeUnit.SECONDS);
        }

        @Override
        public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
            if (! (msg instanceof BlpopCommandWrapper)) {
                return;
            }
            BlpopCommandWrapper command = (BlpopCommandWrapper) msg;
            String taskId = command.getTaskId();
            String[] keys = command.getKeys();

            if (StringUtil.isEmpty(taskId)) {
                return;
            }
            if (keys == null || keys.length == 0) {
                return;
            }

            this.deque.addLast(command);

            super.blpop(ctx, command.getKeys());
        }

    }

    static class BlpopCommandWrapper {

        private String taskId;

        private String[] keys;

        public BlpopCommandWrapper(String taskId, String[] keys) {
            this.taskId = taskId;
            this.keys = keys;
        }

        public String getTaskId() {
            return taskId;
        }

        public String[] getKeys() {
            return keys;
        }
    }

    public static class PictureInfoReceiverPlugin extends Plugin<RedisPictureInfoReceiver> {

        @Override
        @SuppressWarnings("unchecked")
        public void init() {
            GlobalConfiguration globalConfiguration = EnvironmentHolder.get().config();
            //获取redis相关配置
            Map<String, Object> redisConfig = (Map<String, Object>) globalConfiguration.getGlobalConfig("redis");
            if (redisConfig == null) {
                return;
            }
            //ip、端口、密码
            String ip = (String) redisConfig.get("ip");
            Number confPort = (Number) redisConfig.get("port");
            String password = (String) redisConfig.get("password");
            if (StringUtil.isEmpty(ip)) {
                ip = "127.0.0.1";
            }
            if (confPort == null) {
                confPort = 6379;
            }
            int port = NumberUtil.toInt(confPort);
            if (port < 1 || port > 65535) {
                port = 6379;
            }
            Boolean autoReconnect = (Boolean) redisConfig.get("auto_reconnect");
            if (autoReconnect == null) {
                autoReconnect = Boolean.TRUE;
            }

            int popTimeout = NumberUtil.toInt(super.configParams.get("pop_timeout"));
            boolean auto = (Boolean) super.configParams.get("auto");

            this.name = "RedisPictureInfoReceiver";
            this.internal = new RedisPictureInfoReceiver(ip, port, password, autoReconnect, popTimeout, auto);
        }

        public void getAnyPictureInfo(String taskId) {
            this.internal.executeBlpop(taskId, ALL_PICTURE_KEYS);
        }

        public void getOriginPictureInfo(String taskId) {
            this.internal.executeBlpop(taskId, ORIGINAL_PICTURE_KEYS);
        }

        public void getAlarmPictureInfo(String taskId) {
            this.internal.executeBlpop(taskId, ALARM_PICTURE_KEYS);
        }

    }
    
}

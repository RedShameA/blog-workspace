package io.iwd.common.stdio.http;

import io.iwd.common.engine.TaskContext;
import io.iwd.common.engine.TaskExecutor;
import io.iwd.common.environment.Environment;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.event.Event;
import io.iwd.common.event.TaskProceedEvent;
import io.iwd.common.ext.log.Logger;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.epoll.EpollSocketChannel;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.util.function.BiFunction;

/**
 * http请求模板公共抽象基类。
 */
public abstract class AbstractHttpTemplate {

    public static final String APPLICATION_JSON = "application/json; charset=UTF-8";

    private static final Class<? extends SocketChannel> CHANNEL_TYPE =
            EnvironmentHolder.get().isEpollAvailable() ?
                    EpollSocketChannel.class :
                    NioSocketChannel.class;

    protected boolean ssl;

    protected String taskId;

    protected BiFunction<String, Object, TaskProceedEvent> eventConstructor;

    public AbstractHttpTemplate() {
    }

    /**
     * 子类构建Bootstrap时用来获取EventLoopGroup。
     * @return EventLoopGroup。
     */
    protected EventLoopGroup getEventLoopGroup() {
        HttpSender httpSender = EnvironmentHolder.get().httpSender();
        if (httpSender == null) {
            throw new RuntimeException("can not get HttpSender");
        }
        return httpSender.getEventLoopGroup();
    }

    /**
     * 子类构建Bootstrap时用来获取channel类型。
     * @return channel类型。
     */
    protected Class<? extends SocketChannel> getChannelType() {
        return CHANNEL_TYPE;
    }

    /**
     * 子类需要实现以向此父类暴露Bootstrap。
     * @return Bootstrap。
     */
    protected abstract Bootstrap getBootstrap();

    /**
     * 连接建立前需要执行的操作。需要子类重写。
     */
    protected void beforeConnect() {
    }

    public AbstractHttpTemplate forTask(String taskId) {
        this.taskId = taskId;
        return this;
    }

    public AbstractHttpTemplate onResponse(BiFunction<String, Object, TaskProceedEvent> eventConstructor) {
        this.eventConstructor = eventConstructor;
        return this;
    }

    /**
     * 依照模板发送请求。
     */
    public void send() {
        Thread currentThread = Thread.currentThread();
        if (currentThread instanceof TaskExecutor) {
            TaskExecutor taskExecutor = (TaskExecutor) currentThread;
            TaskContext context = taskExecutor.getContext();
            if (this.taskId == null) {
                forTask(context.getTaskId());
            }
            if (this.eventConstructor == null) {
                onResponse(context.getDefaultTaskProceedEventConstructor());
            }
        }
        if (this.taskId == null || this.eventConstructor == null) {
            Logger.warn("http template must have task id and event constructor");
            return;
        }
        Bootstrap bootstrap = getBootstrap();
        if (bootstrap == null) {
            return;
        }
        beforeConnect();
        bootstrap.connect();
    }

}

package io.iwd.common.event;

import java.util.List;

/**
 * 事件监听器接口。
 * 对于一些阻塞操作，强烈不建议在{@link EventListener#handleEvent(Event)}中执行，
 * 可以转交给其他线程执行，例如提交到线程池{@link java.util.concurrent.ExecutorService#submit(Runnable)}。
 */
public interface EventListener {

    /**
     * 处理事件。
     * 此方法的实现应尽可能避免阻塞操作。
     * @param event 事件。
     */
    void handleEvent(Event event);

    /**
     * 获取感兴趣的事件类型列表。
     * @return 感兴趣的事件类型列表。
     */
    List<Class<? extends Event>> interests();

}

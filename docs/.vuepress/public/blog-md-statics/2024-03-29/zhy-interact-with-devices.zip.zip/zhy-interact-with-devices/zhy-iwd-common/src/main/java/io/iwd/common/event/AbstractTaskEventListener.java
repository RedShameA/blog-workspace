package io.iwd.common.event;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowRegistry;
import io.iwd.common.engine.TaskReactor;
import io.iwd.common.engine.TaskReactorManager;
import io.iwd.common.environment.Environment;
import io.iwd.common.environment.EnvironmentHolder;

/**
 * 任务事件监听器公共抽象基类。
 */
public abstract class AbstractTaskEventListener implements TaskEventListener {

    @Override
    public void handleEvent(Event event) {
        if (event instanceof TaskProceedEvent) {
            handleTaskProceedEvent((TaskProceedEvent) event);
        } else if (event instanceof TaskStartEvent) {
            handleTaskStartEvent((TaskStartEvent) event);
        }
    }

    /**
     * 处理任务开始事件。
     * @param event 事件。
     */
    protected void handleTaskStartEvent(TaskStartEvent event) {
        String taskId = event.getTaskId();
        String taskPrefix = event.getTaskPrefix();
        if (taskPrefix == null) {
            taskPrefix = this.defaultTaskPrefix();
        }
        String taskName = event.getTaskName();
        Environment environment = EnvironmentHolder.get();
        //选择一个执行线程
        TaskReactorManager taskReactorManager = environment.taskReactorManager();
        if (taskReactorManager == null) {
            throw new RuntimeException("can not get TaskReactorManager");
        }
        TaskReactor reactor = taskReactorManager.chooseReactor(taskId);
        if (reactor == null) {
            throw new RuntimeException("no available task reactor");
        }
        TaskFlowRegistry taskFlowRegistry = environment.taskFlowRegistry();
        if (taskFlowRegistry == null) {
            throw new RuntimeException("can not get TaskFlowRegistry");
        }
        TaskFlow taskFlow = taskFlowRegistry.getTaskFlow(taskPrefix, taskName);
        if (taskFlow == null) {
            throw new RuntimeException("no such task flow: " + taskPrefix + ":" + taskName);
        }
        //开始任务
        reactor.taskStart(taskFlow, taskId, event.getEntranceName(), event.getData(), event.getTaskResult());
    }

    /**
     * 处理任务继续事件。
     * @param event 事件。
     */
    protected void handleTaskProceedEvent(TaskProceedEvent event) {
        String taskId = event.getTaskId();
        //找到之前的执行线程
        TaskReactorManager taskReactorManager = EnvironmentHolder.get().taskReactorManager();
        if (taskReactorManager == null) {
            throw new RuntimeException("can not get TaskReactorManager");
        }
        TaskReactor reactor = taskReactorManager.chooseReactor(taskId);
        if (reactor == null) {
            throw new RuntimeException("no available task reactor");
        }
        reactor.taskProceed(taskId, event.getData());
    }

}

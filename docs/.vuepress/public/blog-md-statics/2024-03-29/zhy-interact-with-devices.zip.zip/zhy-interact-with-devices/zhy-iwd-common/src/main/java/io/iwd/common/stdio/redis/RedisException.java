package io.iwd.common.stdio.redis;

public class RedisException extends RuntimeException {

    public RedisException(String msg) {
        super(msg);
    }

}

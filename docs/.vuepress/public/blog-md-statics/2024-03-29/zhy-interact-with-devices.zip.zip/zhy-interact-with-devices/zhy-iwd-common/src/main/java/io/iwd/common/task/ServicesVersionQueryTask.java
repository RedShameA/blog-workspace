package io.iwd.common.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.event.CommonDefaultTaskProceedEvent;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;

import java.text.SimpleDateFormat;
import java.util.Date;

import static io.iwd.common.CommonConst.TASK_PREFIX;

public class ServicesVersionQueryTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "ServicesVersionQuery", CommonDefaultTaskProceedEvent::new);

        taskFlow.addNode("QUERY_VERSION", context -> {

            Integer expectedServicesCount = (Integer) context.getInput();
            context.putData("expectedServicesCount", expectedServicesCount);
            context.putData("receivedResponseCount", 0);
            JsonObject data = JsonObject.create();
            context.putData("data", data);

            JsonObject message = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("systime", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));

            Redis.silentMode().publish("GET_MODULE_STATE", message.stringify());

            context.setNext("RECEIVED_ONE_RESPONSE");
            JsonObject finalMessage = JsonObject.create()
                    .put("code", Code.TIMEOUT_BUT_CONSIDERED_COMPLETED | 0x0001)
                    .put("data", data);
            context.setTimeoutMessage(finalMessage);
            context.setTimestamp(System.currentTimeMillis() + 3000);
            context.await();
        });

        taskFlow.addNode("RECEIVED_ONE_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            String name = input.getString("module_nm");
            String version = input.getString("module_version");
            JsonObject data = (JsonObject) context.getData("data");
            data.put(name, version);

            Integer receivedResponseCount = (Integer) context.getData("receivedResponseCount");
            receivedResponseCount++;
            context.putData("receivedResponseCount", receivedResponseCount);

            Integer expectedServicesCount = (Integer) context.getData("expectedServicesCount");

            if (expectedServicesCount - receivedResponseCount <= 0) {
                context.complete(JsonObject.create()
                        .put("code", Code.NORMAL_SUCCESS | 0x0001)
                        .put("data", data)
                );
                return;
            }

            context.setNext("RECEIVED_ONE_RESPONSE");
            JsonObject finalMessage = JsonObject.create()
                    .put("code", Code.TIMEOUT_BUT_CONSIDERED_COMPLETED | 0x0001 + receivedResponseCount)
                    .put("data", data);
            context.setTimeoutMessage(finalMessage);
            context.setTimestamp(System.currentTimeMillis() + 3000);
            context.await();
        });

        return taskFlow;
    }

}

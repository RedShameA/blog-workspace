package io.iwd.common.event.srs;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;
import io.iwd.common.ext.util.Generator;

/**
 * srs关闭webrtc视频的事件。
 */
public class SrsCloseRtcEvent extends TaskStartEvent {

    public SrsCloseRtcEvent(Object data) {
        super(null, "SrsCloseRtc", data, new TaskResult());
    }

    public String getTaskId() {
        return Generator.create32UniqueId();
    }

}

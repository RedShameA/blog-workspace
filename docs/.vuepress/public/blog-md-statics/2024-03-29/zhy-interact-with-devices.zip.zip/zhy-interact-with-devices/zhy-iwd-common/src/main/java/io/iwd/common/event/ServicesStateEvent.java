package io.iwd.common.event;

import io.iwd.common.entity.ServiceStateInfo;

public class ServicesStateEvent implements Event {

    private final ServiceStateInfo serviceStateInfo;

    public ServicesStateEvent(ServiceStateInfo serviceStateInfo) {
        this.serviceStateInfo = serviceStateInfo;
    }

    public ServiceStateInfo getServiceStateInfo() {
        return serviceStateInfo;
    }
}

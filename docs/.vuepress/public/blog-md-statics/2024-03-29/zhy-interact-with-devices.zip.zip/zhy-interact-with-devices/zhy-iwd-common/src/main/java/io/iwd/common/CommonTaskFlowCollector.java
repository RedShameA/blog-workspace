package io.iwd.common;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowCollector;
import io.iwd.common.task.ServicesVersionQueryTask;
import io.iwd.common.task.SrsAllStreamInfoQueryTask;
import io.iwd.common.task.SrsVersionQueryTask;

import java.util.LinkedList;
import java.util.List;

public class CommonTaskFlowCollector implements TaskFlowCollector {

    @Override
    public List<TaskFlow> getTaskFlowList() {

        List<TaskFlow> taskFlowList = new LinkedList<>();

        //服务版本查询
        taskFlowList.add(new ServicesVersionQueryTask().getTaskFlow());
        //srs版本查询
        taskFlowList.add(new SrsVersionQueryTask().getTaskFlow());
        //srs全部流信息查询
        taskFlowList.add(new SrsAllStreamInfoQueryTask().getTaskFlow());

        return taskFlowList;
    }
}

package io.iwd.common.stdio.redis;

public final class RedisHolder {

    private RedisHolder() {}

    static final Redis SILENT_MODE = new SilentModeRedis();

    static final Redis INTERACTIVE_MODE = new InteractiveModeRedis();

}

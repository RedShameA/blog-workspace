package io.iwd.common.ext.util;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceArray;

public class MpscLinkedArrayQueue<E> {

    protected static final int MAX_CHUNK_CAPACITY = 0x80;

    protected static final int MAX_QUEUE_SIZE = 0x20000000;

    protected static final Object JUMP = new Object();

    protected static final Object BUFFER_CONSUMED = new Object();

    protected static final int CONTINUE_TO_P_INDEX_CAS = 0;
    protected static final int RETRY = 1;
    protected static final int QUEUE_FULL = 2;
    protected static final int QUEUE_RESIZE = 3;

    protected final int chunkSize;

    protected final int queueSize;

    protected final int mask;

    protected final AtomicInteger producerIndex;

    protected final AtomicReference<AtomicReferenceArray<Object>> producerBuffer;

    protected final AtomicInteger consumerIndex;

    protected final AtomicReference<AtomicReferenceArray<Object>> consumerBuffer;

    protected final AtomicInteger producerLimit;

    public MpscLinkedArrayQueue(int chunkSize, int queueSize) {
        this.chunkSize = this.roundupPowerOfTwo(chunkSize, MAX_CHUNK_CAPACITY);
        this.queueSize = this.roundupPowerOfTwo(queueSize, MAX_QUEUE_SIZE);
        this.mask = (this.chunkSize - 1) << 1;
        this.producerIndex = new AtomicInteger(0);
        AtomicReferenceArray<Object> buffer = new AtomicReferenceArray<>(this.chunkSize + 1);
        this.producerBuffer = new AtomicReference<>();
        this.producerBuffer.set(buffer);
        this.consumerIndex = new AtomicInteger(0);
        this.consumerBuffer = new AtomicReference<>();
        this.consumerBuffer.set(buffer);
        this.producerLimit = new AtomicInteger(this.mask);
    }

    public void put(E e) {
        if (e == null) {
            throw new NullPointerException();
        }

        AtomicReferenceArray<Object> buffer;
        int pIndex;

        while (true) {
            int pLimit = this.producerLimit.get();
            pIndex = this.producerIndex.get();
            if ((pIndex & 1) == 1) {
                continue;
            }

            buffer = this.producerBuffer.get();

            if (pLimit <= pIndex) {

                int result = offerSlowPath(pIndex, pLimit);
                switch (result) {
                    case CONTINUE_TO_P_INDEX_CAS:
                        break;
                    case RETRY:
                        continue;
                    case QUEUE_FULL:
                        onQueueFull(e);
                        return;
                    case QUEUE_RESIZE:
                        resize(buffer, pIndex, e);
                        return;
                }
            }

            if (this.producerIndex.compareAndSet(pIndex, pIndex + 2)) {
                break;
            }
        }

        int offset = (pIndex & this.mask) >>> 1;
        buffer.set(offset, e);

    }

    @SuppressWarnings("unchecked")
    public E get() {
        AtomicReferenceArray<Object> buffer = this.consumerBuffer.get();
        int cIndex = this.consumerIndex.get();
        int offset = (cIndex & this.mask) >>> 1;

        Object e = buffer.get(offset);
        if (e == null) {
            if (cIndex != this.producerIndex.get()) {
                do {
                    e = buffer.get(offset);
                } while (e == null);
            } else {
                return null;
            }
        }
        if (e == JUMP) {
            AtomicReferenceArray<Object> next = nextBuffer(buffer);
            return newBufferPoll(next, cIndex);
        }
        buffer.set(offset, null);
        this.consumerIndex.set(cIndex + 2);
        return (E) e;
    }

    protected int roundupPowerOfTwo(int size, int max) {
        if (size > max) {
            return max;
        }
        if ((size & (size - 1)) != 0) {
            int s = 1;
            while (s < size) {
                s <<= 1;
            }
            size = s;
        }
        return Math.min(size, max);
    }

    protected int offerSlowPath(int pIndex, int pLimit) {
        int cIndex = this.consumerIndex.get();
        int capacity = this.mask;

        if (cIndex + capacity > pIndex) {
            if (!this.producerLimit.compareAndSet(pLimit, cIndex + capacity)) {
                return RETRY;
            } else {
                return CONTINUE_TO_P_INDEX_CAS;
            }
        } else if (queueSize - (pIndex - cIndex) <= 0) {
            return QUEUE_FULL;
        } else if (this.producerIndex.compareAndSet(pIndex, pIndex + 1)) {
            return QUEUE_RESIZE;
        } else {
            return RETRY;
        }
    }

    protected void resize(AtomicReferenceArray<Object> oldBuffer, int pIndex, E e) {
        AtomicReferenceArray<Object> newBuffer;
        try {
            newBuffer = new AtomicReferenceArray<>(this.chunkSize + 1);
        } catch (OutOfMemoryError oom) {
            this.producerIndex.set(pIndex + 1);
            throw oom;
        }

        this.producerBuffer.set(newBuffer);

        int offset = (pIndex & this.mask) >>> 1;
        newBuffer.set(offset, e);
        oldBuffer.set(this.chunkSize, newBuffer);

        int cIndex = this.consumerIndex.get();
        int available = queueSize - (pIndex - cIndex);

        this.producerLimit.set(pIndex + Math.min(this.mask, available));

        this.producerIndex.set(pIndex + 2);

        oldBuffer.set(offset, JUMP);
    }

    protected void onQueueFull(E e) {}

    @SuppressWarnings("unchecked")
    protected AtomicReferenceArray<Object> nextBuffer(AtomicReferenceArray<Object> buffer) {
        int offset = this.chunkSize;
        AtomicReferenceArray<Object> nextBuffer = (AtomicReferenceArray<Object>) buffer.get(offset);
        this.consumerBuffer.set(nextBuffer);
        buffer.set(offset, BUFFER_CONSUMED);
        return nextBuffer;
    }

    @SuppressWarnings("unchecked")
    protected E newBufferPoll(AtomicReferenceArray<Object> next, int cIndex) {
        int offset = (cIndex & this.mask) >>> 1;
        Object e = next.get(offset);
        next.set(offset, null);
        this.consumerIndex.set(cIndex + 2);
        return (E) e;
    }

}

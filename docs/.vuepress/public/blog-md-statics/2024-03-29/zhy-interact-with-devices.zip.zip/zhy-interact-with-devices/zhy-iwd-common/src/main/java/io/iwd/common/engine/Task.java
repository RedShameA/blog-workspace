package io.iwd.common.engine;

/**
 * 代表一个任务节点。多个Task可以组成一个TaskFlow。
 * @see TaskFlow
 */
@FunctionalInterface
public interface Task {

    /**
     * @param context 任务执行上下文。
     * @throws Exception 异常。
     */
    void execute(TaskContextFacade context) throws Exception;

}

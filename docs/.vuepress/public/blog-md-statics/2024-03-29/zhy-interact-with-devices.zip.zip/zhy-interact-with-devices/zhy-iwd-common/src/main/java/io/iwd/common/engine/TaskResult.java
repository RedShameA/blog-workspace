package io.iwd.common.engine;

import io.iwd.common.command.Command;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.log.Logger;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.LockSupport;

/**
 * 任务结果容器。
 */
public class TaskResult { //TODO (1)支持多个线程等待; (2)支持多个监听器;

    /**
     * 空结果占位对象。
     */
    public static final Object NON_RESULT = new Object();

    /**
     * 未完成状态。
     */
    public static final int STATE_UNDONE = -1;

    /**
     * 不稳定状态，说明正在变更状态。
     */
    public static final int STATE_UNSTABLE = 0;

    /**
     * 完成状态。
     */
    public static final int STATE_COMPLETED = 1;

    /**
     * 超时状态。
     */
    public static final int STATE_TIMEOUT = 2;

    /**
     * 失败状态。
     */
    public static final int STATE_FAILED = 3;

    /**
     * 此容器的状态。
     */
    private final AtomicInteger state;

    /**
     * 等待结果的线程。
     */
    private final AtomicReference<Thread> awaitThread;

    /**
     * 结果监听器。
     */
    private final AtomicReference<Listener<?>> listener;

    /**
     * 结果监听器是否已被调用。
     */
    private final AtomicBoolean listenerCalled;

    /**
     * listener调用产生的Future代理。
     */
    private volatile FutureProxy<?> futureProxy;

    /**
     * 结果对象，可能是任何类型。
     */
    private volatile Object result;

    /**
     * 标准构造器。
     */
    public TaskResult() {
        this.state = new AtomicInteger(STATE_UNDONE);
        this.awaitThread = new AtomicReference<>(null);
        this.listener = new AtomicReference<>(null);
        this.listenerCalled = new AtomicBoolean(false);
        this.result = NON_RESULT;
    }

    /**
     * 设置此容器为完成状态，并设置结果对象。
     * @param result 结果对象。
     */
    void setCompleted(Object result) {
        if (this.state.compareAndSet(STATE_UNDONE, STATE_UNSTABLE)) {
            if (result != null) {
                this.result = result;
            }
            this.state.set(STATE_COMPLETED);
            resultSetDone();
        }
    }

    /**
     * 设置此容器为超时状态，并设置结果对象。
     * @param result 结果对象。
     */
    void setTimeout(Object result) {
        if (this.state.compareAndSet(STATE_UNDONE, STATE_UNSTABLE)) {
            if (result != null) {
                this.result = result;
            }
            this.state.set(STATE_TIMEOUT);
            resultSetDone();
        }
    }

    /**
     * 设置此容器为失败状态，并设置结果对象。
     * @param result 结果对象。
     */
    void setFailed(Object result) {
        if (this.state.compareAndSet(STATE_UNDONE, STATE_UNSTABLE)) {
            if (result != null) {
                this.result = result;
            }
            this.state.set(STATE_FAILED);
            resultSetDone();
        }
    }

    /**
     * @return 是否已经有结果。
     */
    public boolean hasResult() {
        return this.state.get() > STATE_UNSTABLE && this.result != NON_RESULT;
    }

    /**
     * @return 结果对象。
     */
    public Object getResult() {
        if (this.state.get() > STATE_UNSTABLE) {
            return this.result;
        }
        return null;
    }

    /**
     * @return 是否是完成状态。
     */
    public boolean isCompleted() {
        return this.state.get() == STATE_COMPLETED;
    }

    /**
     * @return 是否是超时状态。
     */
    public boolean isTimeout() {
        return this.state.get() == STATE_TIMEOUT;
    }

    /**
     * @return 是否是失败状态。
     */
    public boolean isFailed() {
        return this.state.get() == STATE_FAILED;
    }

    /**
     * 让当前线程等待结果，直到此结果容器变为一种稳定状态。
     */
    public void await() {
        this.await(0L);
    }

    /**
     * 让当前线程等待结果，直到此结果容器变为一种稳定状态，或达到最长等待时间。
     * @param time 最长等待时间，毫秒。如果传入一个小于等于0的参数，那么等同于调用{@link TaskResult#await()}。
     */
    public void await(long time) {
        if (!this.awaitThread.compareAndSet(null, Thread.currentThread())) {
            throw new IllegalStateException("waiting thread already set");
        }
        if (time <= 0) {
            while (this.state.get() <= STATE_UNSTABLE) {
                LockSupport.park();
            }
        } else {
            long beforePark = System.currentTimeMillis();
            while (this.state.get() <= STATE_UNSTABLE) {
                LockSupport.parkNanos(time * 1_000_000);
                long afterPark = System.currentTimeMillis();
                long diff = afterPark - beforePark;
                if (diff >= time) {
                    break;
                } else {
                    time -= diff;
                    beforePark = afterPark;
                }
            }
        }
    }

    /**
     * 设置结果监听器，当产生结果时，调用监听器。
     * @param listener 结果监听器。
     * @return FutureProxy。
     */
    @SuppressWarnings("unchecked")
    public <T> Future<T> onDone(Listener<T> listener) {
        if (!this.listener.compareAndSet(null, listener)) {
            throw new IllegalStateException("listener already set");
        }
        this.futureProxy = new FutureProxy<T>();
        if (this.state.get() <= STATE_UNSTABLE) {
            return (Future<T>) this.futureProxy;
        }
        //如果已经产生了结果，尝试调用监听器
        if (!this.listenerCalled.compareAndSet(false, true)) {
            return (Future<T>) this.futureProxy;
        }
        TaskResultService taskResultService = EnvironmentHolder.get().taskResultService();
        if (taskResultService == null) {
            Logger.error("can not get TaskResultService");
            return (Future<T>) this.futureProxy;
        }
        Future<T> future = taskResultService.submit(() -> listener.handle(this));
        ((FutureProxy<T>) this.futureProxy).set(future);
        return (Future<T>) this.futureProxy;
    }

    @SuppressWarnings("unchecked")
    public <T> Future<T> listenerFuture() {
        return (Future<T>) this.futureProxy;
    }

    @SuppressWarnings("unchecked")
    private <T> void resultSetDone() {
        Thread t = this.awaitThread.get();
        if (t != null) {
            LockSupport.unpark(t);
        }
        Listener<T> listener = (Listener<T>) this.listener.get();
        if (listener == null) {
            return;
        }
        if (!this.listenerCalled.compareAndSet(false, true)) {
            return;
        }
        TaskResultService taskResultService = EnvironmentHolder.get().taskResultService();
        if (taskResultService == null) {
            Logger.error("can not get TaskResultService");
            return;
        }
        Future<T> future = taskResultService.submit(() -> listener.handle(this));
        while (this.futureProxy == null) { //自旋等待futureProxy被赋值
            Thread.yield();
        }
        ((FutureProxy<T>) this.futureProxy).set(future);
    }

    /**
     * 结果监听器。
     */
    @FunctionalInterface
    public interface Listener<T> {
        T handle(TaskResult result);
    }

    /**
     * {@link Future}的代理对象。当用于调用{@link TaskResult#onDone(Listener)}时，用户需要被返回一个{@link Future}，以管理任务的状态。
     * 但是{@link Listener}的处理逻辑只有当任务上下文进入稳定状态后才会被执行。因此需要先返回给用户一个{@link Future}的代理对象。
     * 当任务上下文进入稳定状态后，{@link Listener}的处理逻辑被提交到任务结果服务线程池中时，再将提交返回的{@link Future}放入代理对象中。
     * 在代理对象未被填充的一段时间里，它会表现的像{@link Future}没有产生结果一样，但是{@link FutureProxy#cancel(boolean)}操作不会影响到未来将被置入的{@link Future}。
     * @param <T> Future的结果类型。
     */
    static class FutureProxy<T> implements Future<T> {

        private final AtomicReference<WaitNode> waiters;

        private volatile Future<T> future;

        FutureProxy() {
            this.waiters = new AtomicReference<>(null);
        }

        @Override
        public boolean cancel(boolean mayInterruptIfRunning) {
            return this.future != null && this.future.cancel(mayInterruptIfRunning);
        }

        @Override
        public boolean isCancelled() {
            return this.future != null && this.future.isCancelled();
        }

        @Override
        public boolean isDone() {
            return this.future != null && this.future.isDone();
        }

        @Override
        public T get() throws InterruptedException, ExecutionException {
            awaitFutureSet(false, 0L);
            return this.future.get();
        }

        @Override
        public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            if (unit == null) {
                throw new NullPointerException();
            }
            long nanos = unit.toNanos(timeout);
            if (nanos <= 0L) {
                return this.future == null ? null : this.future.get(0L, TimeUnit.NANOSECONDS);
            }
            if (nanos / 31_536_000_000_000_000L >= 99L) {
                throw new IllegalArgumentException("waiting too long, more than 99 years!");
            }

            nanos -= awaitFutureSet(true, nanos);

            return this.future == null ? null : this.future.get(nanos, TimeUnit.NANOSECONDS);
        }

        /**
         * @param nanos 最长等待时间，纳秒。
         * @return 实际等待的时间，纳秒。
         */
        long awaitFutureSet(boolean timed, long nanos) throws InterruptedException {
            final long deadline = timed ? System.nanoTime() + nanos : 0L;
            long elapsed = 0L;
            WaitNode q = null;
            boolean queued = false;
            for (;;) {
                if (Thread.interrupted()) {
                    removeWaiter(q);
                    throw new InterruptedException();
                }

                if (this.future != null) {
                    if (q != null)
                        q.thread = null;
                    return elapsed;
                }
                else if (q == null)
                    q = new WaitNode();
                else if (!queued)
                    queued = this.waiters.compareAndSet(q.next = this.waiters.get(), q);
                else if (timed) {
                    long startNanos = System.nanoTime();
                    nanos = deadline - startNanos;
                    if (nanos <= 0L) {
                        removeWaiter(q);
                        return elapsed;
                    }
                    LockSupport.parkNanos(this, nanos);
                    elapsed += (System.nanoTime() - startNanos);
                }
                else {
                    long startNanos = System.nanoTime();
                    LockSupport.park(this);
                    elapsed += (System.nanoTime() - startNanos);
                }

            }
        }

        void removeWaiter(WaitNode node) {
            if (node != null) {
                node.thread = null;
                retry:
                for (;;) {          // restart on removeWaiter race
                    for (WaitNode pred = null, q = this.waiters.get(), s; q != null; q = s) {
                        s = q.next;
                        if (q.thread != null)
                            pred = q;
                        else if (pred != null) {
                            pred.next = s;
                            if (pred.thread == null) // check for race
                                continue retry;
                        }
                        else if (!this.waiters.compareAndSet(q, s))
                            continue retry;
                    }
                    break;
                }
            }
        }

        void wakeupAll() {
            for (WaitNode q; (q = this.waiters.get()) != null;) {
                if (this.waiters.compareAndSet(q, null)) {
                    for (;;) {
                        Thread t = q.thread;
                        if (t != null) {
                            q.thread = null;
                            LockSupport.unpark(t);
                        }
                        WaitNode next = q.next;
                        if (next == null)
                            break;
                        q.next = null; // unlink to help gc
                        q = next;
                    }
                    break;
                }
            }
        }

        void set(Future<T> f) {
            this.future = f;
            wakeupAll();
        }

        static class WaitNode {
            volatile Thread thread;
            volatile WaitNode next;

            WaitNode() {
                this.thread = Thread.currentThread();
            }
        }

    }

}

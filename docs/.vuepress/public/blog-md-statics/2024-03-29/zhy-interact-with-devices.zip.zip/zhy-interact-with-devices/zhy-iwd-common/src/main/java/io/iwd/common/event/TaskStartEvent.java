package io.iwd.common.event;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.util.Generator;

/**
 * 任务开始事件抽象基类。
 */
public abstract class TaskStartEvent implements Event {

    /**
     * 任务id。
     */
    private final String taskId;

    /**
     * 任务的名称。
     */
    private final String taskName;

    /**
     * 任务入口节点名称。
     */
    private final String entranceName;

    /**
     * 任务初始输入的数据。
     */
    private final Object data;

    /**
     * 任务结果对象。
     */
    private final TaskResult taskResult;

    public TaskStartEvent(String taskName, Object data) {
        this(null, taskName, null, data, new TaskResult());
    }

    public TaskStartEvent(String taskName, Object data, TaskResult taskResult) {
        this(null, taskName, null, data, taskResult);
    }

    public TaskStartEvent(String taskId, String taskName, Object data, TaskResult taskResult) {
        this(taskId, taskName, null, data, taskResult);
    }

    /**
     * 标准构造器。
     * @param taskId 任务id。
     * @param taskName 任务的名称。
     * @param entranceName 任务入口节点名称。
     * @param data 任务初始输入的数据。
     * @param taskResult 任务结果对象。
     */
    public TaskStartEvent(String taskId, String taskName, String entranceName, Object data, TaskResult taskResult) {
        if (taskId == null) {
            taskId = Generator.create32UniqueId();
        }
        this.taskId = taskId;
        this.taskName = taskName;
        this.entranceName = entranceName;
        this.data = data;
        this.taskResult = taskResult;
    }

    public String getTaskId() {
        return this.taskId;
    }

    /**
     * 获取任务的前缀。
     * {@link TaskEventListener}中虽然指定了默认的前缀，但不能完全依赖它，否则监听器就会失去处理多种前缀的能力。
     * @return 返回此任务的前缀。
     */
    public String getTaskPrefix() {
        return null;
    }

    /**
     * 获取任务的名称。
     * @return 任务的名称。
     */
    public String getTaskName() {
        return this.taskName;
    }

    /**
     * 获取任务入口节点的名称。
     * @return 任务入口节点的名称。
     */
    public String getEntranceName() {
        return this.entranceName;
    }

    /**
     * 获取任务初始输入的数据。
     * @return 任务初始输入的数据。
     */
    public Object getData() {
        return this.data;
    }

    /**
     * 获取任务结果对象。
     * @return 任务结果对象。
     */
    public TaskResult getTaskResult() {
        return this.taskResult;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() +
                "[taskId:\"" + this.taskId + "\",taskName:\"" + this.taskName + "\"]";
    }
}

package io.iwd.common.ext.json;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractJsonArray implements JsonArray {

    final List<JsonEntity> internal;

    AbstractJsonArray(List<JsonEntity> list) {
        internal = list;
    }

    @Override
    public JsonArray copy() {
        JsonArray newJsonArray = new StandardJsonArray();
        for(JsonEntity jsonEntity : internal) {
            if(jsonEntity instanceof JsonObject) {
                newJsonArray.add(((JsonObject) jsonEntity).copy());
            }
            else if(jsonEntity instanceof JsonArray) {
                newJsonArray.add(((JsonArray) jsonEntity).copy());
            }
            else {
                newJsonArray.add(jsonEntity);
            }
        }
        return newJsonArray;
    }

    @Override
    public JsonArray freeze() {
        ArrayList<JsonEntity> copiedList = new ArrayList<>(internal.size());
        for(JsonEntity jsonEntity : internal) {
            if(jsonEntity instanceof JsonObject) {
                copiedList.add(((JsonObject) jsonEntity).freeze());
            }
            else if(jsonEntity instanceof JsonArray) {
                copiedList.add(((JsonArray) jsonEntity).freeze());
            }
            else {
                copiedList.add(jsonEntity);
            }
        }
        return new ImmutableJsonArray(copiedList);
    }

    @Override
    public JsonArray share() {
        ArrayList<JsonEntity> copiedList = new ArrayList<>(internal.size());
        for(JsonEntity jsonEntity : internal) {
            if(jsonEntity instanceof JsonObject) {
                copiedList.add(((JsonObject) jsonEntity).share());
            }
            else if(jsonEntity instanceof JsonArray) {
                copiedList.add(((JsonArray) jsonEntity).share());
            }
            else {
                copiedList.add(jsonEntity);
            }
        }
        return new SharedJsonArray(copiedList);
    }

    @Override
    public String stringify() {
        StringBuilder sb = new StringBuilder().append('[');
        for(JsonEntity jsonEntity : internal) {
            sb.append(jsonEntity.stringify()).append(',');
        }
        if(sb.length() > 1) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.append(']').toString();
    }

    @Override
    public List<Object> simplify() {
        List<Object> list = new ArrayList<>(internal.size());
        for(JsonEntity e : internal) {
            list.add(e.simplify());
        }
        return list;
    }

    @Override
    public int size() {
        return internal.size();
    }

    @Override
    public JsonArray add(Object element) {
        if (element instanceof JsonEntity) {
            internal.add((JsonEntity) element);
        }
        else if (element instanceof Number) {
            internal.add(new JsonNumber((Number) element));
        }
        else if (element instanceof String) {
            internal.add(new JsonString((String) element));
        }
        else if (element instanceof Boolean) {
            internal.add(new JsonBoolean((Boolean) element));
        }
        else if (element == null) {
            internal.add(new JsonNull());
        }
        return this;
    }

    @Override
    public JsonArray add(JsonEntity element) {
        internal.add(element == null ? new JsonNull() : element);
        return this;
    }

    @Override
    public JsonArray add(String element) {
        internal.add(element == null ? new JsonNull() : new JsonString(element));
        return this;
    }

    @Override
    public JsonArray add(Number element) {
        internal.add(element == null ? new JsonNull() : new JsonNumber(element));
        return this;
    }

    @Override
    public JsonArray add(Boolean element) {
        internal.add(element == null ? new JsonNull() : new JsonBoolean(element));
        return this;
    }

    @Override
    public JsonArray set(int index, Object element) {
        if (element instanceof JsonEntity) {
            internal.set(index, (JsonEntity) element);
        }
        else if (element instanceof Number) {
            internal.add(index, new JsonNumber((Number) element));
        }
        else if (element instanceof String) {
            internal.add(index, new JsonString((String) element));
        }
        else if (element instanceof Boolean) {
            internal.add(index, new JsonBoolean((Boolean) element));
        }
        else if (element == null) {
            internal.add(index, new JsonNull());
        }
        return this;
    }

    @Override
    public JsonArray set(int index, JsonEntity element) {
        internal.set(index, element == null ? new JsonNull() : element);
        return this;
    }

    @Override
    public JsonArray set(int index, String element) {
        internal.set(index, element == null ? new JsonNull() : new JsonString(element));
        return this;
    }

    @Override
    public JsonArray set(int index, Number element) {
        internal.set(index, element == null ? new JsonNull() : new JsonNumber(element));
        return this;
    }

    @Override
    public JsonArray set(int index, Boolean element) {
        internal.set(index, element == null ? new JsonNull() : new JsonBoolean(element));
        return this;
    }

    @Override
    public Object get(int index) {
        JsonEntity value = internal.get(index);
        if (value == null) {
            return null;
        }
        switch (value.type()) {
            case OBJECT:
            case ARRAY:
                return value;
            case BOOLEAN:
                return ((JsonBoolean) value).internalBoolean();
            case STRING:
                return ((JsonString) value).internalString();
            case Number:
                JsonNumber jsonNumber = (JsonNumber) value;
                Class<? extends Number> numberType = jsonNumber.getNumberType();
                if (Integer.class.isAssignableFrom(numberType) ||
                        Short.class.isAssignableFrom(numberType) ||
                        Byte.class.isAssignableFrom(numberType)) {
                    return jsonNumber.internalInteger();
                }
                if (Long.class.isAssignableFrom(numberType)) {
                    return jsonNumber.internalLong();
                }
                if (Float.class.isAssignableFrom(numberType)) {
                    return jsonNumber.internalFloat();
                }
                if (Double.class.isAssignableFrom(numberType)) {
                    return jsonNumber.internalDouble();
                }
                //TODO other supported types
                return Double.NaN;
            default:
                return null;
        }
    }

    @Override
    public JsonEntity getJsonEntity(int index) {
        return internal.get(index);
    }

    @Override
    public JsonObject getJsonObject(int index) {
        JsonEntity jsonEntity = this.getJsonEntity(index);
        return (jsonEntity == null || jsonEntity instanceof JsonNull) ? null : (JsonObject) jsonEntity;
    }

    @Override
    public JsonArray getJsonArray(int index) {
        JsonEntity jsonEntity = this.getJsonEntity(index);
        return (jsonEntity == null || jsonEntity instanceof JsonNull) ? null : (JsonArray) jsonEntity;
    }

    @Override
    public JsonString getJsonString(int index) {
        JsonEntity jsonEntity = this.getJsonEntity(index);
        return (jsonEntity == null || jsonEntity instanceof JsonNull) ? null : (JsonString) jsonEntity;
    }

    @Override
    public JsonNumber getJsonNumber(int index) {
        JsonEntity jsonEntity = this.getJsonEntity(index);
        return (jsonEntity == null || jsonEntity instanceof JsonNull) ? null : (JsonNumber) jsonEntity;
    }

    @Override
    public JsonBoolean getJsonBoolean(int index) {
        JsonEntity jsonEntity = this.getJsonEntity(index);
        return (jsonEntity == null || jsonEntity instanceof JsonNull) ? null : (JsonBoolean) jsonEntity;
    }

    @Override
    public String getString(int index) {
        JsonString jsonString = getJsonString(index);
        return jsonString == null ? null : jsonString.internalString();
    }

    @Override
    public Number getNumber(int index) {
        JsonNumber jsonNumber = getJsonNumber(index);
        return jsonNumber == null ? null : jsonNumber.internalNumber();
    }

    @Override
    public Integer getInteger(int index) {
        JsonNumber jsonNumber = getJsonNumber(index);
        return jsonNumber == null ? null : jsonNumber.internalInteger();
    }

    @Override
    public Long getLong(int index) {
        JsonNumber jsonNumber = getJsonNumber(index);
        return jsonNumber == null ? null : jsonNumber.internalLong();
    }

    @Override
    public Float getFloat(int index) {
        JsonNumber jsonNumber = getJsonNumber(index);
        return jsonNumber == null ? null : jsonNumber.internalFloat();
    }

    @Override
    public Double getDouble(int index) {
        JsonNumber jsonNumber = getJsonNumber(index);
        return jsonNumber == null ? null : jsonNumber.internalDouble();
    }

    @Override
    public Boolean getBoolean(int index) {
        JsonBoolean jsonBoolean = getJsonBoolean(index);
        return jsonBoolean == null ? null : jsonBoolean.internalBoolean();
    }

    @Override
    public JsonArray remove(int index) {
        internal.remove(index);
        return this;
    }

    @Override
    public JsonEntity take(int index) {
        return internal.remove(index);
    }

    @Override
    public JsonArray clear() {
        internal.clear();
        return this;
    }

    @Override
    public String toString() {
        return this.stringify();
    }
}

package io.iwd.common.stdio.redis;

import io.iwd.common.engine.TaskContext;
import io.iwd.common.engine.TaskExecutor;

public class InteractiveModeRedis extends AbstractRedis {

    @Override
    protected RedisCommandWrapper getCommandWrapper(RedisCommand redisCommand, String[] params) {
        return new RedisCommandWrapper(false, redisCommand, params);
    }

    @Override
    protected void execute(RedisCommandWrapper redisCommandWrapper) {
        if (!redisCommandWrapper.isSilent()) {
            Thread current = Thread.currentThread();
            if (current instanceof TaskExecutor) {
                TaskExecutor taskExecutor = (TaskExecutor) current;
                TaskContext context = taskExecutor.getContext();
                if (redisCommandWrapper.taskId() == null) {
                    redisCommandWrapper.forTask(context.getTaskId());
                }
                if (redisCommandWrapper.eventConstructor() == null) {
                    redisCommandWrapper.onResponse(context.getDefaultTaskProceedEventConstructor());
                }
            }
        }
        super.execute(redisCommandWrapper);
    }
}

package io.iwd.common.stdio.redis;

import io.iwd.common.entity.ServiceStateInfo;
import io.iwd.common.event.ServicesStateEvent;
import io.iwd.common.ext.json.JsonObject;

public class ServicesStateRedisChannelMessageHandler extends RedisChannelMessageHandler {

    @Override
    public void handle(String channelName, String message) {

        JsonObject serviceStateInfo = JsonObject.from(message);
        if (serviceStateInfo == null) {
            return;
        }

        new ServicesStateEvent(new ServiceStateInfo(serviceStateInfo)).publish();

    }

}

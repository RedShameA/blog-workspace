package io.iwd.common.stdio.redis;

import io.iwd.common.event.CommonDefaultTaskProceedEvent;
import io.iwd.common.ext.json.JsonObject;

public class ServicesVersionRedisChannelMessageHandler extends RedisChannelMessageHandler {

    @Override
    public void handle(String channelName, String message) {
        JsonObject serviceData = JsonObject.from(message);
        if (serviceData == null) {
            return;
        }
        String messageId = serviceData.getString("msgid");
        if (messageId == null) {
            return;
        }
        new CommonDefaultTaskProceedEvent(messageId, serviceData).publish();
    }

}

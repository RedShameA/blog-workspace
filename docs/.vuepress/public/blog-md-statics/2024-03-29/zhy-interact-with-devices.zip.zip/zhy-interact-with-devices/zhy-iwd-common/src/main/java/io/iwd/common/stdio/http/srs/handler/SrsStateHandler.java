package io.iwd.common.stdio.http.srs.handler;

import io.iwd.common.entity.ServiceStateInfo;
import io.iwd.common.event.ServicesStateEvent;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.stdio.http.AbstractHttpRequestHandler;
import io.iwd.common.stdio.http.HttpHelper;
import io.iwd.common.stdio.http.HttpRequestHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.HttpResponseStatus;

import java.util.Map;

@HttpRequestHandler(path = "/srs/srsHeartbeat")
public class SrsStateHandler extends AbstractHttpRequestHandler<JsonObject> {

    @Override
    protected void handle0(ChannelHandlerContext waitingResponseContext,
                           String path,
                           String method,
                           Map<String, String> queryString,
                           Map<String, String> headers,
                           JsonObject body) throws Exception {

        HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":200}", null);

        new ServicesStateEvent(new ServiceStateInfo(body)).publish();

    }

}

package io.iwd.common.stdio.redis;

import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.environment.ManagerLifecycle;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.misc.NettyComponentThreadFactory;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.*;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.redis.*;
import io.netty.util.CharsetUtil;
import io.netty.util.ReferenceCountUtil;

import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

/**
 * redis消息监听器，监听所有配置的频道。
 * 最初的ChannelPipeline中包含RedisSubscribeInitializer，负责建立订阅连接，连接建立完成后，替换为RedisSubscribeHandler。
 * 注意，如果订阅会收到大量消息，那么监听机制需要重新设计，因为当前所有频道都是由一个netty eventLoop线程监听的，所有的订阅消息也由这一个线程接收，
 * 这个线程还要负责消息json解析，其处理消息的速度会慢于redis发送的速度。
 * 对于监听来说一个channel只应有一个线程监听（一个channel有多个线程监听没有意义），不同的channel可以由不同的线程监听，以减轻监听线程压力。
 * 那如果这一个channel有大量的消息怎么办呢？
 * 我们应该尽量减少监听线程的压力，将收到的消息轮循分配给其他n个处理线程处理（也就是将json解析及其后续发布事件的工作分配下去）。
 */
public class RedisMessageListener implements ManagerLifecycle, RedisClient {

    private final String ip;

    private final int port;

    private final String password;

    private final boolean autoReconnect;

    private final AtomicBoolean closed;

    private final ReentrantLock lock;

    private final Set<String> channels;

    private EventLoopGroup eventLoopGroup;

    /**
     * 重新于redis建立连接时，关闭此channel，并保存新channel。
     */
    private Channel subscribeChannel;

    public RedisMessageListener(String ip, int port, Set<String> channels, boolean autoReconnect) {
        this(ip, port, channels, null, autoReconnect);
    }

    public RedisMessageListener(String ip, int port, Set<String> channels, String password, boolean autoReconnect) {
        this.ip = ip;
        this.port = port;
        this.channels = new LinkedHashSet<>(channels);
        this.password = password;
        this.autoReconnect = autoReconnect;
        this.closed = new AtomicBoolean(false);
        this.lock = new ReentrantLock();
    }

    @Override
    public void connectAndInit() {

        this.lock.lock();
        try {

            do {
                if (this.closed.get() || this.subscribeChannel != null) {
                    return;
                }

                //需要等pipeline初始化完才能使用
                CountDownLatch countDownLatch = new CountDownLatch(1);
                boolean shouldReconnect = this.autoReconnect && !this.closed.get();

                Bootstrap bootstrap = new Bootstrap();
                bootstrap.group(this.eventLoopGroup);
                bootstrap.channel(EnvironmentHolder.get().isEpollAvailable() ?
                        EpollSocketChannel.class :
                        NioSocketChannel.class);
                bootstrap.handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        pipeline.addLast(new RedisDecoder());
                        pipeline.addLast(new RedisBulkStringAggregator());
                        pipeline.addLast(new RedisArrayAggregator());
                        pipeline.addLast(new RedisEncoder());
                        pipeline.addLast(new RedisSubscribeInitializer(RedisMessageListener.this, RedisMessageListener.this.channels, RedisMessageListener.this.password, countDownLatch));
                    }
                });

                bootstrap
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                        .option(ChannelOption.SO_KEEPALIVE, true)
                        .option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
                        .remoteAddress(new InetSocketAddress(ip, port));

                Logger.info("RedisMessageListener connecting Redis");
                ChannelFuture channelFuture = bootstrap
                        .connect()
                        .awaitUninterruptibly();

                Channel channel = channelFuture.channel();

                if (!channelFuture.isSuccess()) {
                    if (channel != null) {
                        channel.close().awaitUninterruptibly();
                    }
                    this.subscribeChannel = null;
                    Logger.error("RedisMessageListener failed to connect Redis " + ip + ":" + port + (shouldReconnect ? ", reconnecting" : ""));
                    if (shouldReconnect) {
                        continue;
                    }
                    return;
                }

                boolean initSuccess;
                try {
                    initSuccess = countDownLatch.await(10, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    initSuccess = false;
                }
                if (!initSuccess) {
                    if (channel != null) {
                        channel.close().awaitUninterruptibly();
                    }
                    this.subscribeChannel = null;
                    Logger.error("RedisMessageListener failed to initialize" + (shouldReconnect ? ", reconnecting" : ""));
                    if (shouldReconnect) {
                        continue;
                    }
                    return;

                }
                this.subscribeChannel = channel;
                Logger.info("RedisMessagePublisher connected Redis " + ip + ":" + port);
                break;

            } while (true);

        } finally {
            lock.unlock();
        }
    }

    @Override
    public void disconnect() {

        this.lock.lock();
        try {
            if (this.subscribeChannel != null) {
                this.subscribeChannel.close().awaitUninterruptibly();
                this.subscribeChannel = null;
            }
            Logger.info("RedisMessageListener disconnected Redis " + ip + ":" + port);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void reconnectAndInit() {

        this.lock.lock();
        try {
            disconnect();
            connectAndInit();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean isAutoReconnect() {
        return this.autoReconnect;
    }

    @Override
    public boolean isClosed() {
        return this.closed.get();
    }

    @Override
    public void active() {

        if (this.eventLoopGroup != null || this.closed.get()) {
            return;
        }

        this.eventLoopGroup = EnvironmentHolder.get().isEpollAvailable() ?
                new EpollEventLoopGroup(1, new NettyComponentThreadFactory(getClass())) :
                new NioEventLoopGroup(1, new NettyComponentThreadFactory(getClass()));

        connectAndInit();

    }

    @Override
    public void destroy() {

        if (!this.closed.compareAndSet(false, true)) {
            return;
        }

        disconnect();

        if (this.eventLoopGroup != null) {
            this.eventLoopGroup.shutdownGracefully().awaitUninterruptibly();
            this.eventLoopGroup = null;
        }
    }

    /**
     * redis订阅初始化器。与redis建立连接后，进行AUTH密码验证（可选），之后发送订阅命令，订阅成功后修改pipeline为订阅模式。
     */
    static class RedisSubscribeInitializer extends RedisConnectHandler {

        /**
         * 需要订阅的频道。
         */
        private final Set<String> channels;

        private final CountDownLatch countDownLatch;

        private int subscribeResponseReceived;

        public RedisSubscribeInitializer(RedisClient redisClient, Set<String> channels, String password, CountDownLatch countDownLatch) {
            super(redisClient, password);
            this.channels = channels;
            this.countDownLatch = countDownLatch;
            this.subscribeResponseReceived = 0;
        }

        @Override
        protected void channelActiveInternal(ChannelHandlerContext ctx) throws Exception {
            ctx.writeAndFlush(createSubscribeCommand());
        }

        @Override
        protected void channelReadInternal(ChannelHandlerContext ctx, Object msg) {

            try {
                if (msg instanceof ArrayRedisMessage) {
                    //第一行应该是"subscribe"
                    FullBulkStringRedisMessage m = (FullBulkStringRedisMessage) ((ArrayRedisMessage) msg).children().get(0);
                    if ("SUBSCRIBE".equalsIgnoreCase(m.content().toString(CharsetUtil.UTF_8))) {

                        this.subscribeResponseReceived++;
                        if (this.subscribeResponseReceived != this.channels.size()) {
                            return;
                        }

                        Logger.info("subscribe redis success");
                        //移除RedisSubscribeInitializer
                        ctx.channel().pipeline().removeLast();
                        //移除RedisEncoder
                        ctx.channel().pipeline().removeLast();
                        //添加RedisSubscribeHandler
                        ctx.channel().pipeline().addLast(new RedisSubscribeHandler(super.redisClient));
                    }

                } else if (msg instanceof ErrorRedisMessage) {

                    String content = ((ErrorRedisMessage) msg).content();

                    Logger.error("subscribe redis failed, cause: " + content);

                    ctx.close();

                } else {

                    Logger.warn("unexpected redis response type: " + msg.getClass().getSimpleName());
                }
            } finally {
                ReferenceCountUtil.release(msg);
            }

            this.countDownLatch.countDown();
        }

        /**
         * 生成订阅命令字符串。
         * @return 订阅命令字符串。
         */
        private RedisMessage createSubscribeCommand() {
            List<RedisMessage> messages = new ArrayList<>(this.channels.size() + 1);
            messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(PooledByteBufAllocator.DEFAULT, "SUBSCRIBE")));
            for (String c : this.channels) {
                messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(PooledByteBufAllocator.DEFAULT, c)));
            }
            return new ArrayRedisMessage(messages);
        }

    }

    /**
     * redis订阅消息处理器，是所有订阅消息的统一处理入口。
     */
    static class RedisSubscribeHandler extends SimpleChannelInboundHandler<ArrayRedisMessage> {

        private final RedisClient redisClient;

        RedisSubscribeHandler(RedisClient redisClient) {
            this.redisClient = redisClient;
        }

        @Override
        protected void channelRead0(ChannelHandlerContext ctx, ArrayRedisMessage msg) throws Exception {

            List<RedisMessage> messages = msg.children();
            if (messages.size() != 3) {
                Logger.warn("RedisSubscribeHandler received wrong message");
                return;
            }

            //索引0即第一行固定为"message" 不需要获取

            //频道名称
            String channelName = ((FullBulkStringRedisMessage) messages.get(1)).content().toString(CharsetUtil.UTF_8);
            //消息内容
            String content = ((FullBulkStringRedisMessage) messages.get(2)).content().toString(CharsetUtil.UTF_8);

            Logger.info("received redis [" + channelName + "] message: " + content);
            //TODO 下面的步骤可以交由worker线程处理
            //通过频道名称查找对应的消息处理器
            Set<RedisChannelMessageHandler> handlers = findChannelMessageHandlers(channelName);
            if (handlers != null && handlers.size() > 0) {
                for (RedisChannelMessageHandler h : handlers) {
                    h.handle(channelName, content);
                }
            }
        }

        @Override
        public void channelInactive(ChannelHandlerContext ctx) throws Exception {
            boolean shouldReconnect = this.redisClient.isAutoReconnect() && !this.redisClient.isClosed();
            Logger.warn("redis connection (RedisMessageListener) closed" + (shouldReconnect ? ", reconnecting" : ""));
            if (!shouldReconnect) {
                return;
            }
            new Thread(this.redisClient::reconnectAndInit).start();
        }

        /**
         * 查找已注册的合适的redis频道消息处理器。
         * @param channelName 频道名称。
         * @return 所有合适的处理器。
         */
        protected Set<RedisChannelMessageHandler> findChannelMessageHandlers(String channelName) {
            RedisChannelMessageHandlerRegistry redisChannelMessageHandlerRegistry = EnvironmentHolder.get().redisChannelMessageHandlerRegistry();
            if (redisChannelMessageHandlerRegistry == null) {
                Logger.error("can not get RedisChannelMessageHandlerRegistry");
                return null;
            }
            return redisChannelMessageHandlerRegistry.findHandlers(channelName);
        }

    }

}
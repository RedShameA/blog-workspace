package io.iwd.common.command;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;

import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 高级命令接口(抽象类)。你可以设置监听器或者直接获取原始的TaskResult。
 * 只应调用
 * {@link AdvancedCommand#ignore()},
 * {@link AdvancedCommand#await()},
 * {@link AdvancedCommand#await(long)},
 * {@link AdvancedCommand#listen(TaskResult.Listener)},
 * {@link AdvancedCommand#result()}
 * 五个方法中的一个，并且只应调用一次。
 * @param <R> await()的返回类型。
 */
public abstract class AdvancedCommand<R> implements Command<R> {

    /**
     * 任务激活标记。
     */
    protected final AtomicBoolean activated = new AtomicBoolean(false);

    /**
     * 监听器。
     */
    protected TaskResult.Listener<?> listener;

    /**
     * 开始任务，忽略结果。对此方法的调用会立即返回，不会阻塞线程。
     */
    @Override
    public void ignore() {
        activate();
        taskStart();
    }

    /**
     * 开始任务，设置监听器，忽略结果。对此方法的调用会立即返回，不会阻塞线程，当命令执行结束时，监听器会被调用。
     * @param listener 监听器。
     */
    public <T> Future<T> listen(TaskResult.Listener<T> listener) {
        if (listener == null) {
            throw new IllegalArgumentException("listener can not be null");
        }
        activate();
        this.listener = listener;
        return taskStart().listenerFuture();
    }

    /**
     * 开始任务，获取TaskResult。对此方法的调用会立即返回，不会阻塞线程，但此时返回的TaskResult状态不确定。
     * @return TaskResult
     */
    public TaskResult result() {
        activate();
        return taskStart();
    }

    /**
     * 开始任务，获取TaskResult，并使当前线程阻塞等待任务结束。
     * @param handler TaskResult处理器。
     * @param time 等待时间，小于等于0代表不限时等待。
     * @return 子类指定的类型的结果。
     */
    protected R await(AwaitResultHandler<R> handler, long time) {
        if (handler == null) {
            throw new IllegalArgumentException("handler can not be null");
        }
        activate();
        TaskResult taskResult = taskStart();
        if (time > 0) {
            taskResult.await(time);
        } else {
            taskResult.await();
        }
        return handler.handle(taskResult);
    }

    /**
     * 由子类实现，用于准备数据，
     * 并调用 {@link AdvancedCommand#taskActive(String, String, String, Object, TaskStartEventConstructor) taskActive} 方法实际开启任务。
     * @return TaskResult
     */
    protected abstract TaskResult taskStart();

    /**
     * 此方法通常由子类的 {@link AdvancedCommand#taskStart() taskStart} 方法调用，用于实际开启任务。
     * @param taskName 任务名称，用于构造任务开始事件。
     * @param entranceName 任务入口名称，用于构造任务开始事件。
     * @param data 任务输入数据，用于构造任务开始事件。
     * @param constructor 开始事件构造器。
     * @return TaskResult
     */
    protected TaskResult taskActive(String taskId, String taskName, String entranceName, Object data, TaskStartEventConstructor constructor) {
        TaskResult result = new TaskResult();
        TaskResult.Listener<?> listener = this.listener;
        if (listener != null) {
            result.onDone(listener);
        }
        constructor.apply(taskId, taskName, entranceName, data, result).publish();
        return result;
    }

    /**
     * 使命令进入激活状态，以防止命令被重复使用。
     */
    protected void activate() {
        if (!this.activated.compareAndSet(false, true)) {
            throw new IllegalStateException("command can not be started repeatedly");
        }
    }

    /**
     * {@link TaskStartEvent}构造器的类型。
     */
    @FunctionalInterface
    protected interface TaskStartEventConstructor {
        TaskStartEvent apply(String taskId, String taskName, String entranceName, Object data, TaskResult taskResult);
    }

    /**
     * {@link TaskResult}的处理函数。用于在两种await方法等待结束后处理{@link TaskResult}。
     * @param <T> 处理结果类型。
     */
    @FunctionalInterface
    protected interface AwaitResultHandler<T> {
        T handle(TaskResult result);
    }

}

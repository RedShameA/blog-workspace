package io.iwd.common.engine;

/**
 * TaskFlow初始化器，用于生成完整的TaskFlow。
 */
public interface TaskFlowInitializer {

    /**
     * 生成任务流程。
     * @return 任务流程。
     */
    TaskFlow getTaskFlow();

}

package io.iwd.common.stdio.redis;

public interface RedisClient {

    void connectAndInit();

    void disconnect();

    void reconnectAndInit();

    boolean isAutoReconnect();

    boolean isClosed();

}

package io.iwd.common.environment;

import io.iwd.common.ext.util.NumberUtil;

/**
 * 标记一个线程为iwd组件线程，这种线程通常需要容量更大的spscQueue。
 */
public interface ComponentThread {

    /**
     * 返回指定的spscQueue容量。
     * @return spscQueue容量。
     */
    default int spscQueueSize() {
        Object queueSize = EnvironmentHolder.get().config().getGlobalConfig("component_thread_spsc_queue_size");
        if (queueSize == null) {
            return 0x400; //1024
        }
        return NumberUtil.toInt(queueSize);
    }

}

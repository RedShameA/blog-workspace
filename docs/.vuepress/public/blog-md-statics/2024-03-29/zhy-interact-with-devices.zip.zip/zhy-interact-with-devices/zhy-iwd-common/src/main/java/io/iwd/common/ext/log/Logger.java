package io.iwd.common.ext.log;

import io.iwd.common.environment.*;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.FileUtil;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.SpscDiscardQueue;
import io.iwd.common.ext.util.StringUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPOutputStream;

import static java.lang.Thread.State.TERMINATED;

/**
 * iwd库中的日志组件。<br>
 * 为什么不引用已有的开源日志组件呢？<br>
 * 1.引用开源日志组件可能会导致iwd的用户依赖冲突或混乱。<br>
 * 2.开源日志组件的行为特性难以控制。<br>
 * 此日志组件有两大核心目标：<br>
 * 1.让想要打印日志的线程尽可能不阻塞。<br>
 * 此类采用了一个线程一个队列的模型，
 * 任何线程打印日志时，只是将日志信息存入线程独享的队列中，
 * 存入的日志会由日志管理线程统一处理。
 * 此模式有利于iwd异步事件驱动的性能。<br>
 * 2.让iwd的日志单独输出到一个文件中，尽可能不与iwd用户的日志混合。
 * 每当日志管理线程决定要输出日志时，其首先会判断是否存在iwd配置文件中指定的日志文件。
 * 如果不存在指定的文件，则先创建文件。<br>
 * 另外，如果指定的日志输出文件大小超过了阈值，日志管理线程会先将当前日志压缩。
 */
public class Logger {

    /**
     * 配置文件中的属性名。
     */
    private static final String CONFIG_PREFIX = "logger";

    /* 日志级别名称。 */
    private static final String LEVEL_DEBUG = "debug";
    private static final String LEVEL_INFO = "info";
    private static final String LEVEL_WARN = "warn";
    private static final String LEVEL_ERROR = "error";

    /* 日志级别编号，级别越高数字越大。 */
    private static final int LEVEL_DEBUG_NUMBER = 1;
    private static final int LEVEL_INFO_NUMBER = 2;
    private static final int LEVEL_WARN_NUMBER = 3;
    private static final int LEVEL_ERROR_NUMBER = 4;

    /**
     * 日志管理线程。
     */
    private final ScheduledExecutorService executor;

    /**
     * 线程日志表。
     */
    private final ConcurrentMap<Thread, SpscDiscardQueue<Log>> messages;

    /**
     * 指定的日志级别，大于等于此级别的日志会被输出。
     */
    private final int level;

    /**
     * 日志时间格式化器，只应由日志管理线程使用。
     */
    private final SimpleDateFormat format;

    /**
     * 日志输出时间间隔，单位：毫秒。
     */
    private final long flushInterval;

    /**
     * 清理线程日志队列的时间间隔，单位：分钟。
     */
    private final long clearInterval;

    /**
     * 日志输出文件的目录。
     */
    private final String outputFileDir;

    /**
     * 日志输出文件的文件名。
     */
    private final String outputFileName;

    /**
     * 触发压缩的阈值，单位：KB。
     */
    private final int compressThreshold;

    /**
     * 开启日志自动删除。
     */
    private final boolean autoDeleteEnable;

    /**
     * 日志保留阈值，单位MB。
     */
    private final long autoDeleteRetentionThreshold;

    /**
     * 日志删除检查间隔，单位分钟。
     */
    private final int autoDeleteCheckInterval;

    /**
     * 是否在Logger初始化时检查删除日志。
     */
    private final boolean autoDeleteCheckOnStart;

    /**
     * 当前的输出日志文件。
     */
    private volatile FileChannel logFile;

    public Logger(GlobalConfiguration config) {

        Number level = (Number) config.getConfig(ConfigurationLoader.ROOT_CONFIG_FILE_NAME, CONFIG_PREFIX, "level");
        if (level == null) {
            level = 1;
        }
        int l = NumberUtil.toInt(level);
        if (l < 1 || l > 4) {
            l = 1;
        }
        this.level = l;

        String timeFormat = (String) config.getConfig(ConfigurationLoader.ROOT_CONFIG_FILE_NAME, CONFIG_PREFIX, "time_format");
        if (StringUtil.notEmpty(timeFormat)) {
            this.format = new SimpleDateFormat(timeFormat);
        } else {
            this.format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
        }

        Long flushInterval = (Long) config.getConfig(ConfigurationLoader.ROOT_CONFIG_FILE_NAME, CONFIG_PREFIX, "flush_interval");
        if (flushInterval != null && flushInterval > 0 && flushInterval < 5001) {
            this.flushInterval = flushInterval;
        } else {
            this.flushInterval = 200L;
        }

        Long clearInterval = (Long) config.getConfig(ConfigurationLoader.ROOT_CONFIG_FILE_NAME, CONFIG_PREFIX, "clear_interval");
        if (clearInterval != null && clearInterval > 0 && clearInterval < 6) {
            this.clearInterval = clearInterval;
        } else {
            this.clearInterval = 5L;
        }

        String outputFileDir = (String) config.getConfig(ConfigurationLoader.ROOT_CONFIG_FILE_NAME, CONFIG_PREFIX, "output_file_dir");
        if (StringUtil.notEmpty(outputFileDir)) {
            if (!outputFileDir.endsWith("/")) {
                outputFileDir += "/";
            }
            this.outputFileDir = outputFileDir;
        } else {
            this.outputFileDir = null;
        }

        String outputFileName = (String) config.getConfig(ConfigurationLoader.ROOT_CONFIG_FILE_NAME, CONFIG_PREFIX, "output_file_name");
        if (StringUtil.notEmpty(outputFileName)) {
            this.outputFileName = outputFileName;
        } else {
            this.outputFileName = "iwd.log";
        }

        Number compressThreshold = (Number) config.getConfig(ConfigurationLoader.ROOT_CONFIG_FILE_NAME, CONFIG_PREFIX, "compress_threshold");
        if (compressThreshold == null) {
            compressThreshold = 1024 * 4;
        }
        int threshold = NumberUtil.toInt(compressThreshold);
        if (threshold > 1024 * 32) {
            threshold = 1024 * 32;
        }
        this.compressThreshold = threshold;

        @SuppressWarnings("unchecked")
        Map<String, Object> autoDeleteConfig = (Map<String, Object>) config.getConfig(ConfigurationLoader.ROOT_CONFIG_FILE_NAME, CONFIG_PREFIX, "auto_delete");
        if (autoDeleteConfig == null) {
            autoDeleteConfig = new HashMap<>(8);
            autoDeleteConfig.put("enable", false);
            autoDeleteConfig.put("retention_threshold", 1024L);
            autoDeleteConfig.put("check_interval", 60L);
            autoDeleteConfig.put("check_on_start", false);
        }
        Boolean autoDeleteEnable = (Boolean) autoDeleteConfig.get("enable");
        this.autoDeleteEnable = autoDeleteEnable == null ? false : autoDeleteEnable;

        Long autoDeleteRetentionThreshold = (Long) autoDeleteConfig.get("retention_threshold");
        if (autoDeleteRetentionThreshold != null && autoDeleteRetentionThreshold >= 0 && autoDeleteRetentionThreshold <= 1024 * 1024) {
            this.autoDeleteRetentionThreshold = autoDeleteRetentionThreshold;
        } else {
            this.autoDeleteRetentionThreshold = 1024;
        }

        Long autoDeleteCheckInterval = (Long) autoDeleteConfig.get("check_interval");
        if (autoDeleteCheckInterval != null && autoDeleteCheckInterval > 0 && autoDeleteCheckInterval < 1440) {
            this.autoDeleteCheckInterval = NumberUtil.toInt(autoDeleteCheckInterval);
        } else {
            this.autoDeleteCheckInterval = 60;
        }

        Boolean autoDeleteCheckOnStart = (Boolean) autoDeleteConfig.get("check_on_start");
        this.autoDeleteCheckOnStart = autoDeleteCheckOnStart == null ? false : autoDeleteCheckOnStart;

        //创建logger线程
        this.executor = Executors.newSingleThreadScheduledExecutor(r -> {
            SecurityManager s = System.getSecurityManager();
            ThreadGroup group = (s != null) ? s.getThreadGroup() :
                    Thread.currentThread().getThreadGroup();
            String name = "iwd-logger";

            Thread t = new Thread(group, r, name ,0);
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY);
            return t;
        });

        //创建线程日志表
        this.messages = new ConcurrentHashMap<>(32, 0.5f);

        //do log
        this.executor.scheduleWithFixedDelay(() -> {
            try {
                List<Log> logs = new ArrayList<>(20);

                for (SpscDiscardQueue<Log> q : messages.values()) {
                    Log log;
                    while ((log = q.get()) != null) {
                        logs.add(log);
                    }
                }

                //将所有收集到的日志按时间排序
                logs.sort(Log::compareTo);

                StringBuilder builder = new StringBuilder();
                for (Log log : logs) {
                    builder.append(log.getLogString());
                }

                if (builder.length() == 0) {
                    return;
                }

                //输出日志
                flushLog(builder.toString());

            } catch (Throwable t) {
                t.printStackTrace();
            }

        }, this.flushInterval, this.flushInterval, TimeUnit.MILLISECONDS);

        //do clear
        this.executor.scheduleWithFixedDelay(() -> {

            try {
                List<Thread> terminated = new LinkedList<>();
                for (Thread t : messages.keySet()) {
                    if (t.getState() == TERMINATED) {
                        terminated.add(t);
                    }
                }
                for (Thread t : terminated) {
                    messages.remove(t);
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }

        }, this.clearInterval, this.clearInterval, TimeUnit.MINUTES);

        if (this.autoDeleteEnable) {
            //检查日志输出目录中的日志文件（已压缩的）是否过大，超过设置的大小就删除一部分最早的
            Runnable clearLogFileTask = () -> {
                offerLog(LEVEL_INFO, "start cleaning log file...");
                //统计输出目录中所有日志压缩文件的总大小
                File dir = this.outputFileDir == null
                        ? new File(FileUtil.getRunDir())
                        : new File(this.outputFileDir.substring(0, this.outputFileDir.length() - 1));
                if (!dir.exists() || !dir.isDirectory()) {
                    return;
                }
                if (!dir.canRead() || !dir.canWrite()) {
                    return;
                }
                File[] compressedLogFiles = dir.listFiles(pathname ->
                        pathname.isFile() &&
                        pathname.canRead() &&
                        pathname.canWrite() &&
                        pathname.getName().startsWith(this.outputFileName) &&
                        !pathname.getName().equals(this.outputFileName));
                if (compressedLogFiles == null) {
                    return;
                }
                long size = 0L;
                for (File file : compressedLogFiles) {
                    size += file.length();
                }

                long retention = this.autoDeleteRetentionThreshold * 1024 * 1024;
                if (size < retention) {
                    return;
                }
                //按生成时间排序，逐个删除最早的，直到总大小小于保留阈值
                Arrays.sort(compressedLogFiles, (f1, f2) -> {
                    String f1Name = f1.getName();
                    String f2Name = f2.getName();
                    String f1Time = f1Name.substring(this.outputFileName.length(), f1Name.lastIndexOf("."));
                    String f2Time = f2Name.substring(this.outputFileName.length(), f2Name.lastIndexOf("."));
                    return f1Time.compareTo(f2Time);
                });
                long deletedSize = 0L;
                int deletedFileCount = 0;
                for (File file : compressedLogFiles) {
                    long length = file.length();
                    String name = file.getName();
                    boolean delete = file.delete();
                    if (delete) {
                        offerLog(LEVEL_INFO, "delete log file: " + name);
                        deletedSize += length;
                        deletedFileCount++;
                    } else {
                        offerLog(LEVEL_WARN, "can not delete log file: " + name);
                    }
                    size -= length;
                    if (size < retention) {
                        break;
                    }
                }
                offerLog(LEVEL_INFO, "clean log file finished, " + deletedFileCount + " file(s) totaling " + deletedSize + "B have been deleted");
            };
            this.executor.scheduleWithFixedDelay(() -> {
                try {
                    //启动一个新线程来执行，因为对文件系统的操作可能耗时，影响日志输出
                    new Thread(clearLogFileTask, "iwd-log-cleaner").start();
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }, this.autoDeleteCheckOnStart ? 0 : this.autoDeleteCheckInterval, this.autoDeleteCheckInterval, TimeUnit.MINUTES);
        }

    }

    public static void debug(String msg) {
        
        Logger logger = getLogger();

        if (logger != null && logger.needLog(logger.level, LEVEL_DEBUG_NUMBER)) {
            logger.offerLog(LEVEL_DEBUG, msg);
        }
    }

    public static void info(String msg) {

        Logger logger = getLogger();
        
        if (logger != null && logger.needLog(logger.level, LEVEL_INFO_NUMBER)) {
            logger.offerLog(LEVEL_INFO, msg);
        }
    }

    public static void warn(String msg) {

        Logger logger = getLogger();

        if (logger != null && logger.needLog(logger.level, LEVEL_WARN_NUMBER)) {
            logger.offerLog(LEVEL_WARN, msg);
        }
    }

    public static void error(String msg) {

        Logger logger = getLogger();

        if (logger != null && logger.needLog(logger.level, LEVEL_ERROR_NUMBER)) {
            logger.offerLog(LEVEL_ERROR, msg);
        }
    }

    public static void important(String level, String msg) {
        Logger logger = getLogger();
        if (logger != null) {
            logger.offerLog(level, msg);
        }
    }
    
    private static Logger getLogger() {
        return EnvironmentHolder.get().logger();
    }

    /**
     * 根据日志级别判断是否需要输出。
     * @param currentLevel Logger对象指定的级别.
     * @param targetLevel 日志的级别。
     * @return 是否需要输出。
     */
    private boolean needLog(int currentLevel, int targetLevel) {
        return currentLevel <= targetLevel;
    }

    /**
     * 将日志暂存入线程日志表。
     * @param level 日志级别名称。
     * @param msg 日志内容。
     */
    private void offerLog(String level, String msg) {
        Thread t = Thread.currentThread();
        SpscDiscardQueue<Log> logQueue = messages.get(t);
        if (logQueue == null) {
            logQueue = new SpscDiscardQueue<>(
                    t instanceof ComponentThread
                            ? ((ComponentThread) t).spscQueueSize()
                            : 0x80
            );
            messages.put(t, logQueue);
        }
        Log log = new Log(level, msg, new Date(), t.getName());
        logQueue.put(log);
    }

    /**
     * 输出日志。
     * @param log 日志内容。
     * @throws Exception 调用内部方法产生的异常。
     */
    private void flushLog(String log) throws Exception {

        if (this.logFile == null || !this.logFile.isOpen()) {
            openOutputFile();
        }

        //如果当前的日志输出文件大小超过阈值则进行压缩
        if (this.logFile.size() >= this.compressThreshold * 1024) {
            compressAndClearFile();
        }

        FileUtil.lockFor(this.logFile, lock -> {
            //将输出位置设置到文件末尾
            this.logFile.position(this.logFile.size());
            this.logFile.write(ByteBuffer.wrap(log.getBytes(StandardCharsets.UTF_8)));
        });
    }

    /**
     * 打开日志输出文件，如果没有则创建。
     * @throws Exception 打开或创建日志输出文件时发生的异常。
     */
    private void openOutputFile() throws Exception {
        File logFile = this.outputFileDir == null
                ? new File(FileUtil.getRunDir() + FileUtil.getFileSeparator() + this.outputFileName)
                : new File(this.outputFileDir + this.outputFileName);
        if (!logFile.exists()) {
            if (!logFile.createNewFile()) {
                throw new IllegalStateException("create log file failed by createNewFile()");
            }
        }

        try {
            //以读写模式打开
            this.logFile = FileChannel.open(logFile.toPath(), StandardOpenOption.READ, StandardOpenOption.WRITE);
        } catch (Exception e) {
            if (this.logFile != null) {
                this.logFile.close();
                this.logFile = null;
            }
            throw e;
        }
    }

    /**
     * 压缩并清空当前日志输出文件。
     * @throws Exception 压缩过程中发生的异常。
     */
    private void compressAndClearFile() throws Exception {

        if (this.logFile == null || !this.logFile.isOpen()) {
            throw new IllegalStateException("file channel not opened");
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = dateFormat.format(new Date());

        FileUtil.lockFor(this.logFile, lock -> {
            //压缩日志输出文件
            try (FileOutputStream fos = new FileOutputStream((this.outputFileDir == null ? "" : this.outputFileDir) + this.outputFileName + "." + timestamp + ".gz");
                 GZIPOutputStream gzipOutputStream = new GZIPOutputStream(fos)) {
                ByteBuffer readBuffer = ByteBuffer.allocate(1024); //从日志输出文件中读取字节的缓冲区
                byte[] writeBuffer = new byte[1024]; //向压缩文件中写入字节的缓冲数组
                long max = this.logFile.size(); //日志输出文件当前的大小，也就是读取的最大长度
                long readIndex = 0; //当前读取日志输出文件的位置
                while (readIndex < max) {
                    int r = this.logFile.read(readBuffer, readIndex); //从当前位置开始读，将数据读到readBuffer，读取到r个字节
                    if (r == -1) { //-1代表读不到字节了，退出循环
                        break;
                    }
                    readBuffer.flip(); //使readBuffer转入可读状态
                    readBuffer.get(writeBuffer, 0, r); //将readBuffer中的字节复制到writeBuffer
                    gzipOutputStream.write(writeBuffer, 0, r); //向压缩文件写入
                    readBuffer.clear(); //清理readBuffer，准备下一次读取
                    readIndex += r; //读索引累加
                }
                //向压缩文件写入完成
                gzipOutputStream.finish();
                gzipOutputStream.flush();
            }
            //清空内容
            this.logFile.truncate(0);
        });

    }

    /**
     * 标准日志信息。
     */
    private class Log implements Comparable<Log> {

        final String level;
        final String message;
        final Date time;
        final String threadName;

        Log(String level, String message, Date time, String threadName) {
            this.level = level;
            this.message = message;
            this.time = time;
            this.threadName = threadName;
        }

        String getLogString() {
            StringBuilder builder = new StringBuilder();
            builder
                    .append(Logger.this.format.format(time))
                    .append(' ')
                    .append(threadName)
                    .append(' ')
                    .append(level)
                    .append(':')
                    .append(' ')
                    .append(message)
                    .append('\r')
                    .append('\n');
            return builder.toString();
        }

        @Override
        public int compareTo(Log o) {
            return this.time.compareTo(o.time);
        }
    }

}

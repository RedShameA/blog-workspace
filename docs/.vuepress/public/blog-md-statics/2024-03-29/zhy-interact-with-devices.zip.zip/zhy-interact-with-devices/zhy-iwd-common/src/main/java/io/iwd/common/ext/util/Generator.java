package io.iwd.common.ext.util;

import java.util.UUID;

public final class Generator {

    public static String create32UniqueId() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

}

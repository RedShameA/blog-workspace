package io.iwd.common.stdio.redis;

public class SilentModeRedis extends AbstractRedis {

    @Override
    protected RedisCommandWrapper getCommandWrapper(RedisCommand redisCommand, String[] params) {
        return new RedisCommandWrapper(true, redisCommand, params);
    }
}

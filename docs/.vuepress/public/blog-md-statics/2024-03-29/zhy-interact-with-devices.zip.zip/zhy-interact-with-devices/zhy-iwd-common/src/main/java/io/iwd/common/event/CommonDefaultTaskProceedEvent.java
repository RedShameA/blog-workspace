package io.iwd.common.event;

public class CommonDefaultTaskProceedEvent extends TaskProceedEvent {

    public CommonDefaultTaskProceedEvent(String taskId, Object data) {
        super(taskId, data);
    }

}

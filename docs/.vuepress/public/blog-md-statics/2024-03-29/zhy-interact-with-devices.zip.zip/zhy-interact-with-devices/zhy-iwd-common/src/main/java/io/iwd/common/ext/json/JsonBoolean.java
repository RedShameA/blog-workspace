package io.iwd.common.ext.json;

import static io.iwd.common.ext.json.JsonEntity.Type.BOOLEAN;

public class JsonBoolean implements JsonEntity {

    private final boolean internal;

    public JsonBoolean(boolean b) {
        internal = b;
    }

    @Override
    public boolean isImmutable() {
        return true;
    }

    @Override
    public Type type() {
        return BOOLEAN;
    }

    @Override
    public String stringify() {
        return internal ? "true" : "false";
    }

    @Override
    public Boolean simplify() {
        return internal;
    }

    public Boolean internalBoolean() {
        return internal;
    }
}

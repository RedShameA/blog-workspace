package io.iwd.common.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.entity.SrsAllStreamInfoQueryInitParams;
import io.iwd.common.event.CommonDefaultTaskProceedEvent;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.http.srs.template.SrsQueryAllStreamInfoTemplate;

import static io.iwd.common.CommonConst.TASK_PREFIX;

public class SrsAllStreamInfoQueryTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "SrsAllStreamInfoQuery", CommonDefaultTaskProceedEvent::new);

        taskFlow.addNode("SEND_REQUEST", context -> {
            SrsAllStreamInfoQueryInitParams initParams = (SrsAllStreamInfoQueryInitParams) context.getInput();
            Boolean srsApiSsl = initParams.getSrsApiSsl();
            String srsApiIp = initParams.getSrsApiIp();
            Integer srsApiPort = initParams.getSrsApiPort();

            new SrsQueryAllStreamInfoTemplate(srsApiSsl, srsApiIp, srsApiPort).send();

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonArray input = (JsonArray) context.getInput();
            if (input == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "srs service response error"));
                return;
            }
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("data", input));
        });

        taskFlow.setDefaultEntrance("SEND_REQUEST");

        return taskFlow;
    }

}

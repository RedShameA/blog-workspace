package io.iwd.common.stdio.http;

import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.environment.ManagerLifecycle;
import io.iwd.common.event.Event;
import io.iwd.common.event.EventListener;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.misc.NettyComponentThreadFactory;
import io.iwd.common.ext.util.StringUtil;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.*;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollServerSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.ssl.util.SelfSignedCertificate;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.handler.timeout.IdleStateHandler;

import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLException;
import java.net.URLDecoder;
import java.security.cert.CertificateException;
import java.util.*;

/**
 * http服务器。
 */
public class HttpServer implements EventListener, ManagerLifecycle {

    protected final int port;

    protected final String name;

    protected final int threadCount;

    protected final int idleTimeSeconds;

    /**
     * http报文内容最大长度，单位：KB。
     */
    protected final int maxContentLength;

    protected final boolean ssl;

    protected final Map<String, AbstractHttpRequestHandler<?>> handlers;

    protected final HttpRequestHandlerComposite handlerComposite;

    private SslContext sslContext;

    private EventLoopGroup boosGroup;

    private EventLoopGroup eventLoopGroup;

    public HttpServer(int port,
                      String name,
                      int threadCount,
                      int idleTimeSeconds,
                      int maxContentLength,
                      boolean ssl,
                      Map<String, AbstractHttpRequestHandler<?>> handlers) {
        if (port <= 0 || port > 65535) {
            throw new IllegalArgumentException("port must > 0 && <= 65535");
        }
        this.port = port;
        if (StringUtil.isEmpty(name)) {
            name = "http_server_" + port;
        }
        this.name = name;
        if (threadCount < 1) {
            threadCount = 1;
        }
        if (threadCount > 128) {
            threadCount = 128;
        }
        this.threadCount = threadCount;
        if (idleTimeSeconds < 1) {
            idleTimeSeconds = 10;
        }
        if (idleTimeSeconds > 180) {
            idleTimeSeconds = 180;
        }
        this.idleTimeSeconds = idleTimeSeconds;
        if (maxContentLength < 1) {
            maxContentLength = 1024;
        }
        if (maxContentLength > 1024 * 32) {
            maxContentLength = 1024 * 32;
        }
        this.maxContentLength = maxContentLength;
        this.ssl = ssl;
        this.handlers = new LinkedHashMap<>(handlers);
        this.handlerComposite = new HttpRequestHandlerComposite(this.handlers);
    }

    @Override
    public void active() {

        if (this.eventLoopGroup != null) {
            return;
        }

        if (this.ssl) {
            try {
                SelfSignedCertificate cert = new SelfSignedCertificate(); //用自签名证书
                this.sslContext = SslContextBuilder.forServer(cert.certificate(), cert.privateKey()).build();
            } catch (CertificateException e1) {
                Logger.error("create SelfSignedCertificate failed");
                throw new IllegalStateException("create SelfSignedCertificate failed");
            } catch (SSLException e2) {
                Logger.error("create SslContext failed");
                throw new IllegalStateException("create SslContext failed");
            }
        }

        int workerCount = this.threadCount > 1 ? this.threadCount - 1 : this.threadCount;

        if (workerCount != this.threadCount) { //主从
            this.boosGroup = EnvironmentHolder.get().isEpollAvailable() ?
                    new EpollEventLoopGroup(1, new NettyComponentThreadFactory(getClass())) :
                    new NioEventLoopGroup(1, new NettyComponentThreadFactory(getClass()));
        }

        this.eventLoopGroup = EnvironmentHolder.get().isEpollAvailable() ?
                new EpollEventLoopGroup(workerCount, new NettyComponentThreadFactory(getClass())) :
                new NioEventLoopGroup(workerCount, new NettyComponentThreadFactory(getClass()));

        ServerBootstrap serverBootstrap = new ServerBootstrap();
        if (this.boosGroup != null) {
            serverBootstrap.group(this.boosGroup, this.eventLoopGroup);
        } else {
            serverBootstrap.group(this.eventLoopGroup);
        }
        serverBootstrap
                .channel(EnvironmentHolder.get().isEpollAvailable() ? EpollServerSocketChannel.class : NioServerSocketChannel.class)
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        if (HttpServer.this.ssl) {
                            SSLEngine sslEngine = HttpServer.this.sslContext.newEngine(ch.alloc());
                            sslEngine.setWantClientAuth(false);
                            sslEngine.setUseClientMode(false);
                            //SSL处理器
                            pipeline.addFirst("sslHandler", new SslHandler(sslEngine));
                        }
                        //连接空闲(超时)监视器
                        pipeline.addLast("idleStateHandler", new IdleStateHandler(0, 0, HttpServer.this.idleTimeSeconds));
                        //HTTP编解码器
                        pipeline.addLast("httpServerCodec", new HttpServerCodec());
                        //HTTP报文聚合器
                        pipeline.addLast("httpObjectAggregator", new HttpObjectAggregator(1024 * HttpServer.this.maxContentLength));
                        //请求处理器
                        pipeline.addLast("httpRequestHandlerComposite", HttpServer.this.handlerComposite);
                    }
                })
                .option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
                .childOption(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT);

        try {
            serverBootstrap
                    .bind(this.port)
                    .awaitUninterruptibly();
            Logger.info("http" + (this.ssl ? "s" : "") + " server [" + this.name + "] started on " + this.port);
        } catch (Exception e) {
            Logger.error("http" + (this.ssl ? "s" : "") + " server [" + this.name + "] start failed on  " + this.port + " ,cause: " + e.getMessage());
            destroy();
            throw new IllegalStateException(e);
        }
    }

    @Override
    public void destroy() {
        if (this.boosGroup != null) {
            this.boosGroup.shutdownGracefully().awaitUninterruptibly();
            this.boosGroup = null;
        }
        if (this.eventLoopGroup != null) {
            this.eventLoopGroup.shutdownGracefully().awaitUninterruptibly();
            this.eventLoopGroup = null;
        }
    }

    @Override
    public void handleEvent(Event event) {

    }

    @Override
    public List<Class<? extends Event>> interests() {
        return new LinkedList<>();
    }

    @ChannelHandler.Sharable
    protected static class HttpRequestHandlerComposite extends SimpleChannelInboundHandler<FullHttpRequest> {

        private final Map<String, AbstractHttpRequestHandler<?>> handlers;

        protected HttpRequestHandlerComposite(Map<String, AbstractHttpRequestHandler<?>> handlers) {
            this.handlers = handlers;
        }

        protected AbstractHttpRequestHandler<?> findHandler(String path) {
            //TODO 考虑handler的path中存在表达式的情况
            return this.handlers.get(path);
        }

        @Override
        protected void channelRead0(ChannelHandlerContext ctx, FullHttpRequest msg) throws Exception {

            try {

                //获取uri
                String uri = msg.uri().trim();
                //解析uri
                String path; //请求路径
                Map<String, String> queryStringMap; //查询参数
                int qmarkIndex = uri.indexOf("?"); //问号的索引
                if (qmarkIndex == -1) { //没有查询参数
                    path = uri;
                    queryStringMap = Collections.emptyMap();
                }
                else if (qmarkIndex == uri.length() - 1) { //没有查询参数
                    path = uri.substring(0, qmarkIndex);
                    queryStringMap = Collections.emptyMap();
                }
                else {
                    path = uri.substring(0, qmarkIndex);
                    //解析查询参数
                    queryStringMap = new LinkedHashMap<>();
                    String queryString = uri.substring(qmarkIndex + 1);
                    String[] queryParams = queryString.split("&");
                    for (String param : queryParams) {
                        int esignIndex = param.indexOf("="); //等号的索引
                        if (esignIndex == -1) {
                            Logger.warn("parse http query string error: " + param);
                            HttpHelper.response400(ctx);
                            return;
                        }
                        try {
                            //解析key value，注意要进行url解码
                            String key  = param.substring(0, esignIndex);
                            key = URLDecoder.decode(key, "UTF-8");
                            String value = esignIndex == param.length() - 1
                                    ? ""
                                    : param.substring(esignIndex + 1);
                            if (!StringUtil.isEmpty(value)) {
                                value = URLDecoder.decode(value, "UTF-8");
                            }
                            queryStringMap.put(key, value);
                        } catch (Throwable t) {
                            Logger.warn("parse http query string error: " + param);
                            HttpHelper.response400(ctx);
                            return;
                        }

                    }
                }

                //获取对应路径的请求处理器
                AbstractHttpRequestHandler<?> handler = findHandler(path);
                if (handler == null) {
                    HttpHelper.response404(ctx);
                    return;
                }

                String method = msg.method().name();
                //判断请求处理器接受的method与请求是否匹配
                boolean matchMethod = false;
                for (String m : handler.method()) {
                    if (method.equalsIgnoreCase(m)) {
                        matchMethod = true;
                        break;
                    }
                }
                if (!matchMethod) {
                    HttpHelper.response405(ctx);
                    return;
                }

                //获取所有请求头
                Map<String, String> headers = new LinkedHashMap<>();
                msg.headers().forEach(entry -> headers.put(entry.getKey(), entry.getValue()));

                //获取请求体
                ByteBuf contentByteBuf = null;
                switch (method) {
                    case "GET":
                    case "DELETE":
                        break;
                    default:
                        contentByteBuf = msg.content();
                }

                handler.handle(ctx, path, method, queryStringMap, headers, contentByteBuf);
                //此处一般不需要释放contentByteBuf
                //contentByteBuf的释放会由SimpleChannelInboundHandler释放msg时触发

            } catch (Throwable t) {
                HttpHelper.response500(ctx);
                throw new RuntimeException("error occurred while handling http request, cause: " + t.getMessage());
            }

        }

        @Override
        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
            if (cause instanceof DecoderException) {
                DecoderException decoderException = (DecoderException) cause;
                if (decoderException.getCause() instanceof SSLException) {
                    return; //ssl引发的异常忽略
                }
            }
            HttpHelper.response500(ctx);
            Logger.warn("HttpRequestHandlerComposite caught exception: " + cause.getMessage());
        }

        @Override
        public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
            if (evt instanceof IdleStateEvent) {
                Logger.warn("HttpRequestHandlerComposite idle triggered");
                HttpHelper.response503(ctx);
                return;
            }
        }
    }

}

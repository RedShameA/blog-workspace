package io.iwd.common.event;

import io.iwd.common.CommonConst;
import io.iwd.common.engine.TaskResult;

public class CommonDefaultTaskStartEvent extends TaskStartEvent {

    public CommonDefaultTaskStartEvent(String taskName, Object data) {
        super(taskName, data);
    }

    public CommonDefaultTaskStartEvent(String taskName, Object data, TaskResult taskResult) {
        super(taskName, data, taskResult);
    }

    public CommonDefaultTaskStartEvent(String taskId, String taskName, Object data, TaskResult taskResult) {
        super(taskId, taskName, data, taskResult);
    }

    public CommonDefaultTaskStartEvent(String taskId, String taskName, String entranceName, Object data, TaskResult taskResult) {
        super(taskId, taskName, entranceName, data, taskResult);
    }

    @Override
    public String getTaskPrefix() {
        return CommonConst.TASK_PREFIX;
    }

}

package io.iwd.common.event;

public abstract class LogEvent implements Event {

    public interface LogType {

        int code();

        String name();

    }

    protected final LogType logType;

    protected final String logMessage;

    protected LogEvent(LogType logType, String logMessage) {
        this.logType = logType;
        this.logMessage = logMessage;
    }

    public LogType getLogType() {
        return logType;
    }

    public String getLogMessage() {
        return logMessage;
    }

}

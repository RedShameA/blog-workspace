package io.iwd.common.ext.util;

import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.locks.LockSupport;

public class MpscConsumerBlockingQueue<E> extends MpscLinkedArrayQueue<E> {

    protected final Thread consumer;

    protected volatile boolean parking;

    public MpscConsumerBlockingQueue(Thread consumer, int chunkSize, int queueSize) {
        super(chunkSize, queueSize);
        this.consumer = consumer;
        this.parking = false;
    }

    @Override
    public void put(E e) {
        if (e == null) {
            throw new NullPointerException();
        }

        AtomicReferenceArray<Object> buffer;
        int pIndex;

        while (true) {
            int pLimit = this.producerLimit.get();
            pIndex = this.producerIndex.get();
            if ((pIndex & 1) == 1) {
                continue;
            }

            buffer = this.producerBuffer.get();

            if (pLimit <= pIndex) {

                int result = offerSlowPath(pIndex, pLimit);
                switch (result) {
                    case CONTINUE_TO_P_INDEX_CAS:
                        break;
                    case RETRY:
                        continue;
                    case QUEUE_FULL:
                        onQueueFull(e);
                        return;
                    case QUEUE_RESIZE:
                        resize(buffer, pIndex, e);
                        if (this.parking) {
                            LockSupport.unpark(this.consumer);
                        }
                        return;
                }
            }

            if (this.producerIndex.compareAndSet(pIndex, pIndex + 2)) {
                break;
            }
        }

        int offset = (pIndex & this.mask) >>> 1;
        buffer.set(offset, e);
        if (this.parking) {
            LockSupport.unpark(this.consumer);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public E get() {
        while (true) {
            AtomicReferenceArray<Object> buffer = this.consumerBuffer.get();
            int cIndex = this.consumerIndex.get();
            int offset = (cIndex & this.mask) >>> 1;

            Object e = buffer.get(offset);
            if (e == null) {
                if (cIndex != this.producerIndex.get()) {
                    do {
                        e = buffer.get(offset);
                    } while (e == null);
                } else if (this.parking) {
                    LockSupport.park();
                    continue;
                } else {
                    this.parking = true;
                    continue;
                }
            }
            if (this.parking) {
                this.parking = false;
            }
            if (e == JUMP) {
                AtomicReferenceArray<Object> next = nextBuffer(buffer);
                return newBufferPoll(next, cIndex);
            }
            buffer.set(offset, null);
            this.consumerIndex.set(cIndex + 2);
            return (E) e;
        }
    }

}

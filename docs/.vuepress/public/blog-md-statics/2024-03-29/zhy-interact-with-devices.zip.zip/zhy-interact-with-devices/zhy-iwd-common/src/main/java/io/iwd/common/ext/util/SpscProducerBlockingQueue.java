package io.iwd.common.ext.util;

import java.util.concurrent.locks.LockSupport;

/**
 * 单生产者单消费者队列。
 * 使用此队列时，生产者线程和消费者线程始终不可改变。
 * 当队列已满，生产者无法将元素入队时，生产者线程会阻塞等待，直到队列有可用空间。
 * 因此，强烈不建议生产者和消费者是同一线程，否则有死锁的风险。
 * @param <T> 元素类型。
 */
public class SpscProducerBlockingQueue<T> extends SpscQueue<T> {

    protected final Thread producer;

    protected volatile boolean producerParking;

    public SpscProducerBlockingQueue(Thread producer, int size) {
        super(size);
        if (producer == null) {
            throw new NullPointerException();
        }
        this.producer = producer;
        this.producerParking = false;
    }

    public void put(T e) {
        if (e == null) {
            throw new NullPointerException();
        }
        if (this.producer != Thread.currentThread()) {
            throw new IllegalStateException("current thread is not the producer");
        }

        Object[] buf = super.buffer;
        int i = super.in;
        //检查可用大小
        while (true) {
            int o = super.out;
            int used = ((i < o ? 0x10000 : 0) | i) - o;
            if (buf.length > used) {
                if (this.producerParking) { //能只进行volatile读就不要进行volatile写
                    this.producerParking = false;
                }
                break;
            }
            this.producerParking = true;
            if (o != super.out) {
                this.producerParking = false;
                break;
            }
            LockSupport.park();
        }

        int target = i & (buf.length - 1);
        if (buf[target] != null) {
            throw new IllegalStateException("element is not consumed");
        }
        buf[target] = e;
        super.in = (i + 1) & MAX_UNSIGNED_INT_16;
    }

    @SuppressWarnings("unchecked")
    public T get() {
        int i = super.in, o = super.out;
        if (i == o) {
            return null;
        }
        Object[] buf = super.buffer;
        int target = o & (buf.length - 1);
        Object e = buf[target];
        buf[target] = null;
        super.out = (o + 1) & MAX_UNSIGNED_INT_16;
        if (this.producerParking) {
            LockSupport.unpark(this.producer);
        }
        return (T) e;
    }

}

package io.iwd.common.environment;

import io.iwd.common.engine.*;
import io.iwd.common.event.CommonTaskEventListener;
import io.iwd.common.event.Event;
import io.iwd.common.event.EventMulticaster;
import io.iwd.common.event.EventListener;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.FileUtil;
import io.iwd.common.stdio.http.AbstractHttpRequestHandler;
import io.iwd.common.stdio.http.HttpRequestHandler;
import io.iwd.common.stdio.http.HttpServer;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.http.HttpSender;
import io.iwd.common.stdio.redis.*;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * iwd运行的环境容器。此类在最初设计时计划可以通过继承来扩展可包含的组件。
 * 但前期开发时采用了静态方法获取组件，而静态方法无法继承，因此后期不能再采用这种方式。
 */
public class Environment {

    /**
     * 当前环境下netty是否支持epoll。
     */
    protected boolean epollAvailable;

    /**
     * 每一个Task默认的等待时间。
     */
    protected long taskDefaultAwaitTime = 3000L;

    /**
     * 全局配置。
     */
    protected GlobalConfiguration globalConfiguration;

    /**
     * 全局配置读取器。
     */
    protected GlobalConfigurationReader configReader;

    /**
     * 配置加载器。
     */
    protected ConfigurationLoader configurationLoader;

    /**
     * 日志打印器。
     */
    protected Logger logger;

    /**
     * 事件派发器。
     */
    protected EventMulticaster eventMulticaster;

    /**
     * 任务流程注册中心。
     */
    protected TaskFlowRegistry taskFlowRegistry;

    /**
     * 任务执行器管理器。
     */
    protected TaskReactorManager taskReactorManager;

    /**
     * 任务结果处理服务。
     */
    protected TaskResultService taskResultService;

    /**
     * redis消息处理器注册中心。
     */
    protected RedisChannelMessageHandlerRegistry redisChannelMessageHandlerRegistry;

    /**
     * redis消息监听器。
     */
    protected RedisMessageListener redisMessageListener;

    /**
     * redis访问器。
     */
    protected RedisAccessor redisAccessor;

    /**
     * http请求发送器。
     */
    protected HttpSender httpSender;

    /**
     * 所有http服务器。
     */
    protected List<HttpServer> httpServers;

    /**
     * 自定义插件。
     */
    protected Map<String, Plugin<?>> plugins;

    public Environment() {}

    /**
     * 刷新环境，按顺序创建、初始化必要的组件。
     */
    public synchronized void refresh() {

        publishEnvironment();

        initConfig();

        postInitConfig();

        initLogger();

        Logger.important("environment", createBanner());

        initTaskFlowRegistry();

        initTaskReactorManager();

        initTaskResultService();

        initRedisClient();

        initHttpCenter();

        initPlugins();

        initEventMulticaster();
        
        //激活环境
        active();

    }

    /**
     * 激活所有组件，让它们开始真正使用资源。
     */
    protected void active() {
        if (this.redisAccessor != null) {
            ((ManagerLifecycle) this.redisAccessor).active();
        }
        if (this.taskReactorManager != null) {
            this.taskReactorManager.active();
        }
        if (this.taskResultService != null) {
            this.taskResultService.active();
        }
        if (this.httpSender != null) {
            this.httpSender.active();
        }
        if (this.httpServers != null) {
            for (HttpServer server : this.httpServers) {
                server.active();
            }
        }
        if (this.redisMessageListener != null) {
            this.redisMessageListener.active();
        }
        if (this.plugins != null) {
            for (Plugin<?> plugin : this.plugins.values()) {
                plugin.active();
            }
        }
    }

    /**
     * 关闭环境。
     */
    public synchronized void shutdown() {
        if (this.redisMessageListener != null) {
            this.redisMessageListener.destroy();
            this.redisMessageListener = null;
        }
        if (this.redisAccessor != null) {
            ((ManagerLifecycle) this.redisAccessor).destroy();
            this.redisAccessor = null;
        }
        if (this.taskReactorManager != null) {
            this.taskReactorManager.destroy();
            this.taskReactorManager = null;
        }
        if (this.taskResultService != null) {
            this.taskResultService.destroy();
            this.taskResultService = null;
        }
        if (this.httpSender != null) {
            this.httpSender.destroy();
            this.httpSender = null;
        }
        if (this.plugins != null) {
            for (Plugin<?> plugin : this.plugins.values()) {
                plugin.destroy();
            }
            this.plugins.clear();
            this.plugins = null;
        }
    }

    /**
     * 将此环境发布到{@link EnvironmentHolder}。
     */
    protected void publishEnvironment() {
        EnvironmentHolder.set(this);
    }

    /**
     * 加载基础配置。
     */
    protected void initConfig() {
        this.globalConfiguration = new GlobalConfiguration();

        this.configurationLoader = new ConfigurationLoader(this.globalConfiguration);

        this.configurationLoader.loadRootConfigFile();

        @SuppressWarnings("unchecked")
        List<String> extPackages = (List<String>) this.globalConfiguration.getGlobalConfig("ext_packages");
        if (extPackages != null && extPackages.size() != 0) {
            extPackages.forEach(pkg -> {
                //扩展包不能叫global,否则会与全局配置冲突
                if ("global".equalsIgnoreCase(pkg)) {
                    throw new IllegalStateException("ext package can not named as global");
                }
                this.configurationLoader.loadConfigFile("classpath:iwd-" + pkg + ".conf");
                this.configurationLoader.loadConfigFile("file:./iwd-" + pkg + ".conf");
            });
        }

        //TODO post init config

        Long defaultAwaitTime = (Long) this.globalConfiguration.getGlobalConfig("task", "default_await_time");
        if (defaultAwaitTime == null) {
            defaultAwaitTime = 3000L;
        }
        this.taskDefaultAwaitTime = defaultAwaitTime;

        //检查当前环境是否支持epoll
        try {
            Class<?> nettyEpollClass = Class.forName("io.netty.channel.epoll.Epoll");
            Method isAvailableMethod = nettyEpollClass.getMethod("isAvailable");
            this.epollAvailable =  (Boolean) isAvailableMethod.invoke(null);
        } catch (Exception e) {
            this.epollAvailable = false;
        }

        this.configReader = new GlobalConfigurationReader();
    }

    /**
     * 加载基础配置后处理，子类可以重写此方法，对配置进行修改。
     */
    protected void postInitConfig() {}

    @SuppressWarnings("unchecked")
    protected String createBanner() {
        final StringBuilder builder = new StringBuilder();
        builder.append("\r\n");
        try (InputStream globalBannerStream = FileUtil.getClasspathFileAsStream("banner-global.txt");) {
            if (globalBannerStream == null) {
                return null;
            }
            byte[] buf = new byte[globalBannerStream.available()];
            int r = globalBannerStream.read(buf);
            if (r > 0) {
                builder.append(new String(buf, StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {}

        List<String> extPackages = (List<String>) this.globalConfiguration.getGlobalConfig("ext_packages");
        if (extPackages == null || extPackages.size() == 0) {
            return builder.toString();
        }
        extPackages.forEach(pkg -> {
            try (InputStream pkgBannerStream = FileUtil.getClasspathFileAsStream("banner-" + pkg + ".txt");) {
                if (pkgBannerStream == null) {
                    return;
                }
                byte[] buf = new byte[pkgBannerStream.available()];
                int r = pkgBannerStream.read(buf);
                if (r > 0) {
                    builder.append(new String(buf, StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) {}
        });

        return builder.toString();
    }

    /**
     * 初始化日志打印器。
     */
    protected void initLogger() {
        this.logger = new Logger(this.globalConfiguration);
    }

    /**
     * 初始化任务流程注册中心。
     */
    @SuppressWarnings("unchecked")
    protected void initTaskFlowRegistry() {
        List<String> taskFlowCollectors = new ArrayList<>();

        String globalCollectorName = (String) this.globalConfiguration.getGlobalConfig("task_flow_collector");
        if (StringUtil.isEmpty(globalCollectorName)) {
            throw new IllegalStateException("common package must have task flow collector");
        }
        taskFlowCollectors.add(globalCollectorName);

        List<String> extPackages = (List<String>) this.globalConfiguration.getGlobalConfig("ext_packages");
        if (extPackages != null && extPackages.size() != 0) {
            extPackages.forEach(pkg -> {
                String collectorName = (String) this.globalConfiguration.getExtConfig(pkg, "task_flow_collector");
                if (StringUtil.isEmpty(collectorName)) {
                    throw new IllegalStateException("ext package must have task flow collector");
                }
                taskFlowCollectors.add(collectorName);
            });
        }

        Map<String, Map<String, TaskFlow>> taskFlowMap = new HashMap<>();
        for (String t : taskFlowCollectors) {
            TaskFlowCollector collector;
            try {
                Class<?> cls = Class.forName(t);
                Constructor<?> constructor = cls.getConstructor();
                collector = (TaskFlowCollector) constructor.newInstance();
            } catch (ClassNotFoundException e) {
                throw new IllegalStateException("can not found task flow collector class:" + t);
            } catch (NoSuchMethodException e) {
                throw new IllegalStateException("can not found task flow collector constructor:" + t);
            } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
                throw new IllegalStateException("can not create instance:" + t);
            }

            List<TaskFlow> taskFlowList = collector.getTaskFlowList();
            for (TaskFlow taskFlow : taskFlowList) {
                taskFlowMap.computeIfAbsent(taskFlow.getPrefix(), k -> new HashMap<>()).put(taskFlow.getName(), taskFlow);
            }
        }

        this.taskFlowRegistry = new TaskFlowRegistry(taskFlowMap);
    }

    /**
     * 初始化任务执行器管理器。
     */
    @SuppressWarnings("unchecked")
    protected void initTaskReactorManager() {
        Object reactorCount = this.globalConfiguration.getGlobalConfig("task", "reactor_count");
        if (reactorCount == null) {
            reactorCount = 1;
        }
        int count = NumberUtil.toInt(reactorCount);
        this.taskReactorManager = new TaskReactorManager(count);
    }

    /**
     * 初始化任务结果处理服务。
     */
    protected void initTaskResultService() {
        Number threadCount = (Number) this.globalConfiguration.getGlobalConfig("task", "result_handle_thread_count");
        if (threadCount == null) {
            threadCount = 4;
        }
        int count = NumberUtil.toInt(threadCount);
        if (count < 1 || count > 128) {
            count = 4;
        }
        this.taskResultService = new TaskResultService(count);
    }

    /**
     * 初始化redis客户端组件：发布、订阅、数据访问。
     */
    @SuppressWarnings("unchecked")
    protected void initRedisClient() {
        //获取redis相关配置
        Map<String, Object> redisConfig = (Map<String, Object>) this.globalConfiguration.getGlobalConfig("redis");
        if (redisConfig == null) {
            return;
        }
        //ip、端口、密码
        String ip = (String) redisConfig.get("ip");
        Number confPort = (Number) redisConfig.get("port");
        String password = (String) redisConfig.get("password");
        if (StringUtil.isEmpty(ip)) {
            ip = "127.0.0.1";
        }
        if (confPort == null) {
            confPort = 6379;
        }
        int port = NumberUtil.toInt(confPort);
        if (port < 1 || port > 65535) {
            port = 6379;
        }
        Boolean autoReconnect = (Boolean) redisConfig.get("auto_reconnect");
        if (autoReconnect == null) {
            autoReconnect = Boolean.TRUE;
        }

        this.redisAccessor = new SingleConnectionRedisAccessor(ip, port, password, autoReconnect);

        //获取订阅相关配置
        List<Map<String, Object>> subscribe = new ArrayList<>();
        Map<String, Object> commonSubscribe = (Map<String, Object>) this.globalConfiguration.getGlobalConfig("redis", "subscribe");
        if (commonSubscribe != null) {
            for (Map.Entry<String, Object> sub : commonSubscribe.entrySet()) {
                Object v =  sub.getValue();
                if (! (v instanceof Map) || ((Map<?, ?>)v).size() == 0) {
                    throw new IllegalStateException("global.redis.subscribe." + sub.getKey() + " format error");
                }
                Map<String, Object> group = (Map<String, Object>) v;
                String channelName = (String) group.get("channel_name");
                String className = (String) group.get("class_name");
                if (StringUtil.isEmpty(channelName) || StringUtil.isEmpty(className)) {
                    throw new IllegalStateException("global.redis.subscribe." + sub.getKey() + " format error");
                }
                Map<String, Object> subInfo = new HashMap<>(4);
                subInfo.put("channel", channelName);
                subInfo.put("handler", className);
                subscribe.add(subInfo);
            }
        }

        List<String> extPackages = (List<String>) this.globalConfiguration.getGlobalConfig("ext_packages");
        if (extPackages != null && extPackages.size() != 0) {
            extPackages.forEach(pkg -> {
                Map<String, Object> pkgSubscribe = (Map<String, Object>) this.globalConfiguration.getExtConfig(pkg, "redis", "subscribe");
                if (pkgSubscribe != null) {
                    for (Map.Entry<String, Object> sub : pkgSubscribe.entrySet()) {
                        Object v =  sub.getValue();
                        if (! (v instanceof Map) || ((Map<?, ?>)v).size() == 0) {
                            throw new IllegalStateException(pkg + ".redis.subscribe." + sub.getKey() + " format error");
                        }
                        Map<String, Object> group = (Map<String, Object>) v;
                        String channelName = (String) group.get("channel_name");
                        String className = (String) group.get("class_name");
                        if (StringUtil.isEmpty(channelName) || StringUtil.isEmpty(className)) {
                            throw new IllegalStateException(pkg + ".redis.subscribe." + sub.getKey() + " format error");
                        }
                        Map<String, Object> subInfo = new HashMap<>(4);
                        subInfo.put("channel", channelName);
                        subInfo.put("handler", className);
                        subscribe.add(subInfo);
                    }
                }
            });
        }

        //消息处理器缓存
        Map<String, RedisChannelMessageHandler> handlers = new HashMap<>();
        //需要注册监听的频道名称和消息处理器
        Map<String, Set<RedisChannelMessageHandler>> registryMap = new HashMap<>();
        //所有需要监听的频道名称
        Set<String> channels = new LinkedHashSet<>();

        for (Map<String, Object> subInfo : subscribe) {
            //频道名称
            String channel = (String) subInfo.get("channel");
            //消息处理器全类名
            String handlerName = (String) subInfo.get("handler");
            try {
                RedisChannelMessageHandler existed = handlers.get(handlerName);
                if (existed == null) {
                    //缓存中没有则创建
                    Class<?> cls = Class.forName(handlerName);
                    Constructor<?> constructor = cls.getConstructor();
                    existed = (RedisChannelMessageHandler) constructor.newInstance();
                    //添加到缓存
                    handlers.put(handlerName, existed);
                }
                registryMap.computeIfAbsent(channel, k -> new LinkedHashSet<>()).add(existed);
                channels.add(channel);
            } catch (Exception e) {
                throw new IllegalStateException("create RedisChannelMessageHandler failed: " + handlerName);
            }
        }

        //如果没有需要监听的频道 就不需要创建监听器
        if (channels.size() > 0) {
            //创建redis消息处理器注册中心
            this.redisChannelMessageHandlerRegistry = new RedisChannelMessageHandlerRegistry(registryMap);
            //创建redis消息监听器
            this.redisMessageListener = new RedisMessageListener(ip, port, channels, password, autoReconnect);
        }

    }

    /**
     * 初始化http服务器和请求发送器。
     */
    @SuppressWarnings("unchecked")
    protected void initHttpCenter() {
        //获取global http配置
        Map<String, Object> globalHttpConfig = (Map<String, Object>) this.globalConfiguration.getGlobalConfig("http");
        if (globalHttpConfig == null) {
            return;
        }
        //获取sender配置
        Map<String, Object> sender = (Map<String, Object>) globalHttpConfig.get("sender");
        if (sender != null) {
            Number threadCount = (Number) sender.get("thread_count");
            if (threadCount == null) {
                threadCount = 1;
            }
            int tc = NumberUtil.toInt(threadCount);
            if (tc < 1 || tc > 128) {
                tc = 1;
            }
            this.httpSender = new HttpSender(tc);
        }

        //获取global & ext的handler配置
        List<Map<String, Object>> allHandlerConfig = new LinkedList<>();
        Map<String, Map<String, Object>> globalHandlerConfig = (Map<String, Map<String, Object>>) globalHttpConfig.get("handler");
        if (globalHandlerConfig != null) {
            allHandlerConfig.addAll(globalHandlerConfig.values());
        }

        List<String> extPackages = (List<String>) this.globalConfiguration.getGlobalConfig("ext_packages");
        if (extPackages != null && extPackages.size() != 0) {
            extPackages.forEach(pkg -> {
                Map<String, Map<String, Object>> pkgHandlerConfig = (Map<String, Map<String, Object>>) this.globalConfiguration.getExtConfig(pkg, "http", "handler");
                if (pkgHandlerConfig != null) {
                    allHandlerConfig.addAll(pkgHandlerConfig.values());
                }
            });
        }

        //获取所有配置声明的handler
        Map<String, Set<AbstractHttpRequestHandler<?>>> handlers = new HashMap<>();
        for (Map<String, Object> handlerConfig : allHandlerConfig) {
            String serverName = (String) handlerConfig.get("server_name");
            String className = (String) handlerConfig.get("class_name");
            try {
                Class<AbstractHttpRequestHandler<?>> cls = (Class<AbstractHttpRequestHandler<?>>) Class.forName(className);
                boolean annotationPresent = cls.isAnnotationPresent(HttpRequestHandler.class);
                if (!annotationPresent) {
                    throw new IllegalStateException("@HttpRequestHandler annotation not present on " + cls.getName());
                }
                AbstractHttpRequestHandler<?> abstractHttpRequestHandler = cls.getConstructor().newInstance();
                handlers.computeIfAbsent(serverName, k -> new LinkedHashSet<>()).add(abstractHttpRequestHandler);
            } catch (Exception e) {
                throw new IllegalStateException("can not create AbstractHttpRequestHandler [" + className + "], cause: " + e.getMessage());
            }
        }

        //获取global & ext的server配置
        List<Map<String, Object>> allServerConfig = new LinkedList<>();
        Set<Integer> portSet = new HashSet<>(); //检查是否有端口重复
        Set<String> nameSet = new HashSet<>(); //检查是否有名称重复
        Map<String, Map<String, Object>> globalServerConfig = (Map<String, Map<String, Object>>) globalHttpConfig.get("server");
        if (globalServerConfig != null) {
            for (Map.Entry<String, Map<String, Object>> s : globalServerConfig.entrySet()) {
                Map<String, Object> serverConfig = new HashMap<>(s.getValue());
                serverConfig.put("name", s.getKey());
                allServerConfig.add(serverConfig);
            }
        }

        if (extPackages != null && extPackages.size() != 0) {
            extPackages.forEach(pkg -> {
                Map<String, Map<String, Object>> pkgServerConfig = (Map<String, Map<String, Object>>) this.globalConfiguration.getExtConfig(pkg, "http", "server");
                if (pkgServerConfig != null) {
                    for (Map.Entry<String, Map<String, Object>> s : pkgServerConfig.entrySet()) {
                        Map<String, Object> serverConfig = new HashMap<>(s.getValue());
                        serverConfig.put("name", s.getKey());
                        allServerConfig.add(serverConfig);
                    }
                }
            });
        }

        //获取所有配置声明的server
        List<HttpServer> servers = new ArrayList<>(allServerConfig.size());
        for (Map<String, Object> config : allServerConfig) {
            String name = (String) config.get("name");
            if (StringUtil.isEmpty(name)) {
                throw new IllegalStateException("missing server name");
            }
            if (nameSet.contains(name)) {
                throw new IllegalStateException("same server name exists");
            }
            nameSet.add(name);
            Number port = (Number) config.get("port");
            if (port == null) {
                throw new IllegalStateException(name + " missing server port");
            }
            int p = NumberUtil.toInt(port);
            if (portSet.contains(p)) {
                throw new IllegalStateException("same server port exists");
            }
            portSet.add(p);

            Number threadCount = (Number) config.get("thread_count");
            if (threadCount == null) {
                threadCount = 1;
            }
            int tc = NumberUtil.toInt(threadCount);
            Number idleTimeSeconds = (Number) config.get("idle_time_seconds");
            if (idleTimeSeconds == null) {
                idleTimeSeconds = 15;
            }
            int itc = NumberUtil.toInt(idleTimeSeconds);
            Number maxContentLength = (Number) config.get("max_content_length");
            if (maxContentLength == null) {
                maxContentLength = 1024;
            }
            int mcl = NumberUtil.toInt(maxContentLength);
            Boolean ssl = (Boolean) config.get("ssl");
            if (ssl == null) {
                ssl = Boolean.FALSE;
            }
            Set<AbstractHttpRequestHandler<?>> handlerSet = handlers.get(name);
            if (handlerSet == null || handlerSet.size() == 0) {
                continue;
            }
            Map<String, AbstractHttpRequestHandler<?>> handlerMap = new HashMap<>();
            for (AbstractHttpRequestHandler<?> h : handlerSet) {
                String path = h.path();
                handlerMap.put(path, h);
            }
            HttpServer httpServer = new HttpServer(p, name, tc, itc, mcl, ssl, handlerMap);
            servers.add(httpServer);
        }

        this.httpServers = servers;
    }

    /**
     * 初始化插件。
     */
    @SuppressWarnings("unchecked")
    protected void initPlugins() {
        Map<String, Plugin<?>> pluginMap = new LinkedHashMap<>(8, 0.25f);

        List<Map<String, Object>> globalPlugins = (List<Map<String, Object>>) this.globalConfiguration.getGlobalConfig("plugins");
        if (globalPlugins != null && globalPlugins.size() != 0) {
            globalPlugins.forEach(plugin -> {
                String name = (String) plugin.get("name");
                String className = (String) plugin.get("class_name");
                Map<String, Object> configParams = (Map<String, Object>) plugin.get("config_params");
                Plugin<?> p;
                try {
                    Class<?> cls = Class.forName(className);
                    Constructor<?> constructor = cls.getConstructor();
                    p = (Plugin<?>) constructor.newInstance();
                } catch (ClassNotFoundException e) {
                    throw new IllegalStateException("can not found plugin class:" + className);
                } catch (NoSuchMethodException e) {
                    throw new IllegalStateException("can not found plugin constructor:" + className);
                } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
                    throw new IllegalStateException("can not create instance:" + className);
                }
                if (pluginMap.containsKey(name)) {
                    throw new IllegalStateException("plugin [" + name + "] already exists");
                }
                p.setConfigParams(configParams);
                p.init();
                pluginMap.put(name, p);
            });
        }

        List<String> extPackages = (List<String>) this.globalConfiguration.getGlobalConfig("ext_packages");
        if (extPackages != null && extPackages.size() != 0) {
            extPackages.forEach(pkg -> {
                List<Map<String, Object>> pkgPlugins = (List<Map<String, Object>>) this.globalConfiguration.getExtConfig(pkg, "plugins");
                if (pkgPlugins == null || pkgPlugins.isEmpty()) {
                    return;
                }
                pkgPlugins.forEach(plugin -> {
                    String name = (String) plugin.get("name");
                    String className = (String) plugin.get("class_name");
                    Map<String, Object> configParams = (Map<String, Object>) plugin.get("config_params");
                    Plugin<?> p;
                    try {
                        Class<?> cls = Class.forName(className);
                        Constructor<?> constructor = cls.getConstructor();
                        p = (Plugin<?>) constructor.newInstance();
                    } catch (ClassNotFoundException e) {
                        throw new IllegalStateException("can not found plugin class:" + className);
                    } catch (NoSuchMethodException e) {
                        throw new IllegalStateException("can not found plugin constructor:" + className);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
                        throw new IllegalStateException("can not create instance:" + className);
                    }
                    if (pluginMap.containsKey(name)) {
                        throw new IllegalStateException("plugin [" + name + "] already exists");
                    }
                    p.setConfigParams(configParams);
                    p.init();
                    pluginMap.put(name, p);
                });
            });
        }

        this.plugins = pluginMap;
    }

    /**
     * 初始化事件派发器。
     */
    @SuppressWarnings("unchecked")
    protected void initEventMulticaster() {
        List<EventListener> listenerList = new LinkedList<>();

        Map<String, String> commonListeners = (Map<String, String>) this.globalConfiguration.getGlobalConfig("event_listener");
        if (commonListeners != null && commonListeners.size() != 0) {
            for (String className : commonListeners.values()) {
                try {
                    Class<?> listenerClass = Class.forName(className);
                    Constructor<?> constructor = listenerClass.getConstructor();
                    EventListener eventListener = (EventListener) constructor.newInstance();
                    listenerList.add(eventListener);
                } catch (ClassNotFoundException e) {
                    throw new IllegalStateException("can not found event listener class:" + className);
                } catch (NoSuchMethodException e) {
                    throw new IllegalStateException("can not found event listener constructor:" + className);
                } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
                    throw new IllegalStateException("can not create instance:" + className);
                }
            }
        }

        List<String> extPackages = (List<String>) this.globalConfiguration.getGlobalConfig("ext_packages");
        if (extPackages != null && extPackages.size() != 0) {
            extPackages.forEach(pkg -> {
                Map<String, String> eventListeners = (Map<String, String>) this.globalConfiguration.getExtConfig(pkg, "event_listener");
                if (eventListeners == null || eventListeners.size() == 0) {
                    return;
                }
                for (String className : eventListeners.values()) {
                    try {
                        Class<?> listenerClass = Class.forName(className);
                        Constructor<?> constructor = listenerClass.getConstructor();
                        EventListener eventListener = (EventListener) constructor.newInstance();
                        listenerList.add(eventListener);
                    } catch (ClassNotFoundException e) {
                        throw new IllegalStateException("can not found event listener class:" + className);
                    } catch (NoSuchMethodException e) {
                        throw new IllegalStateException("can not found event listener constructor:" + className);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
                        throw new IllegalStateException("can not create instance:" + className);
                    }
                }
            });
        }

        Map<Class<? extends Event>, List<EventListener>> listenerMap = new HashMap<>();
        for (EventListener el : listenerList) {
            List<Class<? extends Event>> interests = el.interests();
            for (Class<? extends Event> ec : interests) {
                listenerMap.computeIfAbsent(ec, k -> new LinkedList<>()).add(el);
            }
        }

        this.eventMulticaster = new EventMulticaster(listenerMap);

    }

    public GlobalConfiguration config() {
        return this.globalConfiguration;
    }

    public GlobalConfigurationReader configReader() {
        return this.configReader;
    }

    public Logger logger() {
        return this.logger;
    }
    
    public long taskDefaultAwaitTime() {
        return this.taskDefaultAwaitTime;
    }

    public EventMulticaster eventMulticaster() {
        return this.eventMulticaster;
    }

    public TaskFlowRegistry taskFlowRegistry() {
        return this.taskFlowRegistry;
    }

    public TaskReactorManager taskReactorManager() {
        return this.taskReactorManager;
    }

    public TaskResultService taskResultService() {
        return this.taskResultService;
    }

    public RedisAccessor redisAccessor() {
        return this.redisAccessor;
    }

    public RedisChannelMessageHandlerRegistry redisChannelMessageHandlerRegistry() {
        return this.redisChannelMessageHandlerRegistry;
    }

    public HttpSender httpSender() {
        return this.httpSender;
    }

    @SuppressWarnings("unchecked")
    public <T> T plugin(String name) {
        Map<String, Plugin<?>> plugins = this.plugins;
        if (plugins == null) {
            return null;
        }
        Plugin<?> plugin = plugins.get(name);
        if (plugin == null) {
            return null;
        }
        return (T) plugin.internal();
    }

    /**
     * 返回是否可以使用netty epoll。
     * @return 是否可以使用netty epoll。
     */
    public boolean isEpollAvailable() {
        return this.epollAvailable;
    }

}

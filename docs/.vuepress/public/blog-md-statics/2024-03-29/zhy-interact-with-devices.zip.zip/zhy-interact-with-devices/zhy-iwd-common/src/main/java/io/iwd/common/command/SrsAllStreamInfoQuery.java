package io.iwd.common.command;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.entity.SrsAllStreamInfoQueryInitParams;
import io.iwd.common.event.CommonDefaultTaskStartEvent;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;

/**
 * srs全部流信息查询命令。
 */
public class SrsAllStreamInfoQuery extends AdvancedCommand<String> {
    
    private SrsAllStreamInfoQueryInitParams initParams = new SrsAllStreamInfoQueryInitParams();

    /**
     * 设置与srs的api交互是否使用https。默认从配置文件中获取。
     * @param srsApiSsl 与srs的api交互是否使用https。
     * @return SrsAllStreamInfoQuery命令对象。
     */
    public SrsAllStreamInfoQuery setSrsApiSsl(Boolean srsApiSsl) {
        this.initParams.setSrsApiSsl(srsApiSsl);
        return this;
    }

    /**
     * 设置srs的api交互ip。默认从配置文件中获取。
     * @param srsApiIp srs的api交互ip。
     * @return SrsAllStreamInfoQuery命令对象。
     */
    public SrsAllStreamInfoQuery setSrsApiIp(String srsApiIp) {
        this.initParams.setSrsApiIp(srsApiIp);
        return this;
    }

    /**
     * 设置srs的api交互端口。默认从配置文件中获取。
     * @param srsApiPort srs的api交互端口。
     * @return SrsAllStreamInfoQuery命令对象。
     */
    public SrsAllStreamInfoQuery setSrsApiPort(Integer srsApiPort) {
        this.initParams.setSrsApiPort(srsApiPort);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "SrsAllStreamInfoQuery", null, data.populateDefault().validate(), CommonDefaultTaskStartEvent::new);
    }

    @Override
    public String await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject rlt = (JsonObject) result.getResult();
                JsonArray data = rlt.getJsonArray("data");
                return data.stringify();
            }
            return "[]";
        }, time);
    }
    
}

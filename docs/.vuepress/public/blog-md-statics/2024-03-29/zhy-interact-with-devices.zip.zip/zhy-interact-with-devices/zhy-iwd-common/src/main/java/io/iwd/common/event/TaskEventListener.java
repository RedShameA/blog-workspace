package io.iwd.common.event;

/**
 * 任务事件监听器。
 */
public interface TaskEventListener extends EventListener {

    /**
     * 获取默认的任务前缀。
     * @return 监听器默认的任务前缀。
     */
    String defaultTaskPrefix();

}

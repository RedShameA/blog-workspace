package io.iwd.common.ext.util;

public class SpscDiscardQueue<T> extends SpscQueue<T> {

    public SpscDiscardQueue(int size) {
        super(size);
    }

    @Override
    public void put(T e) {
        if (e == null) {
            throw new NullPointerException();
        }

        Object[] buf = super.buffer;
        int i = super.in;
        int o = super.out;
        int used = ((i < o ? 0x10000 : 0) | i) - o;
        if (buf.length <= used) {
            return; //没有空间直接丢弃
        }
        int target = i & (buf.length - 1);
        if (buf[target] != null) {
            throw new IllegalStateException("element is not consumed");
        }
        buf[target] = e;
        super.in = (i + 1) & MAX_UNSIGNED_INT_16;
    }

    @SuppressWarnings("unchecked")
    @Override
    public T get() {
        int i = super.in, o = super.out;
        if (i == o) {
            return null;
        }
        Object[] buf = super.buffer;
        int target = o & (buf.length - 1);
        Object e = buf[target];
        buf[target] = null;
        super.out = (o + 1) & MAX_UNSIGNED_INT_16;
        return (T) e;
    }
}

package io.iwd.common.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.Validator;

public class SrsAllStreamInfoQueryInitParams implements TaskInitParams {

    private Boolean srsApiSsl;

    private String srsApiIp;

    private Integer srsApiPort;

    public Boolean getSrsApiSsl() {
        return srsApiSsl;
    }

    public void setSrsApiSsl(Boolean srsApiSsl) {
        this.srsApiSsl = srsApiSsl;
    }

    public String getSrsApiIp() {
        return this.srsApiIp;
    }

    public void setSrsApiIp(String srsApiIp) {
        this.srsApiIp = srsApiIp;
    }

    public Integer getSrsApiPort() {
        return this.srsApiPort;
    }

    public void setSrsApiPort(Integer srsApiPort) {
        this.srsApiPort = srsApiPort;
    }

    @Override
    public SrsAllStreamInfoQueryInitParams populateDefault() {
        EnvironmentHolder.get().config().getInBatch(conf -> {
            if (this.srsApiSsl == null) {
                this.srsApiSsl = (Boolean) conf.getGlobalConfigInBatch("srs", "api_ssl");
            }
            if (this.srsApiIp == null) {
                this.srsApiIp = (String) conf.getGlobalConfigInBatch("srs", "api_ip");
            }
            if (this.srsApiPort == null) {
                this.srsApiPort = NumberUtil.toInt(conf.getGlobalConfigInBatch("srs", "api_port"));
            }
        });

        return this;
    }

    @Override
    public SrsAllStreamInfoQueryInitParams validate() {
        if (this.srsApiSsl == null) {
            throw new IllegalArgumentException("common srs api ssl error");
        }
        if (!Validator.isIpv4(this.srsApiIp)) {
            throw new IllegalArgumentException("common srs api ip format error");
        }
        if (this.srsApiPort == null || this.srsApiPort < 1 || srsApiPort > 65535) {
            throw new IllegalArgumentException("common srs api port format error");
        }
        return this;
    }

}

package io.iwd.common.event.ipm;

import io.iwd.common.entity.AlarmPictureInfo;
import io.iwd.common.event.Event;

public class AlarmPictureReceivedEvent implements Event {

    private final AlarmPictureInfo alarmPictureInfo;

    public AlarmPictureReceivedEvent(AlarmPictureInfo alarmPictureInfo) {
        this.alarmPictureInfo = alarmPictureInfo;
    }
}

package io.iwd.common.stdio.http;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标注一个类为http请求处理器，指定其处理的请求路径和允许的请求方法。
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface HttpRequestHandler {

    String path();

    String[] method() default {"POST"};

}

package io.iwd.common.stdio.http;

import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.log.Logger;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.CharsetUtil;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Map;

/**
 * http请求处理器公共抽象基类。
 * @param <T> 请求体类型。
 */
public abstract class AbstractHttpRequestHandler<T> {

    /**
     * 允许的http method。
     */
    protected final String[] method;

    /**
     * 请求路径。
     */
    protected final String path;

    /**
     * 请求体类型。
     */
    protected final Class<?> bodyType;

    /**
     * 标准构造器。构造时确定请求体的类型。
     */
    protected AbstractHttpRequestHandler() {
        //获取子类上的注解信息
        HttpRequestHandler handlerInfo = getClass().getDeclaredAnnotation(HttpRequestHandler.class);
        this.method = handlerInfo.method();
        this.path = handlerInfo.path();
        this.bodyType = findBodyType();
    }

    public String path() {
        return this.path;
    }

    protected String[] method() {
        return this.method;
    }

    protected Class<?> findBodyType() {
        //查找子类处理器接受的body类型
        Class<?> bodyType;
        //分析泛型基类
        //TODO 当前写法只能找取直接继承的子类的泛型参数 应支持找取间接继承的子类的泛型参数
        Class<?> genericBase = getClass();
        //找到继承AbstractHttpRequestHandler的类
        while (true) {
            Class<?> sc = genericBase.getSuperclass();
            if (sc.equals(AbstractHttpRequestHandler.class)) {
                break;
            }
            genericBase = sc;
        }
        Type genericSuperclass = genericBase.getGenericSuperclass();

        if (! (genericSuperclass instanceof ParameterizedType)) {
            //如果不是ParameterizedType，那么bodyType一定是Object
            bodyType = Object.class;
        }
        else {
            ParameterizedType genericClass = (ParameterizedType) genericSuperclass;
            Type[] actualTypeArguments = genericClass.getActualTypeArguments();
            Type t = actualTypeArguments[0];
            if (t instanceof  ParameterizedType) { //如果类型参数还是泛型，取其原始类型即可
                ParameterizedType pt = (ParameterizedType) t;
                bodyType = (Class<?>) pt.getRawType();
            }
            else {
                bodyType = (Class<?>) t;
            }
        }
        return bodyType;
    }

    /**
     * 在请求实际被处理前进行一些准备工作。
     */
    @SuppressWarnings("unchecked")
    protected void handle(ChannelHandlerContext waitingResponseContext,
                                   String path,
                                   String method,
                                   Map<String, String> queryString,
                                   Map<String, String> headers,
                                   ByteBuf byteBuf) throws Exception {

        Object bodyObject;

        if (byteBuf == null) {
            bodyObject = null;
        }
        else if (ByteBuf.class.equals(this.bodyType) || Object.class.equals(this.bodyType)) {
            bodyObject = byteBuf;
        }
        else if (byte[].class.equals(this.bodyType)) {
            byte[] bytes = new byte[byteBuf.readableBytes()];
            byteBuf.readBytes(bytes);
            bodyObject = bytes;
        }
        else {
            String stringContent = byteBuf.toString(CharsetUtil.UTF_8);
            if (String.class.equals(this.bodyType)) {
                bodyObject = stringContent;
            }
            else if (JsonObject.class.equals(this.bodyType)) {
                bodyObject = JsonObject.from(stringContent);
            }
            else if (JsonArray.class.equals(this.bodyType)) {
                bodyObject = JsonArray.from(stringContent);
            }
            else if (Integer.class.equals(this.bodyType)) {
                bodyObject = Integer.parseInt(stringContent);
            }
            else if (Boolean.class.equals(this.bodyType)) {
                bodyObject = Boolean.parseBoolean(stringContent);
            }
            //TODO 解析其他包装类型
            else {
                //TODO 将body解析为实体类对象
                bodyObject = null;
            }
        }

        StringBuilder requestInfo = new StringBuilder();
        requestInfo.append("received ").append(method).append(' ').append(path);
        if (queryString.size() != 0) {
            requestInfo.append('?');
            for (Map.Entry<String, String> entry : queryString.entrySet()) {
                requestInfo.append(entry.getKey()).append('=').append(entry.getValue()).append('&');
            }
            requestInfo.deleteCharAt(requestInfo.length() - 1);
        }
        if (bodyObject != null) {
            requestInfo.append(' ');
            requestInfo.append(bodyObject.toString());
        }
        Logger.info(requestInfo.toString());

        handle0(waitingResponseContext, path, method, queryString, headers, (T) bodyObject);
    }

    /**
     * 子类需要实现以实际处理请求。
     * @param waitingResponseContext 等待响应的{@link ChannelHandlerContext}。
     * @param path 请求路径。
     * @param method http method。
     * @param queryString uri中的查询字符串。
     * @param headers 请求头集合。
     * @param body 请求体。
     * @throws Exception 异常。
     */
    protected abstract void handle0(ChannelHandlerContext waitingResponseContext,
                                    String path,
                                    String method,
                                    Map<String, String> queryString,
                                    Map<String, String> headers,
                                    T body) throws Exception;

    @Override
    public boolean equals(Object another) {
        if (another == this) {
            return true;
        }
        return this.getClass().equals(another.getClass());
    }

    @Override
    public int hashCode() {
        return this.getClass().getName().hashCode();
    }

}

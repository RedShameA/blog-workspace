package io.iwd.common.event.srs;

import io.iwd.common.event.TaskProceedEvent;

/**
 * srs通知rtsp拉流准备就绪的事件。
 */
public class SrsRtspReadyEvent extends TaskProceedEvent {

    public SrsRtspReadyEvent(String taskId) {
        super(taskId, null);
    }

}

package io.iwd.common.stdio.redis;

import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.util.StringUtil;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.redis.*;
import io.netty.util.ReferenceCountUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * redis连接处理器，用于建立连接、完成认证。
 */
public abstract class RedisConnectHandler extends ChannelDuplexHandler {

    public static final int STATE_UNCONNECTED = 1;
    public static final int STATE_AUTH = 2;
    public static final int STATE_PING = 3;
    public static final int STATE_CONNECTED = 4;

    /**
     * 此handler关联的redis客户端组件。
     */
    protected final RedisClient redisClient;

    /**
     * redis认证密码 AUTH password
     */
    protected final String password;

    /**
     * redis连接建立的状态。
     * 1)Unconnected
     * 2)Auth
     * 3)Ping
     * 4)Connected
     */
    private int state;

    public RedisConnectHandler(RedisClient redisClient) {
        this(redisClient, null);
    }

    public RedisConnectHandler(RedisClient redisClient, String password) {
        this.redisClient = redisClient;
        this.password = password;
        this.state = STATE_UNCONNECTED;
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        if (StringUtil.isEmpty(this.password)) {
            this.state = STATE_PING;
            ctx.writeAndFlush(createPingCommand());
        } else {
            this.state = STATE_AUTH;
            //设置了密码 需要发送AUTH命令
            ctx.writeAndFlush(createAuthCommand(this.password));
        }
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {

        if (this.state == STATE_CONNECTED) {
            //如果连接已建立 就不再处理channelRead
            channelReadInternal(ctx, msg);
            return;
        }
        if (this.state == STATE_UNCONNECTED) {
            //未建立连接时收到消息？如果有这种情况，只能不处理
            ReferenceCountUtil.release(msg);
            return;
        }

        try {
            //连接未建立 一般是收到AUTH的响应或PING的响应
            if (msg instanceof SimpleStringRedisMessage) {
                String content = ((SimpleStringRedisMessage) msg).content();

                if (this.state == STATE_AUTH) {
                    if ("OK".equalsIgnoreCase(content)) {
                        //AUTH响应OK 发送PING
                        this.state = STATE_PING;
                        ctx.writeAndFlush(createPingCommand());
                    } else {
                        Logger.warn("state: AUTH,received unexpected redis response: " + content);
                    }
                } else if (this.state == STATE_PING) {
                    if ("PONG".equalsIgnoreCase(content)) {
                        //PING响应PONG 连接建立完成
                        this.state = STATE_CONNECTED;
                        channelActiveInternal(ctx);
                    } else {
                        Logger.warn("state: PING,received unexpected redis response: " + content);
                    }
                }

            } else if (msg instanceof ErrorRedisMessage) {
                String content = ((ErrorRedisMessage) msg).content();

                Logger.error("redis connect failed: " + content);

                ctx.close();
            } else {

                Logger.warn("unexpected redis response type: " + msg.getClass().getSimpleName());
            }
        } finally {
            //这里处理了消息，子类就不需要处理了，释放即可
            ReferenceCountUtil.release(msg);
        }
    }

    /**
     * 子类实现，用来执行redis连接建立后的操作。
     * @param ctx ChannelHandlerContext。
     * @throws Exception 异常。
     */
    protected void channelActiveInternal(ChannelHandlerContext ctx) throws Exception {
    }

    /**
     * 子类实现，用来执行redis建立连接后，接收到数据时的操作。
     * @param ctx ChannelHandlerContext。
     * @param msg 收到的数据。
     * @throws Exception 异常。
     */
    protected void channelReadInternal(ChannelHandlerContext ctx, Object msg) throws Exception {
    }

    /**
     * 生成AUTH命令字符串。
     * @param password 密码。
     * @return AUTH命令字符串。
     */
    private RedisMessage createAuthCommand(String password) {
        List<RedisMessage> messages = new ArrayList<>(2);
        messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(PooledByteBufAllocator.DEFAULT, "AUTH")));
        messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(PooledByteBufAllocator.DEFAULT, password)));
        return new ArrayRedisMessage(messages);
    }

    private RedisMessage createPingCommand() {
        return new InlineCommandRedisMessage("PING");
    }

}

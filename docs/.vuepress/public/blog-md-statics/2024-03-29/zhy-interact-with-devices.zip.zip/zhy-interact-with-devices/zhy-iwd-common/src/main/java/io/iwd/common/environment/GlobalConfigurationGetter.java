package io.iwd.common.environment;

public interface GlobalConfigurationGetter {

    Object getConfigInBatch(Object... key);

    Object getGlobalConfigInBatch(Object... key);

    Object getExtConfigInBatch(String extName, Object... key);
}

package io.iwd.common.entity;

public class ServiceVersionInfo {

    private final String serviceName;

    private final String serviceVersion;

    public ServiceVersionInfo(String serviceName, String serviceVersion) {
        this.serviceName = serviceName;
        this.serviceVersion = serviceVersion;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getServiceVersion() {
        return serviceVersion;
    }

    @Override
    public String toString() {
        return "{\"name\":\"" + this.serviceName + "\",\"version\":\"" + this.serviceVersion + "\"}";
    }
}

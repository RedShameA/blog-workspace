package io.iwd.common.stdio.redis;

import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * redis频道消息处理器注册中心。
 */
public class RedisChannelMessageHandlerRegistry {

    /**
     * 注册表。
     */
    private final Map<String, Set<RedisChannelMessageHandler>> handlersMap;

    /**
     * 标准构造器
     */
    public RedisChannelMessageHandlerRegistry(Map<String, Set<RedisChannelMessageHandler>> handlersMap) {
        this.handlersMap = new HashMap<>(32, 0.25f);
        for (Map.Entry<String, Set<RedisChannelMessageHandler>> entry : handlersMap.entrySet()) {
            Set<RedisChannelMessageHandler> s = new LinkedHashSet<>(32, 0.25f);
            s.addAll(entry.getValue());
            this.handlersMap.put(entry.getKey(), s);
        }
    }

    /**
     * 获取某个频道对应的所有处理器。
     * @param channel 频道名称。
     * @return 处理器列表，
     */
    public Set<RedisChannelMessageHandler> findHandlers(String channel) {
        return this.handlersMap.get(channel);
    }

}

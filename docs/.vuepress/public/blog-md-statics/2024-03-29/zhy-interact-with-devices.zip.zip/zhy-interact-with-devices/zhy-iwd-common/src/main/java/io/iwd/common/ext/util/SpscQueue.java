package io.iwd.common.ext.util;

public abstract class SpscQueue<T> {

    protected static final int MAX_CAPACITY = 0X8000;

    protected static final int MAX_UNSIGNED_INT_16 = 0xffff;

    protected final Object[] buffer;

    //此抽象类使用volatile保证可见性，不继承此类的SpscQueue可以使用Unsafe的fence提高性能

    protected volatile int in;

    protected volatile int out;

    public SpscQueue(int size) {
        this.buffer = new Object[roundupPowerOfTwo(size)];
        this.in = 0;
        this.out = 0;
    }

    public abstract void put(T e);

    public abstract T get();

    protected int roundupPowerOfTwo(int size) {
        if (size > MAX_CAPACITY) {
            return MAX_CAPACITY;
        }
        if ((size & (size - 1)) != 0) {
            int s = 1;
            while (s < size) {
                s <<= 1;
            }
            size = s;
        }
        return size;
    }

}

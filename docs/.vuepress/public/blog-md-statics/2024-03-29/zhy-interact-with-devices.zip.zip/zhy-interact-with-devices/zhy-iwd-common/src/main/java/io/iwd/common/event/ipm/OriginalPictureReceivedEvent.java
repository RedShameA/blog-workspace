package io.iwd.common.event.ipm;

import io.iwd.common.entity.OriginalPictureInfo;
import io.iwd.common.event.Event;

public class OriginalPictureReceivedEvent implements Event {

    private final OriginalPictureInfo originalPictureInfo;

    public OriginalPictureReceivedEvent(OriginalPictureInfo originalPictureInfo) {
        this.originalPictureInfo = originalPictureInfo;
    }
}

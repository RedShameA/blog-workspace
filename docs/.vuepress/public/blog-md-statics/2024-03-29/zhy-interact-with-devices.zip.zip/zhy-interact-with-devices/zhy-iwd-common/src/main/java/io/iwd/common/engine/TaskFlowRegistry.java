package io.iwd.common.engine;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 任务流程注册中心，用于存储、获取TaskFlow。
 */
public class TaskFlowRegistry {

    /**
     * 已注册的任务流程及其名称。
     */
    private final Map<String, Map<String, TaskFlow>> taskFlowMap;

    /**
     * 标准构构造器。
     */
    public TaskFlowRegistry(Map<String, Map<String, TaskFlow>> taskFlowMap) {
        this.taskFlowMap = new HashMap<>(32, 0.25f);
        for (Map.Entry<String, Map<String, TaskFlow>> entry : taskFlowMap.entrySet()) {
            Map<String, TaskFlow> m = new HashMap<>(32, 0.25f);
            m.putAll(entry.getValue());
            this.taskFlowMap.put(entry.getKey(), m);
        }
    }

    /**
     * 查找已注册的任务流程。
     * @param name 任务流程的名称。
     * @return 任务流程。
     */
    public TaskFlow getTaskFlow(String prefix, String name) {
        Map<String, TaskFlow> taskFlowNameMap = this.taskFlowMap.get(prefix);
        if (taskFlowNameMap == null) {
            return null;
        }
        return taskFlowNameMap.get(name);
    }
}

package io.iwd.common.ext.util;

import java.util.List;
import java.util.Map;

public final class StringUtil {

    private StringUtil() {}

    private static final String NULL = "null";

    public static boolean isEmpty(String str) {
        return null == str || "".equals(str.trim());
    }

    public static boolean notEmpty(String str) {
        return !isEmpty(str);
    }

    public static String toString(Object object) {
        if (object == null) {
            return NULL;
        }
        if (object instanceof Map) {
            Map<?, ?> map = (Map<?, ?>) object;
            StringBuilder builder = new StringBuilder();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                builder.append('<');
                builder.append(toString(entry.getKey()));
                builder.append(',');
                builder.append(toString(entry.getValue()));
                builder.append('>');
            }
            return builder.toString();
        }
        if (object instanceof List) {
            List<?> list = (List<?>) object;
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < list.size(); i++) {
                builder.append('(');
                builder.append(i);
                builder.append(':');
                builder.append(toString(list.get(i)));
                builder.append(')');
            }
            return builder.toString();
        }
        return object.toString();
    }

    public static String escapeDoubleQuotes(String raw, int level) {
        StringBuilder replacement = new StringBuilder();
        for (int i = 0; i < level; i++) {
            replacement.append("\\\\");
        }
        replacement.append("\"");
        return raw.replaceAll("\"", replacement.toString());
    }

}

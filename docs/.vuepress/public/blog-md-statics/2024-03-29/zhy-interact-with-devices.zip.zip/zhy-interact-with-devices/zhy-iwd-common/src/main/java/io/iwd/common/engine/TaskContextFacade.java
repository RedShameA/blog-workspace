package io.iwd.common.engine;

import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;

/**
 * 任务上下文外观，提供了允许在{@link Task#execute(TaskContextFacade)}方法中调用的接口。
 */
public interface TaskContextFacade {

    /**
     * 最大等待执行时间，毫秒。
     */
    long MAX_AWAIT_MILLIS = 3_600_000L;

    /**
     * 最大延迟执行时间，毫秒。
     */
    long MAX_DELAY_MILLIS = 3_600_000L * 24;

    /**
     * 获取与此Context关联的任务id。
     * @return 任务id。
     */
    String getTaskId();

    /**
     * 存放一项数据。
     * @param key 键。
     * @param value 值。
     */
    void putData(String key, Object value);

    /**
     * 获取一项存放的数据。
     * @param key 键。
     * @return 值。
     */
    Object getData(String key);

    /**
     * 删除一项存放的数据。
     * @param key 键。
     */
    void deleteData(String key);

    /**
     * 设置下一个任务节点。
     * @param nodeName 任务节点名称。
     */
    void setNext(String nodeName);

    /**
     * 设置任务上下文的时间戳。
     * @param timestamp 时间戳。
     */
    void setTimestamp(long timestamp);

    /**
     * 设置超时信息，任务超时后会将此信息置入{@link TaskResult}。
     * @param message 超时信息。
     */
    void setTimeoutMessage(Object message);

    /**
     * 设置完成信息，任务完成后会将此信息置入{@link TaskResult}。
     * @param completedMessage 超时信息。
     */
    void setCompletedMessage(Object completedMessage);

    /**
     * 设置失败信息，任务失败后会将此信息置入{@link TaskResult}。
     * @param failedMessage 失败信息。
     */
    void setFailedMessage(Object failedMessage);

    /**
     * 获取任务节点的输入数据。此方法通常只在任务开始的节点或者其他系统数据传入的节点调用。
     * @return 输入数据。
     */
    Object getInput();

    /**
     * 获取已执行的任务节点数。
     * @return 已执行的任务节点数。
     */
    int getExecutedTaskCount();

    /**
     * 将任务上下文状态设置为继续执行。
     */
    void jump();

    /**
     * 将任务上下文状态设置为延迟执行。
     */
    void delay();

    /**
     * 将任务上下文状态设置为等待执行。
     */
    void await();

    /**
     * 将任务上下文状态设置为完成。
     */
    void complete();

    /**
     * 将任务上下文状态设置为失败。
     */
    void fail();

    /**
     * 继续执行下一个任务节点。
     * @param next 下一个任务节点的名称。
     */
    default void fireNext(String next) {
        this.setNext(next);
        this.jump();
    }

    /**
     * 延迟执行下一个任务节点。
     * @param next 下一个任务节点的名称。
     * @param delayTime 延迟时间，毫秒。
     */
    default void delayNext(String next, long delayTime) {
        if (delayTime < 0) {
            delayTime = 0;
        } else if (delayTime > MAX_DELAY_MILLIS) {
            delayTime = MAX_DELAY_MILLIS;
        }
        this.setNext(next);
        this.setTimestamp(-(System.currentTimeMillis() + delayTime));
        this.delay();
    }

    /**
     * 等待执行下一个任务节点。
     * @param next 下一个任务节点的名称。
     */
    default void awaitNext(String next) {
        String timeoutMessage = "await " + next + " timeout";
        awaitNext(next, EnvironmentHolder.get().taskDefaultAwaitTime(), timeoutMessage);
    }

    /**
     * 等待执行下一个任务节点，并指定最大等待时间。
     * @param next 下一个任务节点的名称。
     * @param awaitTime 最大等待时间，毫秒，超过此时间后可能会被视为超时。
     */
    default void awaitNext(String next,
                           long awaitTime) {
        String timeoutMessage = "await " + next + " timeout";
        awaitNext(next, awaitTime, timeoutMessage);
    }

    /**
     * 等待执行下一个任务节点，并设置超时信息。
     * @param next 下一个任务节点的名称。
     * @param timeoutMessage 超时信息。
     */
    default void awaitNext(String next,
                           String timeoutMessage) {
        awaitNext(next, EnvironmentHolder.get().taskDefaultAwaitTime(), timeoutMessage);
    }

    /**
     * 等待执行下一个任务节点，并设置超时信息。
     * @param next 下一个任务节点的名称。
     * @param timeoutMessage 超时信息。
     */
    default void awaitNext(String next,
                           Object timeoutMessage) {
        awaitNext(next, EnvironmentHolder.get().taskDefaultAwaitTime(), timeoutMessage);
    }

    /**
     * 等待执行下一个任务节点，指定最大等待时间，设置超时信息。
     * @param next 下一个任务节点的名称。
     * @param awaitTime 最大等待时间，毫秒，超过此时间后可能会被视为超时。
     * @param timeoutMessage 超时信息。
     */
    default void awaitNext(String next,
                           long awaitTime,
                           String timeoutMessage) {
        if (awaitTime < 0) {
            awaitTime = 0;
        } else if (awaitTime > MAX_AWAIT_MILLIS) {
            awaitTime = MAX_AWAIT_MILLIS;
        }
        JsonObject messageObject = new CodeMessageJsonObject(
                Code.TIMEOUT_AND_FAILED | getExecutedTaskCount() & 0xffff,
                timeoutMessage);
        this.setNext(next);
        this.setTimestamp(System.currentTimeMillis() + awaitTime);
        this.setTimeoutMessage(messageObject);
        this.await();
    }

    /**
     * 等待执行下一个任务节点，指定最大等待时间，设置超时信息。
     * @param next 下一个任务节点的名称。
     * @param awaitTime 最大等待时间，毫秒，超过此时间后可能会被视为超时。
     * @param timeoutMessage 超时信息。
     */
    default void awaitNext(String next,
                           long awaitTime,
                           Object timeoutMessage) {
        if (awaitTime < 0) {
            awaitTime = 0;
        } else if (awaitTime > MAX_AWAIT_MILLIS) {
            awaitTime = MAX_AWAIT_MILLIS;
        }
        this.setNext(next);
        this.setTimestamp(System.currentTimeMillis() + awaitTime);
        this.setTimeoutMessage(timeoutMessage);
        this.await();
    }

    /**
     * 将任务上下文状态设置为完成，并设置完成信息。
     * @param message 完成信息。
     */
    default void complete(Object message) {
        this.setCompletedMessage(message);
        this.complete();
    }

    /**
     * 将任务上下文状态设置为失败，并设置失败信息。
     * @param message 失败信息。
     */
    default void fail(Object message) {
        this.setFailedMessage(message);
        this.fail();
    }
}

package io.iwd.common.event;

import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 事件派发器。
 */
public class EventMulticaster {

    /**
     * 事件监听器注册表。
     */
    private final Map<Class<? extends Event>, List<EventListener>> listenerMap;

    /**
     * 标准构造器
     */
    public EventMulticaster(Map<Class<? extends Event>, List<EventListener>> listeners) {
        this.listenerMap = new HashMap<>(32, 0.25f);
        this.listenerMap.putAll(listeners);
    }

    /**
     * 发布一个事件。即通知所有已注册的对应事件监听器处理这个事件。
     * @param e 事件。
     */
    public void publishEvent(Event e) {
        List<EventListener> listeners = this.listenerMap.get(e.getClass());
        if (listeners != null) {
            for (EventListener listener : listeners) {
                listener.handleEvent(e);
            }
        }
    }

}

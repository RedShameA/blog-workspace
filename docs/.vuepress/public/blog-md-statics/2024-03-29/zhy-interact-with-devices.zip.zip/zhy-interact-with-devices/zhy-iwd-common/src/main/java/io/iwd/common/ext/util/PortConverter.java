package io.iwd.common.ext.util;

@FunctionalInterface
public interface PortConverter {
    
    Integer applyRawPort(Integer port);

}

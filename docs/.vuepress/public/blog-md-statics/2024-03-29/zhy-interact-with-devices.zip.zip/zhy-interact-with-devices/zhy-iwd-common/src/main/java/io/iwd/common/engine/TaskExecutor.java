package io.iwd.common.engine;

/**
 * 任务执行器接口。
 */
public interface TaskExecutor {

    /**
     * 返回执行器当前正在执行的任务上下文。
     * @return 执行器当前正在执行的任务上下文。
     */
    TaskContext getContext();

}

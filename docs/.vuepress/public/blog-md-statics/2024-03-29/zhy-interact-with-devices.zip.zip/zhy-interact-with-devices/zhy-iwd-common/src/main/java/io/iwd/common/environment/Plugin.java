package io.iwd.common.environment;

import java.util.Map;

public abstract class Plugin<T> implements ManagerLifecycle {

    protected String name;

    protected T internal;

    protected Map<String, Object> configParams;

    public String name() {
        return this.name;
    }

    public T internal() {
        return this.internal;
    }

    public void setConfigParams(Map<String, Object> configParams) {
        this.configParams = configParams;
    }

    public abstract void init();

    @Override
    public void active() {
        if (this.internal instanceof ManagerLifecycle) {
            ((ManagerLifecycle) this.internal).active();
        }
    }

    @Override
    public void destroy() {
        if (this.internal instanceof ManagerLifecycle) {
            ((ManagerLifecycle) this.internal).destroy();
        }
    }
}

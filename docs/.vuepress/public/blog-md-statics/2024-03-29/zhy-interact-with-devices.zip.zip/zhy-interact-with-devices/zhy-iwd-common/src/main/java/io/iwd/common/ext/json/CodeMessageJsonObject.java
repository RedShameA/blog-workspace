package io.iwd.common.ext.json;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * 只包含code和message的{@link JsonObject}实现。
 */
public class CodeMessageJsonObject implements JsonObject {

    private final int code;

    private final String message;

    public CodeMessageJsonObject(int code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public JsonObject copy() {
        return new CodeMessageJsonObject(this.code, this.message);
    }

    @Override
    public JsonObject freeze() {
        return this;
    }

    @Override
    public JsonObject share() {
        return this;
    }

    @Override
    public Object get(String key) {
        switch (key) {
            case "code":
                return this.code;
            case "message":
                return this.message;
        }
        return null;
    }

    @Override
    public JsonEntity getJsonEntity(String key) {
        return null;
    }

    @Override
    public JsonObject getJsonObject(String key) {
        return null;
    }

    @Override
    public JsonArray getJsonArray(String key) {
        return null;
    }

    @Override
    public JsonString getJsonString(String key) {
        return null;
    }

    @Override
    public JsonNumber getJsonNumber(String key) {
        return null;
    }

    @Override
    public JsonBoolean getJsonBoolean(String key) {
        return null;
    }

    @Override
    public Boolean getBoolean(String key) {
        return null;
    }

    @Override
    public String getString(String key) {
        if ("message".equals(key)) {
            return this.message;
        }
        return null;
    }

    @Override
    public Number getNumber(String key) {
        if ("code".equals(key)) {
            return this.code;
        }
        return null;
    }

    @Override
    public Long getLong(String key) {
        if ("code".equals(key)) {
            return (long) this.code;
        }
        return null;
    }

    @Override
    public Integer getInteger(String key) {
        if ("code".equals(key)) {
            return this.code;
        }
        return null;
    }

    @Override
    public Double getDouble(String key) {
        return null;
    }

    @Override
    public Float getFloat(String key) {
        return null;
    }

    @Override
    public JsonObject put(String key, Object value) {
        return this;
    }

    @Override
    public JsonObject put(String key, JsonEntity value) {
        return this;
    }

    @Override
    public JsonObject put(String key, Boolean value) {
        return this;
    }

    @Override
    public JsonObject put(String key, Number value) {
        return this;
    }

    @Override
    public JsonObject put(String key, String value) {
        return this;
    }

    @Override
    public JsonObject remove(String key) {
        return this;
    }

    @Override
    public JsonEntity take(String key) {
        return this;
    }

    @Override
    public JsonObject clear() {
        return this;
    }

    @Override
    public int size() {
        return 2;
    }

    @Override
    public boolean isImmutable() {
        return true;
    }

    @Override
    public String stringify() {
        return "{\"code\":" + this.code + ",\"message\":\"" + this.message + "\"}";
    }

    @Override
    public Map<String, Object> simplify() {
        Map<String, Object> map = new LinkedHashMap<>(4);
        map.put("code", this.code);
        map.put("message", this.message);
        return map;
    }

    @Override
    public Set<String> keySet() {
        HashSet<String> set = new HashSet<>(4);
        set.add("code");
        set.add("message");
        return set;
    }

    @Override
    public String toString() {
        return this.stringify();
    }
}

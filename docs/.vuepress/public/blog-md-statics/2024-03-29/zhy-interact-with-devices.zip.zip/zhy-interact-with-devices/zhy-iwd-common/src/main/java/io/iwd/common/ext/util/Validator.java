package io.iwd.common.ext.util;

public final class Validator {

    public static boolean isIpv4(String input) {
        if (input == null || input.length() < 7 || input.length() > 15) {
            return false;
        }
        String[] nums = input.split("\\.");
        if (nums.length != 4) {
            return false;
        }
        for (String n : nums) {
            if (n.length() == 0 || n.length() > 3) {
                return false;
            }
            for (int i = 0; i < n.length(); i++) {
                char c = n.charAt(i);
                if (c < '0' || c > '9') {
                    return false;
                }
            }
            if (n.length() > 1 && n.charAt(0) == '0') {
                return false;
            }
            int i = Integer.parseInt(n);
            if (i > 255) {
                return false;
            }
        }
        return true;
    }

    public static boolean isIpv4AndPort(String input) {
        if (StringUtil.isEmpty(input) || input.length() < 9) {
            return false;
        }
        int idx = input.indexOf(':');
        if (idx == -1 || idx == input.length() - 1 || idx < 7) {
            return false;
        }
        String ip = input.substring(0, idx);
        String port = input.substring(idx + 1);
        if (!isIpv4(ip)) {
            return false;
        }
        if (port.length() > 5 || !isPositiveIntegerNumber(port) || Integer.parseInt(port) > 65535) {
            return false;
        }
        return true;
    }

    public static boolean isPositiveIntegerNumber(String str) {
        if (StringUtil.isEmpty(str)) {
            return false;
        }
        if (str.charAt(0) == '0') {
            return false;
        }
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c < '0' || c > '9') {
                return false;
            }
        }
        return true;
    }

}

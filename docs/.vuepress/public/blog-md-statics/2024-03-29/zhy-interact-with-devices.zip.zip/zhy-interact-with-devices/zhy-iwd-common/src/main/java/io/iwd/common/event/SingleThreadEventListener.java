package io.iwd.common.event;

import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.util.MpscConsumerBlockingQueue;

import java.util.function.BiConsumer;

public abstract class SingleThreadEventListener implements EventListener {

    protected MpscConsumerBlockingQueue<Event> queue;

    protected Thread worker;

    public SingleThreadEventListener() {
        this(64, 256, (event, name) -> Logger.warn(name + " event queue full, discard " + event));
    }

    public SingleThreadEventListener(int chunkSize, int queueSize, final BiConsumer<Event, String> onQueueFullHandler) {
        final String ListenerName = this.getClass().getSimpleName();
        this.worker = new Thread(() -> {
            while (true) {
                Event event = this.queue.get();
                handleEvent0(event);
            }
        }, ListenerName);
        this.queue = new MpscConsumerBlockingQueue<Event>(this.worker, chunkSize, queueSize) {
            @Override
            protected void onQueueFull(Event event) {
                onQueueFullHandler.accept(event, ListenerName);
            }
        };

        this.worker.start();
    }

    @Override
    public final void handleEvent(Event event) {
        this.queue.put(event);
    }

    public abstract void handleEvent0(Event event);
}

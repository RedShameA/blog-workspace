package io.iwd.common.entity;

import io.iwd.common.ext.json.JsonObject;

public class OriginalPictureInfo extends PictureInfo {

    public OriginalPictureInfo(JsonObject info) {
        super(info);
    }

    @Override
    protected void parse(JsonObject info) {

    }
}

package io.iwd.common.stdio.redis;

import io.iwd.common.engine.TaskContext;
import io.iwd.common.engine.TaskExecutor;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.event.TaskProceedEvent;
import io.netty.buffer.ByteBufAllocator;
import io.netty.handler.codec.redis.RedisMessage;

import java.util.function.BiFunction;

public class RedisCommandWrapper {

    protected final boolean silent;

    protected final RedisCommand redisCommand;

    protected final String[] params;

    protected String taskId;

    protected BiFunction<String, Object, TaskProceedEvent> eventConstructor;

    RedisCommandWrapper(boolean silent, RedisCommand redisCommand, String[] params) {
        this.silent = silent;
        this.redisCommand = redisCommand;
        this.params = params;
    }

    boolean isSilent() {
        return this.silent;
    }

    /**
     * 获取redis命令。
     * @return redis命令。
     */
    String commandName() {
        if (this.redisCommand == null) {
            return null;
        }
        return this.redisCommand.name();
    }

    /**
     * 获取命令参数。
     * @return 命令参数。
     */
    String[] params() {
        return this.params;
    }

    String taskId() {
        return this.taskId;
    }

    BiFunction<String, Object, TaskProceedEvent> eventConstructor() {
        return this.eventConstructor;
    }

    /**
     * 获取命令响应处理器。
     * @return 命令响应处理器。
     */
    Object handleResponse(RedisMessage response) {
        return this.redisCommand.handleResponse(response);
    }

    /**
     * 生成{@code RedisMessage}。
     * @param allocator ByteBufAllocator。
     * @return RedisMessage。
     */
    RedisMessage toRedisMessage(ByteBufAllocator allocator) {
        return this.redisCommand.toRedisMessage(this.params, allocator);
    }

    public RedisCommandWrapper forTask(String taskId) {
        this.taskId = taskId;
        return this;
    }

    public RedisCommandWrapper onResponse(BiFunction<String, Object, TaskProceedEvent> eventConstructor) {
        this.eventConstructor = eventConstructor;
        return this;
    }

    public String fullCommandString() {
        StringBuilder builder = new StringBuilder();
        builder.append(this.redisCommand.name());
        for (String p : this.params) {
            builder.append(' ').append(p);
        }
        return builder.toString();
    }

    public void submit() {
        if (!this.silent) {
            Thread current = Thread.currentThread();
            if (current instanceof TaskExecutor) {
                TaskExecutor taskExecutor = (TaskExecutor) current;
                TaskContext context = taskExecutor.getContext();
                if (this.taskId == null) {
                    this.taskId = context.getTaskId();
                }
                if (this.eventConstructor == null) {
                    this.eventConstructor = context.getDefaultTaskProceedEventConstructor();
                }
            }
        }
        EnvironmentHolder.get().redisAccessor().execute(this);
    }

}

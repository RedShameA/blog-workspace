package io.iwd.common.stdio.http;

import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.environment.ManagerLifecycle;
import io.iwd.common.ext.misc.NettyComponentThreadFactory;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.epoll.Epoll;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;

/**
 * http请求发送器。
 */
public class HttpSender implements ManagerLifecycle {

    private final int threadCount;

    private EventLoopGroup eventLoopGroup;

    public HttpSender(int threadCount) {
        if (threadCount <= 0 || threadCount > 128) {
            throw new IllegalArgumentException("threadCount must > 0 && <= 128");
        }
        this.threadCount = threadCount;
    }

    protected EventLoopGroup getEventLoopGroup() {
        return this.eventLoopGroup;
    }

    @Override
    public void active() {
        this.eventLoopGroup = EnvironmentHolder.get().isEpollAvailable() ?
                new EpollEventLoopGroup(this.threadCount, new NettyComponentThreadFactory(getClass())) :
                new NioEventLoopGroup(this.threadCount, new NettyComponentThreadFactory(getClass()));
    }

    @Override
    public void destroy() {
        if (this.eventLoopGroup != null) {
            this.eventLoopGroup.shutdownGracefully().awaitUninterruptibly();
            this.eventLoopGroup = null;
        }
    }
}

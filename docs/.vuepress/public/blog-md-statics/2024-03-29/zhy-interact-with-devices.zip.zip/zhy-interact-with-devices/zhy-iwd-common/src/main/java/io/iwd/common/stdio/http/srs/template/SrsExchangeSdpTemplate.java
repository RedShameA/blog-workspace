package io.iwd.common.stdio.http.srs.template;

import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.http.AbstractHttpTemplate;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.*;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.*;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.CharsetUtil;

import java.net.InetSocketAddress;

/**
 * 与srs交换webrtc sdp的请求模板。
 */
public class SrsExchangeSdpTemplate extends AbstractHttpTemplate {

    private final String srsApiIp;

    private final int srsApiPort;

    private final String webAddress;

    private final String sdp;

    private final String streamPath;

    public SrsExchangeSdpTemplate(boolean ssl, String ip, int port, String webAddress, String sdp, String streamPath) {
        if (StringUtil.isEmpty(ip)) {
            throw new IllegalArgumentException("SrsExchangeSdpTemplate: param ip can not be empty");
        }

        if (port < 0 || port > 65535) {
            throw new IllegalArgumentException("SrsExchangeSdpTemplate: param port must > 0 && < 65535");
        }

        if (StringUtil.isEmpty(webAddress)) {
            throw new IllegalArgumentException("SrsExchangeSdpTemplate: param webAddress can not be empty");
        }

        if (StringUtil.isEmpty(sdp)) {
            throw new IllegalArgumentException("SrsExchangeSdpTemplate: param sdp can not be empty");
        }

        if (StringUtil.isEmpty(streamPath)) {
            throw new IllegalArgumentException("SrsExchangeSdpTemplate: param streamPath can not be empty");
        }
        super.ssl = ssl;
        this.srsApiIp = ip;
        this.srsApiPort = port;
        this.webAddress = webAddress;
        this.sdp = sdp;
        this.streamPath = streamPath;
    }

    @Override
    protected Bootstrap getBootstrap() {
        return new Bootstrap()
                .group(getEventLoopGroup())
                .channel(getChannelType())
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        //ssl处理器
                        if (SrsExchangeSdpTemplate.super.ssl) {
                            pipeline.addLast(SslContextBuilder.forClient().build().newHandler(ch.alloc()));
                        }
                        //连接空闲(超时)监视器
                        pipeline.addLast(new IdleStateHandler(0, 0, 10));
                        //HTTP编解码器
                        pipeline.addLast(new HttpClientCodec());
                        //HTTP报文聚合器
                        pipeline.addLast(new HttpObjectAggregator(1024 * 128));
                        //SRS请求响应处理器
                        pipeline.addLast(new SrsExchangeSdpHandler());
                    }
                })
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                .remoteAddress(new InetSocketAddress(this.srsApiIp, this.srsApiPort));
    }

    private class SrsExchangeSdpHandler extends SimpleChannelInboundHandler<FullHttpResponse> {

        private final String apiUrl;

        SrsExchangeSdpHandler() {
            this.apiUrl =
                    "http" + (SrsExchangeSdpTemplate.super.ssl ? "s" : ":") + "://" +
                    SrsExchangeSdpTemplate.this.srsApiIp + ":" + SrsExchangeSdpTemplate.this.srsApiPort +
                    "/rtc/v1/play/";
        }

        @Override
        protected void channelRead0(ChannelHandlerContext ctx, FullHttpResponse msg) throws Exception {
            ctx.close();
            int responseCode = msg.status().code();
            String responseBody = msg.content().toString(CharsetUtil.UTF_8);
            Logger.info(this.apiUrl + " response: " + responseCode + " " + responseBody);

            if (responseCode != HttpResponseStatus.OK.code()) {
                //发布事件
                eventConstructor.apply(SrsExchangeSdpTemplate.super.taskId, null).publish();
                return;
            }

            JsonObject responseJson = null;
            try {
                responseJson = JsonObject.from(responseBody);
            } catch (Exception e) {
                Logger.warn("error occurred while parsing json");
            }
            if (responseJson == null) {
                //发布事件
                eventConstructor.apply(SrsExchangeSdpTemplate.super.taskId, null).publish();
                return;
            }

            String answerSdp = responseJson.getString("sdp");
            String sessionId = responseJson.getString("sessionid");
            if (StringUtil.isEmpty(answerSdp)) {
                eventConstructor.apply(SrsExchangeSdpTemplate.super.taskId, null).publish();
                return;
            }

            JsonObject answer = JsonObject.create().put("sdp", answerSdp).put("sessionId", sessionId);
            eventConstructor.apply(SrsExchangeSdpTemplate.super.taskId, answer).publish();

        }

        //发送request
        @Override
        public void channelActive(ChannelHandlerContext ctx) throws Exception {
            String streamUrl =
                    "webrtc://" +
                     SrsExchangeSdpTemplate.this.srsApiIp +
                     SrsExchangeSdpTemplate.this.streamPath;
            String body = JsonObject.create()
                    .put("api", this.apiUrl)
                    .put("streamurl", streamUrl)
                    .put("clientip", (Object) null)
                    .put("sdp", SrsExchangeSdpTemplate.this.sdp)
                    .put("webaddress", SrsExchangeSdpTemplate.this.webAddress)
                    .stringify();
            ByteBuf bodyBuf = ByteBufUtil.writeUtf8(ctx.alloc(), body);
            FullHttpRequest request = new DefaultFullHttpRequest(
                    HttpVersion.HTTP_1_1,
                    HttpMethod.POST,
                    "/rtc/v1/play/",
                    bodyBuf);
            request.headers().set(HttpHeaderNames.CONTENT_TYPE, APPLICATION_JSON);
            request.headers().set(HttpHeaderNames.CONTENT_LENGTH, bodyBuf.readableBytes());

            Logger.info("[" + SrsExchangeSdpTemplate.super.taskId + "] POST " + this.apiUrl + " request: " + body);
            ctx.writeAndFlush(request);
        }

        //处理连接空闲
        @Override
        public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
            if (evt instanceof IdleStateEvent) {
                ctx.close();
                Logger.warn("SrsExchangeSdpHandler IdleStateEvent Triggered, connection close...");
            }
        }

    }

}

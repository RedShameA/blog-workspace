package io.iwd.common.event.srs;

import io.iwd.common.event.LogEvent;

import java.util.HashMap;
import java.util.Map;

public class SrsLogEvent extends LogEvent {

    public enum LogType implements LogEvent.LogType {

        SRS_STREAM_UNDEFINE(0), // 暂未定义，扩展使用
        SRS_STREAM_CONNECTED(1), // 设备连接成功
        SRS_STREAM_DISCONNECT(2), // 设备断开连接
        SRS_STREAM_RTMP_RECV(3), // 收到RTMP流
        SRS_STREAM_RTP_RECV(4), // 收到RTP(CSG)流
        SRS_STREAM_GB28181_RECV(5), // 收到MPEG-2(GB28181)流
        SRS_STREAM_WEBRTC_PUSH(6), // 推WEBRTC流
        SRS_STREAM_WEBRTC_STOP_PUSH(7), // 停止推WEBRTC流
        SRS_STREAM_RTMP_PUSH(8), // 推RTMP流
        SRS_STREAM_RTSP_PUSH(9), // 推RTSP流
        SRS_STREAM_GB28181_TIMEOUT_RECV(10), //等待GB28181流超时
        SRS_STREAM_CSG_TIMEOUT_RECV(11), //等待CSG流超时
        SRS_STREAM_RTC_PLAY(12), //收到rtcPlay
        SRS_STREAM_RTMP_CLIENT_CONNECTED(13), //播放RTMP流
        ;

        private static final Map<Integer, LogType> CODE_TYPE_MAPPING = new HashMap<>();

        static {
            CODE_TYPE_MAPPING.put(0, SRS_STREAM_UNDEFINE);
            CODE_TYPE_MAPPING.put(1, SRS_STREAM_CONNECTED);
            CODE_TYPE_MAPPING.put(2, SRS_STREAM_DISCONNECT);
            CODE_TYPE_MAPPING.put(3, SRS_STREAM_RTMP_RECV);
            CODE_TYPE_MAPPING.put(4, SRS_STREAM_RTP_RECV);
            CODE_TYPE_MAPPING.put(5, SRS_STREAM_GB28181_RECV);
            CODE_TYPE_MAPPING.put(6, SRS_STREAM_WEBRTC_PUSH);
            CODE_TYPE_MAPPING.put(7, SRS_STREAM_WEBRTC_STOP_PUSH);
            CODE_TYPE_MAPPING.put(8, SRS_STREAM_RTMP_PUSH);
            CODE_TYPE_MAPPING.put(9, SRS_STREAM_RTSP_PUSH);
            CODE_TYPE_MAPPING.put(10, SRS_STREAM_GB28181_TIMEOUT_RECV);
            CODE_TYPE_MAPPING.put(11, SRS_STREAM_CSG_TIMEOUT_RECV);
            CODE_TYPE_MAPPING.put(12, SRS_STREAM_RTC_PLAY);
            CODE_TYPE_MAPPING.put(13, SRS_STREAM_RTMP_CLIENT_CONNECTED);
        }

        public static LogType forCode(int code) {
            return CODE_TYPE_MAPPING.get(code);
        }

        private final int code;

        LogType(int code) {
            this.code = code;
        }

        @Override
        public int code() {
            return code;
        }
    }

    public SrsLogEvent(LogType logType, String logMessage) {
        super(logType, logMessage);
    }

}

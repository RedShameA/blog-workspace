package io.iwd.common.stdio.http.srs.handler;

import io.iwd.common.event.srs.SrsRtspReadyEvent;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.http.AbstractHttpRequestHandler;
import io.iwd.common.stdio.http.HttpHelper;
import io.iwd.common.stdio.http.HttpRequestHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.HttpResponseStatus;

import java.util.Map;

/**
 * srs发送rtsp拉流准备就绪请求的处理器。
 */
@HttpRequestHandler(path = "/srs/srsRtspReady")
public class SrsRtspReadyHandler extends AbstractHttpRequestHandler<JsonObject> {

    @Override
    protected void handle0(ChannelHandlerContext waitingResponseContext,
                           String path, String method,
                           Map<String, String> queryString,
                           Map<String, String> headers,
                           JsonObject body) throws Exception {

        String taskId = body.getString("msgid");
        if (StringUtil.isEmpty(taskId)) {
            HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":400,\"message\":\"no msgid\"}", null);
            return;
        }

        new SrsRtspReadyEvent(taskId).publish();

        HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":200}", null);
    }
}

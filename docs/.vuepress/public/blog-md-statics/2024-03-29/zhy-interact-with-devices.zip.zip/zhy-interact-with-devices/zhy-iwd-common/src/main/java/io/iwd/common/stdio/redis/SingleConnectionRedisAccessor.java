package io.iwd.common.stdio.redis;

import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.environment.ManagerLifecycle;
import io.iwd.common.event.TaskProceedEvent;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.misc.NettyComponentThreadFactory;
import io.iwd.common.ext.util.StringUtil;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.*;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.redis.*;
import io.netty.util.ReferenceCountUtil;
import io.netty.util.concurrent.ScheduledFuture;

import java.net.InetSocketAddress;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.BiFunction;

public class SingleConnectionRedisAccessor implements ManagerLifecycle, RedisClient, RedisAccessor {

    protected final String ip;

    protected final int port;

    protected final String password;

    protected final boolean autoReconnect;

    protected final AtomicBoolean closed;

    protected final ReadWriteLock lock;

    protected EventLoopGroup eventLoopGroup;

    protected Channel channel;

    public SingleConnectionRedisAccessor(String ip, int port, String password, boolean autoReconnect) {
        this.ip = ip;
        this.port = port;
        this.password = password;
        this.autoReconnect = autoReconnect;
        this.closed = new AtomicBoolean(false);
        this.lock = new ReentrantReadWriteLock();
    }

    @Override
    public void active() {
        if (this.eventLoopGroup != null || this.closed.get()) {
            return;
        }

        this.eventLoopGroup = EnvironmentHolder.get().isEpollAvailable() ?
                new EpollEventLoopGroup(1, new NettyComponentThreadFactory(getClass())) :
                new NioEventLoopGroup(1, new NettyComponentThreadFactory(getClass()));

        connectAndInit();
    }

    @Override
    public void destroy() {
        if (!this.closed.compareAndSet(false, true)) {
            return;
        }

        disconnect();

        if (this.eventLoopGroup != null) {
            this.eventLoopGroup.shutdownGracefully().awaitUninterruptibly();
            this.eventLoopGroup = null;
        }
    }

    @Override
    public void connectAndInit() {
        Lock lock = this.lock.writeLock();
        lock.lock();
        try {

            do {
                if (this.closed.get() || this.channel != null) {
                    return;
                }

                final RedisClient redisClient = this;
                final String password = this.password;
                //需要等pipeline初始化完才能使用
                final CountDownLatch countDownLatch = new CountDownLatch(1);

                boolean shouldReconnect = this.autoReconnect && !this.closed.get();

                Bootstrap bootstrap = new Bootstrap();
                bootstrap.group(this.eventLoopGroup);
                bootstrap.channel(EnvironmentHolder.get().isEpollAvailable() ?
                        EpollSocketChannel.class :
                        NioSocketChannel.class);
                bootstrap.handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        pipeline.addLast(new RedisEncoder());
                        pipeline.addLast(new RedisDecoder());
                        pipeline.addLast(new RedisBulkStringAggregator());
                        pipeline.addLast(new RedisArrayAggregator());
                        pipeline.addLast(new RedisChannelInitializer(redisClient, password, countDownLatch));
                    }
                });

                bootstrap
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                        .option(ChannelOption.SO_KEEPALIVE, true)
                        .option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
                        .remoteAddress(new InetSocketAddress(ip, port));

                Logger.info(getClass().getSimpleName() + " connecting Redis");
                ChannelFuture channelFuture = bootstrap
                        .connect()
                        .awaitUninterruptibly();

                Channel channel = channelFuture.channel();

                if (!channelFuture.isSuccess()) {
                    if (channel != null) {
                        channel.close().awaitUninterruptibly();
                    }
                    this.channel = null;
                    Logger.error("SingleConnectionRedisAccessor failed to connect Redis " + ip + ":" + port + (shouldReconnect ? ", reconnecting" : ""));
                    if (shouldReconnect) {
                        continue;
                    }
                    return;
                }

                boolean initSuccess;
                try {
                    initSuccess = countDownLatch.await(10, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    initSuccess = false;
                }
                if (!initSuccess) {
                    if (channel != null) {
                        channel.close().awaitUninterruptibly();
                    }
                    this.channel = null;
                    Logger.error("SingleConnectionRedisAccessor failed to initialize" + (shouldReconnect ? ", reconnecting" : ""));
                    if (shouldReconnect) {
                        continue;
                    }
                    return;

                }
                this.channel = channel;
                Logger.info("SingleConnectionRedisAccessor connected Redis " + ip + ":" + port);
                break;

            } while (true);

        } finally {
            lock.unlock();
        }
    }

    @Override
    public void disconnect() {
        Lock lock = this.lock.writeLock();
        lock.lock();
        try {
            if (this.channel != null) {
                this.channel.close().awaitUninterruptibly();
                this.channel = null;
            }
            Logger.info("SingleConnectionRedisAccessor disconnected Redis " + ip + ":" + port);
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void reconnectAndInit() {
        Lock lock = this.lock.writeLock();
        lock.lock();
        try {
            disconnect();
            connectAndInit();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean isAutoReconnect() {
        return this.autoReconnect;
    }

    @Override
    public boolean isClosed() {
        return this.closed.get();
    }

    @Override
    public void execute(RedisCommandWrapper redisCommandWrapper) {
        Lock lock = this.lock.readLock();
        if (!lock.tryLock()) {
            Logger.warn("redis command execute failed, can not get lock, " + redisCommandWrapper.fullCommandString());
            return;
        }
        try {
            if (this.channel != null) {
                this.channel.writeAndFlush(redisCommandWrapper);
            }
        } finally {
            lock.unlock();
        }
    }

    static class RedisChannelInitializer extends RedisConnectHandler {

        private final CountDownLatch countDownLatch;

        public RedisChannelInitializer(RedisClient redisClient, String password, CountDownLatch countDownLatch) {
            super(redisClient, password);
            this.countDownLatch = countDownLatch;
        }

        @Override
        protected void channelActiveInternal(ChannelHandlerContext ctx) throws Exception {

            //移除RedisChannelInitializer
            ctx.channel().pipeline().removeLast();

            //添加RedisChannelHandler
            ctx.channel().pipeline().addLast(new RedisChannelHandler(super.redisClient));

            this.countDownLatch.countDown();
        }
    }

    static class RedisChannelHandler extends ChannelDuplexHandler {

        /**
         * 此handler关联的redis客户端。
         */
        private final RedisClient redisClient;

        /**
         * 命令队列。
         */
        private final Deque<RedisCommandWrapper> deque;

        /**
         * 此handler的ctx，供writeRedisMessage()发送命令使用。
         */
        private ChannelHandlerContext channelHandlerContext;

        private ScheduledFuture<?> monitor;

        private RedisCommandWrapper commandPointer;

        RedisChannelHandler(RedisClient redisClient) {
            this.redisClient = redisClient;
            this.deque = new LinkedList<>();
        }

        @Override
        public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
            this.channelHandlerContext = ctx;
            this.monitor = ctx.channel().eventLoop().scheduleWithFixedDelay(() -> {
                RedisCommandWrapper theEarliest = this.deque.peekFirst();
                if (this.commandPointer == null || this.commandPointer != theEarliest) {
                    this.commandPointer = theEarliest;
                    return;
                }
                //最早的命令未收到回复，断开
                this.channelHandlerContext.channel().close();
            }, 30, 30, TimeUnit.SECONDS);
        }

        @Override
        public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {

            if (! (msg instanceof RedisCommandWrapper)) {
                //不应该有其他类型的数据出站
                return;
            }

            RedisCommandWrapper commandWrapper = (RedisCommandWrapper) msg;
            String commandType = commandWrapper.commandName();
            String[] params = commandWrapper.params();

            if (StringUtil.isEmpty(commandType)) {
                return;
            }
            if (params == null) {
                return;
            }
            if (!commandWrapper.isSilent()) {
                String taskId = commandWrapper.taskId();
                BiFunction<String, Object, TaskProceedEvent> eventConstructor = commandWrapper.eventConstructor();
                if (StringUtil.isEmpty(taskId) || eventConstructor == null) {
                    return;
                }
            }

            this.deque.addLast(commandWrapper);

            RedisMessage redisMessage = commandWrapper.toRedisMessage(ctx.alloc());
            if (redisMessage == null) {
                return;
            }

            this.channelHandlerContext.writeAndFlush(redisMessage);
        }

        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {

            try {
                if (! (msg instanceof RedisMessage)) {
                    return;
                }

                RedisCommandWrapper repliedCommand = this.deque.pollFirst();
                if (repliedCommand == null) {
                    Logger.error("received response, but not command in queue");
                    return;
                }

                RedisMessage redisMessage = (RedisMessage) msg;
                Object response = repliedCommand.handleResponse(redisMessage);

                Logger.info(repliedCommand.fullCommandString() + " >>> " + responseToString(response));

                if (!repliedCommand.isSilent()) {
                    String taskId = repliedCommand.taskId();
                    BiFunction<String, Object, TaskProceedEvent> eventConstructor = repliedCommand.eventConstructor();
                    eventConstructor.apply(taskId, response).publish();
                }

            } finally {
                ReferenceCountUtil.release(msg);
            }
        }

        @Override
        public void channelInactive(ChannelHandlerContext ctx) throws Exception {
            if (this.monitor != null) {
                this.monitor.cancel(false);
            }
            boolean shouldReconnect = this.redisClient.isAutoReconnect() && !this.redisClient.isClosed();
            Logger.warn("redis connection (SingleConnectionRedisAccessor) closed" + (shouldReconnect ? ", reconnecting" : ""));
            if (!shouldReconnect) {
                return;
            }
            new Thread(this.redisClient::reconnectAndInit).start();
        }

        private String responseToString(Object response) {
            if (response instanceof List) {
                List<?> list = (List<?>) response;
                if (list.size() == 0) {
                    return "(empty list or set)";
                }
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < list.size(); i++) {
                    builder.append(i + 1).append(')');
                    builder.append(list.get(i));
                    builder.append(' ');
                }
                return builder.toString();
            }
            if (response instanceof RedisException) {
                return ((RedisException) response).getMessage();
            }
            return String.valueOf(response);
        }

    }

}

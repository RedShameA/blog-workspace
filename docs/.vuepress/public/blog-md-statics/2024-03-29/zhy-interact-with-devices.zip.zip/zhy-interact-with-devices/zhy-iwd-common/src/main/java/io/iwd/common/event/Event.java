package io.iwd.common.event;

import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.log.Logger;

/**
 * 事件接口。所有事件对象都要直接或间接实现此接口。
 */
public interface Event {

    /**
     * 将此事件通过事件派发器发布。
     */
    default void publish() {
        EventMulticaster eventMulticaster = EnvironmentHolder.get().eventMulticaster();
        if (eventMulticaster != null) {
            eventMulticaster.publishEvent(this);
        } else {
            Logger.error("can not get EventMulticaster");
        }
    }

}

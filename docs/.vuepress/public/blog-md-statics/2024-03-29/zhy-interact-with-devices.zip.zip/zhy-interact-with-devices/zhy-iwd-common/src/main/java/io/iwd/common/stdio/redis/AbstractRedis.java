package io.iwd.common.stdio.redis;

import io.iwd.common.environment.EnvironmentHolder;

public abstract class AbstractRedis implements Redis {

    protected abstract RedisCommandWrapper getCommandWrapper(RedisCommand redisCommand, String[] params);

    protected void execute(RedisCommandWrapper redisCommandWrapper) {
        EnvironmentHolder.get().redisAccessor().execute(redisCommandWrapper);
    }

    @Override
    public RedisCommandWrapper command(RedisCommand redisCommand, String... params) {
        return getCommandWrapper(redisCommand, params);
    }

    @Override
    public void publish(String channelName, String message) {
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.PUBLISH, new String[] {channelName, message});
        execute(wrapper);
    }

    @Override
    public void eval(String script, int keysNum, String... params) {
        String[] p = new String[params.length + 2];
        p[0] = script;
        p[1] = String.valueOf(keysNum);
        System.arraycopy(params, 0, p, 2, params.length);
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.EVAL, p);
        execute(wrapper);
    }

    @Override
    public void get(String key) {
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.GET, new String[] {key});
        execute(wrapper);
    }

    @Override
    public void set(String key, String value) {
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.SET, new String[] {key, value});
        execute(wrapper);
    }

    @Override
    public void del(String key) {
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.DEL, new String[] {key});
        execute(wrapper);
    }

    @Override
    public void hget(String key, String field) {
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.HGET, new String[] {key, field});
        execute(wrapper);
    }

    @Override
    public void hset(String key, String field, String value) {
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.HSET, new String[] {key, field, value});
        execute(wrapper);
    }

    @Override
    public void hdel(String key, String field) {
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.HDEL, new String[] {key, field});
        execute(wrapper);
    }

    @Override
    public void hgetall(String key) {
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.HGETALL, new String[] {key});
        execute(wrapper);
    }

    @Override
    public void rpush(String key, String... values) {
        String[] p = new String[values.length + 1];
        p[0] = key;
        System.arraycopy(values, 0, p, 1, values.length);
        RedisCommandWrapper wrapper =
                getCommandWrapper(RedisCommand.RPUSH, p);
        execute(wrapper);
    }
}

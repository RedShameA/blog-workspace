package io.iwd.common.ext.json;

public interface Jsonable<T> {

    JsonObject json();

    T from(String jsonString);

}

package io.iwd.common.environment;

/**
 * 管理器生命周期。
 */
public interface ManagerLifecycle {

    /**
     * 启动线程，进入实际工作状态。
     */
    void active();

    /**
     * 结束工作状态，释放资源。
     */
    void destroy();

}

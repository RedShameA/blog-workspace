package io.iwd.common.stdio.http.srs.handler;

import io.iwd.common.event.srs.SrsCloseRtmpSourceEvent;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.http.AbstractHttpRequestHandler;
import io.iwd.common.stdio.http.HttpHelper;
import io.iwd.common.stdio.http.HttpRequestHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.HttpResponseStatus;

import java.util.Map;

/**
 * srs关闭rtmp视频源的请求处理器。
 */
@HttpRequestHandler(path = "/preService/i1VideoStopChannel")
public class SrsCloseRtmpSourceHandler extends AbstractHttpRequestHandler<JsonObject> {

    @Override
    protected void handle0(ChannelHandlerContext waitingResponseContext,
                           String path,
                           String method,
                           Map<String, String> queryString,
                           Map<String, String> headers,
                           JsonObject body) throws Exception {

        String streamId = body.getString("streamId");
        if (StringUtil.isEmpty(streamId)) {
            HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":400,\"message\":\"no streamId\"}", null);
            return;
        }

        new SrsCloseRtmpSourceEvent(streamId).publish();

        HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":200}", null);
    }
}

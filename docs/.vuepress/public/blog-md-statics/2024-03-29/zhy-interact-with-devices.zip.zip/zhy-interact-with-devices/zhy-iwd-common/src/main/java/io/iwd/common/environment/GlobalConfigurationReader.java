package io.iwd.common.environment;

import io.iwd.common.ext.util.MpscConsumerBlockingQueue;

public class GlobalConfigurationReader {

    private Thread reader;

    private MpscConsumerBlockingQueue<ReadConfigAction> queue;

    public GlobalConfigurationReader() {
        this.reader = new Thread(() -> {
            while (true) {
                ReadConfigAction action = this.queue.get();
                Object configInfo = action.readTask.execute(EnvironmentHolder.get().config());
                action.eventConstructor.apply(action.taskId, configInfo).publish();
            }

        }, "GlobalConfigurationReader");

        this.queue = new MpscConsumerBlockingQueue<>(reader, 16, 64);

        this.reader.start();
    }

    void read(ReadConfigAction readConfigAction) {
        this.queue.put(readConfigAction);
    }

}

package io.iwd.common.engine;

import io.iwd.common.event.TaskProceedEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

/**
 * 任务执行上下文，一般由任务执行线程实际操作，非线程安全。
 */
public class TaskContext implements TaskContextFacade {

    /**
     * 任务id。
     */
    private final String taskId;

    /**
     * 执行任务的TaskReactor。
     */
    private final TaskReactor reactor;

    /**
     * 关联的TaskFlow。
     */
    private final TaskFlow taskFlow;

    /**
     * 数据容器。
     */
    private final Map<String, Object> data;

    /**
     * 任务结果。
     */
    private final TaskResult taskResult;

    /**
     * 每一个任务节点的输入输入。
     */
    private Object input;

    /**
     * 任务状态。
     */
    private TaskState taskState;

    /**
     * 下一个任务节点指针。
     */
    private Task nextNode;

    /**
     * 下一个任务节点名称。
     */
    private String nextNodeName;

    /**
     * 时间戳，为整数时代表超时时间，为负数时代表延迟触发时间。
     */
    private long timestamp;

    /**
     * 当前任务节点的超时消息。
     */
    private Object timeoutMessage;

    /**
     * 当前任务节点的完成消息。
     */
    private Object completedMessage;

    /**
     * 当前任务节点的失败消息。
     */
    private Object failedMessage;

    /**
     * 已执行的任务节点数。
     */
    private int executedTaskCount;

    /**
     * 标准构造器。
     * @param taskId 任务id.
     * @param reactor 与此Context绑定的执行线程。
     * @param taskFlow 任务流程。
     * @param taskResult 任务结果容器。
     */
    public TaskContext(String taskId, TaskReactor reactor, TaskFlow taskFlow, TaskResult taskResult) {
        this.taskId = taskId;
        this.reactor = reactor;
        this.taskFlow = taskFlow;
        this.taskResult = taskResult;
        this.data = new HashMap<>(8);
        this.timestamp = 0L;
        this.executedTaskCount = 0;
    }

    /**
     * 设置下一个任务节点。
     * @param nodeName 任务节点名称。
     */
    @Override
    public void setNext(String nodeName) {
        this.nextNode = this.taskFlow.getNode(nodeName);
        this.nextNodeName = nodeName;
    }

    /**
     * 获取下一个任务节点。
     * @return 任务节点。
     */
    public Task getNext() {
        return this.nextNode;
    }

    /**
     * 获取下一个任务节点名称。
     * @return 任务节点名称。
     */
    public String getNextNodeName() {
        return this.nextNodeName;
    }

    /**
     * 获取默认的{@link TaskProceedEvent}构造器。
     * 此方法的存在是为了方便任务流程开发，任何需要传入TaskProceedEvent构造器的功能都应有手动设置构造器的接口。
     * @return 默认的TaskProceedEvent构造器。
     */
    public BiFunction<String, Object, TaskProceedEvent> getDefaultTaskProceedEventConstructor() {
        return this.taskFlow.getDefaultTaskProceedEventConstructor();
    }

    /**
     * 获取与此Context关联的任务id。
     * @return 任务id。
     */
    @Override
    public String getTaskId() {
        return taskId;
    }

    /**
     * 存放一项数据。
     * @param key 键。
     * @param value 值。
     */
    @Override
    public void putData(String key, Object value) {
        this.data.put(key, value);
    }

    /**
     * 获取一项存放的数据。
     * @param key 键。
     * @return 值。
     */
    @Override
    public Object getData(String key) {
        return this.data.get(key);
    }

    /**
     * 删除一项存放的数据。
     * @param key 键。
     */
    @Override
    public void deleteData(String key) {
        this.data.remove(key);
    }

    /**
     * 返回当前设置的{@link TaskContext#timestamp}。
     * @return 当前设置的timestamp。
     */
    protected long getTimestamp() {
        return timestamp;
    }

    /**
     * 设置{@link TaskContext#timestamp}。
     * @param timestamp 时间戳。
     */
    @Override
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * 获取设置的超时信息。
     * @return 超时信息。
     */
    public Object getTimeoutMessage() {
        return timeoutMessage;
    }

    /**
     * 设置超时信息，任务超时后会将此信息置入{@link TaskResult}。
     * @param message 超时信息。
     */
    @Override
    public void setTimeoutMessage(Object message) {
        this.timeoutMessage = message;
    }

    /**
     * 获取设置的完成信息。
     * @return 完成信息。
     */
    public Object getCompletedMessage() {
        return completedMessage;
    }

    /**
     * 设置完成信息，任务完成后会将此信息置入{@link TaskResult}。
     * @param completedMessage 超时信息。
     */
    @Override
    public void setCompletedMessage(Object completedMessage) {
        this.completedMessage = completedMessage;
    }

    /**
     * 获取设置的失败信息。
     * @return 失败信息。
     */
    public Object getFailedMessage() {
        return failedMessage;
    }

    /**
     * 设置失败信息，任务失败后会将此信息置入{@link TaskResult}。
     * @param failedMessage 失败信息。
     */
    @Override
    public void setFailedMessage(Object failedMessage) {
        this.failedMessage = failedMessage;
    }

    /**
     * 获取{@link TaskResult}。
     * @return TaskResult。
     */
    public TaskResult getTaskResult() {
        return taskResult;
    }

    /**
     * 获取任务节点的输入数据。此方法通常只在任务开始的节点或者其他系统数据传入的节点调用。
     * @return 输入数据。
     */
    @Override
    public Object getInput() {
        return this.input;
    }

    /**
     * 设置任务节点的输入数据。此方法通常由核心组件调用。
     * @param input 输入数据。
     */
    protected void setInput(Object input) {
        this.input = input;
    }

    /**
     * 获取已执行的任务节点数。
     * @return 已执行的任务节点数。
     */
    @Override
    public int getExecutedTaskCount() {
        return this.executedTaskCount;
    }

    /**
     * 任务节点数+1。
     */
    protected void incrementExecutedTaskCount() {
        this.executedTaskCount++;
    }

    /**
     * 将任务上下文状态设置为继续执行。
     */
    @Override
    public void jump() {
        this.taskState = TaskState.CONTINUED;
    }

    /**
     * 将任务上下文状态设置为延迟执行。
     */
    @Override
    public void delay() {
        this.taskState = TaskState.DELAYED;
    }

    /**
     * 将任务上下文状态设置为等待执行。
     */
    @Override
    public void await() {
        this.taskState = TaskState.AWAIT;
    }

    /**
     * 将任务上下文状态设置为完成。
     */
    @Override
    public void complete() {
        this.taskState = TaskState.COMPLETED;
    }

    /**
     * 将任务上下文状态设置为失败。
     */
    @Override
    public void fail() {
        this.taskState = TaskState.FAILED;
    }

    /**
     * 返回任务上下文状态。
     * @return 任务上下文状态。
     */
    protected TaskState getTaskState() {
        return this.taskState;
    }

    /**
     * 清除任务上下文状态。
     */
    protected void clearTaskState() {
        this.taskState = null;
    }

    /**
     * 任务上下文状态枚举。
     */
    protected enum TaskState {
        /**
         * 继续执行。
         */
        CONTINUED,
        /**
         * 延迟执行。
         */
        DELAYED,
        /**
         * 等待执行。
         */
        AWAIT,
        /**
         * 完成。
         */
        COMPLETED,
        /**
         * 失败。
         */
        FAILED
        ;
    }

}

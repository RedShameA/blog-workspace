package io.iwd.common.stdio.http;

import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.*;

import java.util.Collections;
import java.util.Map;

/**
 * http工具类。
 */
public final class HttpHelper {

    private static final Map<CharSequence, CharSequence> JSON_HEADER;

    static {
        JSON_HEADER = Collections.singletonMap(HttpHeaderNames.CONTENT_TYPE, HttpHeaderValues.APPLICATION_JSON);
    }

    public static void response400(ChannelHandlerContext ctx) {
        response(ctx, HttpResponseStatus.BAD_REQUEST, "{\"message\":\"Bad Request\"}", JSON_HEADER);
    }

    public static void response400(ChannelHandlerContext ctx, String info) {
        response(ctx, HttpResponseStatus.BAD_REQUEST, "{\"message\":\"" + info + "\"}", JSON_HEADER);
    }

    public static void response404(ChannelHandlerContext ctx) {
        response(ctx, HttpResponseStatus.NOT_FOUND, "{\"message\":\"Not Found\"}", JSON_HEADER);
    }

    public static void response404(ChannelHandlerContext ctx, String info) {
        response(ctx, HttpResponseStatus.NOT_FOUND, "{\"message\":\"" + info + "\"}", JSON_HEADER);
    }

    public static void response405(ChannelHandlerContext ctx) {
        response(ctx, HttpResponseStatus.METHOD_NOT_ALLOWED, "{\"message\":\"Method Not Allowed\"}", JSON_HEADER);
    }

    public static void response405(ChannelHandlerContext ctx, String info) {
        response(ctx, HttpResponseStatus.METHOD_NOT_ALLOWED, "{\"message\":\"" + info + "\"}", JSON_HEADER);
    }

    public static void response500(ChannelHandlerContext ctx) {
        response(ctx, HttpResponseStatus.INTERNAL_SERVER_ERROR, "{\"message\":\"Internal Server Error\"}", JSON_HEADER);
    }

    public static void response500(ChannelHandlerContext ctx, String info) {
        response(ctx, HttpResponseStatus.INTERNAL_SERVER_ERROR, "{\"message\":\"" + info + "\"}", JSON_HEADER);
    }

    public static void response503(ChannelHandlerContext ctx) {
        response(ctx, HttpResponseStatus.REQUEST_TIMEOUT, "{\"message\":\"Service Unavailable\"}", JSON_HEADER);
    }

    public static void response503(ChannelHandlerContext ctx, String info) {
        response(ctx, HttpResponseStatus.SERVICE_UNAVAILABLE, "{\"message\":\"" + info + "\"}", JSON_HEADER);
    }

    public static void response(ChannelHandlerContext ctx, HttpResponseStatus status, String content, Map<CharSequence, CharSequence> headers) {
        if (!ctx.channel().isOpen()) {
            return;
        }
        FullHttpResponse response = new DefaultFullHttpResponse(
                HttpVersion.HTTP_1_1,
                status,
                ByteBufUtil.writeUtf8(ctx.alloc(), content));
        if (headers != null) {
            headers.forEach((k, v) -> response.headers().set(k, v));
        }
        ctx.writeAndFlush(response).addListener(ChannelFutureListener.CLOSE);
    }

}

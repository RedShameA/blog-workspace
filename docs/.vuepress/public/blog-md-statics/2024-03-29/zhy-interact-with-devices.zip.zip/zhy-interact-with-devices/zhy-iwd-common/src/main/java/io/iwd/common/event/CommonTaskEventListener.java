package io.iwd.common.event;

import io.iwd.common.CommonConst;
import io.iwd.common.event.srs.SrsRtspReadyEvent;

import java.util.LinkedList;
import java.util.List;

public class CommonTaskEventListener extends AbstractTaskEventListener {

    @Override
    public String defaultTaskPrefix() {
        return CommonConst.TASK_PREFIX;
    }

    @Override
    public List<Class<? extends Event>> interests() {
        List<Class<? extends Event>> interestsList = new LinkedList<>();
        interestsList.add(CommonDefaultTaskStartEvent.class);
        interestsList.add(CommonDefaultTaskProceedEvent.class);
        interestsList.add(SrsRtspReadyEvent.class);
        return interestsList;
    }

}

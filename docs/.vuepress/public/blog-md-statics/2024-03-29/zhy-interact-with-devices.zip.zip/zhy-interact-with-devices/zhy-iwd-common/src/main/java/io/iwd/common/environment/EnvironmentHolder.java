package io.iwd.common.environment;

/**
 * {@link Environment}的静态容器。同一个进程只能存在一个{@link EnvironmentHolder}和{@link Environment}。
 */
public final class EnvironmentHolder {

    private static volatile Environment environment;

    static void set(Environment e) {
        EnvironmentHolder.environment = e;
    }

    /**
     * 获取{@link Environment}。
     * @param <T> Environment或其子类型。
     * @return Environment。
     */
    @SuppressWarnings("unchecked")
    public static <T extends Environment> T get() {
        return (T) EnvironmentHolder.environment;
    }

}

package io.iwd.common.engine;

import io.iwd.common.event.TaskProceedEvent;
import io.iwd.common.ext.util.StringUtil;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiFunction;

/**
 * 代表一个完整的任务流程。由若干个Task组成。
 * @see Task
 */
public class TaskFlow {

    /**
     * 此任务流程的前缀。
     */
    private final String prefix;

    /**
     * 此任务流程的名称。
     */
    private final String name;

    /**
     * 此任务流程的默认{@link TaskProceedEvent}构造器。
     */
    private final BiFunction<String, Object, TaskProceedEvent> defaultTaskProceedEventConstructor;

    /**
     * 此任务流程所有的任务节点及任务片段的名称。
     */
    private final Map<String, Task> nodes;

    /**
     * 此任务流程默认的入口任务节点的名称。
     */
    private String defaultEntrance;

    /**
     * TaskFlow的标准构造器。
     * @param name 任务流程的名称。
     */
    public TaskFlow(String prefix, String name, BiFunction<String, Object, TaskProceedEvent> defaultTaskProceedEventConstructor) {
        this.prefix = prefix;
        this.name = name;
        this.defaultTaskProceedEventConstructor = defaultTaskProceedEventConstructor;
        this.nodes = new LinkedHashMap<>(8, 0.5f);
    }

    /**
     * 为此任务流程增加一个任务节点。
     * @param nodeName 任务节点的名称。
     * @param node 任务节点。
     * @return 此任务流程。
     */
    public TaskFlow addNode(String nodeName, Task node) {
        nodes.put(nodeName, node);
        return this;
    }

    /**
     * 在此任务流程中查找指定名称的任务节点。
     * @param nodeName 任务节点的名称。
     * @return 任务节点。
     */
    public Task getNode(String nodeName) {
        return this.nodes.get(nodeName);
    }

    /**
     * 设置此任务流程的默认入口任务节点名称。
     * @param nodeName 任务节点的名称。
     */
    public void setDefaultEntrance(String nodeName) {
        this.defaultEntrance = nodeName;
    }

    /**
     * 返回此任务流程的前缀。
     * @return 此任务流程的名称。
     */
    public String getPrefix() {
        return this.prefix;
    }

    /**
     * 返回此任务流程的名称。
     * @return 此任务流程的名称。
     */
    public String getName() {
        return this.name;
    }

    /**
     * 返回此任务流程的默认{@link TaskProceedEvent}构造器。
     * @return 此任务流程的默认TaskProceedEvent构造器。
     */
    public BiFunction<String, Object, TaskProceedEvent> getDefaultTaskProceedEventConstructor() {
        return this.defaultTaskProceedEventConstructor;
    }

    /**
     * 生成一个此任务流程的上下文。使用默认入口节点。
     * @param taskId 任务id。
     * @param reactor 任务绑定的执行器。
     * @param taskResult 任务结果容器。
     * @return 任务上下文。
     * @see TaskContext
     */
    public TaskContext newContext(String taskId, TaskReactor reactor, TaskResult taskResult) {
        return newContext(taskId, reactor, taskResult, null);
    }

    /**
     * 生成一个此任务流程的上下文。指定入口节点。
     * @param taskId 任务id。
     * @param reactor 任务绑定的执行器。
     * @param taskResult 任务结果容器。
     * @param entrance 入口任务节点名称。
     * @return 务上下文。
     * @see TaskContext
     */
    public TaskContext newContext(String taskId, TaskReactor reactor, TaskResult taskResult, String entrance) {
        TaskContext context = new TaskContext(taskId, reactor, this, taskResult);

        if (StringUtil.notEmpty(entrance) && this.nodes.containsKey(entrance)) {
            //如果指定了入口节点 且存在此节点 就将此节点设置为下一个要执行的节点
            context.setNext(entrance);
        } else if (StringUtil.notEmpty(this.defaultEntrance) && this.nodes.containsKey(this.defaultEntrance)){
            //如果此任务流程有默认入口节点 且存在此节点 就将此节点设置为下一个要执行的节点
            context.setNext(this.defaultEntrance);
        } else if (this.nodes.size() > 0){
            //如果此任务流程包含至少一个节点 就将节点列表第一个设置为下一个要执行的节点
            Iterator<String> iterator = this.nodes.keySet().iterator();
            String firstNodeName = iterator.next();
            context.setNext(firstNodeName);
        }
        return context;
    }

}

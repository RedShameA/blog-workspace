package io.iwd.common.engine;

import io.iwd.common.environment.ManagerLifecycle;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * 任务结果服务。此服务会让额外的工作线程处理任务结果监听逻辑，以防监听逻辑中有阻塞操作，影响任务执行线程。
 */
public class TaskResultService implements ManagerLifecycle {

    /**
     * 线程池中的线程数。
     */
    private final int threadCount;

    /**
     * 线程池。
     */
    private volatile ExecutorService workers;

    public TaskResultService(int threadCount) {
        this.threadCount = threadCount;
    }

    @Override
    public void active() {
        //do nothing
    }

    @Override
    public void destroy() {
        if (this.workers != null) {
            this.workers.shutdownNow();
        }
    }

    <T> Future<T> submit(Callable<T> callable) {
        if (this.workers == null) {
            synchronized (this) {
                if (this.workers == null) {
                    this.workers = Executors.newFixedThreadPool(this.threadCount);
                }
            }
        }
        return this.workers.submit(() -> {
            try {
                return callable.call();
            } catch (Throwable t) {
                t.printStackTrace();
                return null;
            }
        });
    }
}

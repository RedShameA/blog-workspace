package io.iwd.common.ext.json;

public class JsonString implements JsonEntity {

    private final String internal;

    public JsonString(String s) {
        internal = s;
    }

    @Override
    public boolean isImmutable() {
        return true;
    }

    @Override
    public Type type() {
        return Type.STRING;
    }

    @Override
    public String stringify() {
        String str = internal.replaceAll("\"", "\\\\\"");
        return "\"" + str + "\"";
    }

    @Override
    public String simplify() {
        return internal;
    }

    public String internalString() {
        return internal;
    }
}

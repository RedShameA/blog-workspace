package io.iwd.common.stdio.redis;

import io.iwd.common.ext.log.Logger;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.ByteBufUtil;
import io.netty.handler.codec.redis.*;
import io.netty.util.CharsetUtil;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;

import static io.iwd.common.stdio.redis.ResponseHandlers.*;

final class ResponseHandlers {

    static final Function<Object, Object> SIMPLE_STRING_RESPONSE_HANDLER = msg -> {
        if (msg instanceof ErrorRedisMessage) {
            ErrorRedisMessage errorRedisMessage = (ErrorRedisMessage) msg;
            return new RedisException(errorRedisMessage.content());
        }
        if (msg instanceof SimpleStringRedisMessage) {
            SimpleStringRedisMessage simpleStringRedisMessage = (SimpleStringRedisMessage) msg;
            return simpleStringRedisMessage.content();
        }
        return new RedisException("unknown response type: " + msg.getClass());
    };

    static final Function<Object, Object> FULL_BULK_STRING_RESPONSE_HANDLER = msg -> {
        if (msg instanceof ErrorRedisMessage) {
            ErrorRedisMessage errorRedisMessage = (ErrorRedisMessage) msg;
            return new RedisException(errorRedisMessage.content());
        }
        if (msg instanceof FullBulkStringRedisMessage) {
            FullBulkStringRedisMessage fullBulkStringRedisMessage = (FullBulkStringRedisMessage) msg;
            if (fullBulkStringRedisMessage.isNull()) {
                return null;
            }
            return fullBulkStringRedisMessage.content().toString(CharsetUtil.UTF_8);
        }
        return new RedisException("unknown response type: " + msg.getClass());
    };

    static final Function<Object, Object> INTEGER_RESPONSE_HANDLER = msg -> {
        if (msg instanceof ErrorRedisMessage) {
            ErrorRedisMessage errorRedisMessage = (ErrorRedisMessage) msg;
            return new RedisException(errorRedisMessage.content());
        }
        if (msg instanceof IntegerRedisMessage) {
            IntegerRedisMessage integerRedisMessage = (IntegerRedisMessage) msg;
            return integerRedisMessage.value();
        }
        return new RedisException("unknown response type: " + msg.getClass());
    };

    static final Function<Object, Object> ARRAY_RESPONSE_HANDLER = msg -> {
        if (msg instanceof ErrorRedisMessage) {
            ErrorRedisMessage errorRedisMessage = (ErrorRedisMessage) msg;
            return new RedisException(errorRedisMessage.content());
        }
        if (msg instanceof ArrayRedisMessage) {
            ArrayRedisMessage arrayRedisMessage = (ArrayRedisMessage) msg;
            if (arrayRedisMessage.isNull()) {
                return null;
            }
            List<RedisMessage> children = arrayRedisMessage.children();
            List<Object> result = new LinkedList<>();
            for (RedisMessage rm : children) {
                if (rm instanceof FullBulkStringRedisMessage) {
                    FullBulkStringRedisMessage fullBulkStringRedisMessage = (FullBulkStringRedisMessage) rm;
                    String m = fullBulkStringRedisMessage.isNull() ? null : fullBulkStringRedisMessage.content().toString(CharsetUtil.UTF_8);
                    result.add(m);
                }
                else if (rm instanceof IntegerRedisMessage) {
                    IntegerRedisMessage integerRedisMessage = (IntegerRedisMessage) rm;
                    long m = integerRedisMessage.value();
                    result.add(m);
                }
            }
            return result;
        }
        return new RedisException("unknown response type: " + msg.getClass());
    };

    static final Function<Object, Object> ANY_RESPONSE_HANDLER = msg -> {
        if (msg instanceof ErrorRedisMessage) {
            ErrorRedisMessage errorRedisMessage = (ErrorRedisMessage) msg;
            return new RedisException(errorRedisMessage.content());
        }
        if (msg instanceof SimpleStringRedisMessage) {
            SimpleStringRedisMessage simpleStringRedisMessage = (SimpleStringRedisMessage) msg;
            return simpleStringRedisMessage.content();
        }
        if (msg instanceof FullBulkStringRedisMessage) {
            FullBulkStringRedisMessage fullBulkStringRedisMessage = (FullBulkStringRedisMessage) msg;
            if (fullBulkStringRedisMessage.isNull()) {
                return null;
            }
            return fullBulkStringRedisMessage.content().toString(CharsetUtil.UTF_8);
        }
        if (msg instanceof IntegerRedisMessage) {
            IntegerRedisMessage integerRedisMessage = (IntegerRedisMessage) msg;
            return integerRedisMessage.value();
        }
        if (msg instanceof ArrayRedisMessage) {
            ArrayRedisMessage arrayRedisMessage = (ArrayRedisMessage) msg;
            if (arrayRedisMessage.isNull()) {
                return null;
            }
            List<RedisMessage> children = arrayRedisMessage.children();
            List<Object> result = new LinkedList<>();
            for (RedisMessage rm : children) {
                if (rm instanceof FullBulkStringRedisMessage) {
                    FullBulkStringRedisMessage fullBulkStringRedisMessage = (FullBulkStringRedisMessage) rm;
                    String m = fullBulkStringRedisMessage.isNull() ? null : fullBulkStringRedisMessage.content().toString(CharsetUtil.UTF_8);
                    result.add(m);
                }
                else if (rm instanceof IntegerRedisMessage) {
                    IntegerRedisMessage integerRedisMessage = (IntegerRedisMessage) rm;
                    long m = integerRedisMessage.value();
                    result.add(m);
                }
            }
            return result;
        }
        return new RedisException("unknown response type: " + msg.getClass());
    };
}

public enum RedisCommand {

    PUBLISH(INTEGER_RESPONSE_HANDLER),
    EVAL(ANY_RESPONSE_HANDLER),
    GET(FULL_BULK_STRING_RESPONSE_HANDLER),
    SET(SIMPLE_STRING_RESPONSE_HANDLER),
    DEL(INTEGER_RESPONSE_HANDLER),
    HGET(FULL_BULK_STRING_RESPONSE_HANDLER),
    HSET(INTEGER_RESPONSE_HANDLER),
    HDEL(INTEGER_RESPONSE_HANDLER),
    HGETALL(ARRAY_RESPONSE_HANDLER),
    RPUSH(INTEGER_RESPONSE_HANDLER)
    ;

    private final Function<Object, Object> responseHandler;

    RedisCommand(Function<Object, Object> responseHandler) {
        this.responseHandler = responseHandler;
    }

    public Object handleResponse(RedisMessage response) {
        return this.responseHandler.apply(response);
    }

    public RedisMessage toRedisMessage(String[] params, ByteBufAllocator allocator) {
        String command = this.name();
        RedisMessage redisMessage;
        if (params.length == 0) {
            redisMessage = new InlineCommandRedisMessage(command);
        } else {
            List<RedisMessage> messages = new ArrayList<>(params.length + 1);
            messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(allocator, command)));
            for (int i = 0; i < params.length; i++) {
                String p = params[i];
                //这里要注意一下多个参数中有null的情况，redis命令只接受字符串
                if (p == null) {
                    Logger.warn("redis command " + command + "has null param at index " + i);
                    return null;
                } else if ("".equals(p)) {
                    messages.add(FullBulkStringRedisMessage.EMPTY_INSTANCE);
                } else {
                    messages.add(new FullBulkStringRedisMessage(ByteBufUtil.writeUtf8(allocator, p)));
                }
            }
            redisMessage = new ArrayRedisMessage(messages);
        }
        return redisMessage;
    }
}

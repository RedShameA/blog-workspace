package io.iwd.common;

import io.iwd.common.command.ServicesVersionQuery;
import io.iwd.common.command.SrsAllStreamInfoQuery;
import io.iwd.common.command.SrsVersionQuery;

/**
 * 公共命令集。
 */
public class Common {

    /**
     * srs版本查询命令。
     */
    public static SrsVersionQuery srsVersionQuery() {
        return new SrsVersionQuery();
    }

    /**
     * srs全部流信息查询命令。
     */
    public static SrsAllStreamInfoQuery srsAllStreamInfoQuery() {
        return new SrsAllStreamInfoQuery();
    }

    /**
     * 服务版本查询命令。
     */
    public static ServicesVersionQuery servicesVersionQuery() {
        return new ServicesVersionQuery();
    }

}

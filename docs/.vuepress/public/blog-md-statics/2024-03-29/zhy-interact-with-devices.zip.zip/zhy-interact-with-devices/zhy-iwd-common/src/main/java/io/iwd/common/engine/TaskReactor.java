package io.iwd.common.engine;

import io.iwd.common.environment.ComponentThread;
import io.iwd.common.event.TaskProceedEvent;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.util.SpscProducerBlockingQueue;
import io.iwd.common.ext.util.StringUtil;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.LockSupport;
import java.util.function.BiFunction;

import static java.lang.Thread.State.TERMINATED;

/**
 * 任务执行器。由此线程执行任务。
 */
public class TaskReactor extends Thread implements TaskExecutor, ComponentThread {

    /**
     * 所有由此执行器负责执行的任务。
     * taskId -> taskContext
     */
    protected final Map<String, TaskContext> taskMap;

    /**
     * spscQueue集合，key为生产者线程，value为{@link TaskChannel}。
     */
    protected final ConcurrentMap<Thread, TaskChannel> taskChannelMap;

    /**
     * 延迟任务堆。
     */
    protected final DelayedTaskHeap delayedTaskHeap;

    /**
     * 此执行器是否被关闭的标志。
     */
    protected volatile boolean shutdown;

    /**
     * 此执行器是否正在挂起过程中的标志。
     */
    protected volatile boolean parking;

    /**
     * 此执行器当前处理的任务上下文。
     */
    protected TaskContext currentContext;

    /**
     * 标准构造器。
     * @param name 执行器线程的名称。
     */
    public TaskReactor(String name) {
        super(name);
        this.shutdown = false;
        this.parking = false;
        this.taskMap = new HashMap<>(64);
        this.taskChannelMap = new ConcurrentHashMap<>(32, 0.5f);
        this.delayedTaskHeap = new DelayedTaskHeap();
    }

    //event-loop主循环===================================================================================================

    @Override
    public void run() {
        mainLoop();
        Logger.warn("task reactor shutdown");
        cleanAfterShutdown();
    }

    /**
     * TaskReactor的工作循环。
     */
    protected void mainLoop() {
        Throwable throwableInLastLoop = null;

        mainLoop:
        while (!this.shutdown) {
            try {
                if (throwableInLastLoop != null) {
                    Logger.warn("reactor catch a throwable in last loop: " + throwableInLastLoop.getMessage());
                    throwableInLastLoop = null;
                }

                int ran = this.doAllRunnable();
                if (ran != 0) {
                    continue;
                }
                //检查延迟任务堆中是否有到期任务
                DelayedRunnable delayedRunnable = this.delayedTaskHeap.peek();
                if (delayedRunnable != null && delayedRunnable.expiredMillis <= System.currentTimeMillis()) {
                    this.delayedTaskHeap.remove();
                    delayedRunnable.run();
                    continue;
                }
                //检查是否有任务超时
                int killed = killAllTimeoutTask();
                if (killed != 0) {
                    continue;
                }

                //没有找到超时任务，清理TaskChannel
                List<Thread> terminated = new LinkedList<>();
                for (Thread t : this.taskChannelMap.keySet()) {
                    if (t.getState() == TERMINATED) {
                        terminated.add(t);
                    }
                }
                for (Thread t : terminated) {
                    Logger.info("Thread " + t.getName() + " is terminated, remove TaskChannel");
                    this.taskChannelMap.remove(t);
                }
                //调整延迟堆
                this.delayedTaskHeap.reallocate();

                //找到最先触发超时的任务
                TaskContext first = null;
                long timestamp = Long.MAX_VALUE;
                for (TaskContext context : this.taskMap.values()) {
                    long contextTimeoutMills = context.getTimestamp();
                    if (contextTimeoutMills > 0L && contextTimeoutMills < timestamp) {
                        timestamp = contextTimeoutMills;
                        first = context;
                    }
                }

                //进入非活跃模式
                this.parking = true;

                sleepyLoop:
                while (true) {
                    if (this.shutdown) {
                        this.parking = false;
                        break mainLoop;
                    }

                    ran = this.doAllRunnable();
                    if (ran != 0) {
                        this.parking = false;
                        continue mainLoop;
                    }

                    //如果延迟任务先于超时触发
                    if (delayedRunnable != null && delayedRunnable.expiredMillis <= timestamp) {
                        long diff = delayedRunnable.expiredMillis - System.currentTimeMillis();
                        while (true) {
                            if (diff <= 0) {
                                this.parking = false;
                                this.delayedTaskHeap.remove();
                                delayedRunnable.run();
                                continue mainLoop;
                            }
                            //挂起等待新任务或到达延迟时间唤醒
                            LockSupport.parkNanos(diff * 1_000_000);
                            //被唤醒，检查是不是到期唤醒，如果不是，重新进入非活跃循环
                            diff = delayedRunnable.expiredMillis - System.currentTimeMillis();
                            if (diff > 0) {
                                continue sleepyLoop;
                            }
                        }
                    }

                    //如果有等待触发超时的任务
                    else if (first != null) {
                        long diff = timestamp - System.currentTimeMillis();
                        while (true) {
                            if (diff <= 0) {
                                this.parking = false;
                                killTimeoutTask(first);
                                continue mainLoop;
                            }
                            //挂起等待新任务或到达超时时间唤醒
                            LockSupport.parkNanos(diff * 1_000_000);
                            //被唤醒，检查是不是超时唤醒，如果不是，重新进入非活跃循环
                            diff = timestamp - System.currentTimeMillis();
                            if (diff > 0) {
                                continue sleepyLoop;
                            }
                        }
                    }
                    //没有任何可做的事，挂起直至被唤醒
                    LockSupport.park();
                }
            } catch (Throwable throwable) {
                throwableInLastLoop = throwable;
            }
        }
    }

    /**
     * 执行所有可以执行的任务。
     * @return 执行的任务数。
     */
    protected int doAllRunnable() {
        int ran = 0;
        for (TaskChannel taskChannel : this.taskChannelMap.values()) {
            Runnable r;
            while (true) {
                r = taskChannel.get();
                if (r == null) {
                    break;
                }
                r.run();
                ran++;
            }
        }
        return ran;
    }

    /**
     * 终结一个超时的任务。
     * @param context 任务上下文。
     */
    protected void killTimeoutTask(TaskContext context) {
        context.getTaskResult().setTimeout(context.getTimeoutMessage());
        Logger.info("task [" + context.getTaskId() + "] timeout");
        clearTask(context.getTaskId());
    }

    /**
     * 终结所有超时的任务。
     * @return 被终结的任务数。
     */
    protected int killAllTimeoutTask() {
        long currentTimeMillis = System.currentTimeMillis();
        List<TaskContext> timeoutList = new LinkedList<>();
        for (TaskContext context : this.taskMap.values()) {
            long contextTimeoutMills = context.getTimestamp();
            if (contextTimeoutMills > 0 && contextTimeoutMills <= currentTimeMillis) {
                timeoutList.add(context);
            }
        }
        for (TaskContext context : timeoutList) {
            killTimeoutTask(context);
        }
        return timeoutList.size();
    }

    /**
     * 此执行器发现{@link TaskReactor#shutdown}被置为true后，跳出循环后，在线程终结前的清理工作。
     */
    protected void cleanAfterShutdown() {}

    //内部执行任务的方法===================================================================================================

    /**
     * 执行任务节点。
     * @param context 任务上下文。
     * @param data 新输入的数据。
     */
    protected void executeTask(TaskContext context, Object data) {
        loop: while (true) {
            String taskId = context.getTaskId();
            //检查是否执行了过多的片段
            if (context.getExecutedTaskCount() >= 0xffff) {
                context.getTaskResult().setFailed("task executed too many steps");
                clearTask(taskId);
                Logger.error("task [" + taskId + "] executed too many steps, check if there have a logic loop");
                return;
            }
            Task next = context.getNext();
            String nodeName = context.getNextNodeName();
            if (next == null) {
                context.getTaskResult().setFailed("can not find next");
                clearTask(taskId);
                Logger.warn("task [" + taskId + "] can not find next (" + nodeName + ")");
                return;
            }
            context.setInput(data); //设置输入参数
            context.setTimestamp(0L); //清除时间戳
            context.clearTaskState(); //清除任务状态，以防失控
            this.currentContext = context; //设置当前执行的context
            try {
                next.execute(context); //真正执行任务节点
            } catch (Exception t) {
                context.getTaskResult().setFailed(t.getMessage());
                clearTask(taskId);
                StackTraceElement[] stackTrace = t.getStackTrace();
                String point = null;
                if (stackTrace != null && stackTrace.length > 0) {
                    StackTraceElement stackTraceElement = stackTrace[0];
                    if (stackTraceElement != null) {
                        point = stackTrace[0].toString();
                    }
                }
                Logger.error("task [" + taskId + "] unexpected terminated (" + nodeName + ") with exception " + t.getClass().getName() +
                        "(" + t.getMessage() + "), at " + point);
                t.printStackTrace();
                return;
            } finally {
                this.currentContext = null;
            }
            context.incrementExecutedTaskCount(); //已执行的任务节点数+1
            TaskContext.TaskState taskState = context.getTaskState();
            if (taskState == null) {
                //任务失控
                context.getTaskResult().setFailed("task lose control, you need to set the state at each step");
                clearTask(taskId);
                Logger.error("task [" + taskId + "] lose control -? " + nodeName);
                return;
            }
            try {
                switch (taskState) {
                    case CONTINUED:
                        data = null;
                        Logger.info("task [" + taskId + "] continued -> " + context.getNextNodeName());
                        continue loop;
                    case DELAYED:
                        if (insertDelayedRunnable(taskId, -context.getTimestamp())) {
                            Logger.info("task [" + taskId + "] delayed -| " + context.getNextNodeName());
                        } else {
                            context.getTaskResult().setFailed("reactor has too many delayed task");
                            clearTask(taskId);
                            Logger.error("task [" + taskId + "] can not put into heap, task failed");
                        }
                        break loop;
                    case AWAIT:
                        Logger.info("task [" + taskId + "] await -| " + context.getNextNodeName());
                        break loop;
                    case COMPLETED:
                        //设置任务结果容器中的完成结果
                        Object completedMessage = context.getCompletedMessage();
                        context.getTaskResult().setCompleted(completedMessage);
                        clearTask(taskId);
                        Logger.info("task [" + taskId + "] completed -* " + completedMessage);
                        break loop;
                    case FAILED:
                        //设置任务结果容器中的失败结果
                        Object failedMessage = context.getFailedMessage();
                        context.getTaskResult().setFailed(failedMessage);
                        clearTask(taskId);
                        Logger.warn("task [" + taskId + "] failed -# " + failedMessage);
                        break loop;
                }
            } finally {
                //清除任务输入
                context.setInput(null);
            }
        }
    }

    /**
     * 清理存储的任务信息。
     * @param taskId 任务id。
     */
    protected void clearTask(String taskId) {
        this.taskMap.remove(taskId);
    }

    /**
     * 将一个延迟执行的任务插入到堆中。
     * @param taskId 任务id。
     * @param expiredMills 超时毫秒。
     * @return 是否插入成功。
     */
    protected boolean insertDelayedRunnable(String taskId, long expiredMills) {
        Runnable runnable = () -> {
            try {
                //通过任务id获取到之前存储的任务上下文
                TaskContext context = this.taskMap.get(taskId);
                //此时任务上下文如果为null 说明任务不存在
                if (context == null) {
                    Logger.info("task [" + taskId + "] not exist");
                    return;
                }
                //执行任务
                Logger.info("task [" + taskId + "] expired -> " + context.getNextNodeName());
                executeTask(context, null);
            } catch (Exception t) {
                clearTask(taskId);
                t.printStackTrace();
            }
        };
        DelayedRunnable delayedRunnable = new DelayedRunnable(runnable, expiredMills);
        return this.delayedTaskHeap.put(delayedRunnable);
    }

    /**
     * 关闭执行器。
     */
    protected void close() {
        this.shutdown = true;
        LockSupport.unpark(this);
    }


    //TaskExecutor接口实现===============================================================================================

    /**
     * 返回执行器当前正在执行的任务上下文。
     * @return 执行器当前正在执行的任务上下文。
     */
    @Override
    public TaskContext getContext() {
        if (Thread.currentThread() != this) {
            throw new IllegalStateException("another thread called getContext()");
        }
        return this.currentContext;
    }

    //TaskReactorManager分发任务的接口====================================================================================

    /**
     * 继续执行某个任务。
     * @param taskId 任务id。
     * @param data 新输入的数据。
     */
    public void taskProceed(String taskId, Object data) {
        //提交给执行线程
        Runnable r = () -> {
            try {
                //通过任务id获取到之前存储的任务上下文
                TaskContext context = this.taskMap.get(taskId);
                //此时任务上下文如果为null 说明任务不存在
                if (context == null) {
                    Logger.info("task [" + taskId + "] not exist");
                    return;
                }
                //执行任务
                Logger.info("task [" + taskId + "] proceed -> " + context.getNextNodeName());
                executeTask(context, data);
            } catch (Exception t) {
                clearTask(taskId);
                t.printStackTrace();
            }
        };
        TaskChannel taskChannel = this.getTaskChannel();
        taskChannel.put(r);
    }

    /**
     * 开始执行任务。
     * @param taskFlow 任务流程。
     * @param taskId 任务id。
     * @param entranceName 任务入口节点的名称。
     * @param data 输入的数据。
     * @param taskResult 任务结果容器。
     */
    public void taskStart(TaskFlow taskFlow, String taskId, String entranceName, Object data, TaskResult taskResult) {
        //提交给执行线程
        Runnable r = () -> {
            try {
                //如果任务id已经存在则返回
                if (this.taskMap.containsKey(taskId)) {
                    Logger.warn("task [" + taskId + "] already exists, but reactor received start event");
                    return;
                }
                //创建任务上下文
                //无论是否指定入口 最终都应该有一个入口被选中
                TaskContext context = StringUtil.isEmpty(entranceName) ?
                        taskFlow.newContext(taskId, this, taskResult) :
                        taskFlow.newContext(taskId, this, taskResult, entranceName);
                //记录下任务id与对应的任务上下文
                this.taskMap.put(taskId, context);
                //执行任务
                Logger.info("task [" + taskId + "] (" + taskFlow.getPrefix() + ":" + taskFlow.getName() + ") start -> " + context.getNextNodeName());
                executeTask(context, data);
            } catch (Exception t) {
                clearTask(taskId);
                t.printStackTrace();
            }
        };
        TaskChannel taskChannel = this.getTaskChannel();
        taskChannel.put(r);
    }

    /**
     * 获取{@link TaskChannel}，用于提交任务。
     * @return TaskChannel。
     */
    protected TaskChannel getTaskChannel() {
        Thread t = Thread.currentThread();
        TaskChannel taskChannel = this.taskChannelMap.get(t);
        if (taskChannel == null) {
            if (t == this) {
                taskChannel = new SelfConsumeQueue();
            } else {
                int size = t instanceof ComponentThread ? ((ComponentThread) t).spscQueueSize() : 0x80;
                taskChannel = new DefaultTaskChannel(t, size);
            }
            this.taskChannelMap.put(t, taskChannel);
        }
        return taskChannel;
    }

    //内部结构===========================================================================================================

    /**
     * 任务管道，此执行器会从管道中取任务执行。各种生产者线程会将任务提交到管道中。
     */
    protected interface TaskChannel {
        void put(Runnable runnable);
        Runnable get();
    }

    /**
     * 默认的任务管道实现，基于生产阻塞的spscQueue。
     */
    protected class DefaultTaskChannel extends SpscProducerBlockingQueue<Runnable> implements TaskChannel {

        public DefaultTaskChannel(Thread producer, int size) {
            super(producer, size);
        }

        @Override
        public void put(Runnable e) {
            super.put(e);
            if (TaskReactor.this.parking) {
                LockSupport.unpark(TaskReactor.this);
            }
        }
    }

    /**
     * 此执行器线程自己使用的队列。
     * 如果此执行器线程在向自己提交任务时使用基于生产阻塞的spscQueue，那么就会出现死锁。
     */
    protected static class SelfConsumeQueue implements TaskChannel {

        protected Node head;
        protected Node tail;

        public void put(Runnable runnable) {
            Node node = new Node(runnable);
            if (this.tail == null) {
                this.head = this.tail = node;
                return;
            }
            this.tail.next = node;
            this.tail = node;
        }

        @Override
        public Runnable get() {
            Node h = this.head;
            if (h == null) {
                return null;
            }
            this.head = h.next;
            if (this.head == null) {
                this.tail = null;
            }
            return h.runnable;
        }

        protected static class Node {
            protected final Runnable runnable;
            protected Node next;
            protected Node(Runnable runnable) {
                this.runnable = runnable;
            }
        }

    }

    /**
     * 延迟任务容器。
     */
    protected static class DelayedRunnable implements Runnable, Comparable<DelayedRunnable> {

        protected final Runnable runnable;

        protected final long expiredMillis;

        public DelayedRunnable(Runnable runnable, long expiredMillis) {
            this.runnable = runnable;
            this.expiredMillis = expiredMillis;
        }

        @Override
        public void run() {
            this.runnable.run();
        }

        @Override
        public int compareTo(DelayedRunnable o) {
            long diff = this.expiredMillis - o.expiredMillis;
            return diff < 0 ? -1 : (diff > 0 ? 1 : 0);
        }
    }

    /**
     * 延迟任务堆。
     */
    protected static class DelayedTaskHeap {

        protected static final int HEAP_MIN_CAPACITY =  1 << 4;
        protected static final int HEAP_MAX_CAPACITY =  1 << 15;

        protected int size;

        protected DelayedRunnable[] heap;

        protected DelayedTaskHeap() {
            this.size = 0;
            this.heap = new DelayedRunnable[HEAP_MIN_CAPACITY];
        }

        protected boolean put(DelayedRunnable runnable) {
            //检查堆是否需要膨胀
            if (this.size == this.heap.length) {
                if (this.heap.length >= HEAP_MAX_CAPACITY) {
                    Logger.error("heap full");
                    return false;
                }
                int newCapacity = this.heap.length << 1;
                DelayedRunnable[] newHeap = new DelayedRunnable[newCapacity];
                System.arraycopy(this.heap, 0, newHeap, 0, this.heap.length);
                this.heap = newHeap;
            }
            int index = this.size;
            this.heap[index] = runnable;
            //向上调整
            while (true) {
                int parent = (index - 1) >> 1;
                if (parent < 0) {
                    break;
                }
                if (this.heap[parent].compareTo(runnable) <= 0) {
                    break;
                }
                this.heap[index] = this.heap[parent];
                this.heap[parent] = runnable;
                index = parent;
            }
            this.size++;
            return true;
        }

        protected DelayedRunnable remove() {
            if (this.size == 0) {
                return null;
            }
            DelayedRunnable first = this.heap[0];
            this.heap[0] = this.heap[this.size - 1];
            this.heap[this.size - 1] = null;
            this.size--;
            //向下调整
            int parent = 0;
            while (true) {
                int child = parent * 2 + 1;
                if (child >= this.size) {
                    break;
                }
                if (child + 1 < this.size && this.heap[child + 1].compareTo(this.heap[child]) < 0) {
                    child++;
                }
                if (this.heap[parent].compareTo(this.heap[child]) <= 0) {
                    break;
                }
                DelayedRunnable p = this.heap[parent];
                this.heap[parent] = this.heap[child];
                this.heap[child] = p;
                parent = child;
            }
            return first;
        }

        protected DelayedRunnable peek() {
            return this.heap[0];
        }

        protected void reallocate() {
            //检查堆是否需要收缩 如果当前大小小于等于容量的四分之一 且收缩后不低于最小容量
            if (this.size <= this.heap.length >> 2 && this.heap.length >> 1 >= HEAP_MIN_CAPACITY) {
                int newCapacity = this.heap.length >> 1;
                DelayedRunnable[] newHeap = new DelayedRunnable[newCapacity];
                System.arraycopy(this.heap, 0, newHeap, 0, this.size);
                this.heap = newHeap;
            }
        }

    }

}

package io.iwd.common.entity;

import io.iwd.common.ext.json.JsonObject;

import java.util.HashMap;
import java.util.Map;

public class ServiceStateInfo {

    private static final Map<Integer, String> serviceNameMap = new HashMap<>();

    static {
        serviceNameMap.put(101,"FCM");
        serviceNameMap.put(102,"SIP");
        serviceNameMap.put(103,"DSS");
        serviceNameMap.put(104,"SRS");
        serviceNameMap.put(201,"IPM");
    }

    public ServiceStateInfo(JsonObject stateInfo) {
        Integer serviceId = stateInfo.getInteger("serviceId");
        String serviceName = serviceNameMap.get(serviceId);

        this.serviceId = serviceId;
        this.serviceName = serviceName;

        String serverName = stateInfo.getString("serverName");
        String version = stateInfo.getString("version");
        Boolean alarm = stateInfo.getBoolean("alarm");

        this.serverName = serverName;
        this.version = version;
        this.alarm = alarm;

        if (alarm != null && alarm) {

            String time = stateInfo.getString("time");
            Integer level = stateInfo.getInteger("level");
            String msg = stateInfo.getString("msg");

            this.time = time;
            this.level = level;
            this.msg = msg;
        } else {

            JsonObject server = stateInfo.getJsonObject("server").copy();
            JsonObject sys = server.getJsonObject("sys").copy();

            this.server = server;
            this.sys = sys;

            this.mac = server.getString("mac").replaceAll("-", ":").toUpperCase();

            JsonObject jvm = server.getJsonObject("jvm").copy();
            JsonObject cpu = server.getJsonObject("cpu").copy();
            JsonObject mem = server.getJsonObject("mem").copy();
            JsonObject disk = server.getJsonObject("sysFile").copy();

            this.jvm = jvm;
            this.cpu = cpu;
            this.mem = mem;
            this.disk = disk;

            String ip = sys.getString("computerIp");
            Integer port = sys.getInteger("port");

            this.computerIp = ip;
            this.port = port;

            String computerName = sys.getString("computerName");
            String osName = sys.getString("osName");
            String osArch = sys.getString("osArch");
            Integer cpuNum = cpu.getInteger("cpuNum");
            Float cpuFree = cpu.getFloat("free");
            Float cpuUsage = 100.0f - cpuFree;

            this.computerName = computerName;
            this.osName = osName;
            this.osArch = osArch;
            this.cpuNum = cpuNum;
            this.cpuFree = cpuFree;
            this.cpuUsage = cpuUsage;

            Float memFree = mem.getFloat("free");
            Float memTotal = mem.getFloat("total");
            Float memUsage = mem.getFloat("usage");
            Float memUsed = mem.getFloat("used");

            this.memFree = memFree;
            this.memTotal = memTotal;
            this.memUsage = memUsage;
            this.memUsed = memUsed;

            String startTime = jvm.getString("startTime");
            String runtime = jvm.getString("runTime");

            this.startTime = startTime;
            this.runtime = runtime;

            Float jvmFree = jvm.getFloat("free");
            Float jvmTotal = jvm.getFloat("total");
            Float jvmUsage = jvm.getFloat("usage");
            Float jvmUsed = jvm.getFloat("used");

            this.jvmFree = jvmFree;
            this.jvmTotal = jvmTotal;
            this.jvmUsage = jvmUsage;
            this.jvmUsed = jvmUsed;

            Float diskFree = disk.getFloat("free");
            Float diskTotal = disk.getFloat("total");
            Float diskUsage = disk.getFloat("usage");
            Float diskUsed = disk.getFloat("used");

            this.diskFree = diskFree;
            this.diskTotal = diskTotal;
            this.diskUsage = diskUsage;
            this.diskUsed = diskUsed;
        }

    }

    private Integer serviceId;

    private String serviceName;

    private String serverName;

    private String version;

    private Boolean alarm;

    private String time;

    private Integer level;

    private String msg;

    private JsonObject server;

    private JsonObject sys;

    private String mac;

    private JsonObject jvm;

    private String computerIp;

    private Integer port;

    private String startTime;

    private String runtime;

    private JsonObject cpu;

    private JsonObject mem;

    private JsonObject disk;

    private String computerName;

    private String osName;

    private String osArch;

    private Integer cpuNum;

    private Float cpuFree;

    private Float cpuUsage;

    private Float memFree;

    private Float memTotal;

    private Float memUsage;

    private Float memUsed;

    private Float jvmFree;

    private Float jvmTotal;

    private Float jvmUsage;

    private Float jvmUsed;

    private Float diskFree;

    private Float diskTotal;

    private Float diskUsage;

    private Float diskUsed;

    public Integer getServiceId() {
        return serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getServerName() {
        return serverName;
    }

    public String getVersion() {
        return version;
    }

    public Boolean getAlarm() {
        return alarm;
    }

    public String getTime() {
        return time;
    }

    public Integer getLevel() {
        return level;
    }

    public String getMsg() {
        return msg;
    }

    public JsonObject getServer() {
        return server;
    }

    public JsonObject getSys() {
        return sys;
    }

    public String getMac() {
        return mac;
    }

    public JsonObject getJvm() {
        return jvm;
    }

    public String getComputerIp() {
        return computerIp;
    }

    public Integer getPort() {
        return port;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getRuntime() {
        return runtime;
    }

    public JsonObject getCpu() {
        return cpu;
    }

    public JsonObject getMem() {
        return mem;
    }

    public JsonObject getDisk() {
        return disk;
    }

    public String getComputerName() {
        return computerName;
    }

    public String getOsName() {
        return osName;
    }

    public String getOsArch() {
        return osArch;
    }

    public Integer getCpuNum() {
        return cpuNum;
    }

    public Float getCpuFree() {
        return cpuFree;
    }

    public Float getCpuUsage() {
        return cpuUsage;
    }

    public Float getMemFree() {
        return memFree;
    }

    public Float getMemTotal() {
        return memTotal;
    }

    public Float getMemUsage() {
        return memUsage;
    }

    public Float getMemUsed() {
        return memUsed;
    }

    public Float getJvmFree() {
        return jvmFree;
    }

    public Float getJvmTotal() {
        return jvmTotal;
    }

    public Float getJvmUsage() {
        return jvmUsage;
    }

    public Float getJvmUsed() {
        return jvmUsed;
    }

    public Float getDiskFree() {
        return diskFree;
    }

    public Float getDiskTotal() {
        return diskTotal;
    }

    public Float getDiskUsage() {
        return diskUsage;
    }

    public Float getDiskUsed() {
        return diskUsed;
    }
}

package io.iwd.common.ext.misc;

import io.iwd.common.environment.ComponentThread;
import io.netty.util.concurrent.FastThreadLocalThread;

public class NettyComponentFastThreadLocalThread
        extends FastThreadLocalThread
        implements ComponentThread {

    public NettyComponentFastThreadLocalThread() {
    }

    public NettyComponentFastThreadLocalThread(Runnable target) {
        super(target);
    }

    public NettyComponentFastThreadLocalThread(ThreadGroup group, Runnable target) {
        super(group, target);
    }

    public NettyComponentFastThreadLocalThread(String name) {
        super(name);
    }

    public NettyComponentFastThreadLocalThread(ThreadGroup group, String name) {
        super(group, name);
    }

    public NettyComponentFastThreadLocalThread(Runnable target, String name) {
        super(target, name);
    }

    public NettyComponentFastThreadLocalThread(ThreadGroup group, Runnable target, String name) {
        super(group, target, name);
    }

    public NettyComponentFastThreadLocalThread(ThreadGroup group, Runnable target, String name, long stackSize) {
        super(group, target, name, stackSize);
    }
}

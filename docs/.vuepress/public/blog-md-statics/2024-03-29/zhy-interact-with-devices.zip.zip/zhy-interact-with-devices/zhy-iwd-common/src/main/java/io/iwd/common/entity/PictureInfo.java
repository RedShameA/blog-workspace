package io.iwd.common.entity;

import io.iwd.common.ext.json.JsonObject;

public abstract class PictureInfo {

    protected abstract void parse(JsonObject info);

    public PictureInfo(JsonObject info) {
        parse(info);
    }
}

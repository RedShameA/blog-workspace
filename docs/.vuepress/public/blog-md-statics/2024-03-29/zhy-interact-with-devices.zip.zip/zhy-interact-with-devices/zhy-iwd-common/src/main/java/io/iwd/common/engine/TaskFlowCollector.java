package io.iwd.common.engine;

import java.util.List;

/**
 * 任务流程收集器。用于收集每个包中所有的任务流程，方便注册。
 */
public interface TaskFlowCollector {

    /**
     * 返回{@link TaskFlow}列表。
     * @return TaskFlow列表。
     */
    List<TaskFlow> getTaskFlowList();

}

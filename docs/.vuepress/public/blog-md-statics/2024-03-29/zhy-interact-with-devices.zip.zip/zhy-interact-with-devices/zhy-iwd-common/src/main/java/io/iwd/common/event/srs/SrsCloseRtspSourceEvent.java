package io.iwd.common.event.srs;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;
import io.iwd.common.ext.util.Generator;

/**
 * srs关闭rtsp视频源的事件。
 */
public class SrsCloseRtspSourceEvent extends TaskStartEvent {

    public SrsCloseRtspSourceEvent(Object data) {
        super(null, "SrsCloseRtspSource", data, new TaskResult());
    }

    public String getTaskId() {
        return Generator.create32UniqueId();
    }

}

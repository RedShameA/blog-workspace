package io.iwd.common.environment;

@FunctionalInterface
public interface GlobalConfigurationBatchTask {

    void execute(GlobalConfigurationGetter conf);

}

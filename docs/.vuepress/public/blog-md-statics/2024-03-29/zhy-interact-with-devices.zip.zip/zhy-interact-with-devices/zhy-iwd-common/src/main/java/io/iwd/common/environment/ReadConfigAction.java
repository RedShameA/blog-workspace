package io.iwd.common.environment;

import io.iwd.common.engine.TaskContext;
import io.iwd.common.engine.TaskExecutor;
import io.iwd.common.event.TaskProceedEvent;
import io.iwd.common.ext.log.Logger;

import java.util.function.BiFunction;

public class ReadConfigAction {

    @FunctionalInterface
    public interface ReadTask {
        Object execute(GlobalConfiguration configuration);
    }

    final ReadTask readTask;
    String taskId;
    BiFunction<String, Object, TaskProceedEvent> eventConstructor;

    public ReadConfigAction(ReadTask readTask) {
        this.readTask = readTask;
    }

    public ReadConfigAction forTask(String taskId) {
        this.taskId = taskId;
        return this;
    }

    public ReadConfigAction onRead(BiFunction<String, Object, TaskProceedEvent> eventConstructor) {
        this.eventConstructor = eventConstructor;
        return this;
    }

    public void start() {
        Thread currentThread = Thread.currentThread();
        if (currentThread instanceof TaskExecutor) {
            TaskExecutor taskExecutor = (TaskExecutor) currentThread;
            TaskContext context = taskExecutor.getContext();
            if (this.taskId == null) {
                forTask(context.getTaskId());
            }
            if (this.eventConstructor == null) {
                onRead(context.getDefaultTaskProceedEventConstructor());
            }
        }
        if (this.taskId == null || this.eventConstructor == null) {
            Logger.warn("read config action must have task id and event constructor");
            return;
        }
        EnvironmentHolder.get().configReader().read(this);
    }

}

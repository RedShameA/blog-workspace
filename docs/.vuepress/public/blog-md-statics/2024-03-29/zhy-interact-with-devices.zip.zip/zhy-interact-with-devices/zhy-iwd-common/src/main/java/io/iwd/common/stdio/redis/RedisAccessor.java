package io.iwd.common.stdio.redis;

public interface RedisAccessor {

    void execute(RedisCommandWrapper redisCommandWrapper);

}

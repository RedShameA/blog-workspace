package io.iwd.common.ext.util;

/**
 * 通用结果码.
 * 结果码只占用int的由高到低第2个字节，第3、4个字节用来标记在代码中的位置，在同一个Task中，不同位置生成的结果码应尽可能不同。
 * 结果码由高到低第1个字节不使用，以避免可能的负数结果和过长的十进制显示。
 */
public final class Code {

    /**
     * 任务成功完成。
     */
    public static final int NORMAL_SUCCESS = 0x10 << 16;

    /**
     * 任务成功完成，但产生了一些可以接受的问题。
     */
    public static final int SUCCESS_WITH_ACCEPTABLE_PROBLEM = 0x11 << 16;

    public static final int SUCCESS_WITH_NO_RESPONSE = 0x12 << 16;

    /**
     * 任务成功完成，但过程中进行过重试操作。
     */
    public static final int SUCCESS_WITH_RETRY = 0x13 << 16;

    /**
     * 任务完成，但产生了意料之外的结果。
     */
    public static final int COMPLETED_WITH_UNEXPECTED_RESULT = 0x20 << 16;

    /**
     * 任务出现异常，但仍视为完成。
     */
    public static final int EXCEPTIONS_OCCUR_BUT_CONSIDERED_COMPLETED = 0x21 << 16;

    /**
     * 任务失败，但仍视为完成。
     */
    public static final int FAILED_BUT_CONSIDERED_COMPLETED = 0x22 << 16;

    /**
     * 任务超时，但仍视为完成。
     */
    public static final int TIMEOUT_BUT_CONSIDERED_COMPLETED = 0X23 << 16;

    /**
     * 任务超时并失败。
     */
    public static final int TIMEOUT_AND_FAILED = 0x30 << 16;

    /**
     * 任务失败，因为非法的初始参数。
     */
    public static final int FAILED_WITH_ILLEGAL_INIT_PARAMS = 0x40 << 16;

    /**
     * 任务失败，因为内部服务出错。
     */
    public static final int FAILED_WITH_INTERNAL_SERVER_ERROR = 0X41 << 16;

    /**
     * 任务失败，因为中间件出错。
     */
    public static final int FAILED_WITH_MIDDLEWARE_ERROR = 0x42 << 16;

    /**
     * 任务失败，因为锁被占用。
     */
    public static final int FAILED_WITH_LOCK_OCCUPIED = 0x43 << 16;

    /**
     * 任务失败，因为出现了非法的数据。
     */
    public static final int FAILED_WITH_ILLEGAL_DATA = 0x44 << 16;


    public static boolean isCompleted(int code) {
        return ((code >>> 20) & 0x0f) <= 2;
    }

    public static boolean isTimeout(int code) {
        return ((code >>> 20) & 0x0f) == 3;
    }

    public static boolean isFailed(int code) {
        return ((code >>> 20) & 0x0f) == 4;
    }

}

package io.iwd.common.command;

/**
 * 最简单的命令接口, 你可以忽略或等待结果。
 * 只应调用ignored(),await()两个个方法中的一个，并且只应调用一次。
 * @param <R> await()的返回类型
 */
public interface Command<R> {

    /**
     * 开始任务，忽略结果。对此方法的调用应立即返回，不会阻塞线程。
     */
    void ignore();

    /**
     * 开始任务，等待结果，对此方法的调用会阻塞线程，直到结果容器{@link io.iwd.common.engine.TaskResult}变为一种稳定状态。
     * @return 命令执行的结果。
     */
    default R await() {
        return this.await(0L);
    }

    /**
     * 开始任务，等待结果，对此方法的调用会阻塞线程。
     * 与{@link Command#await()}相比，此方法允许设置一个大于0的最大等待时间，单位毫秒。
     * 等待线程将在达到最大等待时间后被唤醒，或者在命令产生结果后被唤醒。
     * 当等待线程被唤醒时，它将根据那时的结果容器{@link io.iwd.common.engine.TaskResult}的状态，来决定返回给调用者一个什么样的结果。
     * @param time 最长等待时间，毫秒。如果传入一个小于等于0的参数，那么等同于调用{@link Command#await()}。
     * @return 命令执行的结果。
     */
    R await(long time);

    /**
     * 返回命令的名字。
     * @return 命令的名字
     */
    default String name() {
        return this.getClass().getSimpleName();
    }

}

package io.iwd.common.command;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.entity.ServiceVersionInfo;
import io.iwd.common.event.CommonDefaultTaskStartEvent;
import io.iwd.common.ext.json.JsonObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 服务版本查询命令。
 */
public class ServicesVersionQuery extends AdvancedCommand<List<ServiceVersionInfo>> {

    private Integer expectedServiceCount;

    /**
     * 设置期望响应的服务数。
     * @param expectedServiceCount 期望响应的服务数。
     * @return ServicesVersionQuery命令对象。
     */
    public ServicesVersionQuery setExpectedServiceCount(Integer expectedServiceCount) {
        this.expectedServiceCount = expectedServiceCount;
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        if (this.expectedServiceCount == null || this.expectedServiceCount < 1 || this.expectedServiceCount > 255) {
            throw new IllegalArgumentException("common expected service count error");
        }
        return super.taskActive(null, "ServicesVersionQuery", null, this.expectedServiceCount, CommonDefaultTaskStartEvent::new);
    }

    @Override
    public List<ServiceVersionInfo> await(long time) {
        return super.await(result -> {
            JsonObject rlt = (JsonObject) result.getResult();
            if (rlt == null) {
                return Collections.emptyList();
            }
            JsonObject data = rlt.getJsonObject("data");
            if (data == null) {
                return Collections.emptyList();
            }
            List<ServiceVersionInfo> list = new ArrayList<>(rlt.size());
            for (String name : data.keySet()) {
                String version = data.getString(name);
                ServiceVersionInfo versionInfo = new ServiceVersionInfo(name, version);
                list.add(versionInfo);
            }
            return list;
        }, time);
    }

}

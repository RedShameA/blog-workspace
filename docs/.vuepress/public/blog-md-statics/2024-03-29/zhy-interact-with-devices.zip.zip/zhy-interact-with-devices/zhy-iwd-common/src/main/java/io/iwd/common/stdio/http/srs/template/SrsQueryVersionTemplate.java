package io.iwd.common.stdio.http.srs.template;

import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.http.AbstractHttpTemplate;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.*;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.CharsetUtil;

import java.net.InetSocketAddress;

public class SrsQueryVersionTemplate extends AbstractHttpTemplate {

    private final String srsApiIp;

    private final int srsApiPort;

    public SrsQueryVersionTemplate(boolean ssl, String ip, int port) {
        if (StringUtil.isEmpty(ip)) {
            throw new IllegalArgumentException("SrsQueryVersionTemplate: param ip can not be empty");
        }

        if (port < 0 || port > 65535) {
            throw new IllegalArgumentException("SrsQueryVersionTemplate: param port must > 0 && < 65535");
        }
        super.ssl = ssl;
        this.srsApiIp = ip;
        this.srsApiPort = port;
    }

    @Override
    protected Bootstrap getBootstrap() {
        return new Bootstrap()
                .group(getEventLoopGroup())
                .channel(getChannelType())
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        //ssl处理器
                        if (SrsQueryVersionTemplate.super.ssl) {
                            pipeline.addLast(SslContextBuilder.forClient().build().newHandler(ch.alloc()));
                        }
                        //连接空闲(超时)监视器
                        pipeline.addLast(new IdleStateHandler(0, 0, 10));
                        //HTTP编解码器
                        pipeline.addLast(new HttpClientCodec());
                        //HTTP报文聚合器
                        pipeline.addLast(new HttpObjectAggregator(1024 * 4));
                        //SRS请求响应处理器
                        pipeline.addLast(new SrsQueryVersionHandler());
                    }
                })
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                .remoteAddress(new InetSocketAddress(this.srsApiIp, this.srsApiPort));
    }

    private class SrsQueryVersionHandler extends SimpleChannelInboundHandler<FullHttpResponse> {

        private final String url;

        SrsQueryVersionHandler() {
            this.url =
                    "http" + (SrsQueryVersionTemplate.super.ssl ? "s" : "") + "://" +
                    SrsQueryVersionTemplate.this.srsApiIp + ":" + SrsQueryVersionTemplate.this.srsApiPort +
                    "/api/v1/versions";
        }

        //处理response
        @Override
        protected void channelRead0(ChannelHandlerContext ctx, FullHttpResponse msg) throws Exception {
            ctx.close();
            int responseCode = msg.status().code();
            String responseBody = msg.content().toString(CharsetUtil.UTF_8);
            Logger.info("[" + SrsQueryVersionTemplate.super.taskId + "] " + this.url + " response: " + responseCode + " " + responseBody);

            if (responseCode != HttpResponseStatus.OK.code()) {
                //发布事件
                eventConstructor.apply(SrsQueryVersionTemplate.super.taskId, null).publish();
                return;
            }

            JsonObject responseJson = null;
            try {
                responseJson = JsonObject.from(responseBody);
            } catch (Exception e) {
                Logger.warn("error occurred while parsing json");
            }
            if (responseJson == null) {
                //发布事件
                eventConstructor.apply(SrsQueryVersionTemplate.super.taskId, null).publish();
                return;
            }

            JsonObject data = responseJson.getJsonObject("data");
            //发布事件
            eventConstructor.apply(SrsQueryVersionTemplate.super.taskId, data).publish();
        }

        //发送request
        @Override
        public void channelActive(ChannelHandlerContext ctx) throws Exception {
            FullHttpRequest request = new DefaultFullHttpRequest(
                    HttpVersion.HTTP_1_1,
                    HttpMethod.GET,
                    "/api/v1/versions");

            Logger.info("[" + SrsQueryVersionTemplate.super.taskId + "] GET " + this.url + " request: ");
            ctx.writeAndFlush(request);
        }

        //处理连接空闲
        @Override
        public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
            if (evt instanceof IdleStateEvent) {
                ctx.close();
                Logger.warn("SrsQueryVersionHandler IdleStateEvent Triggered, connection close...");
            }
        }


    }

}

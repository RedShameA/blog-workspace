package io.iwd.common.ext.misc;

import io.netty.util.concurrent.DefaultThreadFactory;

public class NettyComponentThreadFactory extends DefaultThreadFactory {

    public NettyComponentThreadFactory(Class<?> poolType) {
        super(poolType);
    }

    public NettyComponentThreadFactory(String poolName) {
        super(poolName);
    }

    public NettyComponentThreadFactory(Class<?> poolType, boolean daemon) {
        super(poolType, daemon);
    }

    public NettyComponentThreadFactory(String poolName, boolean daemon) {
        super(poolName, daemon);
    }

    public NettyComponentThreadFactory(Class<?> poolType, int priority) {
        super(poolType, priority);
    }

    public NettyComponentThreadFactory(String poolName, int priority) {
        super(poolName, priority);
    }

    public NettyComponentThreadFactory(Class<?> poolType, boolean daemon, int priority) {
        super(poolType, daemon, priority);
    }

    public NettyComponentThreadFactory(String poolName, boolean daemon, int priority, ThreadGroup threadGroup) {
        super(poolName, daemon, priority, threadGroup);
    }

    public NettyComponentThreadFactory(String poolName, boolean daemon, int priority) {
        super(poolName, daemon, priority);
    }

    @Override
    protected Thread newThread(Runnable r, String name) {
        return new NettyComponentFastThreadLocalThread(super.threadGroup, r, name);
    }

}

package io.iwd.common.engine;

/**
 * 任务初始化参数接口。用于封装任务开始时传入的参数，便于存取和校验。
 */
public interface TaskInitParams {

    /**
     * 填充默认值。
     * @return 此对象本身。
     */
    default TaskInitParams populateDefault() {
        return this;
    }

    /**
     * 验证参数。
     * @return 此对象本身。
     */
    TaskInitParams validate();

}

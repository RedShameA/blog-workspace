package io.iwd.common.ext.util;

public final class NumberUtil {

    private NumberUtil() {}

    public static int toInt(long l) {
        return (int) l;
    }

    public static int toInt(Long l) {
        return l.intValue();
    }

    public static int toInt(Number l) {
        return l.intValue();
    }

    public static int toInt(Object l) {
        if (! (l instanceof Number)) {
            throw new IllegalArgumentException("Argument is not a Number");
        }
        return ((Number) l).intValue();
    }

    public static boolean inRange(int val, int gt, int lt, boolean gte, boolean lte) {
        if (gte) {
            if (val < gt) {
                return false;
            }
        } else {
            if (val <= gt) {
                return false;
            }
        }
        if (lte) {
            if (val > lt) {
                return false;
            }
        } else {
            if (val >= lt) {
                return false;
            }
        }
        return true;
    }

    public static boolean inRange(long val, long gt, long lt, boolean gte, boolean lte) {
        if (gte) {
            if (val < gt) {
                return false;
            }
        } else {
            if (val <= gt) {
                return false;
            }
        }
        if (lte) {
            if (val > lt) {
                return false;
            }
        } else {
            if (val >= lt) {
                return false;
            }
        }
        return true;
    }

    public static int insureInRange(int val, int gt, int lt, boolean gte, boolean lte, int backVal) {
        if (inRange(val, gt, lt, gte, lte)) {
            return val;
        } else if (inRange(backVal, gt, lt, gte, lte)){
            return backVal;
        } else {
            throw new IllegalArgumentException("value not in range, and back value not in range too");
        }
    }

    public static long insureInRange(long val, long gt, long lt, boolean gte, boolean lte, long backVal) {
        if (inRange(val, gt, lt, gte, lte)) {
            return val;
        } else if (inRange(backVal, gt, lt, gte, lte)){
            return backVal;
        } else {
            throw new IllegalArgumentException("value not in range, and back value not in range too");
        }
    }

}

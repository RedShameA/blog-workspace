package io.iwd.common.environment;

import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.FileUtil;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Map;


/**
 * 配置加载器。
 */
public final class ConfigurationLoader {

    public static final String ROOT_CONFIG_FILE_NAME = "iwd-global.conf";

    public final GlobalConfiguration globalConfiguration;

    ConfigurationLoader(GlobalConfiguration globalConfiguration) {
        this.globalConfiguration = globalConfiguration;
    }

    /**
     * 加载全局根配置文件。
     */
    public void loadRootConfigFile() {

        loadConfigFile("classpath:" + ROOT_CONFIG_FILE_NAME);
        loadConfigFile("file:./" + ROOT_CONFIG_FILE_NAME);

    }

    /**
     * 加载一个配置文件。
     * @param path 文件路径。
     */
    public void loadConfigFile(String path) {

        String fileName = FileUtil.getLastFileName(path);

        if (FileUtil.inClasspath(path)) {

            try (InputStream confStream = FileUtil.getClasspathFileAsStream(path)) {

                if (confStream == null) {
                    return;
                }

                parseFileStreamInternal(fileName, confStream);

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (FileUtil.inFileSystem(path)) {

            try (FileInputStream confStream = FileUtil.getFileSystemFileAsStream(path)) {

                if (confStream == null) {
                    return;
                }

                parseFileStreamInternal(fileName, confStream);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void parseFileStreamInternal(String key, InputStream stream) throws IOException {

        byte[] confBytes = new byte[stream.available()];
        int r = stream.read(confBytes);
        if (r == -1) {
            throw new IllegalStateException("config file error");
        }

        String jsonString = new String(confBytes, StandardCharsets.UTF_8);

        //过滤注释
        String[] lines = jsonString.split("\r\n|\n");
        StringBuilder valid = new StringBuilder();
        for (String line : lines) {
            if (line.startsWith("#")) {
                continue;
            }
            valid.append(line);
        }
        jsonString = valid.toString();

        JsonObject fileObj = JsonObject.from(jsonString);
        Map<String, Object> newConf = fileObj.simplify();

        if (this.globalConfiguration.getConfig(key) != null) {
            Map<String, Object> origin = (Map<String, Object>) this.globalConfiguration.getConfig(key);
            mergeMap(origin, newConf);
            newConf = origin;
        }
        this.globalConfiguration.setConfigFile(key, newConf);
    }

    /**
     * 将additional合并到origin中。此方法直接对origin进行更新。
     * @param origin 源Map。
     * @param additional 覆盖的Map。
     */
    @SuppressWarnings("unchecked")
    private void mergeMap(Map<String, Object> origin, Map<String, Object> additional) {
        for (Map.Entry<String, Object> additionalEntry : additional.entrySet()) {
            String key = additionalEntry.getKey();
            Object value = additionalEntry.getValue();

            if (origin.get(key) instanceof Map && value instanceof Map) {
                Map<String, Object> originSubMap = (Map<String, Object>) origin.get(key);
                mergeMap(originSubMap, (Map<String, Object>) value);
            } else {
                origin.put(key, value);
            }
        }
    }

}

package io.iwd.common.stdio.http.srs.handler;

import io.iwd.common.event.srs.SrsCloseRtcAudioEvent;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.http.AbstractHttpRequestHandler;
import io.iwd.common.stdio.http.HttpHelper;
import io.iwd.common.stdio.http.HttpRequestHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.HttpResponseStatus;

import java.util.Map;

/**
 * srs关闭webrtc语音的请求处理器。
 */
@HttpRequestHandler(path = "/srs/srsCloseRtcAudio")
public class SrsCloseRtcAudioHandler extends AbstractHttpRequestHandler<JsonObject> {

    @Override
    protected void handle0(ChannelHandlerContext waitingResponseContext,
                           String path,
                           String method,
                           Map<String, String> queryString,
                           Map<String, String> headers,
                           JsonObject body) throws Exception {
        String ssrc = body.getString("ssrc");
        if (StringUtil.isEmpty(ssrc)) {
            HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":400,\"message\":\"no ssrc\"}", null);
            return;
        }

        String callId = body.getString("callId");
        if (StringUtil.isEmpty(callId)) {
            HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":400,\"message\":\"no callId\"}", null);
            return;
        }

        new SrsCloseRtcAudioEvent(ssrc + "_" + callId).publish();

        HttpHelper.response(waitingResponseContext, HttpResponseStatus.OK, "{\"code\":200}", null);

    }
}

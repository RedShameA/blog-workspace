package io.iwd.common.stdio.redis;

/**
 * redis订阅频道消息处理器。
 */
public abstract class RedisChannelMessageHandler {

    /**
     * 处理消息。
     * @param channelName 频道名称。
     * @param message 消息内容。
     */
    public abstract void handle(String channelName, String message);

}

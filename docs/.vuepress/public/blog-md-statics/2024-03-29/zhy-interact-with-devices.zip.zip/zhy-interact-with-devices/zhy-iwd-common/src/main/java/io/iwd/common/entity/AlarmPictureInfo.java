package io.iwd.common.entity;

import io.iwd.common.ext.json.JsonObject;

public class AlarmPictureInfo extends PictureInfo {

    public AlarmPictureInfo(JsonObject info) {
        super(info);
    }

    @Override
    protected void parse(JsonObject info) {

    }
}

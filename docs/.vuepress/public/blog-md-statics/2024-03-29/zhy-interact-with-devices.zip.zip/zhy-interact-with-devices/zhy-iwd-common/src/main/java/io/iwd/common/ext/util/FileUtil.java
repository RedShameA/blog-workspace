package io.iwd.common.ext.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.regex.Matcher;

public final class FileUtil {

    public static final String RUN_DIR = getRunDir();

    public static final String FILE_SEPARATOR = getFileSeparator();

    public static final String STANDARD_SEPARATOR = "/";

    public static String getFileSeparator() {
        return System.getProperty("file.separator");
    }

    public static String getRunDir() {
        return System.getProperty("user.dir");
    }

    public static void lockFor(FileChannel channel, LockHandler lockHandler) throws Exception {
        FileLock lock = channel.lock();
        try {
            lockHandler.handle(lock);
        } finally {
            lock.release();
        }
    }

    public static void tryLockFor(FileChannel channel, LockHandler lockHandler, TryLockFailedHandler tryLockFailedHandler) throws Exception {
        FileLock lock = channel.tryLock();
        if (lock == null) {
            tryLockFailedHandler.handle();
            return;
        }
        try {
            lockHandler.handle(lock);
        } finally {
            lock.release();
        }
    }

    /**
     * 将传入路径的文件分隔符转换为当前操作系统的文件分隔符。
     * @param path 待处理的路径。
     * @return 处理后的路径
     */
    public static String matchSystemFileSeparator(String path) {

        path = path.replaceAll("\\\\", STANDARD_SEPARATOR);

        while (path.contains(STANDARD_SEPARATOR + STANDARD_SEPARATOR)) {
            path = path.replaceAll(STANDARD_SEPARATOR + STANDARD_SEPARATOR, STANDARD_SEPARATOR);
        }
        path = FILE_SEPARATOR.equals(STANDARD_SEPARATOR)
                ? path
                : path.replaceAll(STANDARD_SEPARATOR, Matcher.quoteReplacement(FILE_SEPARATOR));
        return path;
    }

    public static boolean inClasspath(String path) {
        return path.length() > 10 && path.startsWith("classpath:");
    }

    public static boolean inFileSystem(String path) {
        return path.length() > 5 && path.startsWith("file:");
    }

    /**
     * 获取路径中最后一个文件的名称。
     * @param path 文件路径。
     * @return 文件名。
     */
    public static String getLastFileName(String path) {
        char fs = FILE_SEPARATOR.charAt(0);
        char ss = STANDARD_SEPARATOR.charAt(0);
        char last = path.charAt(path.length() - 1);
        if (last == fs || last == ss) { //路径最后是分隔符
            return "";
        }
        String fileName = path;
        if (fileName.startsWith("file:") || fileName.startsWith("classpath:")) {
            fileName = fileName.substring(path.indexOf(":") + 1);
        }
        for (int i = fileName.length() - 1; i >= 0; i--) {
            char c = fileName.charAt(i);
            if (c == fs || c == ss) {
                fileName = fileName.substring(i + 1);
                break;
            }
        }
        return fileName;
    }

    public static InputStream getClasspathFileAsStream(String path) {
        path = path.startsWith("classpath:") ? path.substring(10) : path;
        path = matchSystemFileSeparator(path);
        return FileUtil.class.getClassLoader().getResourceAsStream(path);
    }

    public static FileInputStream getFileSystemFileAsStream(String path) throws FileNotFoundException {
        path = path.startsWith("file:") ? path.substring(5) : path;
        path = matchSystemFileSeparator(path);
        if (path.startsWith("." + FILE_SEPARATOR)) { //以 ./ 或 .\ 开头，代表当前程序运行路径
            path = RUN_DIR + path.substring(1);
        }
        else if (path.startsWith(".." + FILE_SEPARATOR)){ //以 ../ 或 ..\ 开头，代表当前程序运行路径上级路径
            String pathFromRoot = RUN_DIR;
            String pathFromFile = path;
            while (pathFromFile.startsWith(".." + FILE_SEPARATOR)) {
                pathFromFile = pathFromFile.substring(3);
                pathFromRoot = pathFromRoot.substring(0, pathFromRoot.lastIndexOf(FILE_SEPARATOR));
            }
            path = pathFromRoot + FILE_SEPARATOR + pathFromFile;
        }
        else if (path.startsWith(FILE_SEPARATOR)) { //此路径视为绝对路径
            path = path;
        }
        else { //视为当前程序运行路径
            path = RUN_DIR + FILE_SEPARATOR + path;
        }

        File file = new File(path);
        if (!file.exists()) {
            return null;
        }
        return new FileInputStream(file);
    }

    @FunctionalInterface
    public interface LockHandler {
        void handle(FileLock lock) throws Exception;
    }

    @FunctionalInterface
    public interface TryLockFailedHandler {
        void handle();
    }

}

package io.iwd.common.environment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * 全局配置容器，其中包括各扩展包的配置。
 */
public final class GlobalConfiguration implements GlobalConfigurationGetter {

    private final Object nonValue = new Object();

    private final Map<String, Object> config = new HashMap<>(16, 0.5f);

    private final ReadWriteLock lock = new ReentrantReadWriteLock(true);

    @SuppressWarnings("unchecked")
    public boolean hasConfigKey(Object... key) {
        Lock readLock = lock.readLock();
        readLock.lock();
        try {
            if (key.length == 0) {
                return false;
            }
            Object content = nonValue;

            for (Object k : key) {
                if (content == null) {
                    return false;
                }

                if (k instanceof String) {
                    if (content == nonValue) {
                        if (!config.containsKey(k)) {
                            return false;
                        }
                        content = config.get(k);
                    } else {
                        Map<String, Object> preContent = (Map<String, Object>) content;
                        if (!preContent.containsKey(k)) {
                            return false;
                        }
                        content = preContent.get(k);
                    }
                } else if (k instanceof Integer) {
                    List<Object> preContent = (List<Object>) content;
                    if (preContent.size() <= (Integer) k) {
                        return false;
                    }
                    content = ((List<Object>) content).get((Integer) k);
                }
            }

            return true;

        } finally {
            readLock.unlock();
        }
    }

    @SuppressWarnings("unchecked")
    public Object getConfig(Object... key) {

        Lock readLock = lock.readLock();
        readLock.lock();
        try {

            if (key.length == 0) {
                return null;
            }

            Object content = nonValue;

            for (Object k : key) {
                if (content == null) {
                    return null;
                }

                if (k instanceof String) {
                    if (content == nonValue) {
                        content = config.get(k);
                    } else {
                        content = ((Map<String, Object>) content).get(k);
                    }
                } else if (k instanceof Integer) {
                    content = ((List<Object>) content).get((Integer) k);
                }
            }

            return getCopy(content);
        } finally {
            readLock.unlock();
        }
    }

    /**
     * 获取global中的配置。
     * @param key 键列表。
     * @return 配置。
     */
    public Object getGlobalConfig(Object... key) {
        Object[] keys = new Object[key.length + 1];
        keys[0] = ConfigurationLoader.ROOT_CONFIG_FILE_NAME;
        System.arraycopy(key, 0, keys, 1, key.length);
        return getConfig(keys);
    }

    /**
     * 获取扩展包中的配置。
     * @param extName 扩展包名。
     * @param key 键列表。
     * @return 配置。
     */
    public Object getExtConfig(String extName, Object... key) {
        Object[] keys = new Object[key.length + 1];
        keys[0] = "iwd-" + extName + ".conf";
        System.arraycopy(key, 0, keys, 1, key.length);
        return getConfig(keys);
    }

    /**
     * 检查是否存在某个扩展包(的配置)。
     * @param extName 扩展包名。
     * @return 是否存在此扩展包的配置。
     */
    public boolean hasExtPackage(String extName) {
        return hasConfigKey("iwd-" + extName + ".conf");
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object getConfigInBatch(Object... key) {
        if (key.length == 0) {
            return null;
        }

        Object content = nonValue;

        for (Object k : key) {
            if (content == null) {
                return null;
            }

            if (k instanceof String) {
                if (content == nonValue) {
                    content = config.get(k);
                } else {
                    content = ((Map<String, Object>) content).get(k);
                }
            } else if (k instanceof Integer) {
                content = ((List<Object>) content).get((Integer) k);
            }
        }

        return getCopy(content);
    }

    @Override
    public Object getGlobalConfigInBatch(Object... key) {
        Object[] keys = new Object[key.length + 1];
        keys[0] = ConfigurationLoader.ROOT_CONFIG_FILE_NAME;
        System.arraycopy(key, 0, keys, 1, key.length);
        return getConfigInBatch(keys);
    }

    @Override
    public Object getExtConfigInBatch(String extName, Object... key) {
        Object[] keys = new Object[key.length + 1];
        keys[0] = "iwd-" + extName + ".conf";
        System.arraycopy(key, 0, keys, 1, key.length);
        return getConfigInBatch(keys);
    }

    /**
     * 在一次读锁中多次获取配置。在batchTask中调用带{@code InBatch}后缀的方法。
     * @param batchTask 批量任务。
     * @see GlobalConfigurationBatchTask
     */
    public void getInBatch(GlobalConfigurationBatchTask batchTask) {
        Lock readLock = lock.readLock();
        readLock.lock();
        try {
            batchTask.execute(this);
        } finally {
            readLock.unlock();
        }
    }

    public void setConfigFile(String key, Object content) {

        Lock writeLock = lock.writeLock();
        writeLock.lock();
        try {
            config.put(key, content);
        } finally {
            writeLock.unlock();
        }
    }

    @SuppressWarnings("unchecked")
    public void setConfig(Object... keyValue) {

        Lock writeLock = lock.writeLock();
        writeLock.lock();

        try {

            if (keyValue.length < 2) {
                return;
            }

            int keyLength = keyValue.length - 1;
            Object value = keyValue[keyLength];
            Object collection = config;

            for (int i = 0; i < keyLength - 1; i ++) {
                Object key = keyValue[i];
                if (key instanceof String) {
                    collection = ((Map<String, Object>) collection).get(key);
                } else if (key instanceof Integer) {
                    collection = ((List<Object>) collection).get((Integer) key);
                } else {
                    throw new IllegalStateException("error key type: " + key.getClass().getSimpleName());
                }
                if (collection == null) {
                    throw new NullPointerException("no such key: " + key + " (index: " + i + ")");
                }
            }

            Object lastKey = keyValue[keyLength - 1];
            if (lastKey instanceof String) {
                ((Map<String, Object>) collection).put((String) lastKey, value);
            } else if (lastKey instanceof Integer) {
                ((List<Object>) collection).set((Integer) lastKey, value);
            } else {
                throw new IllegalStateException("error key type: " + lastKey.getClass().getSimpleName());
            }
        } finally {
            writeLock.unlock();
        }
    }

    GlobalConfiguration() {

    }

    /**
     * 获取一个配置的拷贝，但非集合类型不会进行拷贝。
     * @param content
     * @return
     */
    @SuppressWarnings("unchecked")
    private Object getCopy(Object content) {
        if (content instanceof Map) {
            Map<String, Object> copy = new HashMap<>();
            for (Map.Entry<String, Object> entry : ((Map<String, Object>) content).entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                copy.put(key, getCopy(value));
            }
            return copy;
        }
        else if (content instanceof List) {
            List<Object> copy = new ArrayList<>();
            for (Object element : (List<Object>) content) {
                copy.add(getCopy(element));
            }
            return copy;
        }
        else {
            return content;
        }
    }

}

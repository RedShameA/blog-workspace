package io.iwd.gb28181.event;

import io.iwd.common.event.LogEvent;

import java.util.HashMap;
import java.util.Map;

public class SipServiceLogEvent extends LogEvent {

    public enum LogType implements LogEvent.LogType {

        SIP_LOG_DEVICE_NONE(0), // 暂未定义，扩展使用
        SIP_LOG_DEVICE_REGISTER(1), // 设备注册状态
        SIP_LOG_DEVICE_STATE(2), // 设备心跳状态
        SIP_LOG_DEVICE_QUERY(3), // 设备目录返回状态
        SIP_LOG_DEVICE_START_PLAY(4), // 设备下发推流状态
        SIP_LOG_DEVICE_START_PLAY_RET(5), // 设备返回推流状态
        ;

        private static final Map<Integer, LogType> CODE_TYPE_MAPPING = new HashMap<>();

        static {
            CODE_TYPE_MAPPING.put(0, SIP_LOG_DEVICE_NONE);
            CODE_TYPE_MAPPING.put(1, SIP_LOG_DEVICE_REGISTER);
            CODE_TYPE_MAPPING.put(2, SIP_LOG_DEVICE_STATE);
            CODE_TYPE_MAPPING.put(3, SIP_LOG_DEVICE_QUERY);
            CODE_TYPE_MAPPING.put(4, SIP_LOG_DEVICE_START_PLAY);
            CODE_TYPE_MAPPING.put(5, SIP_LOG_DEVICE_START_PLAY_RET);
        }

        public static LogType forCode(int code) {
            return CODE_TYPE_MAPPING.get(code);
        }

        private final int code;

        LogType(int code) {
            this.code = code;
        }

        @Override
        public int code() {
            return code;
        }
    }

    public SipServiceLogEvent(LogType logType, String logMessage) {
        super(logType, logMessage);
    }

}

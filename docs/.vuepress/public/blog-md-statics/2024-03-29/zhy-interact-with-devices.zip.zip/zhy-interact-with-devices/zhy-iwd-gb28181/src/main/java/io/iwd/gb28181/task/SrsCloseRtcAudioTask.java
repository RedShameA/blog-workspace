package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.environment.ReadConfigAction;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import static io.iwd.gb28181.Gb28181Const.*;

public class SrsCloseRtcAudioTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "SrsCloseRtcAudio", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("QUERY_IF_AUTO_CLOSE", context -> {
            String streamId = (String) context.getInput();
            context.putData("streamId", streamId);

            new ReadConfigAction(conf -> conf.getExtConfig("gb28181", "auto_close_audio_stream")).start();
            context.awaitNext("REMOVE_REAL_AUDIO_INFO");
        });

        //获取ssrc记录
        taskFlow.addNode("REMOVE_REAL_AUDIO_INFO", context -> {
            Boolean autoClose = (Boolean) context.getInput();
            if (autoClose == null || !autoClose) {
                context.complete(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0001,
                        "gb28181 disable auto close audio stream"));
                return;
            }

            String[] ssrcAndCallId = ((String) context.getData("streamId")).split("_");
            String ssrc = ssrcAndCallId[0];
            String callId = ssrcAndCallId[1];
            context.putData("ssrc", ssrc);
            context.putData("callId", callId);

            String script = "local dncn = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(dncn == false) then return; end;" +
                            "redis.call('HDEL', KEYS[1], KEYS[2]);" +
                            "return dncn;";
            Redis.interactiveMode().eval(script, 2, REDIS_REAL_TIME_AUDIO_INFO_MAP_KEY, ssrc);

            context.awaitNext("GOT_REAL_AUDIO_INFO_AND_ISSUE_COMMAND");
        });

        taskFlow.addNode("GOT_REAL_AUDIO_INFO_AND_ISSUE_COMMAND", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "query real time audio info error"));
                return;
            }
            String dncnStr = (String) input;
            if (StringUtil.isEmpty(dncnStr)) {
                context.complete(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0002,
                        "no real time audio info"));
                return;
            }

            String[] dncn = dncnStr.split("_");
            String dn = dncn[0];
            String cn = dncn[1];

            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("handle_val", 10)
                    .put("command_val", 2)
                    .put("devicenum", dn)
                    .put("chd_num", cn)
                    .put("callid", context.getData("callId"));

            Redis.silentMode().publish("dev_broadcast_stop", data.stringify());

            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("QUERY_IF_AUTO_CLOSE");

        return taskFlow;

    }

}

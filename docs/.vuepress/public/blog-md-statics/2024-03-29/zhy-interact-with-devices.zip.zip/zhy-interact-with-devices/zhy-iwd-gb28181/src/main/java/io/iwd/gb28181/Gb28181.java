package io.iwd.gb28181;

import io.iwd.gb28181.command.*;

/**
 * Gb28181协议命令集。
 */
public class Gb28181 {

    /**
     * 注册设备命令。
     */
    public static DeviceRegister deviceRegister() {
        return new DeviceRegister();
    }

    /**
     * 设备注销命令。
     */
    public static DeviceDeregister deviceDeregister() {
        return new DeviceDeregister();
    }

    /**
     * 设备通道查询命令。
     */
    public static DeviceChannelQuery deviceChannelQuery() {
        return new DeviceChannelQuery();
    }

    /**
     * 镜头控制命令。
     */
    public static LensControl lensControl() {
        return new LensControl();
    }

    /**
     * 变倍控制命令。
     */
    public static ZoomControl zoomControl() {
        return new ZoomControl();
    }

    /**
     * 焦距控制命令。
     */
    public static FocusControl focusControl() {
        return new FocusControl();
    }

    /**
     * 光圈控制命令。
     */
    public static ApertureControl apertureControl() {
        return new ApertureControl();
    }

    /**
     * webrtc实时视频播放命令。
     */
    public static RealTimeVideoWebrtcPlay realTimeVideoWebrtcPlay() {
        return new RealTimeVideoWebrtcPlay();
    }

    /**
     * 实时视频停止命令。
     */
    public static RealTimeVideoStop realTimeVideoStop() {
        return new RealTimeVideoStop();
    }

    /**
     * 查询录像文件。
     */
    public static HistoryVideoFileQuery historyVideoFileQuery() {
        return new HistoryVideoFileQuery();
    }

    /**
     * webrtc录像文件播放命令。
     */
    public static HistoryVideoWebrtcPlay historyVideoWebrtcPlay() {
        return new HistoryVideoWebrtcPlay();
    }

    /**
     * 录像回放停止命令。
     */
    public static HistoryVideoStop historyVideoStop() {
        return new HistoryVideoStop();
    }

    /**
     * 录像回放暂停命令。
     */
    public static HistoryVideoPause historyVideoPause() {
        return new HistoryVideoPause();
    }

    /**
     * 录像回放继续命令。
     */
    public static HistoryVideoContinue historyVideoContinue() {
        return new HistoryVideoContinue();
    }

    /**
     * 录像回放速度控制命令。
     */
    public static HistoryVideoSpeedControl historyVideoSpeedControl() {
        return new HistoryVideoSpeedControl();
    }

    /**
     * 录像回放重新定位命令。
     */
    public static HistoryVideoRelocate historyVideoRelocate() {
        return new HistoryVideoRelocate();
    }

    /**
     * 预置位调用命令。
     */
    public static PresetCall presetCall() {
        return new PresetCall();
    }

    /**
     * 预置位重新定位命令。
     */
    public static PresetRelocate presetRelocate() {
        return new PresetRelocate();
    }

    /**
     * 预置位删除命令。
     */
    public static PresetRemove presetRemove() {
        return new PresetRemove();
    }

    /**
     * 巡航线配置命令。
     */
    public static CruiseConfig cruiseConfig() {
        return new CruiseConfig();
    }

    /**
     * 巡航线删除命令。
     */
    public static CruiseRemove cruiseRemove() {
        return new CruiseRemove();
    }

    /**
     * 巡航线开启命令。
     */
    public static CruiseStart cruiseStart() {
        return new CruiseStart();
    }

    /**
     * 巡航线停止命令。
     */
    public static CruiseStop cruiseStop() {
        return new CruiseStop();
    }

    /**
     * 图片抓拍命令。
     */
    public static Snapshot snapshot() {
        return new Snapshot();
    }

    /**
     * 实时音频webrtc播送命令。
     */
    public static RealTimeAudioWebrtcSend realTimeAudioWebrtcSend() {
        return new RealTimeAudioWebrtcSend();
    }

}

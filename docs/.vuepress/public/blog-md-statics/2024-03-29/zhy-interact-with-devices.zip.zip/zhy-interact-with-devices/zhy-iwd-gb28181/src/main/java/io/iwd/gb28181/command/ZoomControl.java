package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.entity.ZoomControlInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

import static io.iwd.gb28181.Gb28181Const.*;

/**
 * 变倍控制命令。
 */
public class ZoomControl extends AdvancedCommand<Boolean> {

    private ZoomControlInitParams initParams = new ZoomControlInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return ZoomControl命令对象。
     */
    public ZoomControl setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return ZoomControl命令对象。
     */
    public ZoomControl setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置变倍控制选项。
     * @param zoomControlOption 变倍控制选项。
     * @return ZoomControl命令对象。
     * @see io.iwd.gb28181.Gb28181Const.ZoomControlOption
     */
    public ZoomControl setZoomControlOption(ZoomControlOption zoomControlOption) {
        this.initParams.setZoomControlOption(zoomControlOption);
        return this;
    }

    /**
     * 设置变倍控制速度。
     * @param speed 控制速度。
     * @return ZoomControl命令对象。
     */
    public ZoomControl setSpeed(Integer speed) {
        this.initParams.setSpeed(speed);
        return this;
    }

    /**
     * 设置变倍控制速度选项。
     * @param controlSpeedOption 控制速度选项。
     * @return ZoomControl命令对象。
     * @see io.iwd.gb28181.Gb28181Const.ControlSpeedOption
     */
    public ZoomControl setControlSpeedOption(ControlSpeedOption controlSpeedOption) {
        this.initParams.setControlSpeedOption(controlSpeedOption);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "ZoomControl", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

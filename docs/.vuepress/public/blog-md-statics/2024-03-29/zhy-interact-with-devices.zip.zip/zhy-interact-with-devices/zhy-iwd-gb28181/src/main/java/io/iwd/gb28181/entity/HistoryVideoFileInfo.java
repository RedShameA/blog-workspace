package io.iwd.gb28181.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HistoryVideoFileInfo implements Comparable<HistoryVideoFileInfo> {

    private final String name;

    private final Date startTime;

    private final Date endTime;

    private final String path;

    public HistoryVideoFileInfo(String name, Date startTime, Date endTime, String path) {
        this.name = name;
        this.startTime = startTime;
        this.endTime = endTime;
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public Date getStartTime() {
        return startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public String getPath() {
        return path;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return "{\"name\":\"" + this.name +
                "\",\"startTime\":\"" + dateFormat.format(this.startTime) +
                "\",\"endTime\":\"" + dateFormat.format(this.endTime) +
                "\",\"path\":\"" + this.path + "\"}";
    }

    @Override
    public int compareTo(HistoryVideoFileInfo o) {
        return this.startTime.compareTo(o.startTime);
    }
}

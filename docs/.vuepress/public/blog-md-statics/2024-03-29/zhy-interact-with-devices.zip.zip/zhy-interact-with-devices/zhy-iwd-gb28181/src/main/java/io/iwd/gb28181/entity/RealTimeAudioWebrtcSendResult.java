package io.iwd.gb28181.entity;

/**
 * 实时语音webrtc播送的结果。
 */
public class RealTimeAudioWebrtcSendResult {

    /**
     * 播放是否成功。
     */
    private final boolean success;

    /**
     * webrtc answer sdp。
     */
    private final String sdp;

    /**
     * 信令服务可能返回的ssrc。
     */
    private final String ssrc;

    /**
     * 标准构造器。
     * @param success 播放是否成功。
     * @param sdp webrtc answer sdp。
     * @param ssrc ssrc。
     */
    public RealTimeAudioWebrtcSendResult(boolean success, String sdp, String ssrc) {
        this.success = success;
        this.sdp = sdp;
        this.ssrc = ssrc;
    }

    /**
     * 返回是否播放成功。
     * @return 是否播放成功。
     */
    public boolean isSuccess() {
        return this.success;
    }

    /**
     * 返回answer sdp。
     * @return answer sdp。
     */
    public String getSdp() {
        return this.sdp;
    }

    /**
     * 返回可能存在的ssrc。
     * @return ssrc。
     */
    public String getSsrc() {
        return this.ssrc;
    }

    @Override
    public String toString() {
        return "{\"success\":" + this.success + ",\"sdp\":" + this.sdp + ",\"ssrc\":" + this.ssrc + "}";
    }

}

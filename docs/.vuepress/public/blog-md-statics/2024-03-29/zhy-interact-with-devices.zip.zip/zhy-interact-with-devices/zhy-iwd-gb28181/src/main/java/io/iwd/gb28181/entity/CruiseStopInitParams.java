package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.util.Gb28181Validator;

import static io.iwd.gb28181.Gb28181Const.MAX_CRUISE_ID_NUMBER;
import static io.iwd.gb28181.Gb28181Const.MIN_CRUISE_ID_NUMBER;

public class CruiseStopInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private Integer cruiseId;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Integer getCruiseId() {
        return cruiseId;
    }

    public void setCruiseId(Integer cruiseId) {
        this.cruiseId = cruiseId;
    }

    @Override
    public CruiseStopInitParams populateDefault() {
        return this;
    }

    @Override
    public CruiseStopInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (this.cruiseId == null || this.cruiseId < MIN_CRUISE_ID_NUMBER || this.cruiseId > MAX_CRUISE_ID_NUMBER) {
            throw new IllegalArgumentException("gb28181 cruise id format error");
        }
        return this;
    }
}

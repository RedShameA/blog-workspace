package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.gb28181.entity.HistoryVideoFileInfo;
import io.iwd.gb28181.entity.HistoryVideoFileQueryInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * 历史视频文件查询命令。
 */
public class HistoryVideoFileQuery extends AdvancedCommand<List<HistoryVideoFileInfo>> {

    private HistoryVideoFileQueryInitParams initParams = new HistoryVideoFileQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置查询开始时间。
     * @param startTime 查询开始时间。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setStartTime(Date startTime) {
        this.initParams.setStartTime(startTime);
        return this;
    }

    /**
     * 设置查询结束时间。
     * @param endTime 查询结束时间。
     * @return HistoryVideoFileQuery命令对象。
     */
    public HistoryVideoFileQuery setEndTime(Date endTime) {
        this.initParams.setEndTime(endTime);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoFileQuery", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public List<HistoryVideoFileInfo> await(long time) {
        return super.await(result -> {
            if (!result.isCompleted() || !result.hasResult()) {
                return Collections.emptyList();
            }
            JsonObject completedResult = (JsonObject) result.getResult();
            JsonArray data = completedResult.getJsonArray("data");
            List<HistoryVideoFileInfo> list = new ArrayList<>(data.size());
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 0; i < data.size(); i++) {
                JsonObject fileInfo = data.getJsonObject(i);
                String name = fileInfo.getString("name");
                String st = fileInfo.getString("startTime");
                String et = fileInfo.getString("endTime");
                String path = fileInfo.getString("path");
                Date startTime, endTime;
                try {
                    startTime = dateFormat.parse(st);
                    endTime = dateFormat.parse(et);
                } catch (ParseException ex) {
                    startTime = null;
                    endTime = null;
                }
                HistoryVideoFileInfo historyVideoFileInfo =
                        new HistoryVideoFileInfo(name, startTime, endTime, path);
                list.add(historyVideoFileInfo);
            }
            return list;
        }, time);
    }
}

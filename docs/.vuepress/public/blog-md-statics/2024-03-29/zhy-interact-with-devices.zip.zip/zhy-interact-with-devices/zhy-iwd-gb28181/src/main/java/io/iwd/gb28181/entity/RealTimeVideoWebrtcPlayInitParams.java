package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.gb28181.util.Gb28181Validator;

import static io.iwd.gb28181.Gb28181Const.*;

public class RealTimeVideoWebrtcPlayInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private VideoStreamMode videoStreamMode;

    private VideoStreamProtocol videoStreamProtocol;

    private String mediaServerIp;

    private Integer mediaServerPort;

    private String offerSdp;

    private Boolean useExistingStream;

    private Boolean srsApiSsl;

    private String srsApiIp;

    private Integer srsApiPort;

    private String webAddress;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public VideoStreamMode getVideoStreamMode() {
        return this.videoStreamMode;
    }

    public void setVideoStreamMode(VideoStreamMode videoStreamMode) {
        this.videoStreamMode = videoStreamMode;
    }

    public VideoStreamProtocol getVideoStreamProtocol() {
        return this.videoStreamProtocol;
    }

    public void setVideoStreamProtocol(VideoStreamProtocol videoStreamProtocol) {
        this.videoStreamProtocol = videoStreamProtocol;
    }

    public String getMediaServerIp() {
        return this.mediaServerIp;
    }

    public void setMediaServerIp(String mediaServerIp) {
        this.mediaServerIp = mediaServerIp;
    }

    public Integer getMediaServerPort() {
        return this.mediaServerPort;
    }

    public void setMediaServerPort(Integer mediaServerPort) {
        this.mediaServerPort = mediaServerPort;
    }

    public String getOfferSdp() {
        return this.offerSdp;
    }

    public void setOfferSdp(String offerSdp) {
        this.offerSdp = offerSdp;
    }

    public Boolean getUseExistingStream() {
        return this.useExistingStream;
    }

    public void setUseExistingStream(Boolean useExistingStream) {
        this.useExistingStream = useExistingStream;
    }

    public Boolean getSrsApiSsl() {
        return srsApiSsl;
    }

    public void setSrsApiSsl(Boolean srsApiSsl) {
        this.srsApiSsl = srsApiSsl;
    }

    public String getSrsApiIp() {
        return this.srsApiIp;
    }

    public void setSrsApiIp(String srsApiIp) {
        this.srsApiIp = srsApiIp;
    }

    public Integer getSrsApiPort() {
        return this.srsApiPort;
    }

    public void setSrsApiPort(Integer srsApiPort) {
        this.srsApiPort = srsApiPort;
    }

    public String getWebAddress() {
        return this.webAddress;
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }

    @Override
    public RealTimeVideoWebrtcPlayInitParams populateDefault() {
        if (this.videoStreamMode == null) {
            this.videoStreamMode = VideoStreamMode.UDP;
        }
        if (this.videoStreamProtocol == null) {
            this.videoStreamProtocol = VideoStreamProtocol.RTSP;
        }
        if (this.useExistingStream == null) {
            this.useExistingStream = Boolean.TRUE;
        }
        EnvironmentHolder.get().config().getInBatch(conf -> {
            if (this.mediaServerIp == null) {
                this.mediaServerIp = (String) conf.getExtConfigInBatch("gb28181", "srs", "push_stream_ip");
            }
            if (this.mediaServerPort == null) {
                this.mediaServerPort = NumberUtil.toInt(conf.getExtConfigInBatch("gb28181", "srs", "push_stream_port"));
            }
            if (this.srsApiSsl == null) {
                this.srsApiSsl = (Boolean) conf.getGlobalConfigInBatch("srs", "api_ssl");
            }
            if (this.srsApiIp == null) {
                this.srsApiIp = (String) conf.getGlobalConfigInBatch("srs", "api_ip");
            }
            if (this.srsApiPort == null) {
                this.srsApiPort = NumberUtil.toInt(conf.getGlobalConfigInBatch("srs", "api_port"));
            }
            if (this.webAddress == null) {
                this.webAddress = (String) conf.getGlobalConfigInBatch("srs", "web_address");
            }
        });
        return this;
    }

    @Override
    public RealTimeVideoWebrtcPlayInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (this.videoStreamMode == null) {
            throw new IllegalArgumentException("gb28181 video stream mode error");
        }
        if (this.videoStreamProtocol == null) {
            throw new IllegalArgumentException("gb28181 video stream protocol error");
        }
        if (!Validator.isIpv4(this.mediaServerIp)) {
            throw new IllegalArgumentException("gb28181 media server ip format error");
        }
        if (this.mediaServerPort == null || this.mediaServerPort < 1 || mediaServerPort > 65535) {
            throw new IllegalArgumentException("gb28181 media server port format error");
        }
        if (StringUtil.isEmpty(offerSdp)) {
            throw new IllegalArgumentException("gb28181 webrtc offer sdp format error");
        }
        if (this.useExistingStream == null) {
            throw new IllegalArgumentException("gb28181 use existing stream error");
        }
        if (this.srsApiSsl == null) {
            throw new IllegalArgumentException("gb28181 srs api ssl error");
        }
        if (!Validator.isIpv4(this.srsApiIp)) {
            throw new IllegalArgumentException("gb28181 srs api ip format error");
        }
        if (this.srsApiPort == null || this.srsApiPort < 1 || srsApiPort > 65535) {
            throw new IllegalArgumentException("gb28181 srs api port format error");
        }
        if (!Validator.isIpv4AndPort(this.webAddress)) {
            throw new IllegalArgumentException("gb28181 web address format error");
        }
        return this;
    }
}

package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.gb28181.util.Gb28181Validator;

public class DeviceRegisterInitParams implements TaskInitParams {

    private String deviceNumber;

    private Integer heartbeatInterval;

    private Integer maxHeartbeatLost;

    private String password;

    private String serverId;

    private String serverIp;

    private Integer serverPort;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getHeartbeatInterval() {
        return this.heartbeatInterval;
    }

    public void setHeartbeatInterval(Integer heartbeatInterval) {
        this.heartbeatInterval = heartbeatInterval;
    }

    public Integer getMaxHeartbeatLost() {
        return this.maxHeartbeatLost;
    }

    public void setMaxHeartbeatLost(Integer maxHeartbeatLost) {
        this.maxHeartbeatLost = maxHeartbeatLost;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getServerId() {
        return this.serverId;
    }

    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    public String getServerIp() {
        return this.serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public Integer getServerPort() {
        return this.serverPort;
    }

    public void setServerPort(Integer serverPort) {
        this.serverPort = serverPort;
    }

    @Override
    public DeviceRegisterInitParams populateDefault() {
        EnvironmentHolder.get().config().getInBatch(conf -> {
            if (this.heartbeatInterval == null) {
                this.heartbeatInterval = NumberUtil.toInt(conf.getExtConfigInBatch("gb28181", "sip", "heartbeat_interval"));
            }
            if (this.maxHeartbeatLost == null) {
                this.maxHeartbeatLost = NumberUtil.toInt(conf.getExtConfigInBatch("gb28181", "sip", "max_heartbeat_lost"));
            }
            if (this.password == null) {
                this.password = (String) conf.getExtConfigInBatch("gb28181", "sip", "password");
            }
            if (this.serverId == null) {
                this.serverId = (String) conf.getExtConfigInBatch("gb28181", "sip", "server_id");
            }
            if (this.serverIp == null) {
                this.serverIp = (String) conf.getExtConfigInBatch("gb28181", "sip", "server_ip");
            }
            if (this.serverPort == null) {
                this.serverPort = NumberUtil.toInt(conf.getExtConfigInBatch("gb28181", "sip", "server_port"));
            }
        });
        return this;
    }

    @Override
    public DeviceRegisterInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (this.heartbeatInterval == null || this.heartbeatInterval < 0 || this.heartbeatInterval > 86400) {
            throw new IllegalArgumentException("gb28181 heartbeat interval format error");
        }
        if (this.maxHeartbeatLost == null || this.maxHeartbeatLost < 0 || this.maxHeartbeatLost > 999) {
            throw new IllegalArgumentException("gb28181 max heartbeat lost format error");
        }
        if (StringUtil.isEmpty(this.password)) {
            throw new IllegalArgumentException("gb28181 password format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.serverId)) {
            throw new IllegalArgumentException("gb28181 server id format error");
        }
        if (!Validator.isIpv4(this.serverIp)) {
            throw new IllegalArgumentException("gb28181 server ip format error");
        }
        if (this.serverPort == null || this.serverPort < 0 || this.serverPort > 65535) {
            throw new IllegalArgumentException("gb28181 server port format error");
        }
        return this;
    }
}

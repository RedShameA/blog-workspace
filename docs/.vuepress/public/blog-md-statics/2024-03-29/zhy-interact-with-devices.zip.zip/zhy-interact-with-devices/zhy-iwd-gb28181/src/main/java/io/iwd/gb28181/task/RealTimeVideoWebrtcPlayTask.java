package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.http.srs.template.SrsExchangeSdpTemplate;
import io.iwd.common.stdio.http.srs.template.SrsQueryStreamTemplate;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.RealTimeVideoWebrtcPlayInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import static io.iwd.gb28181.Gb28181Const.*;

public class RealTimeVideoWebrtcPlayTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "RealTimeVideoWebrtcPlay", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            RealTimeVideoWebrtcPlayInitParams input = (RealTimeVideoWebrtcPlayInitParams) context.getInput();
            context.putData("deviceNumber", input.getDeviceNumber());
            context.putData("channelNumber", input.getChannelNumber());
            context.putData("videoStreamMode", input.getVideoStreamMode().code());
            context.putData("mediaServerIp", input.getMediaServerIp());
            context.putData("mediaServerPort", input.getMediaServerPort());
            context.putData("offerSdp", input.getOfferSdp());
            context.putData("srsApiSsl", input.getSrsApiSsl());
            context.putData("srsApiIp", input.getSrsApiIp());
            context.putData("srsApiPort", input.getSrsApiPort());
            context.putData("webAddress", input.getWebAddress());
            Boolean useExistingStream = input.getUseExistingStream();

            if (useExistingStream) {
                context.fireNext("QUERY_SSRC");
            } else {
                context.fireNext("ISSUE_VIDEO_START_COMMAND");
            }
        });

        taskFlow.addNode("QUERY_SSRC", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            String script = "local ssrc = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(ssrc == false) then return; end;" +
                            "local dncn = redis.call('HGET', KEYS[1], ssrc);" +
                            "if(dncn ~= KEYS[2]) then redis.call('HDEL', KEYS[1], KEYS[2]); return; end;" +
                            "return ssrc;";
            String dncn = deviceNumber + "_" + channelNumber;
            Redis.interactiveMode().eval(script, 2, REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY, dncn);

            context.awaitNext("GOT_SSRC");
        });

        taskFlow.addNode("GOT_SSRC", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "query ssrc error"));
                return;
            }
            String ssrc = (String) input;
            if (StringUtil.isEmpty(ssrc)) {
                context.fireNext("ISSUE_VIDEO_START_COMMAND");
            } else {
                context.putData("ssrc", ssrc);
                context.fireNext("QUERY_STREAM");
            }
        });

        taskFlow.addNode("QUERY_STREAM", context -> {
            String streamId = "chid" + context.getData("ssrc");
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");

            new SrsQueryStreamTemplate(srsApiSsl, srsApiIp, srsApiPort, streamId).send();
            context.awaitNext("SRS_RESPONSE_STREAM");
        });

        taskFlow.addNode("SRS_RESPONSE_STREAM", context -> {
            Boolean input = (Boolean) context.getInput();
            if (input == null || !input) {
                context.fireNext("ISSUE_VIDEO_START_COMMAND");
            } else {
                context.fireNext("EXCHANGE_SDP");
            }
        });

        taskFlow.addNode("ISSUE_VIDEO_START_COMMAND", context -> {
            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("devicenum", context.getData("deviceNumber"))
                    .put("chd_num", context.getData("channelNumber"))
                    .put("handle_val", 5)
                    .put("command_val", 1)
                    .put("streamip", context.getData("mediaServerIp"))
                    .put("streamport", context.getData("mediaServerPort"))
                    .put("videotransport", context.getData("videoStreamMode"))
                    .put("rtc", 1);

            Redis.silentMode().publish("dev_realvideo_start", data.stringify());
            context.awaitNext("RECEIVED_VIDEO_START_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_VIDEO_START_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer state = input.getInteger("state");
            if (state == null || state != 1) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "sip service response error"));
                return;
            }
            Integer ssrcValue = input.getInteger("devicessrc");
            if (ssrcValue == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "sip service response no ssrc"));
                return;
            }
            context.putData("ssrc", ssrcValue.toString());

            context.fireNext("SAVE_SSRC");
        });

        taskFlow.addNode("SAVE_SSRC", context -> {
            String ssrc = (String) context.getData("ssrc");
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            String script = "redis.call('HSET', KEYS[1], KEYS[2], KEYS[3]);" +
                            "redis.call('HSET', KEYS[1], KEYS[3], KEYS[2]);" +
                            "return 2;";

            Redis.interactiveMode().eval(script, 3, REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY, deviceNumber + "_" + channelNumber, ssrc);
            context.awaitNext("SAVE_SSRC_COMPLETED");
        });

        taskFlow.addNode("SAVE_SSRC_COMPLETED", context -> {
            if (! (context.getInput() instanceof Number)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0002,
                        "redis error"));
                return;
            }

            context.fireNext("EXCHANGE_SDP");
        });

        taskFlow.addNode("EXCHANGE_SDP", context -> {
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            String webAddress = (String) context.getData("webAddress");
            String offerSdp = (String) context.getData("offerSdp");
            String streamPath = "/live/chid" + context.getData("ssrc");

            new SrsExchangeSdpTemplate(srsApiSsl, srsApiIp, srsApiPort, webAddress, offerSdp, streamPath).send();
            context.awaitNext("SRS_RESPONSE_ANSWER_SDP");
        });

        taskFlow.addNode("SRS_RESPONSE_ANSWER_SDP", context -> {
            JsonObject input = (JsonObject) context.getInput();
            if (input == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0003,
                        "can not get answer sdp"));
                return;
            }
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("sdp", input.getString("sdp"))
                    .put("ssrc", context.getData("ssrc")));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

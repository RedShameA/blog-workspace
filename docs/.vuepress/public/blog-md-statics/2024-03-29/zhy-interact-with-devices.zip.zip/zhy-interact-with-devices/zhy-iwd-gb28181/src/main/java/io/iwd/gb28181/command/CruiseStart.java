package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.gb28181.entity.CruiseStartInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

/**
 * 巡航线开启命令。
 */
public class CruiseStart  extends AdvancedCommand<Boolean> {

    private CruiseStartInitParams initParams = new CruiseStartInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return CruiseStart命令对象。
     */
    public CruiseStart setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return CruiseStart命令对象。
     */
    public CruiseStart setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置巡航线id。
     * @param cruiseId 巡航线id。
     * @return CruiseStart命令对象。
     */
    public CruiseStart setCruiseId(Integer cruiseId) {
        this.initParams.setCruiseId(cruiseId);
        return this;
    }

    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "CruiseStart", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

package io.iwd.gb28181;

public class Gb28181Const {

    public static final String TASK_PREFIX = "Gb28181";

    public static final String REDIS_CHANNEL_MAP_KEY = "gb28181_channel_map";
    public static final String REDIS_DEV_INFO_LOCK_KEY_PREFIX = "dev-info-lock_";
    public static final String REDIS_DEV_INFO_KEY_PREFIX = "dev-info_";
    public static final String REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY = "gb28181_real_video_info";
    public static final String REDIS_REAL_TIME_AUDIO_INFO_MAP_KEY = "gb28181_real_audio_info";
    public static final String REDIS_HISTORY_VIDEO_INFO_MAP_KEY = "gb28181_history_video_info";

    public static final int MIN_CONTROL_SPEED = 1;
    public static final int MAX_CONTROL_SPEED = 255;

    public static final int MIN_PRESET_ID_NUMBER = 1;
    public static final int MAX_PRESET_ID_NUMBER = 255;

    public static final int MIN_CRUISE_ID_NUMBER = 1;
    public static final int MAX_CRUISE_ID_NUMBER = 8;

    public static final int MIN_CRUISE_PRESET_INTERVAL = 15;
    public static final int MAX_CRUISE_PRESET_INTERVAL = 100;

    public static final int MIN_CRUISE_SPEED = 1;
    public static final int MAX_CRUISE_SPEED = 255;

    /**
     * 控制速度选项，用于替代控制速度值。
     */
    public enum ControlSpeedOption {
        /**
         * 一档。
         */
        ONE(25),
        /**
         * 二档。
         */
        TWO(50),
        /**
         * 三档。
         */
        THREE(75),
        /**
         * 四档。
         */
        FOUR(100),
        /**
         * 五档。
         */
        FIVE(125),
        /**
         * 六档。
         */
        SIX(150),
        /**
         * 七档。
         */
        SEVEN(175),
        /**
         * 八档。
         */
        EIGHT(200),
        /**
         * 九档。
         */
        NINE(225),
        /**
         * 十档。
         */
        TEN(250),
        ;
        private final int speed;
        ControlSpeedOption(int speed) {
            this.speed = speed;
        }
        public int speed() {
            return this.speed;
        }
    }

    /**
     * 镜头控制选项，用于选择镜头控制的方向。
     * 有些设备可能不支持LEFT_UP RIGHT_UP LEFT_DOWN RIGHT_DOWN方向。
     */
    public enum LensControlOption {
        /**
         * 停止。
         */
        STOP(0),
        /**
         * 向上。
         */
        UP(1),
        /**
         * 向下。
         */
        DOWN(2),
        /**
         * 向左。
         */
        LEFT(3),
        /**
         * 向右。
         */
        RIGHT(4),
        /**
         * 向左上。
         */
        LEFT_UP(5),
        /**
         * 向右上。
         */
        RIGHT_UP(6),
        /**
         * 向左下。
         */
        LEFT_DOWN(7),
        /**
         * 向右下。
         */
        RIGHT_DOWN(8),
        ;
        private final int code;
        LensControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 变倍控制选项，用于选择变倍加/变倍减。
     */
    public enum ZoomControlOption {
        /**
         * 停止。
         */
        STOP(0),
        /**
         * 变倍加。
         */
        PLUS(25),
        /**
         * 变倍减。
         */
        MINUS(26),
        ;
        private final int code;
        ZoomControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 调焦控制选项，用于控制调焦远/调焦近。
     */
    public enum FocusControlOption {
        /**
         * 停止。
         */
        STOP(0),
        /**
         * 调焦近。
         */
        NEAR(1),
        /**
         * 调焦远。
         */
        FAR(2),
        ;
        private final int code;
        FocusControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 光圈控制选项，用于控制光圈开/光圈关。
     */
    public enum ApertureControlOption {
        /**
         * 停止。
         */
        STOP(0),
        /**
         * 光圈开。
         */
        OPEN(3),
        /**
         * 光圈关。
         */
        CLOSE(4),
        ;
        private final int code;
        ApertureControlOption(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 视频流模式。
     */
    public enum VideoStreamMode {
        /**
         * UDP模式。
         */
        UDP(1),
        /**
         * TCP主动模式。
         * 目前SRS不支持TCP主动。
         */
        TCP_ACTIVE(2),
        /**
         * TCP被动模式。
         */
        TCP_PASSIVE(3),
        ;
        private final int code;
        VideoStreamMode(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 视频流协议。
     */
    public enum VideoStreamProtocol {
        /**
         * RTSP协议。
         */
        RTSP(2),
        ;
        private final int code;
        VideoStreamProtocol(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }

    /**
     * 录像回放速度选项。
     */
    public enum HistoryVideoSpeedOption {
        /**
         * 四分之一倍速。
         */
        X025("0.25"),
        /**
         * 二分之一倍速。
         */
        X05("0.5"),
        /**
         * 一倍速。
         */
        X1("1.0"),
        /**
         * 二倍速。
         */
        X2("2.0"),
        /**
         * 四倍速。
         */
        X4("4.0"),
        ;
        private final String value;
        HistoryVideoSpeedOption(String value) {
            this.value = value;
        }
        public String value() {
            return this.value;
        }
    }

    /**
     * 巡航速度选项。
     */
    public enum CruiseSpeedOption {
        /**
         * 一档。
         */
        ONE(25),
        /**
         * 二档。
         */
        TWO(50),
        /**
         * 三档。
         */
        THREE(75),
        /**
         * 四档。
         */
        FOUR(100),
        /**
         * 五档。
         */
        FIVE(125),
        /**
         * 六档。
         */
        SIX(150),
        /**
         * 七档。
         */
        SEVEN(175),
        /**
         * 八档。
         */
        EIGHT(200),
        /**
         * 九档。
         */
        NINE(225),
        /**
         * 十档。
         */
        TEN(250),
        ;
        private final int speed;
        CruiseSpeedOption(int speed) {
            this.speed = speed;
        }
        public int speed() {
            return this.speed;
        }
    }

    /**
     * 音频流模式。
     */
    public enum AudioStreamMode {
        /**
         * TCP主动模式。
         */
        TCP_ACTIVE(1),
        /**
         * TCP被动模式。
         */
        TCP_PASSIVE(2),
        ;
        private final int code;
        AudioStreamMode(int code) {
            this.code = code;
        }
        public int code() {
            return this.code;
        }
    }


}

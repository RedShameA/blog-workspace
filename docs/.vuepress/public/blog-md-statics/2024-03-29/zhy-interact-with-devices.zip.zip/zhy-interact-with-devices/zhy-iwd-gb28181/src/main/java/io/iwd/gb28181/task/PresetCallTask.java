package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.PresetCallInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import static io.iwd.gb28181.Gb28181Const.TASK_PREFIX;

public class PresetCallTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "PresetCall", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            PresetCallInitParams input = (PresetCallInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            String channelNumber = input.getChannelNumber();
            Integer presetId = input.getPresetId();

            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("handle_val", 3)
                    .put("command_val", 2)
                    .put("devicenum", deviceNumber)
                    .put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber)
                    .put("yzwId", presetId);

            Redis.silentMode().publish("dev_control", data.stringify());

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer state = input.getInteger("state");
            if (state == null || state != 1) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "sip service response error: " + input.getInteger("errorcode")));
                return;
            }
            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }
}

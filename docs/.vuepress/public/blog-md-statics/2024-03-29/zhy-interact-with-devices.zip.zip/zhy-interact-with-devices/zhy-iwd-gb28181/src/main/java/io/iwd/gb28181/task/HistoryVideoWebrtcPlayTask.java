package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.http.srs.template.SrsExchangeSdpTemplate;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.HistoryVideoWebrtcPlayInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import static io.iwd.gb28181.Gb28181Const.REDIS_HISTORY_VIDEO_INFO_MAP_KEY;
import static io.iwd.gb28181.Gb28181Const.TASK_PREFIX;

public class HistoryVideoWebrtcPlayTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HistoryVideoWebrtcPlay", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            HistoryVideoWebrtcPlayInitParams input = (HistoryVideoWebrtcPlayInitParams) context.getInput();
            context.putData("deviceNumber", input.getDeviceNumber());
            context.putData("channelNumber", input.getChannelNumber());
            context.putData("startTime", String.valueOf(input.getStartTime().getTime() / 1000));
            context.putData("endTime", String.valueOf(input.getEndTime().getTime() / 1000));
            context.putData("videoStreamMode", input.getVideoStreamMode().code());
            context.putData("mediaServerIp", input.getMediaServerIp());
            context.putData("mediaServerPort", input.getMediaServerPort());
            context.putData("offerSdp", input.getOfferSdp());
            context.putData("srsApiSsl", input.getSrsApiSsl());
            context.putData("srsApiIp", input.getSrsApiIp());
            context.putData("srsApiPort", input.getSrsApiPort());
            context.putData("webAddress", input.getWebAddress());

            context.fireNext("ISSUE_COMMAND");
        });

        taskFlow.addNode("ISSUE_COMMAND", context -> {

            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("sessionid", context.getTaskId())
                    .put("starttime", context.getData("startTime"))
                    .put("endtime", context.getData("endTime"))
                    .put("handle_val", 6)
                    .put("command_val", 1)
                    .put("devicenum", context.getData("deviceNumber"))
                    .put("chd_num", context.getData("channelNumber"))
                    .put("videotransport", context.getData("videoStreamMode"))
                    .put("streamip", context.getData("mediaServerIp"))
                    .put("streamport", context.getData("mediaServerPort"));

            Redis.silentMode().publish("dev_historyvideo_start", data.stringify());

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer state = input.getInteger("state");
            if (state == null || state != 1) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "sip service response error"));
                return;
            }

            Integer ssrcValue = input.getInteger("devicessrc");
            if (ssrcValue == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "sip service response no ssrc"));
                return;
            }
            context.putData("ssrc", ssrcValue.toString());
            context.putData("sessionId", input.getString("msgid"));

            context.fireNext("SAVE_HISTORY_VIDEO_INFO");
        });

        taskFlow.addNode("SAVE_HISTORY_VIDEO_INFO", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            String ssrc = (String) context.getData("ssrc");
            String script = "local dncnList = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(dncnList == false or dncnList == '') " +
                            "then redis.call('HSET', KEYS[1], KEYS[2], ARGV[1]); " +
                            "else redis.call('HSET', KEYS[1], KEYS[2], dncnList..','..ARGV[1]);" +
                            "end;" +
                            "redis.call('HSET', KEYS[1], KEYS[3], ARGV[2]);" +
                            "return 2;";

            Redis.interactiveMode().eval(script, 3,
                    REDIS_HISTORY_VIDEO_INFO_MAP_KEY, ssrc, "ts:" + ssrc,
                    deviceNumber + "_" + channelNumber, String.valueOf(System.currentTimeMillis()));

            context.awaitNext("SAVE_HISTORY_VIDEO_INFO_COMPLETED");
        });

        taskFlow.addNode("SAVE_HISTORY_VIDEO_INFO_COMPLETED", context -> {
            if (! (context.getInput() instanceof Number)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "redis error"));
                return;
            }

            context.fireNext("EXCHANGE_SDP");
        });

        taskFlow.addNode("EXCHANGE_SDP", context -> {
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            String webAddress = (String) context.getData("webAddress");
            String offerSdp = (String) context.getData("offerSdp");
            String streamPath = "/live/chid" + context.getData("ssrc");

            new SrsExchangeSdpTemplate(srsApiSsl, srsApiIp, srsApiPort, webAddress, offerSdp, streamPath).send();
            context.awaitNext("SRS_RESPONSE_ANSWER_SDP");
        });

        taskFlow.addNode("SRS_RESPONSE_ANSWER_SDP", context -> {
            JsonObject input = (JsonObject) context.getInput();
            if (input == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0003,
                        "can not get answer sdp"));
                return;
            }
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("sdp", input.getString("sdp"))
                    .put("sessionId", context.getData("sessionId"))
                    .put("ssrc", context.getData("ssrc")));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

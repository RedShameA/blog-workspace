package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.util.Gb28181Validator;

import java.util.Date;

public class HistoryVideoFileQueryInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private Date startTime;

    private Date endTime;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    @Override
    public HistoryVideoFileQueryInitParams populateDefault() {
        return this;
    }

    @Override
    public HistoryVideoFileQueryInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (this.startTime == null) {
            throw new IllegalArgumentException("gb28181 start time format error");
        }
        if (this.endTime == null) {
            throw new IllegalArgumentException("gb28181 end time format error");
        }
        if (this.startTime.compareTo(this.endTime) >= 0) {
            throw new IllegalArgumentException("gb28181 start time is earlier than end time");
        }
        return this;
    }
}

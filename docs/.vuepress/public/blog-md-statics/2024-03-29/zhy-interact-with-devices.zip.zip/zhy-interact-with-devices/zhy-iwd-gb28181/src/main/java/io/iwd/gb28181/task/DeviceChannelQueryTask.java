package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.log.Logger;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.DeviceChannelQueryInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import static io.iwd.gb28181.Gb28181Const.*;

public class DeviceChannelQueryTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "DeviceChannelQuery", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("QUERY_CACHE_IF_ALLOWED", context -> {
            DeviceChannelQueryInitParams data = (DeviceChannelQueryInitParams) context.getInput();
            String deviceNumber = data.getDeviceNumber();
            context.putData("deviceNumber", deviceNumber);

            Boolean useCache = data.getUseCache();

            if (useCache != null && useCache) {
                Redis.interactiveMode().hget(REDIS_CHANNEL_MAP_KEY, deviceNumber);

                context.awaitNext("GOT_CACHE");
                return;
            }

            context.fireNext("QUERY_UP_TO_DATE");
        });

        taskFlow.addNode("GOT_CACHE", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                Logger.warn("error occur while getting cache from redis");
                context.putData("hasRedisError", true);
                context.fireNext("QUERY_UP_TO_DATE");
                return;
            }
            String channelMapStr = (String) input;
            if (channelMapStr == null) {
                context.fireNext("QUERY_UP_TO_DATE");
                return;
            }

            JsonObject channelMap = JsonObject.from(channelMapStr);
            if (channelMap == null || channelMap.size() == 0) {
                context.fireNext("QUERY_UP_TO_DATE");
                return;
            }

            context.complete(JsonObject.create()
                        .put("code", Code.NORMAL_SUCCESS | 0x0001)
                        .put("data", channelMap));
        });

        taskFlow.addNode("QUERY_UP_TO_DATE", context -> {
            JsonObject message = JsonObject.create()
                    .put("handle_val", 7)
                    .put("command_val", 1)
                    .put("devicenum", context.getData("deviceNumber"))
                    .put("chd_num", "")
                    .put("msgid", context.getTaskId());

            Redis.silentMode().publish("dev_information_query", message.stringify());

            context.awaitNext("RECEIVED_CHANNEL_INFO", 10000L);
        });

        taskFlow.addNode("RECEIVED_CHANNEL_INFO", context -> {
            JsonObject sipData = (JsonObject) context.getInput();
            JsonObject data = JsonObject.create();

            for (int i = 0; ; ++i) {
                String key = "devicelist_" + i;
                JsonObject channel = sipData.getJsonObject(key);
                if (channel == null) {
                    break;
                }
                String channelNumber = channel.getString("deviceid");
                if (StringUtil.isEmpty(channelNumber)) {
                    continue;
                }
                data.put(channelNumber, channel);
            }

            context.putData("data", data);

            Redis.interactiveMode().hset(REDIS_CHANNEL_MAP_KEY, (String) context.getData("deviceNumber"), data.stringify());

            context.awaitNext("CACHE_CHANNEL_INFO_COMPLETED");
        });

        taskFlow.addNode("CACHE_CHANNEL_INFO_COMPLETED", context -> {
            Object input = context.getInput();
            if (! (input instanceof String) || !"OK".equals(input)) {
                context.complete(JsonObject.create()
                        .put("code", Code.EXCEPTIONS_OCCUR_BUT_CONSIDERED_COMPLETED | 0x0001)
                        .put("data", context.getData("data")));
                return;
            }
            if (context.getData("hasRedisError") != null) {
                context.complete(JsonObject.create()
                        .put("code", Code.SUCCESS_WITH_ACCEPTABLE_PROBLEM | 0x0001)
                        .put("data", context.getData("data")));
                return;
            }
            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0002)
                    .put("data", context.getData("data")));
        });

        taskFlow.setDefaultEntrance("QUERY_CACHE_IF_ALLOWED");

        return taskFlow;
    }
}

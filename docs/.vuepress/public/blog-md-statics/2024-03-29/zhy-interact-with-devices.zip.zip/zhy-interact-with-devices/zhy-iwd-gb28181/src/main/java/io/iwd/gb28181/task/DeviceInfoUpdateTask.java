package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.Generator;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.Gb28181Const;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;
import io.iwd.gb28181.util.Gb28181Validator;

public class DeviceInfoUpdateTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(Gb28181Const.TASK_PREFIX, "DeviceInfoUpdate", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            Object input = context.getInput();
            if (! (input instanceof String)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_ILLEGAL_INIT_PARAMS | 0x0001,
                        "input only accept raw json string"));
                return;
            }
            String rawMessage = (String) input;
            JsonObject data = JsonObject.from(rawMessage);
            if (data == null) {
                context.fail(new CodeMessageJsonObject(
                                Code.FAILED_WITH_ILLEGAL_INIT_PARAMS | 0x0002,
                                "input only accept raw json string"));
                return;
            }
            String deviceNumber = data.getString("devicenum");
            if (! Gb28181Validator.isGb28181DeviceNumber(deviceNumber)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_ILLEGAL_INIT_PARAMS | 0x0003,
                        "can not find legal device number"));
                return;
            }
            Integer state = data.getInteger("state");
            if (state == null) {
                context.fail(new CodeMessageJsonObject(
                                Code.FAILED_WITH_ILLEGAL_INIT_PARAMS | 0x0004,
                                "can not find legal state number"));
                return;
            }
            if (data.getString("time") == null) {
                data.put("time", "");
            }
            if (data.getString("deviceip") == null) {
                data.put("deviceip", "");
            }
            if (data.getInteger("deviceport") == null) {
                data.put("deviceport", 0);
            }
            if (data.getString("extranetip") == null) {
                data.put("extranetip", "");
            }
            if (data.getInteger("extranetport") == null) {
                data.put("extranetport", 0);
            }
            if (data.getInteger("expires") == null) {
                data.put("expires", 3600);
            }
            if (data.getInteger("protocol_tp") == null) {
                data.put("protocol_tp", 2);
            }

            context.putData("deviceNumber", deviceNumber);
            context.putData("updateInfo", data);
            context.putData("state", state);

            context.putData("lock", Generator.create32UniqueId());
            context.putData("retry", 3); //加锁可以重试三次

            context.fireNext("LOCK_AND_GET_DEVICE_INFO");
        });

        taskFlow.addNode("LOCK_AND_GET_DEVICE_INFO", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String deviceInfoLockKey = Gb28181Const.REDIS_DEV_INFO_LOCK_KEY_PREFIX + deviceNumber;
            String deviceInfoKey = Gb28181Const.REDIS_DEV_INFO_KEY_PREFIX + deviceNumber;
            String lock = (String) context.getData("lock");
            String script = "local lock = redis.call('GET',KEYS[1]);" +
                            "if(lock ~= false) then return 0; end;" +
                            "redis.call('SET',KEYS[1],ARGV[1]);" +
                            "redis.call('EXPIRE',KEYS[1],10);" +
                            "return redis.call('GET',KEYS[2]);";

            Redis.interactiveMode().eval(script, 2, deviceInfoLockKey, deviceInfoKey, lock);

            context.awaitNext("LOCK_AND_GET_DEVICE_INFO_COMPLETED_AND_UPDATE");
        });

        taskFlow.addNode("LOCK_AND_GET_DEVICE_INFO_COMPLETED_AND_UPDATE", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "lock and get device info error"));
                return;
            }
            if (input instanceof Number) { //没获取到锁
                Integer retry = (Integer) context.getData("retry");
                if (retry <= 0) {
                    context.fail(new CodeMessageJsonObject(
                                    Code.FAILED_WITH_LOCK_OCCUPIED | 0x0001,
                                    "can not get lock"));
                    return;
                }
                --retry;
                context.putData("retry", retry);

                context.delayNext("LOCK_AND_GET_DEVICE_INFO", 1000);
                return;
            }
            if (input == null) { //没有获取到设备信息
                context.complete(new CodeMessageJsonObject(
                                Code.COMPLETED_WITH_UNEXPECTED_RESULT | 0x0001,
                                "can not find device info, task cancel"));
                return;
            }
            String deviceInfoStr = (String) input;
            JsonObject deviceInfo = JsonObject.from(deviceInfoStr);
            if (deviceInfo == null) {
                context.fail(new CodeMessageJsonObject(
                                Code.FAILED_WITH_ILLEGAL_DATA | 0x0001,
                                "parse json error"));
                return;
            }

            Integer state = (Integer) context.getData("state");
            JsonObject updateInfo = (JsonObject) context.getData("updateInfo");
            deviceInfo.put("state", updateInfo.getInteger("state"));
            deviceInfo.put("time", updateInfo.getString("time"));
            if (state != 0) {
                deviceInfo.put("deviceip", updateInfo.getString("deviceip"));
                deviceInfo.put("deviceport", updateInfo.getInteger("deviceport"));
                deviceInfo.put("extranetip", updateInfo.getString("extranetip"));
                deviceInfo.put("extranetport", updateInfo.getInteger("extranetport"));
                deviceInfo.put("expires", updateInfo.getInteger("expires"));
                deviceInfo.put("protocol_tp", updateInfo.getInteger("protocol_tp"));
            }

            String deviceNumber = (String) context.getData("deviceNumber");
            String deviceInfoLockKey = Gb28181Const.REDIS_DEV_INFO_LOCK_KEY_PREFIX + deviceNumber;
            String deviceInfoKey = Gb28181Const.REDIS_DEV_INFO_KEY_PREFIX + deviceNumber;
            String lock = (String) context.getData("lock");

            String script = "local lock = redis.call('GET',KEYS[1]);" +
                            "if(lock ~= ARGV[1]) then return 0; end;" +
                            "redis.call('SET',KEYS[2],ARGV[2]);" +
                            "redis.call('DEL',KEYS[1]);";
            if (state != 1) {
                script += "redis.call('HDEL',KEYS[3],KEYS[4]);";
                Redis.interactiveMode().eval(script, 4, deviceInfoLockKey, deviceInfoKey, Gb28181Const.REDIS_CHANNEL_MAP_KEY, deviceNumber, lock, deviceInfo.toString());
            } else {
                Redis.interactiveMode().eval(script, 2, deviceInfoLockKey, deviceInfoKey, lock, deviceInfo.toString());
            }

            context.awaitNext("UPDATE_DEVICE_INFO_COMPLETED");
        });

        taskFlow.addNode("UPDATE_DEVICE_INFO_COMPLETED", context -> {
            if (context.getInput() instanceof Number) {
                context.complete(new CodeMessageJsonObject(
                                Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0001,
                                "lose lock, task cancel"));
                return;
            }

            context.complete(new CodeMessageJsonObject(
                            Code.NORMAL_SUCCESS | 0x0001,
                            "device info update success"));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

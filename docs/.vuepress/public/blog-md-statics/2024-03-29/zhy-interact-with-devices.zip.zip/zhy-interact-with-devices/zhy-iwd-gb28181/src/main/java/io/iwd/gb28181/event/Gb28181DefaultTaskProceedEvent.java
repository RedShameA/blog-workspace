package io.iwd.gb28181.event;

import io.iwd.common.event.TaskProceedEvent;

public class Gb28181DefaultTaskProceedEvent extends TaskProceedEvent {

    public Gb28181DefaultTaskProceedEvent(String taskId, Object data) {
        super(taskId, data);
    }

}

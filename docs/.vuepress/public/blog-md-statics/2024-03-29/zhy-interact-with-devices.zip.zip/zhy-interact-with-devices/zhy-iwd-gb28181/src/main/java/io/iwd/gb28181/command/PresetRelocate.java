package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.gb28181.entity.PresetRelocateInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

/**
 * 预置位重新定位命令。
 */
public class PresetRelocate extends AdvancedCommand<Boolean> {

    private PresetRelocateInitParams initParams = new PresetRelocateInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return PresetRelocate命令对象。
     */
    public PresetRelocate setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PresetRelocate命令对象。
     */
    public PresetRelocate setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置预置位id。
     * @param presetId 预置位id。
     * @return PresetRelocate命令对象。
     */
    public PresetRelocate setPresetId(Integer presetId) {
        this.initParams.setPresetId(presetId);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PresetRelocate", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }

}

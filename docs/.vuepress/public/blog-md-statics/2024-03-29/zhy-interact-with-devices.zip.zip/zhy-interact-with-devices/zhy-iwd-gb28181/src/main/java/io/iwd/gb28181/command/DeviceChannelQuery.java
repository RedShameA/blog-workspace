package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.gb28181.entity.DeviceChannelQueryInitParams;
import io.iwd.gb28181.entity.DeviceChannelQueryResult;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

/**
 * 设备通道查询命令。
 */
public class DeviceChannelQuery extends AdvancedCommand<DeviceChannelQueryResult> {

    private DeviceChannelQueryInitParams initParams = new DeviceChannelQueryInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return DeviceChannelQuery命令对象。
     */
    public DeviceChannelQuery setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置是否使用redis缓存的数据。
     * @param useCache 是否使用缓存。
     * @return DeviceChannelQuery命令对象。
     */
    public DeviceChannelQuery setUseCache(Boolean useCache) {
        this.initParams.setUseCache(useCache);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "DeviceChannelQuery", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public DeviceChannelQueryResult await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                Integer code = completedResult.getInteger("code");
                if (Code.isCompleted(code)) {
                    JsonObject data = completedResult.getJsonObject("data");
                    return new DeviceChannelQueryResult(data);
                }
            }
            return new DeviceChannelQueryResult(JsonObject.empty());
        }, time);
    }
}

package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.HistoryVideoStopInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import java.util.List;

import static io.iwd.gb28181.Gb28181Const.*;

public class HistoryVideoStopTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HistoryVideoStop", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            HistoryVideoStopInitParams input = (HistoryVideoStopInitParams) context.getInput();
            context.putData("deviceNumber", input.getDeviceNumber());
            context.putData("channelNumber", input.getChannelNumber());
            context.putData("ssrc", input.getSsrc());
            context.putData("retry", 3); //允许最多重试3次

            context.fireNext("QUERY_HISTORY_VIDEO_INFO");
        });

        taskFlow.addNode("QUERY_HISTORY_VIDEO_INFO", context -> {
            String ssrc = (String) context.getData("ssrc");
            String script = "local result = {};" +
                            "result[1] = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(not result[1]) then result[1] = ''; end;" +
                            "result[2] = redis.call('HGET', KEYS[1], KEYS[3]);" +
                            "if(not result[2]) then result[2] = ''; end;" +
                            "return result;";
            Redis.interactiveMode().eval(script, 3, REDIS_HISTORY_VIDEO_INFO_MAP_KEY, ssrc, "ts:" + ssrc);

            context.awaitNext("GOT_HISTORY_VIDEO_INFO");
        });

        taskFlow.addNode("GOT_HISTORY_VIDEO_INFO", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "query history video info error"));
                return;
            }
            @SuppressWarnings("unchecked")
            List<String> info = (List<String>) input;
            if (info.isEmpty()) {
                context.fireNext("ISSUE_COMMAND");
                return;
            }
            String dncnList = info.get(0);
            if (StringUtil.isEmpty(dncnList)) {
                context.fireNext("ISSUE_COMMAND");
                return;
            }
            String timestamp = info.get(1);
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            String target = deviceNumber + "_" + channelNumber;
            StringBuilder newListBuilder = new StringBuilder();
            for (String dncn : dncnList.split(",")) {
                //TODO 可以验一下数据
                if (!target.equals(dncn)) {
                    newListBuilder.append(dncn).append(',');
                }
            }
            if (newListBuilder.length() > 0) {
                newListBuilder.deleteCharAt(newListBuilder.length() - 1);
            }
            String newList = newListBuilder.toString();

            if (newList.equals(dncnList)) { //列表里不包含目标设备通道，不需要更新
                context.fireNext("ISSUE_COMMAND");
                return;
            }
            //列表已修改，更新信息
            context.putData("newList", newList);
            context.putData("oldList", dncnList);
            context.putData("oldTimestamp", timestamp);
            context.fireNext("UPDATE_HISTORY_VIDEO_INFO");
        });

        taskFlow.addNode("UPDATE_HISTORY_VIDEO_INFO", context -> {
            String ssrc = (String) context.getData("ssrc");
            String oldList = (String) context.getData("oldList");
            String newList = (String) context.getData("newList");
            String oldTimestamp = (String) context.getData("oldTimestamp");
            String script = "local ts = redis.call('HGET', KEYS[1], KEYS[3]);" +
                            "local dncnList = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(ts ~= ARGV[1] or dncnList ~= ARGV[2]) then return; end;" +
            (StringUtil.isEmpty(newList)
                            ? "redis.call('HDEL', KEYS[1], KEYS[2]);"
                            : "redis.call('HSET', KEYS[1], KEYS[2], ARGV[3]);") +
                            "redis.call('HSET', KEYS[1], KEYS[3], ARGV[4]);" +
                            "return 2;";
            Redis.interactiveMode().eval(script, 3,
                    REDIS_HISTORY_VIDEO_INFO_MAP_KEY, ssrc, "ts:" + ssrc,
                    oldTimestamp, oldList, newList, String.valueOf(System.currentTimeMillis()));

            context.awaitNext("UPDATE_HISTORY_VIDEO_INFO_COMPLETED");
        });

        taskFlow.addNode("UPDATE_HISTORY_VIDEO_INFO_COMPLETED", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0002,
                        "update history video info error"));
                return;
            }
            if (input == null) {
                int retry = (Integer) context.getData("retry");
                if (retry > 0) {
                    retry--;
                    context.putData("retry", retry);
                    context.delayNext("QUERY_HISTORY_VIDEO_INFO", 100);
                    return;
                }
                context.putData("updateFailed", true);
            }
            context.fireNext("ISSUE_COMMAND");
        });

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            JsonObject data = JsonObject.create()
                    .put("msgid", "")
                    .put("handle_val", 6)
                    .put("command_val", 2)
                    .put("devicenum", deviceNumber)
                    .put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber)
                    .put("devicessrc", context.getData("ssrc"));
            Redis.silentMode().publish("dev_historyvideo_stop", data.stringify());

            int retry = (Integer) context.getData("retry");
            if (retry < 3) {
                Boolean updateFailed = (Boolean) context.getData("updateFailed");
                if (updateFailed != null) {
                    context.complete(new CodeMessageJsonObject(
                            Code.SUCCESS_WITH_ACCEPTABLE_PROBLEM | 0x0001,
                            "update history video info failed, but command issued"));
                    return;
                }
                context.complete(new CodeMessageJsonObject(
                        Code.SUCCESS_WITH_RETRY | 0x0001,
                        "update history video info success with retry " + (3 - retry) + " times, command issued"));
                return;
            }
            context.complete(new CodeMessageJsonObject(
                    Code.SUCCESS_WITH_NO_RESPONSE | 0x0001,
                    "update history video info success, command issued"));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

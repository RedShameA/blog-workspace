package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.entity.HistoryVideoStopInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

/**
 * 录像回放停止命令。
 */
public class HistoryVideoStop extends AdvancedCommand<Boolean> {

    private HistoryVideoStopInitParams initParams = new HistoryVideoStopInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoStop命令对象。
     */
    public HistoryVideoStop setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoStop命令对象。
     */
    public HistoryVideoStop setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置ssrc。
     * @param ssrc ssrc。
     * @return HistoryVideoStop命令对象。
     */
    public HistoryVideoStop setSsrc(String ssrc) {
        this.initParams.setSsrc(ssrc);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoStop", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.entity.HistoryVideoSpeedControlInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

import static io.iwd.gb28181.Gb28181Const.*;

/**
 * 录像回放速度控制命令。
 */
public class HistoryVideoSpeedControl extends AdvancedCommand<Boolean> {

    private HistoryVideoSpeedControlInitParams initParams = new HistoryVideoSpeedControlInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置会话id。
     * @param sessionId 会话id。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setSessionId(String sessionId) {
        this.initParams.setSessionId(sessionId);
        return this;
    }

    /**
     * 设置录像回放速度。
     * @param historyVideoSpeedOption 录像回放速度。
     * @return HistoryVideoSpeedControl命令对象。
     */
    public HistoryVideoSpeedControl setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.initParams.setHistoryVideoSpeedOption(historyVideoSpeedOption);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "HistoryVideoSpeedControl", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

package io.iwd.gb28181.entity;

/**
 * 历史视频webrtc播放的结果。
 */
public class HistoryVideoWebrtcPlayResult {

    /**
     * 播放是否成功。
     */
    private final boolean success;

    /**
     * webrtc answer sdp。
     */
    private final String sdp;

    /**
     * 流媒体服务可能返回的会话id，用于标记一个视频流或类似的概念。
     */
    private final String sessionId;

    /**
     * 流媒体服务可能返回的ssrc。
     */
    private final String ssrc;

    /**
     * 标准构造器。
     * @param success 播放是否成功。
     * @param sdp webrtc的answer sdp。
     * @param sessionId 会话id。
     * @param ssrc ssrc。
     */
    public HistoryVideoWebrtcPlayResult(boolean success, String sdp, String sessionId, String ssrc) {
        this.success = success;
        this.sdp = sdp;
        this.sessionId = sessionId;
        this.ssrc = ssrc;
    }

    /**
     * 返回是否播放成功。
     * @return 是否播放成功。
     */
    public boolean isSuccess() {
        return this.success;
    }

    /**
     * 返回answer sdp。
     * @return answer sdp。
     */
    public String getSdp() {
        return this.sdp;
    }

    /**
     * 返回可能存在的会话id。
     * @return 会话id。
     */
    public String getSessionId() {
        return this.sessionId;
    }

    /**
     * 返回可能存在的ssrc。
     * @return ssrc。
     */
    public String getSsrc() {
        return this.ssrc;
    }

    @Override
    public String toString() {
        return "{\"success\":" + this.success + ",\"sdp\":" + this.sdp + ",\"sessionId\":" + this.sessionId + ",\"ssrc\":" + this.ssrc + "}";
    }

}

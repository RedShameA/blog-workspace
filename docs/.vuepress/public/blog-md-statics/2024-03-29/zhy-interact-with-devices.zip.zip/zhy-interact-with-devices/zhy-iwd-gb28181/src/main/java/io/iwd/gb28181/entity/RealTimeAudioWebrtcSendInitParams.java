package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.ext.util.NumberUtil;
import io.iwd.common.ext.util.PortConverter;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.ext.util.Validator;
import io.iwd.gb28181.util.Gb28181Validator;

import static io.iwd.gb28181.Gb28181Const.*;

public class RealTimeAudioWebrtcSendInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private AudioStreamMode audioStreamMode;

    private String pullAudioStreamIp;

    private String offerSdp;

    private Boolean srsApiSsl;

    private String srsApiIp;

    private Integer srsApiPort;

    private String webAddress;

    private PortConverter srsAudioStreamPortConverter;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public AudioStreamMode getAudioStreamMode() {
        return this.audioStreamMode;
    }

    public void setAudioStreamMode(AudioStreamMode audioStreamMode) {
        this.audioStreamMode = audioStreamMode;
    }

    public String getPullAudioStreamIp() {
        return this.pullAudioStreamIp;
    }

    public void setPullAudioStreamIp(String pullAudioStreamIp) {
        this.pullAudioStreamIp = pullAudioStreamIp;
    }

    public String getOfferSdp() {
        return this.offerSdp;
    }

    public void setOfferSdp(String offerSdp) {
        this.offerSdp = offerSdp;
    }

    public Boolean getSrsApiSsl() {
        return this.srsApiSsl;
    }

    public void setSrsApiSsl(Boolean srsApiSsl) {
        this.srsApiSsl = srsApiSsl;
    }

    public String getSrsApiIp() {
        return this.srsApiIp;
    }

    public void setSrsApiIp(String srsApiIp) {
        this.srsApiIp = srsApiIp;
    }

    public Integer getSrsApiPort() {
        return this.srsApiPort;
    }

    public void setSrsApiPort(Integer srsApiPort) {
        this.srsApiPort = srsApiPort;
    }

    public String getWebAddress() {
        return this.webAddress;
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }

    public PortConverter getSrsAudioStreamPortConverter() {
        return srsAudioStreamPortConverter;
    }

    public void setSrsAudioStreamPortConverter(PortConverter srsAudioStreamPortConverter) {
        this.srsAudioStreamPortConverter = srsAudioStreamPortConverter;
    }

    @Override
    public RealTimeAudioWebrtcSendInitParams populateDefault() {
        if (this.audioStreamMode == null) {
            this.audioStreamMode = AudioStreamMode.TCP_ACTIVE;
        }
        EnvironmentHolder.get().config().getInBatch(conf -> {
            if (this.pullAudioStreamIp == null) {
                this.pullAudioStreamIp = (String) conf.getExtConfigInBatch("gb28181", "srs", "pull_audio_stream_ip");
            }
            if (this.srsApiSsl == null) {
                this.srsApiSsl = (Boolean) conf.getGlobalConfigInBatch("srs", "api_ssl");
            }
            if (this.srsApiIp == null) {
                this.srsApiIp = (String) conf.getGlobalConfigInBatch("srs", "api_ip");
            }
            if (this.srsApiPort == null) {
                this.srsApiPort = NumberUtil.toInt(conf.getGlobalConfigInBatch("srs", "api_port"));
            }
            if (this.webAddress == null) {
                this.webAddress = (String) conf.getGlobalConfigInBatch("srs", "web_address");
            }
        });
        if (this.srsAudioStreamPortConverter == null) {
            this.srsAudioStreamPortConverter = p -> p;
        }
        return this;
    }

    @Override
    public RealTimeAudioWebrtcSendInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (this.audioStreamMode == null) {
            throw new IllegalArgumentException("gb28181 audio stream mode error");
        }
        if (!Validator.isIpv4(this.pullAudioStreamIp)) {
            throw new IllegalArgumentException("gb28181 pull audio stream ip format error");
        }
        if (StringUtil.isEmpty(offerSdp)) {
            throw new IllegalArgumentException("gb28181 webrtc offer sdp format error");
        }
        if (this.srsApiSsl == null) {
            throw new IllegalArgumentException("gb28181 srs api ssl error");
        }
        if (!Validator.isIpv4(this.srsApiIp)) {
            throw new IllegalArgumentException("gb28181 srs api ip format error");
        }
        if (this.srsApiPort == null || this.srsApiPort < 1 || srsApiPort > 65535) {
            throw new IllegalArgumentException("gb28181 srs api port format error");
        }
        if (!Validator.isIpv4AndPort(this.webAddress)) {
            throw new IllegalArgumentException("gb28181 web address format error");
        }
        if (this.srsAudioStreamPortConverter == null) {
            throw new IllegalArgumentException("gb28181 srs audio stream port converter error");
        }
        return this;
    }

}

package io.iwd.gb28181.util;

import io.iwd.common.ext.util.StringUtil;

public final class Gb28181Validator {

    public static boolean isGb28181DeviceNumber(String deviceNumber) {
        if (StringUtil.isEmpty(deviceNumber)) {
            return false;
        }
        if (deviceNumber.length() != 20) {
            return false;
        }
        for (int i = 0; i < 20; i++) {
            char c = deviceNumber.charAt(i);
            if (c < '0' || c > '9') {
                return false;
            }
        }
        return true;
    }

}

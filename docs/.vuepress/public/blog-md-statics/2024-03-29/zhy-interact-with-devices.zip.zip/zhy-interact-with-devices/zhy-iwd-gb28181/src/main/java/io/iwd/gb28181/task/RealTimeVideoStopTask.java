package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.RealTimeVideoStopInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import static io.iwd.gb28181.Gb28181Const.*;

public class RealTimeVideoStopTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "RealTimeVideoStop", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            RealTimeVideoStopInitParams input = (RealTimeVideoStopInitParams) context.getInput();
            context.putData("deviceNumber", input.getDeviceNumber());
            context.putData("channelNumber", input.getChannelNumber());

            context.fireNext("REMOVE_REAL_TIME_VIDEO_INFO");
        });

        taskFlow.addNode("REMOVE_REAL_TIME_VIDEO_INFO", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            String script = "local ssrc = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(ssrc ~= false and redis.call('HGET', KEYS[1], ssrc) == KEYS[2]) " +
                            "then redis.call('HDEL', KEYS[1], ssrc); end;" +
                            "redis.call('HDEL', KEYS[1], KEYS[2]); return;";
            Redis.interactiveMode().eval(script, 2, REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY, deviceNumber + "_" + channelNumber);
            context.awaitNext("REMOVE_REAL_TIME_VIDEO_INFO_COMPLETED");
        });

        taskFlow.addNode("REMOVE_REAL_TIME_VIDEO_INFO_COMPLETED", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                context.putData("redisError", true);
            }
            context.fireNext("ISSUE_COMMAND");
        });

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("handle_val", 5)
                    .put("command_val", 2)
                    .put("devicenum", deviceNumber)
                    .put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber);

            Redis.silentMode().publish("dev_realvideo_stop", data.stringify());

            if (context.getData("redisError") != null) {
                context.complete(new CodeMessageJsonObject(
                        Code.SUCCESS_WITH_ACCEPTABLE_PROBLEM | 0x0001,
                        null));
            } else {
                context.complete(new CodeMessageJsonObject(
                        Code.SUCCESS_WITH_NO_RESPONSE | 0x0001,
                        null));
            }
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

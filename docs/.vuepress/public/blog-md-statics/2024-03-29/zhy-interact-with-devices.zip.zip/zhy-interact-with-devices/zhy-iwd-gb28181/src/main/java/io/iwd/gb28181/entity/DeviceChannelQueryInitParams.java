package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.util.Gb28181Validator;

public class DeviceChannelQueryInitParams implements TaskInitParams {

    private String deviceNumber;

    private Boolean useCache;

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Boolean getUseCache() {
        return useCache;
    }

    public void setUseCache(Boolean useCache) {
        this.useCache = useCache;
    }

    @Override
    public DeviceChannelQueryInitParams populateDefault() {
        if (this.useCache == null) {
            this.useCache = Boolean.FALSE;
        }
        return this;
    }

    @Override
    public DeviceChannelQueryInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        return this;
    }
}

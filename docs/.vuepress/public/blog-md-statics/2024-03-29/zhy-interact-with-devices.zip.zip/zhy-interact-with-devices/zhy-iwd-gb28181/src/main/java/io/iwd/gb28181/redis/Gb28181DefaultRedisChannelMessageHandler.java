package io.iwd.gb28181.redis;

import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.stdio.redis.RedisChannelMessageHandler;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

public class Gb28181DefaultRedisChannelMessageHandler extends RedisChannelMessageHandler {

    @Override
    public void handle(String channelName, String message) {
        JsonObject sipData = JsonObject.from(message);
        if (sipData == null) {
            return;
        }
        String messageId = sipData.getString("msgid");
        if (messageId == null) {
            return;
        }
        new Gb28181DefaultTaskProceedEvent(messageId, sipData).publish();
    }
}

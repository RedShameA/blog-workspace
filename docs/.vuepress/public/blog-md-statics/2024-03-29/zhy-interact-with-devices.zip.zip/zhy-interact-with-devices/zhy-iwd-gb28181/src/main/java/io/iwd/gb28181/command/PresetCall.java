package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.gb28181.entity.PresetCallInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

/**
 * 预置位调用命令。
 */
public class PresetCall extends AdvancedCommand<Boolean> {

    private PresetCallInitParams initParams = new PresetCallInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return PresetCall命令对象。
     */
    public PresetCall setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return PresetCall命令对象。
     */
    public PresetCall setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置预置位id。
     * @param presetId 预置位id。
     * @return PresetCall命令对象。
     */
    public PresetCall setPresetId(Integer presetId) {
        this.initParams.setPresetId(presetId);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "PresetCall", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

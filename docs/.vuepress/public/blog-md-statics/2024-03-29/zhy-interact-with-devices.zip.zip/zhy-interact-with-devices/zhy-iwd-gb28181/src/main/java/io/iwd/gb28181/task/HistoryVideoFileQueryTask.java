package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.HistoryVideoFileQueryInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import java.text.SimpleDateFormat;
import java.util.Date;

import static io.iwd.gb28181.Gb28181Const.TASK_PREFIX;

public class HistoryVideoFileQueryTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HistoryVideoFileQuery", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            HistoryVideoFileQueryInitParams input = (HistoryVideoFileQueryInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            String channelNumber = input.getChannelNumber();
            Date startTime = input.getStartTime();
            Date endTime = input.getEndTime();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("handle_val", 8)
                    .put("command_val", 1)
                    .put("devicenum", deviceNumber)
                    .put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber)
                    .put("starttime", dateFormat.format(startTime).replaceFirst(" ", "T"))
                    .put("endtime", dateFormat.format(endTime).replaceFirst(" ", "T"));
            Redis.silentMode().publish("dev_videofile_query", data.stringify());

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer state = input.getInteger("state");
            if (state == null || state != 1) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "sip service response error: " + input.getInteger("errorcode")));
                return;
            }

            JsonArray list = JsonArray.create();
            for (int fileIndex = 0; ; fileIndex++) {
                String key = "file_" + fileIndex;
                JsonObject fileInfo = input.getJsonObject(key);
                if (fileInfo == null) {
                    break;
                }
                JsonObject fi = JsonObject.create();
                fi.put("name", fileInfo.getString("name"));
                String st = fileInfo.getString("starttime");
                String et = fileInfo.getString("endtime");
                if (st != null) {
                    st = st.replaceFirst("T", " ");
                }
                if (et != null) {
                    et = et.replaceFirst("T", " ");
                }
                fi.put("startTime", st);
                fi.put("endTime", et);
                String path = fileInfo.getString("path");
                fi.put("path", path);
                list.add(fi);
            }

            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("data", list));
        });

        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }
}

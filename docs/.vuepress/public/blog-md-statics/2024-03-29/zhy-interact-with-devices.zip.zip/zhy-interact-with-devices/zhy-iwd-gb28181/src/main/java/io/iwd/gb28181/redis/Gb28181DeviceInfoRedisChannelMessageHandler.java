package io.iwd.gb28181.redis;

import io.iwd.common.environment.EnvironmentHolder;
import io.iwd.common.stdio.redis.RedisChannelMessageHandler;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;
import io.iwd.gb28181.event.Gb28181DeviceInfoUpdateEvent;

public class Gb28181DeviceInfoRedisChannelMessageHandler extends RedisChannelMessageHandler {

    @Override
    public void handle(String channelName, String message) {

        Boolean autoUpdate = (Boolean) EnvironmentHolder.get().config().getExtConfig("gb28181", "auto_update_device_info");
        if (autoUpdate == null) {
            autoUpdate = Boolean.TRUE;
        }

        if (autoUpdate) {
            //发布给reactorManager
            new Gb28181DefaultTaskStartEvent("DeviceInfoUpdate", message).publish();
        }

        //发布给其他监听器
        new Gb28181DeviceInfoUpdateEvent(message).publish();
    }
}

package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.gb28181.entity.DeviceDeregisterInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

/**
 * 设备注销命令。
 */
public class DeviceDeregister extends AdvancedCommand<Boolean> {

    private DeviceDeregisterInitParams initParams = new DeviceDeregisterInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return DeviceDeregister。
     */
    public DeviceDeregister setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "DeviceDeregister", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                Integer code = completedResult.getInteger("code");
                return Code.isCompleted(code);
            }
            return false;
        }, time);
    }
}

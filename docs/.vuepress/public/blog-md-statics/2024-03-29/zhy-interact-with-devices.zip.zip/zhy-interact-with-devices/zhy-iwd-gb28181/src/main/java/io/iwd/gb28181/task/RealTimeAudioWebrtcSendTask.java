package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.PortConverter;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.RealTimeAudioWebrtcSendInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;
import io.iwd.gb28181.http.template.SrsGetAudioPortTemplate;
import io.iwd.gb28181.http.template.SrsPublishRtcStreamTemplate;

import static io.iwd.gb28181.Gb28181Const.*;

public class RealTimeAudioWebrtcSendTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "RealTimeAudioWebrtcSend", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            RealTimeAudioWebrtcSendInitParams input = (RealTimeAudioWebrtcSendInitParams) context.getInput();
            context.putData("deviceNumber", input.getDeviceNumber());
            context.putData("channelNumber", input.getChannelNumber());
            context.putData("audioStreamMode", input.getAudioStreamMode().code());
            context.putData("pullAudioStreamIp", input.getPullAudioStreamIp());
            context.putData("offerSdp", input.getOfferSdp());
            context.putData("srsApiSsl", input.getSrsApiSsl());
            context.putData("srsApiIp", input.getSrsApiIp());
            context.putData("srsApiPort", input.getSrsApiPort());
            context.putData("webAddress", input.getWebAddress());
            context.putData("portConverter", input.getSrsAudioStreamPortConverter());

            context.fireNext("REQUEST_AUDIO_PORT");
        });

        taskFlow.addNode("REQUEST_AUDIO_PORT", context -> {
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            Integer audioStreamMode = (Integer) context.getData("audioStreamMode");

            new SrsGetAudioPortTemplate(srsApiSsl, srsApiIp, srsApiPort, audioStreamMode).send();

            context.awaitNext("RECEIVED_AUDIO_PORT");
        });

        taskFlow.addNode("RECEIVED_AUDIO_PORT", context -> {
            Integer port = (Integer) context.getInput();
            if (port == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "get audio port error"));
                return;
            }

            PortConverter portConverter = (PortConverter) context.getData("portConverter");
            port = portConverter.applyRawPort(port);
            context.putData("pullAudioStreamPort", port);

            context.fireNext("ISSUE_PULL_AUDIO_COMMAND");
        });

        taskFlow.addNode("ISSUE_PULL_AUDIO_COMMAND", context -> {
            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("handle_val", 10)
                    .put("command_val", 1)
                    .put("devicenum", context.getData("deviceNumber"))
                    .put("chd_num", context.getData("channelNumber"))
                    .put("streamip", context.getData("pullAudioStreamIp"))
                    .put("streamport", context.getData("pullAudioStreamPort"))
                    .put("videotransport", 1)
                    .put("rtc", 1);

            Redis.silentMode().publish("dev_broadcast_start", data.stringify());

            context.awaitNext("RECEIVED_PULL_AUDIO_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_PULL_AUDIO_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            if (input == null) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "sip service response error"));
                return;
            }
            Integer state = input.getInteger("state");
            if (state == null || state != 1) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0003,
                        "sip service response error"));
                return;
            }

            context.putData("sipData", input);

            context.fireNext("PUBLISH_AUDIO_STREAM");
        });

        taskFlow.addNode("PUBLISH_AUDIO_STREAM", context -> {
            JsonObject sipData = (JsonObject) context.getData("sipData");
            String ssrc = sipData.getString("devicessrc");
            String callId = sipData.getString("callid");
            String deviceIp = sipData.getString("audiodevip");
            String devicePort = sipData.getString("audiodevport");
            Integer streamPort = sipData.getInteger("streamport");
            Boolean srsApiSsl = (Boolean) context.getData("srsApiSsl");
            String srsApiIp = (String) context.getData("srsApiIp");
            Integer srsApiPort = (Integer) context.getData("srsApiPort");
            Integer audioStreamMode = (Integer) context.getData("audioStreamMode");
            String offerSdp = (String) context.getData("offerSdp");
            String webAddress = (String) context.getData("webAddress");

            context.putData("ssrc", ssrc);

            new SrsPublishRtcStreamTemplate(srsApiSsl, srsApiIp, srsApiPort, "chid" + Integer.parseInt(ssrc),
                    offerSdp, webAddress, callId, deviceIp, Integer.parseInt(devicePort), streamPort, audioStreamMode).send();

            context.awaitNext("RECEIVED_PUBLISH_AUDIO_STREAM_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_PUBLISH_AUDIO_STREAM_RESPONSE", context -> {
            String input = (String) context.getInput();
            if (StringUtil.isEmpty(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0004,
                        "can not get answer sdp"));
                return;
            }

            context.putData("sdp", input);

            context.fireNext("SAVE_SSRC");
        });

        taskFlow.addNode("SAVE_SSRC", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            String ssrc = (String) context.getData("ssrc");

            Redis.interactiveMode().hset(REDIS_REAL_TIME_AUDIO_INFO_MAP_KEY, ssrc, deviceNumber + "_" + channelNumber);

            context.awaitNext("SAVE_SSRC_COMPLETED");
        });

        taskFlow.addNode("SAVE_SSRC_COMPLETED", context -> {
            if (! (context.getInput() instanceof Number)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "redis error"));
                return;
            }

            context.complete(JsonObject.create()
                    .put("code", Code.NORMAL_SUCCESS | 0x0001)
                    .put("sdp", context.getData("sdp"))
                    .put("ssrc", context.getData("ssrc")));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

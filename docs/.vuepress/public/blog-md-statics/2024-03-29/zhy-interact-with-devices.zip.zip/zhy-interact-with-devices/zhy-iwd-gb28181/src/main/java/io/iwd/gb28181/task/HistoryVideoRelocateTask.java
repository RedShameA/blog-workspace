package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.HistoryVideoRelocateInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import static io.iwd.gb28181.Gb28181Const.TASK_PREFIX;

public class HistoryVideoRelocateTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "HistoryVideoRelocate", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("ISSUE_COMMAND", context -> {
            HistoryVideoRelocateInitParams input = (HistoryVideoRelocateInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            String channelNumber = input.getChannelNumber();

            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("handle_val", 6)
                    .put("command_val", 6)
                    .put("sessionid", input.getSessionId())
                    .put("devicenum", deviceNumber)
                    .put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber)
                    .put("dragrange", input.getOffset());

            Redis.silentMode().publish("dev_historyvideo_control", data.stringify());

            context.awaitNext("RECEIVED_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer state = input.getInteger("state");
            if (state == null || state != 1) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "sip service response error: " + input.getInteger("errorcode")));
                return;
            }
            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("ISSUE_COMMAND");

        return taskFlow;
    }
}

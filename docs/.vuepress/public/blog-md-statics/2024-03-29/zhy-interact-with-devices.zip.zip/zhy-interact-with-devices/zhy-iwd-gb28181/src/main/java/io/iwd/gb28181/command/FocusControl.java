package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.entity.FocusControlInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

import static io.iwd.gb28181.Gb28181Const.*;

/**
 * 焦距控制命令。
 */
public class FocusControl extends AdvancedCommand<Boolean> {

    private FocusControlInitParams initParams = new FocusControlInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return FocusControl命令对象。
     */
    public FocusControl setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return FocusControl命令对象。
     */
    public FocusControl setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置焦距控制选项。
     * @param focusControlOption 焦距控制选项。
     * @return FocusControl命令对象。
     * @see io.iwd.gb28181.Gb28181Const.FocusControlOption
     */
    public FocusControl setFocusControlOption(FocusControlOption focusControlOption) {
        this.initParams.setFocusControlOption(focusControlOption);
        return this;
    }

    /**
     * 设置焦距控制速度。
     * @param speed 控制速度。
     * @return FocusControl命令对象。
     */
    public FocusControl setSpeed(Integer speed) {
        this.initParams.setSpeed(speed);
        return this;
    }

    /**
     * 设置焦距控制速度选项。
     * @param controlSpeedOption 控制速度选项。
     * @return FocusControl命令对象。
     * @see io.iwd.gb28181.Gb28181Const.ControlSpeedOption
     */
    public FocusControl setControlSpeedOption(ControlSpeedOption controlSpeedOption) {
        this.initParams.setControlSpeedOption(controlSpeedOption);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "FocusControl", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> result.isCompleted() && result.hasResult(), time);
    }
}

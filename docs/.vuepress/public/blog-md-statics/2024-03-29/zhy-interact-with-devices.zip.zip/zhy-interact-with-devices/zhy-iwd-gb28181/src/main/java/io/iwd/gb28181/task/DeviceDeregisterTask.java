package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.DeviceDeregisterInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import static io.iwd.gb28181.Gb28181Const.*;

public class DeviceDeregisterTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "DeviceDeregister", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("DELETE_DEVICE_INFO", context -> {
            DeviceDeregisterInitParams input = (DeviceDeregisterInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            String deviceInfoKey = REDIS_DEV_INFO_KEY_PREFIX + deviceNumber;
            String deviceInfoLockKey = REDIS_DEV_INFO_LOCK_KEY_PREFIX + deviceNumber;
            String script = "redis.call('DEL', KEYS[1]);" +
                            "redis.call('HDEL', KEYS[3], KEYS[2]);" +
                            "redis.call('DEL', KEYS[4]);" +
                            "return 3;";
            Redis.interactiveMode().eval(script, 4, deviceInfoKey, deviceNumber, REDIS_CHANNEL_MAP_KEY, deviceInfoLockKey);

            context.awaitNext("DELETE_DEVICE_INFO_COMPLETED");
        });

        taskFlow.addNode("DELETE_DEVICE_INFO_COMPLETED", context -> {
            if (! (context.getInput() instanceof Number)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "failed to delete redis data"));
                return;
            }

            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("DELETE_DEVICE_INFO");

        return taskFlow;
    }
}

package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.entity.CruiseConfigInitParams;
import io.iwd.gb28181.entity.CruisePresetInfo;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

import java.util.List;

import static io.iwd.gb28181.Gb28181Const.TASK_PREFIX;

public class CruiseConfigTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "CruiseConfig", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            CruiseConfigInitParams input = (CruiseConfigInitParams) context.getInput();
            String deviceNumber = input.getDeviceNumber();
            String channelNumber = input.getChannelNumber();
            Integer cruiseId = input.getCruiseId();
            List<CruisePresetInfo> cruisePresetList = input.getCruisePresetList();

            context.putData("deviceNumber", deviceNumber);
            context.putData("channelNumber", channelNumber);
            context.putData("cruiseId", cruiseId);
            context.putData("cruisePresetList", cruisePresetList);

            context.fireNext("ISSUE_REMOVE_COMMAND");
        });

        taskFlow.addNode("ISSUE_REMOVE_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            Integer cruiseId = (Integer) context.getData("cruiseId");
            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("handle_val", 4)
                    .put("command_val", 2)
                    .put("devicenum", deviceNumber)
                    .put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber)
                    .put("xhxId", cruiseId);

            Redis.silentMode().publish("dev_control", data.stringify());

            context.awaitNext("RECEIVED_REMOVE_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_REMOVE_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer state = input.getInteger("state");
            if (state == null || state != 1) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0001,
                        "sip service response error: " + input.getInteger("errorcode")));
                return;
            }

            context.fireNext("ISSUE_ADD_COMMAND");
        });

        taskFlow.addNode("ISSUE_ADD_COMMAND", context -> {
            String deviceNumber = (String) context.getData("deviceNumber");
            String channelNumber = (String) context.getData("channelNumber");
            Integer cruiseId = (Integer) context.getData("cruiseId");
            @SuppressWarnings("unchecked")
            List<CruisePresetInfo> cruisePresetList = (List<CruisePresetInfo>) context.getData("cruisePresetList");
            JsonArray presetArray = JsonArray.create();
            for (CruisePresetInfo presetInfo : cruisePresetList) {
                JsonObject presetInfoObject =
                        JsonObject.create()
                                .put("yzwId", presetInfo.getPresetId())
                                .put("speed", presetInfo.getSpeed())
                                .put("interval", presetInfo.getInterval());
                presetArray.add(presetInfoObject);
            }
            JsonObject data = JsonObject.create()
                    .put("msgid", context.getTaskId())
                    .put("handle_val", 4)
                    .put("command_val", 1)
                    .put("devicenum", deviceNumber)
                    .put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber)
                    .put("yzwList", presetArray)
                    .put("xhxId", cruiseId);

            Redis.silentMode().publish("dev_control", data.stringify());

            context.awaitNext("RECEIVED_ADD_RESPONSE");
        });

        taskFlow.addNode("RECEIVED_ADD_RESPONSE", context -> {
            JsonObject input = (JsonObject) context.getInput();
            Integer state = input.getInteger("state");
            if (state == null || state != 1) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_INTERNAL_SERVER_ERROR | 0x0002,
                        "sip service response error: " + input.getInteger("errorcode")));
                return;
            }
            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.util.Gb28181Validator;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import static io.iwd.gb28181.Gb28181Const.*;

public class CruiseConfigInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private Integer cruiseId;

    private final List<CruisePresetInfo> cruisePresetList = new LinkedList<>();

    public String getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public Integer getCruiseId() {
        return cruiseId;
    }

    public void setCruiseId(Integer cruiseId) {
        this.cruiseId = cruiseId;
    }

    public void addPreset(Integer presetId, Integer speed, Integer interval) {
        CruisePresetInfo cruisePresetInfo = new CruisePresetInfo(presetId, speed, interval);
        this.cruisePresetList.add(cruisePresetInfo);
    }

    public void addPreset(Integer presetId, CruiseSpeedOption speedOption, Integer interval) {
        CruisePresetInfo cruisePresetInfo = new CruisePresetInfo(presetId, speedOption, interval);
        this.cruisePresetList.add(cruisePresetInfo);
    }

    public void addPreset(Collection<CruisePresetInfo> presetList) {
        this.cruisePresetList.addAll(presetList);
    }

    public List<CruisePresetInfo> getCruisePresetList() {
        return this.cruisePresetList;
    }

    @Override
    public CruiseConfigInitParams populateDefault() {
        return this;
    }

    @Override
    public CruiseConfigInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (this.cruiseId == null || this.cruiseId < MIN_CRUISE_ID_NUMBER || this.cruiseId > MAX_CRUISE_ID_NUMBER) {
            throw new IllegalArgumentException("gb28181 cruise id error");
        }
        if (this.cruisePresetList.size() > 255) {
            throw new IllegalArgumentException("gb28181 cruise preset list size error");
        }
        for (CruisePresetInfo presetInfo : this.cruisePresetList) {
            Integer presetId = presetInfo.getPresetId();
            Integer speed = presetInfo.getSpeed();
            Integer interval = presetInfo.getInterval();
            if (presetId == null || presetId < MIN_PRESET_ID_NUMBER || presetId > MAX_PRESET_ID_NUMBER) {
                throw new IllegalArgumentException("gb28181 cruise preset id error");
            }
            if (speed == null || speed < MIN_CRUISE_SPEED || speed > MAX_CRUISE_SPEED) {
                throw new IllegalArgumentException("gb28181 cruise speed error");
            }
            if (interval == null || interval < MIN_CRUISE_PRESET_INTERVAL || interval > MAX_CRUISE_PRESET_INTERVAL) {
                throw new IllegalArgumentException("gb28181 cruise preset interval error");
            }
        }
        return this;
    }
}

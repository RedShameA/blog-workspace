package io.iwd.gb28181.event;

import io.iwd.common.event.AbstractTaskEventListener;
import io.iwd.common.event.Event;
import io.iwd.common.event.srs.SrsCloseRtcAudioEvent;
import io.iwd.common.event.srs.SrsCloseRtcEvent;
import io.iwd.common.event.srs.SrsCloseRtspSourceEvent;
import io.iwd.common.event.srs.SrsRtspReadyEvent;
import io.iwd.gb28181.Gb28181Const;

import java.util.LinkedList;
import java.util.List;

public class Gb28181TaskEventListener extends AbstractTaskEventListener {

    @Override
    public String defaultTaskPrefix() {
        return Gb28181Const.TASK_PREFIX;
    }

    @Override
    public List<Class<? extends Event>> interests() {
        List<Class<? extends Event>> interestsList = new LinkedList<>();
        interestsList.add(Gb28181DefaultTaskStartEvent.class);
        interestsList.add(Gb28181DefaultTaskProceedEvent.class);
        interestsList.add(SrsCloseRtcEvent.class);
        interestsList.add(SrsCloseRtspSourceEvent.class);
        interestsList.add(SrsCloseRtcAudioEvent.class);
        return interestsList;
    }
}

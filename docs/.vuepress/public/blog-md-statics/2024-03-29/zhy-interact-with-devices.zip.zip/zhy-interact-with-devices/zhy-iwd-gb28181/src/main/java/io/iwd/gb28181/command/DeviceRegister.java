package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.gb28181.entity.DeviceRegisterInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

/**
 * 设备注册命令。
 * 主动注册设备。通常用于在系统中添加了一个设备后。
 * 使用此命令可能会在redis中添加一些数据，强烈不建议通过iwd之外的途径修改这些数据。
 */
public class DeviceRegister extends AdvancedCommand<Boolean> {

    private DeviceRegisterInitParams initParams = new DeviceRegisterInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return DeviceRegister命令对象。
     */
    public DeviceRegister setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置心跳间隔。
     * @param heartbeatInterval 心跳间隔，单位秒。
     * @return DeviceRegister命令对象。
     */
    public DeviceRegister setHeartbeatInterval(Integer heartbeatInterval) {
        this.initParams.setHeartbeatInterval(heartbeatInterval);
        return this;
    }

    /**
     * 设置最大心跳丢失数。
     * @param maxHeartbeatLost 最大心跳丢失数。
     * @return DeviceRegister命令对象。
     */
    public DeviceRegister setMaxHeartbeatLost(Integer maxHeartbeatLost) {
        this.initParams.setMaxHeartbeatLost(maxHeartbeatLost);
        return this;
    }

    /**
     * 设置注册密码。
     * @param password 注册密码。
     * @return DeviceRegister命令对象。
     */
    public DeviceRegister setPassword(String password) {
        this.initParams.setPassword(password);
        return this;
    }

    /**
     * 设置SIP服务的gb28181编号。
     * @param serverId SIP服务的gb28181编号。
     * @return DeviceRegister命令对象。
     */
    public DeviceRegister setServerId(String serverId) {
        this.initParams.setServerId(serverId);
        return this;
    }

    /**
     * 设置SIP服务的ip。
     * @param serverIp IP服务的ip。
     * @return DeviceRegister命令对象。
     */
    public DeviceRegister setServerIp(String serverIp) {
        this.initParams.setServerIp(serverIp);
        return this;
    }

    /**
     * 设置SIP服务的端口。
     * @param serverPort SIP服务的端口。
     * @return DeviceRegister命令对象。
     */
    public DeviceRegister setServerPort(Integer serverPort) {
        this.initParams.setServerPort(serverPort);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "DeviceRegister", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public Boolean await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                Integer code = completedResult.getInteger("code");
                return Code.isCompleted(code);
            }
            return false;
        }, time);
    }
}

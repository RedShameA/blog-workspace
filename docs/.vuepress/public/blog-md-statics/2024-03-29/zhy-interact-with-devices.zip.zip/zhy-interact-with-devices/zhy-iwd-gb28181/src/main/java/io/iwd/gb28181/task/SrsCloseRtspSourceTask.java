package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.environment.ReadConfigAction;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;
import io.iwd.gb28181.util.Gb28181Validator;

import static io.iwd.gb28181.Gb28181Const.*;

public class SrsCloseRtspSourceTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(TASK_PREFIX, "SrsCloseRtspSource", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("QUERY_IF_AUTO_CLOSE", context -> {
            String ssrc = (String) context.getInput();
            context.putData("ssrc", ssrc);

            new ReadConfigAction(conf -> conf.getExtConfig("gb28181", "auto_close_video_stream")).start();
            context.awaitNext("REMOVE_REAL_VIDEO_INFO");
        });

        //获取ssrc记录
        taskFlow.addNode("REMOVE_REAL_VIDEO_INFO", context -> {

            Boolean autoClose = (Boolean) context.getInput();
            if (autoClose == null || !autoClose) {
                context.complete(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0003,
                        "gb28181 disable auto close video stream"));
                return;
            }

            String ssrc = (String) context.getData("ssrc");
            context.putData("ssrc", ssrc);
            String script = "local dncn = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "if(dncn == false) then return; end;" +
                            "redis.call('HDEL', KEYS[1], KEYS[2]);" +
                            "redis.call('HDEL', KEYS[1], dncn);" +
                            "return dncn;";
            Redis.interactiveMode().eval(script, 2, REDIS_REAL_TIME_VIDEO_INFO_MAP_KEY, ssrc);

            context.awaitNext("GOT_REAL_VIDEO_INFO_AND_ISSUE_COMMAND");
        });

        taskFlow.addNode("GOT_REAL_VIDEO_INFO_AND_ISSUE_COMMAND", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "query real time video info error"));
                return;
            }
            String dncnStr = (String) input;
            if (StringUtil.isEmpty(dncnStr)) {
                context.fireNext("REMOVE_HISTORY_VIDEO_INFO");
                context.putData("noRealTimeVideoSsrc", Boolean.TRUE);
                return;
            }

            int code = 0;
            issue: {
                String[] dncn = dncnStr.split("_");
                if (dncn.length != 2) {
                    code = 0x0001;
                    break issue;
                }
                String deviceNumber = dncn[0];
                String channelNumber = dncn[1];
                if (!Gb28181Validator.isGb28181DeviceNumber(deviceNumber) ||
                    !Gb28181Validator.isGb28181DeviceNumber(channelNumber)) {
                    code = 0x0002;
                    break issue;
                }

                JsonObject data = JsonObject.create()
                        .put("msgid", context.getTaskId())
                        .put("handle_val", 5)
                        .put("command_val", 2)
                        .put("devicenum", deviceNumber)
                        .put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber);
                Redis.silentMode().publish("dev_realvideo_stop", data.stringify());
            }

            if (code != 0) {
                context.putData("code", code);
            }
            context.fireNext("REMOVE_HISTORY_VIDEO_INFO");
        });

        taskFlow.addNode("REMOVE_HISTORY_VIDEO_INFO", context -> {
            String ssrc = (String) context.getData("ssrc");
            String script = "local dncnList = redis.call('HGET', KEYS[1], KEYS[2]);" +
                            "redis.call('HDEL', KEYS[1], KEYS[2]);" + //删除通道记录
                            "redis.call('HDEL', KEYS[1], KEYS[3]);" + //删除更新时间记录
                            "return dncnList;";

            Redis.interactiveMode().eval(script, 3, REDIS_HISTORY_VIDEO_INFO_MAP_KEY, ssrc, "ts:" + ssrc);

            context.awaitNext("GOT_HISTORY_VIDEO_INFO_AND_PROCESS");
        });

        taskFlow.addNode("GOT_HISTORY_VIDEO_INFO_AND_PROCESS", context -> {
            Object input = context.getInput();
            if (Redis.isException(input)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0002,
                        "query history video info error"));
                return;
            }
            String dncnListStr = (String) input;
            Integer code = (Integer) context.getData("code");
            Boolean noRealTimeVideoSsrc = (Boolean) context.getData("noRealTimeVideoSsrc");
            //没有历史视频信息
            if (StringUtil.isEmpty(dncnListStr)) {
                //查实时视频信息有数据错误
                if (code != null) {
                    context.fail(new CodeMessageJsonObject(
                            Code.FAILED_WITH_ILLEGAL_DATA | code,
                            "real time video device number or channel number format error, no history video ssrc record"));
                    return;
                }
                //没有实时视频信息
                if (noRealTimeVideoSsrc != null) {
                    context.complete(new CodeMessageJsonObject(
                            Code.SUCCESS_WITH_ACCEPTABLE_PROBLEM | 0x0001,
                            "no any video info record"));
                    return;
                }
                //已下发实时视频停止
                context.complete(new CodeMessageJsonObject(
                        Code.NORMAL_SUCCESS | 0x0001,
                        "issued real time video stop command, and no history video ssrc record"));
                return;
            }

            String[] dncnList = dncnListStr.split(",");
            int formatError = 0;
            JsonObject data = JsonObject.create()
                    .put("msgid", "")
                    .put("handle_val", 6)
                    .put("command_val", 2)
                    .put("devicessrc", context.getData("ssrc"));
            for (String dncnStr : dncnList) {
                String[] dncn = dncnStr.split("_");
                if (dncn.length != 2) {
                    formatError++;
                    continue;
                }
                String deviceNumber = dncn[0];
                String channelNumber = dncn[1];
                if (!Gb28181Validator.isGb28181DeviceNumber(deviceNumber) ||
                    !Gb28181Validator.isGb28181DeviceNumber(channelNumber)) {
                    formatError++;
                    continue;
                }
                data.put("devicenum", deviceNumber).put("chd_num", deviceNumber.equals(channelNumber) ? "" : channelNumber);
                Redis.silentMode().publish("dev_historyvideo_stop", data.stringify());
            }

            //因数据错误 没有一个历史视频停止命令下发
            if (formatError == dncnList.length) {
                if (code != null) {
                    context.fail(new CodeMessageJsonObject(
                            Code.FAILED_WITH_ILLEGAL_DATA | 0x0003,
                            "all real time and history video device number or channel number format error"));
                    return;
                }
                //没有实时视频信息
                if (noRealTimeVideoSsrc != null) {
                    context.fail(new CodeMessageJsonObject(
                            Code.FAILED_WITH_ILLEGAL_DATA | 0x0004,
                            "all history video device number or channel number format error"));
                    return;
                }
                //已下发实时视频停止
                context.complete(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0003,
                        "issued real time video stop command, but all history video device number or channel number format error"));
                return;
            }

            //有部分数据错误
            if (formatError != 0) {
                if (code != null) {
                    context.complete(new CodeMessageJsonObject(
                            Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0004,
                            "real time and history video device number or channel number format error, only " + (dncnList.length - formatError) + " command(s) issued"));
                    return;
                }
                //没有实时视频信息
                if (noRealTimeVideoSsrc != null) {
                    context.complete(new CodeMessageJsonObject(
                            Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0005,
                            "history video device number or channel number format error, only " + (dncnList.length - formatError) + " command(s) issued"));
                    return;
                }
                //已下发实时视频停止
                context.complete(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | 0x0006,
                        "issued real time video stop command, but history video device number or channel number format error, only " + (dncnList.length - formatError) + " command(s) issued"));
                return;
            }

            //查实时视频信息有数据错误
            if (code != null) {
                context.complete(new CodeMessageJsonObject(
                        Code.FAILED_BUT_CONSIDERED_COMPLETED | code,
                        "real time video device number or channel number format error, but issued all history video stop command(s)"));
                return;
            }
            //没有实时视频信息
            if (noRealTimeVideoSsrc != null) {
                context.complete(new CodeMessageJsonObject(
                        Code.NORMAL_SUCCESS | 0x0002,
                        "no real time video info, but issued all history video stop command(s)"));
                return;
            }
            //已下发实时视频停止
            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0003,
                    "issued all real time and history video stop commands"));

        });

        taskFlow.setDefaultEntrance("QUERY_IF_AUTO_CLOSE");

        return taskFlow;
    }
}

package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.gb28181.util.Gb28181Validator;

public class HistoryVideoPauseInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private String sessionId;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    @Override
    public HistoryVideoPauseInitParams populateDefault() {
        return this;
    }

    @Override
    public HistoryVideoPauseInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (StringUtil.isEmpty(this.sessionId)) {
            throw new IllegalArgumentException("gb28181 session id format error");
        }
        return this;
    }
}

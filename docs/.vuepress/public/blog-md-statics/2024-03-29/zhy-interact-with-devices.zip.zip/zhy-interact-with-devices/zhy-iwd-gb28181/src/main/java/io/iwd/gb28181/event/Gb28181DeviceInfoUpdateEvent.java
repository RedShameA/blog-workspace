package io.iwd.gb28181.event;

import io.iwd.common.event.Event;

public class Gb28181DeviceInfoUpdateEvent implements Event {

    private final String rawMessage;

    public Gb28181DeviceInfoUpdateEvent(String rawMessage) {
        this.rawMessage = rawMessage;
    }

    public String getRawMessage() {
        return rawMessage;
    }
}

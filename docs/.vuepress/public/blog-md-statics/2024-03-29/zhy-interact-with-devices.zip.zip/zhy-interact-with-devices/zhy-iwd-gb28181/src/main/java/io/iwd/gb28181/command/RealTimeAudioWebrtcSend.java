package io.iwd.gb28181.command;

import io.iwd.common.command.AdvancedCommand;
import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.engine.TaskResult;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.PortConverter;
import io.iwd.gb28181.entity.RealTimeAudioWebrtcSendInitParams;
import io.iwd.gb28181.entity.RealTimeAudioWebrtcSendResult;
import io.iwd.gb28181.entity.RealTimeVideoWebrtcPlayResult;
import io.iwd.gb28181.event.Gb28181DefaultTaskStartEvent;

import static io.iwd.gb28181.Gb28181Const.*;

public class RealTimeAudioWebrtcSend extends AdvancedCommand<RealTimeAudioWebrtcSendResult> {

    private RealTimeAudioWebrtcSendInitParams initParams = new RealTimeAudioWebrtcSendInitParams();

    /**
     * 设置设备编号。
     * @param deviceNumber 设备编号。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setDeviceNumber(String deviceNumber) {
        this.initParams.setDeviceNumber(deviceNumber);
        return this;
    }

    /**
     * 设置通道编号。
     * @param channelNumber 通道编号。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setChannelNumber(String channelNumber) {
        this.initParams.setChannelNumber(channelNumber);
        return this;
    }

    /**
     * 设置音频流模式。
     * @param audioStreamMode 音频流模式。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setAudioStreamMode(AudioStreamMode audioStreamMode) {
        this.initParams.setAudioStreamMode(audioStreamMode);
        return this;
    }

    /**
     * 设置设备拉音频流ip。
     * @param pullAudioStreamIp 音频拉流ip。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setPullAudioStreamIp(String pullAudioStreamIp) {
        this.initParams.setPullAudioStreamIp(pullAudioStreamIp);
        return this;
    }

    /**
     * 设置offer sdp。
     * @param offerSdp offer sdp。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setOfferSdp(String offerSdp) {
        this.initParams.setOfferSdp(offerSdp);
        return this;
    }

    /**
     * 设置与srs的api交互是否使用https。默认从配置文件中获取。
     * @param srsApiSsl 与srs的api交互是否使用https。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setSrsApiSsl(Boolean srsApiSsl) {
        this.initParams.setSrsApiSsl(srsApiSsl);
        return this;
    }

    /**
     * 设置srs的api交互ip。默认从配置文件中获取。
     * @param srsApiIp srs的api交互ip。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setSrsApiIp(String srsApiIp) {
        this.initParams.setSrsApiIp(srsApiIp);
        return this;
    }

    /**
     * 设置srs的api交互端口。默认从配置文件中获取。
     * @param srsApiPort srs的api交互端口。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setSrsApiPort(Integer srsApiPort) {
        this.initParams.setSrsApiPort(srsApiPort);
        return this;
    }

    /**
     * 设置web服务接收srs http请求的地址。默认从配置文件中获取。
     * @param webAddress web服务接收srs http请求的地址。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setWebAddress(String webAddress) {
        this.initParams.setWebAddress(webAddress);
        return this;
    }

    /**
     * 设置srs音频流发布端口的转换器。用于将srs返回的端口号映射为自定义的端口号。
     * @param portConverter srs音频流发布端口的转换器。
     * @return RealTimeAudioWebrtcSend命令对象。
     */
    public RealTimeAudioWebrtcSend setSrsAudioStreamPortConverter(PortConverter portConverter) {
        this.initParams.setSrsAudioStreamPortConverter(portConverter);
        return this;
    }

    @Override
    protected TaskResult taskStart() {
        TaskInitParams data = this.initParams;
        this.initParams = null;
        return super.taskActive(null, "RealTimeAudioWebrtcSend", null, data.populateDefault().validate(), Gb28181DefaultTaskStartEvent::new);
    }

    @Override
    public RealTimeAudioWebrtcSendResult await(long time) {
        return super.await(result -> {
            if (result.isCompleted() && result.hasResult()) {
                JsonObject completedResult = (JsonObject) result.getResult();
                String sdp = completedResult.getString("sdp");
                String ssrc = completedResult.getString("ssrc");
                return new RealTimeAudioWebrtcSendResult(true, sdp, ssrc);
            }
            return new RealTimeAudioWebrtcSendResult(false, null, null);
        }, time);
    }

}

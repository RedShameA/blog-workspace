package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.gb28181.util.Gb28181Validator;

import static io.iwd.gb28181.Gb28181Const.*;

public class HistoryVideoSpeedControlInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private String sessionId;

    private HistoryVideoSpeedOption historyVideoSpeedOption;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public HistoryVideoSpeedOption getHistoryVideoSpeedOption() {
        return historyVideoSpeedOption;
    }

    public void setHistoryVideoSpeedOption(HistoryVideoSpeedOption historyVideoSpeedOption) {
        this.historyVideoSpeedOption = historyVideoSpeedOption;
    }

    @Override
    public HistoryVideoSpeedControlInitParams populateDefault() {
        if (this.historyVideoSpeedOption == null) {
            this.historyVideoSpeedOption = HistoryVideoSpeedOption.X1;
        }
        return this;
    }

    @Override
    public HistoryVideoSpeedControlInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (StringUtil.isEmpty(this.sessionId)) {
            throw new IllegalArgumentException("gb28181 session id format error");
        }
        if (this.historyVideoSpeedOption == null) {
            throw new IllegalArgumentException("gb28181 history video speed option error");
        }
        return this;
    }
}

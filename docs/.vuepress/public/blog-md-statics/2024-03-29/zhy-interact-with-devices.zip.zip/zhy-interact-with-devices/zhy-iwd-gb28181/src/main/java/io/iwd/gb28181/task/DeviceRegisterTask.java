package io.iwd.gb28181.task;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowInitializer;
import io.iwd.common.ext.json.CodeMessageJsonObject;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.ext.util.Code;
import io.iwd.common.stdio.redis.Redis;
import io.iwd.gb28181.Gb28181Const;
import io.iwd.gb28181.entity.DeviceRegisterInitParams;
import io.iwd.gb28181.event.Gb28181DefaultTaskProceedEvent;

public class DeviceRegisterTask implements TaskFlowInitializer {

    @Override
    public TaskFlow getTaskFlow() {
        TaskFlow taskFlow = new TaskFlow(Gb28181Const.TASK_PREFIX, "DeviceRegister", Gb28181DefaultTaskProceedEvent::new);

        taskFlow.addNode("PREPARE_DATA", context -> {
            DeviceRegisterInitParams data = (DeviceRegisterInitParams) context.getInput();
            String deviceNumber = data.getDeviceNumber();
            Integer heartbeatInterval = data.getHeartbeatInterval();
            Integer maxHeartbeatLost = data.getMaxHeartbeatLost();
            String password = data.getPassword();
            String serverId = data.getServerId();
            String serverIp = data.getServerIp();
            Integer serverPort = data.getServerPort();

            JsonObject deviceInfo = JsonObject.create()
                    .put("state", 0)
                    .put("time", "")
                    .put("heart_time", heartbeatInterval)
                    .put("heart_count", maxHeartbeatLost)
                    .put("password", password)
                    .put("sipid", serverId)
                    .put("sipip", serverIp)
                    .put("sipport", serverPort);

            context.putData("deviceInfo", deviceInfo);
            context.putData("deviceNumber", deviceNumber);

            context.fireNext("RESET_DEVICE_INFO");
        });

        taskFlow.addNode("RESET_DEVICE_INFO", context -> {
            JsonObject deviceInfo = (JsonObject) context.getData("deviceInfo");
            String deviceNumber = (String) context.getData("deviceNumber");

            String deviceInfoKey = Gb28181Const.REDIS_DEV_INFO_KEY_PREFIX + deviceNumber;
            String deviceInfoLockKey = Gb28181Const.REDIS_DEV_INFO_LOCK_KEY_PREFIX + deviceNumber; //更新设备信息时使用的锁
            String deviceInfoValue = deviceInfo.stringify();

            String script = "redis.call('HDEL', KEYS[1], KEYS[2]);" +
                            "redis.call('SET', KEYS[3], ARGV[1]);" +
                            "redis.call('DEL', KEYS[4]);" +
                            "return 1;";
            Redis.interactiveMode().eval(script, 4, Gb28181Const.REDIS_CHANNEL_MAP_KEY, deviceNumber, deviceInfoKey, deviceInfoLockKey, deviceInfoValue);

            context.awaitNext("RESET_DEVICE_INFO_COMPLETED");
        });

        taskFlow.addNode("RESET_DEVICE_INFO_COMPLETED", context -> {
            if (! (context.getInput() instanceof Number)) {
                context.fail(new CodeMessageJsonObject(
                        Code.FAILED_WITH_MIDDLEWARE_ERROR | 0x0001,
                        "failed to update redis data"));
                return;
            }

            context.complete(new CodeMessageJsonObject(
                    Code.NORMAL_SUCCESS | 0x0001,
                    null));
        });

        taskFlow.setDefaultEntrance("PREPARE_DATA");

        return taskFlow;
    }
}

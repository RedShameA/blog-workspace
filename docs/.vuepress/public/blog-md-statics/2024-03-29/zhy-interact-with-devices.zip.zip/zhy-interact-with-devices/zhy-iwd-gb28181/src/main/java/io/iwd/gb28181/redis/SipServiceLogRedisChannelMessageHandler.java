package io.iwd.gb28181.redis;

import io.iwd.common.ext.json.JsonArray;
import io.iwd.common.ext.json.JsonObject;
import io.iwd.common.stdio.redis.RedisChannelMessageHandler;
import io.iwd.gb28181.event.SipServiceLogEvent;

public class SipServiceLogRedisChannelMessageHandler extends RedisChannelMessageHandler {

    @Override
    public void handle(String channelName, String message) {

        JsonArray logList = JsonArray.from(message);
        for (int i = 0; i < logList.size(); i++) {
            JsonObject log = logList.getJsonObject(i);
            Integer type = log.getInteger("type");
            String content = log.getString("content");
            SipServiceLogEvent.LogType logType = SipServiceLogEvent.LogType.forCode(type);
            if (logType == null) {
                continue;
            }

            new SipServiceLogEvent(logType, content).publish();
        }

    }

}

package io.iwd.gb28181.entity;

import io.iwd.common.ext.json.JsonObject;

import java.util.Map;
import java.util.Set;

/**
 * gb28181设备通道查询结果。
 */
public class DeviceChannelQueryResult {

    private final JsonObject internal;

    public DeviceChannelQueryResult(JsonObject internal) {
        this.internal = internal;
    }

    /**
     * 返回通道编号集合。
     * @return 通道编号集合。
     */
    public Set<String> getChannelNumberSet() {
        return this.internal.keySet();
    }

    /**
     * 返回指定通道详情。
     * @param channelNumber 通道编号。
     * @return 指定通道详情。
     */
    public Map<String, Object> getChannelDetail(String channelNumber) {
        JsonObject channelDetail = internal.getJsonObject(channelNumber);
        if (channelDetail == null) {
            return null;
        }
        return channelDetail.simplify();
    }

    /**
     * 返回所有通道详情。
     * @return 所有通道详情。
     */
    @SuppressWarnings("unchecked")
    public Map<String, Map<String, Object>> getAll() {
        Map<String, ?> map = this.internal.simplify();
        return (Map<String, Map<String, Object>>) map;
    }

    @Override
    public String toString() {
        return this.internal.stringify();
    }
}

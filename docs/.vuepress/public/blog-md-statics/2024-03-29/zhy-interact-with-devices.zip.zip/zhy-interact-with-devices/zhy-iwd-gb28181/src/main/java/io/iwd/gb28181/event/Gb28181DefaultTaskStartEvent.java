package io.iwd.gb28181.event;

import io.iwd.common.engine.TaskResult;
import io.iwd.common.event.TaskStartEvent;
import io.iwd.gb28181.Gb28181Const;

public class Gb28181DefaultTaskStartEvent extends TaskStartEvent {

    public Gb28181DefaultTaskStartEvent(String taskName, Object data) {
        super(taskName, data);
    }

    public Gb28181DefaultTaskStartEvent(String taskName, Object data, TaskResult taskResult) {
        super(taskName, data, taskResult);
    }

    public Gb28181DefaultTaskStartEvent(String taskId, String taskName, Object data, TaskResult taskResult) {
        super(taskId, taskName, data, taskResult);
    }

    public Gb28181DefaultTaskStartEvent(String taskId, String taskName, String entranceName, Object data, TaskResult taskResult) {
        super(taskId, taskName, entranceName, data, taskResult);
    }

    @Override
    public String getTaskPrefix() {
        return Gb28181Const.TASK_PREFIX;
    }

}

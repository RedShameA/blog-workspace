package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.common.ext.util.StringUtil;
import io.iwd.gb28181.util.Gb28181Validator;

public class HistoryVideoRelocateInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private String sessionId;

    private Integer offset;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public String getSessionId() {
        return this.sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Integer getOffset() {
        return this.offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    @Override
    public HistoryVideoRelocateInitParams populateDefault() {
        if (this.offset == null) {
            this.offset = 0;
        }
        return this;
    }

    @Override
    public HistoryVideoRelocateInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (StringUtil.isEmpty(this.sessionId)) {
            throw new IllegalArgumentException("gb28181 session id format error");
        }
        if (this.offset == null || this.offset < 0) {
            throw new IllegalArgumentException("gb28181 offset format error");
        }
        return this;
    }
}

package io.iwd.gb28181.entity;

import io.iwd.common.engine.TaskInitParams;
import io.iwd.gb28181.util.Gb28181Validator;

import static io.iwd.gb28181.Gb28181Const.*;

public class FocusControlInitParams implements TaskInitParams {

    private String deviceNumber;

    private String channelNumber;

    private FocusControlOption focusControlOption;

    private Integer speed;

    public String getDeviceNumber() {
        return this.deviceNumber;
    }

    public void setDeviceNumber(String deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public String getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    public FocusControlOption getFocusControlOption() {
        return this.focusControlOption;
    }

    public void setFocusControlOption(FocusControlOption focusControlOption) {
        this.focusControlOption = focusControlOption;
    }

    public Integer getSpeed() {
        return this.speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public void setControlSpeedOption(ControlSpeedOption controlSpeedOption) {
        this.speed = controlSpeedOption.speed();
    }

    @Override
    public FocusControlInitParams populateDefault() {
        if (this.focusControlOption == null) {
            this.focusControlOption = FocusControlOption.STOP;
        }
        if (this.speed == null) {
            this.speed = ControlSpeedOption.ONE.speed();
        }
        return this;
    }

    @Override
    public FocusControlInitParams validate() {
        if (!Gb28181Validator.isGb28181DeviceNumber(this.deviceNumber)) {
            throw new IllegalArgumentException("gb28181 device number format error");
        }
        if (!Gb28181Validator.isGb28181DeviceNumber(this.channelNumber)) {
            throw new IllegalArgumentException("gb28181 channel number format error");
        }
        if (this.focusControlOption == null) {
            throw new IllegalArgumentException("gb28181 focus control option error");
        }
        if (this.speed == null || this.speed < MIN_CONTROL_SPEED || this.speed > MAX_CONTROL_SPEED) {
            throw new IllegalArgumentException("gb28181 speed error");
        }
        return this;
    }
}

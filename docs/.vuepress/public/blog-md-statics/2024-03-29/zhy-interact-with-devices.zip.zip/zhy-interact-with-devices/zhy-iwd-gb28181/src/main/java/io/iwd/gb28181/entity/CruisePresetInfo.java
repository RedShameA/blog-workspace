package io.iwd.gb28181.entity;

import io.iwd.gb28181.Gb28181Const.*;

public class CruisePresetInfo {

    private final Integer presetId;

    private final Integer speed;

    private final Integer interval;

    public CruisePresetInfo(Integer presetId, Integer speed, Integer interval) {
        this.presetId = presetId;
        this.speed = speed;
        this.interval = interval;
    }

    public CruisePresetInfo(Integer presetId, CruiseSpeedOption cruiseSpeedOption, Integer interval) {
        this.presetId = presetId;
        this.speed = cruiseSpeedOption.speed();
        this.interval = interval;
    }

    public Integer getPresetId() {
        return this.presetId;
    }

    public Integer getSpeed() {
        return this.speed;
    }

    public Integer getInterval() {
        return this.interval;
    }

    @Override
    public String toString() {
        return "{\"presetId\":" + this.presetId + ",\"speed\":" + this.speed + ",\"interval\":" + this.interval + "}";
    }
}

package io.iwd.gb28181;

import io.iwd.common.engine.TaskFlow;
import io.iwd.common.engine.TaskFlowCollector;
import io.iwd.gb28181.task.*;

import java.util.LinkedList;
import java.util.List;

public class Gb28181TaskFlowCollector implements TaskFlowCollector {

    @Override
    public List<TaskFlow> getTaskFlowList() {

        List<TaskFlow> taskFlowList = new LinkedList<>();

        //设备注册
        taskFlowList.add(new DeviceRegisterTask().getTaskFlow());
        //设备注销
        taskFlowList.add(new DeviceDeregisterTask().getTaskFlow());
        //设备信息更新
        taskFlowList.add(new DeviceInfoUpdateTask().getTaskFlow());
        //设备通道查询
        taskFlowList.add(new DeviceChannelQueryTask().getTaskFlow());

        //镜头控制
        taskFlowList.add(new LensControlTask().getTaskFlow());
        //变倍控制
        taskFlowList.add(new ZoomControlTask().getTaskFlow());
        //焦距控制
        taskFlowList.add(new FocusControlTask().getTaskFlow());
        //光圈控制
        taskFlowList.add(new ApertureControlTask().getTaskFlow());

        //实时视频webrtc播放
        taskFlowList.add(new RealTimeVideoWebrtcPlayTask().getTaskFlow());
        //实时视频停止
        taskFlowList.add(new RealTimeVideoStopTask().getTaskFlow());

        //录像文件查询
        taskFlowList.add(new HistoryVideoFileQueryTask().getTaskFlow());
        //录像文件webrtc播放
        taskFlowList.add(new HistoryVideoWebrtcPlayTask().getTaskFlow());
        //录像回放停止
        taskFlowList.add(new HistoryVideoStopTask().getTaskFlow());
        //录像回放继续
        taskFlowList.add(new HistoryVideoContinueTask().getTaskFlow());
        //录像回放暂停
        taskFlowList.add(new HistoryVideoPauseTask().getTaskFlow());
        //录像回放速度控制
        taskFlowList.add(new HistoryVideoSpeedControlTask().getTaskFlow());
        //录像回放重新定位
        taskFlowList.add(new HistoryVideoRelocateTask().getTaskFlow());

        //srs停止webrtc视频
        taskFlowList.add(new SrsCloseRtcTask().getTaskFlow());
        //srs停止rtsp视频源
        taskFlowList.add(new SrsCloseRtspSourceTask().getTaskFlow());
        //srs停止webrtc音频
        taskFlowList.add(new SrsCloseRtcAudioTask().getTaskFlow());

        //预置位调用
        taskFlowList.add(new PresetCallTask().getTaskFlow());
        //预置位重新定位
        taskFlowList.add(new PresetRelocateTask().getTaskFlow());
        //预置位删除
        taskFlowList.add(new PresetRemoveTask().getTaskFlow());

        //巡航线配置
        taskFlowList.add(new CruiseConfigTask().getTaskFlow());
        //巡航线删除
        taskFlowList.add(new CruiseRemoveTask().getTaskFlow());
        //巡航线开启
        taskFlowList.add(new CruiseStartTask().getTaskFlow());
        //巡航线停止
        taskFlowList.add(new CruiseStopTask().getTaskFlow());

        //图片抓拍
        taskFlowList.add(new SnapshotTask().getTaskFlow());

        //实时音频webrtc播送
        taskFlowList.add(new RealTimeAudioWebrtcSendTask().getTaskFlow());

        return taskFlowList;
    }
}
